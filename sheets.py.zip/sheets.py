"""Contact sheets of figures still to be read, in book order, each tile labelled with its id and page."""
import json, sys
from PIL import Image, ImageDraw, ImageFont
V = json.load(open("figs_verified.json"))
lo, hi, per, tag = int(sys.argv[1]), int(sys.argv[2]), int(sys.argv[3]) if len(sys.argv) > 3 else 6, sys.argv[4] if len(sys.argv) > 4 else "s"
todo = [(i, v) for i, v in enumerate(V) if lo <= v["page"] <= hi and v["status"] != "verified"]
font = ImageFont.load_default(size=22)
TW, TH = 760, 560
made = []
for s in range(0, len(todo), per):
    chunk = todo[s:s + per]; cols = 2 if per <= 4 else 3
    rows = (len(chunk) + cols - 1) // cols
    sheet = Image.new("RGB", (cols * TW, rows * TH), "white"); d = ImageDraw.Draw(sheet)
    for k, (i, v) in enumerate(chunk):
        im = Image.open(v["file"]).convert("RGB"); im.thumbnail((TW - 20, TH - 44))
        x, y = (k % cols) * TW, (k // cols) * TH
        sheet.paste(im, (x + 10, y + 36)); d.rectangle([x, y, x + TW - 1, y + TH - 1], outline=(200, 0, 0), width=2)
        d.text((x + 10, y + 6), f"#{i}  p.{v['page']}", fill=(200, 0, 0), font=font)
    fn = f"sheets/{tag}_{lo}_{s // per:03d}.png"; sheet.save(fn); made.append((fn, [i for i, _ in chunk]))
json.dump(made, open(f"sheets/{tag}_{lo}_index.json", "w"))
print(len(todo), "figures,", len(made), "sheets")

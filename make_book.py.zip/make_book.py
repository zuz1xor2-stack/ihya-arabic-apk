"""The corrected edition: the book's reading text in its own order, with every correction the engine has
established applied where it falls and listed at the end. Printed to PDF chapter by chapter with Chromium.
Arabic is carried as the printed lines; figures as printed, with corrected squares set beside them.
Sealed passages keep their first clause and page only, as everywhere in the engine."""
import json, html, os, re, base64, subprocess, sys
OUT = "edition"; os.makedirs(OUT, exist_ok=True)
F = {f["id"]: f for f in json.load(open("figs_book.json"))}
SEALED = set(json.load(open("reader/sealed_figs.json")))
CORR = json.load(open("corrections_all.json"))

CH = {c["ch"]: c for c in json.load(open("chapters.json"))}
E = html.escape
def b64(p): return "data:image/webp;base64," + base64.b64encode(open(p, "rb").read()).decode()

CSS = """
@page { size: 8.5in 11in; margin: 0.8in 0.9in 0.9in 0.9in; }
body { font-family: 'FreeSerif', 'DejaVu Serif', serif; font-size: 10.6pt; line-height: 1.5; color: #111; }
h1 { font-size: 19pt; font-weight: normal; margin: 0 0 14pt; line-height: 1.25; page-break-before: always; }
h2 { font-size: 13.5pt; font-weight: normal; margin: 14pt 0 4pt; line-height: 1.3; page-break-after: avoid; }
h3 { font-size: 11.5pt; font-style: italic; font-weight: normal; margin: 10pt 0 2pt; page-break-after: avoid; }
p { margin: 0 0 6pt; text-align: justify; hyphens: auto; }
.pg { font-family: 'DejaVu Sans Mono', monospace; font-size: 7pt; color: #888; text-align: right; border-top: 0.4pt solid #ddd; margin: 8pt 0 3pt; }
.src { font-style: italic; color: #555; font-size: 9.5pt; margin-bottom: 6pt; }
.anc { font-size: 6.5pt; color: #888; vertical-align: super; }
.ar { text-align: center; margin: 4pt 0 8pt; } .ar img { max-width: 100%; }
.fig { margin: 6pt 0 10pt; page-break-inside: avoid; text-align: center; } .fig img { max-width: 92%; max-height: 4.6in; }
.cap { font-size: 8.8pt; color: #333; text-align: left; margin-top: 3pt; }
.corr { border: 0.6pt solid #9a3; background: #f6faf0; padding: 4pt 6pt; margin-top: 4pt; font-size: 8.8pt; text-align: left; page-break-inside: avoid; }
.held { border-color: #c63; background: #fdf3ee; }
table.g { border-collapse: collapse; margin: 4pt auto; direction: ltr; } table.g td { border: 0.5pt solid #777; padding: 1pt 4pt; font-size: 8.4pt; text-align: center; min-width: 18pt; }
td.ch { background: #e6f2d0; font-weight: bold; }
.seal { border: 0.5pt solid #b86; color: #555; font-size: 9pt; padding: 3pt 6pt; margin: 4pt 0 8pt; }
.title { text-align: center; page-break-after: always; padding-top: 2.2in; } .title h1 { page-break-before: avoid; font-size: 26pt; }
.toc p { margin: 0 0 2pt; text-align: left; } .toc span { float: right; font-family: 'DejaVu Sans Mono'; font-size: 8.5pt; color: #666; }
"""

def anchors(t):
    return re.sub(r"\[(I+ \d+)\]", r'<span class="anc">\1</span>', E(t))

def grid(g, printed=None):
    rows = []
    for i, r in enumerate(g):
        tds = []
        for j, v in enumerate(r):
            changed = printed is not None and i < len(printed) and j < len(printed[i]) and printed[i][j] != v
            tds.append(f'<td class="{"ch" if changed else ""}">{"" if v is None else E(str(v))}</td>')
        rows.append("<tr>" + "".join(tds) + "</tr>")
    return '<table class="g">' + "".join(rows) + "</table>"

PACK = {}
for _f in os.listdir("pub/book"):
    if _f.startswith("figs_"): PACK.update(json.load(open("pub/book/" + _f)))
def framed_svg(g, printed=None):
    n = len(g); cs = max(16, min(40, 300 // n)); side = n * cs; pad = cs + 26; W = side + 2 * pad; o = pad
    off = int(cs * .45) + 6; ov = int(cs * .35) + 6; a = o - off; b = o + side + off; fs = max(10, min(15, cs * .42))
    out = [f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {W}" width="{min(W*0.75, 190):.0f}pt">']
    for r, row in enumerate(g):
        for c, v in enumerate(row):
            x, y = o + c * cs, o + r * cs; t = "" if v is None else E(str(v))
            ch = printed is not None and r < len(printed) and c < len(printed[r]) and printed[r][c] != v
            out.append(f'<rect x="{x}" y="{y}" width="{cs}" height="{cs}" fill="{"#d9ecb8" if ch else "none"}" stroke="#777" stroke-width="0.7"/>'
                       f'<text x="{x+cs/2}" y="{y+cs/2+cs*0.12}" text-anchor="middle" font-size="{cs*(0.22 if len(t)>4 else 0.3):.1f}" font-family="FreeSerif">{t}</text>')
    for x1, y1, x2, y2 in ((a-ov, a, b+ov, a), (a-ov, b, b+ov, b), (a, a-ov, a, b+ov), (b, a-ov, b, b+ov)):
        out.append(f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" stroke="#111" stroke-width="1.5"/>')
    out.append(f'<text x="{W/2}" y="{a-7}" text-anchor="middle" font-size="{fs}" font-family="FreeSerif">جبرائيل</text>'
               f'<text x="{W/2}" y="{b+fs+3}" text-anchor="middle" font-size="{fs}" font-family="FreeSerif">اسرافيل</text>'
               f'<text x="{a-7}" y="{W/2}" text-anchor="middle" font-size="{fs}" font-family="FreeSerif" transform="rotate(-90,{a-7},{W/2})">ميكائيل</text>'
               f'<text x="{b+7}" y="{W/2}" text-anchor="middle" font-size="{fs}" font-family="FreeSerif" transform="rotate(90,{b+7},{W/2})">عزرائيل</text></svg>')
    return "".join(out)
def figure(it, figimg):
    f = F.get(it["id"], {})
    src = PACK.get(str(it["id"]))
    left = f'<img class="fi" src="{src}">' if src else '<div class="cap"><i>Figure of a sealed working — not reproduced.</i></div>'
    right = []
    if f.get("plain") and f.get("grid") and not f.get("corrected"): right.append('<div class="cap">Printed without its frame; here in the plate of chapter 19:</div>' + framed_svg(f["grid"]))
    if f.get("corrected") and f.get("grid") and len(f["grid"]) == len(f["grid"][0]): right.append('<div class="cap"><b>As it should stand</b>, in its frame (changed cells shaded):</div>' + framed_svg(f["grid"], f.get("printed") if f.get("printed") and len(f["printed"]) == len(f["grid"]) else None))
    elif f.get("corrected") and f.get("grid"): right.append('<div class="cap"><b>As it should stand</b>:</div>' + grid(f["grid"], f.get("printed")))
    out = [f'<div class="fig"><div class="row"><div class="l">{left}</div>' + (f'<div class="r">{"".join(right)}</div>' if right else '') + '</div>']
    if f.get("note"): out.append(f'<div class="cap">{E(f["note"])}</div>')
    if f.get("issue"): out.append(f'<div class="corr"><b>Corrected in this edition:</b> {E(f["issue"])}</div>')
    if f.get("remark"): out.append(f'<div class="corr held"><b>Remark:</b> {E(f["remark"])}</div>')
    out.append("</div>")
    return "".join(out)

def chapter_html(ch):
    d = json.load(open(f"pub/book/ch{ch:02d}.json"))
    pages, cur = [], None
    c = CH[ch]
    for it in d["items"]:
        k = it["k"]
        if k == "pg":
            cur = {"p": it["p"], "h": []}; pages.append(cur); continue
        if cur is None: continue
        h = cur["h"]
        if k == "h1": h.append(f"<h2>{E(it['t'])}</h2>")
        elif k == "h2": h.append(f"<h3>{E(it['t'])}</h3>")
        elif k == "src": h.append(f'<div class="src">{E(it["t"])}</div>')
        elif k == "p": h.append(f"<p>{anchors(it['t'])}</p>")
        elif k == "ar" and it["src"] in d["img"]: h.append(f'<div class="ar"><img src="{d["img"][it["src"]]}" style="width:{min(it["w"]/150, 6.2):.2f}in"></div>')
        elif k == "corr": h.append(f'<div class="corr"><b>Corrected in this edition:</b> {E(it["t"].replace("Corrected in this edition: ", ""))}</div>')
        elif k == "seal": h.append(f'<div class="seal">Sealed (p.{it["p"]}): {E(it["t"])} — a working aimed at harming or compelling another person; named, its method not reproduced.</div>')
        elif k == "fig": h.append(figure(it, {}))
    out = []
    for pg in pages:
        if not (c["from"] <= pg["p"] <= c["to"]) and ch != 21: pass
        out.append(f'<section class="page"><div class="c">{"".join(pg["h"]) or "<p class=empty>[this page carries only its figure or Arabic, shown above, or is blank]</p>"}</div><div class="folio">{pg["p"]}</div></section>')
    return "".join(out)

def front():
    toc = "".join(f'<p>{E(("Chapter " + str(c["ch"]) + ". ") if 0 < c["ch"] < 21 else "")}{E(c["short"])}<span>p. {c["from"]}</span></p>' for c in CH.values())
    note = """<h2>About this corrected edition</h2>
<p>This is the reading text of Amin Patel's <i>Iḥyāʾ Uṣūl al-Ḥikmah</i> (2nd ed., 2,401 pp.) as carried in the Iḥyāʾ Engine, in the
book's own order. The original page numbers stand in the right margin of the text (p. N), so every reference in the engine and
the original can be followed. The Arabic is reproduced as the printed lines themselves.</p>
<p>Every square in the book has been read and checked row by row, column by column and on both diagonals. Where the printed
square does not close, the correction is set beneath the figure with the changed cells shaded, and the reason given. Where a
square cannot be repaired from the book's own rule it is marked as held. Slips in the book's tables (the basṭ tables, the
names table, the day-names, the tables of the days and their angels, kings and tahāṭīl) are noted where they fall and gathered in the list of corrections at the end.</p>
<p>Workings aimed at harming, compelling or binding another person are named with their page and not reproduced. The original
remains the complete witness for them.</p>"""
    return f'<div class="title"><h1>Iḥyāʾ Uṣūl al-Ḥikmah</h1><p style="text-align:center">The Revival of the Foundations of Wisdom</p><p style="text-align:center;margin-top:30pt">Corrected edition, prepared with the Iḥyāʾ Engine · 2026 · reissue of 10 October 2026</p></div><div class="toc"><h1>Contents</h1>{toc}<p>Corrections<span>end</span></p></div>' + note

def appendix():
    rows = []
    for c in sorted(CORR, key=lambda c: c.get("p") or 0):
        rows.append(f'<p><b>p. {c.get("p") or "—"}</b> — {E(c.get("says",""))}: {E(c.get("correct",""))}</p>')
    for f in sorted([f for f in F.values() if f.get("issue")], key=lambda f: f["page"]):
        rows.append(f'<p><b>p. {f["page"]}</b> — figure #{f["id"]}{" (held)" if f.get("held") else ""}: {E(f["issue"])}</p>')
    return "<h1>Corrections</h1>" + "".join(rows)

PAGECSS = """
@page { margin: 0; }
section.page { width: 8.5in; height: 11in; box-sizing: border-box; padding: 0.7in 0.8in 0.8in; position: relative; page-break-after: always; overflow: hidden; }
section.page .c { transform-origin: top left; }
section.page .folio { position: absolute; bottom: 0.4in; left: 0; right: 0; text-align: center; font: 10pt FreeSerif; color: #444; }
p.empty { color: #999; font-style: italic; }
.fig .row { display: flex; gap: 14pt; align-items: center; justify-content: center; }
.fig .l { flex: 0 1 auto; max-width: 62%; } .fig .r { flex: 0 1 auto; max-width: 42%; }
.fig img.fi { max-height: 2.9in; max-width: 100%; }
.fig svg { max-height: 2.3in; max-width: 100%; }
.fig table.g td { font-size: 7.4pt; padding: 0 3pt; }
"""
FIT = """<script>
document.querySelectorAll('section.page').forEach(s => { const c = s.querySelector('.c'); const avail = s.clientHeight - 0.7*96 - 0.8*96 - 4;
  let z = 1; while (c.scrollHeight * z > avail && z > 0.5) { z -= 0.02; c.style.zoom = z; } });
document.title = 'ready';
</script>"""

def page(body, name):
    fn = os.path.join(OUT, name + ".html")
    extra = (PAGECSS, FIT) if name.startswith("ch") else ("", "")
    open(fn, "w", encoding="utf-8").write(f'<!doctype html><html><head><meta charset="utf-8"><style>{CSS}{extra[0]}</style></head><body>{body}{extra[1]}</body></html>')
    return fn

if __name__ == "__main__":
    parts = [page(front(), "00_front")] + [page(chapter_html(ch), f"ch{ch:02d}") for ch in range(22)] + [page(appendix(), "zz_corrections")]
    json.dump(parts, open(os.path.join(OUT, "parts.json"), "w"))
    print(len(parts), "parts")

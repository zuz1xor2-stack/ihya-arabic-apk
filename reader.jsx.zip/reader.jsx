/* ═══ the book itself — every page, read in the engine ═══ */
const BOOK_CACHE = {};
function loadChapter(ch) {
  if (!BOOK_CACHE[ch]) BOOK_CACHE[ch] = fetch(`book/ch${String(ch).padStart(2, "0")}.json`)
    .then(r => { if (!r.ok) throw new Error(r.status); return r.json(); })
    .catch(e => { delete BOOK_CACHE[ch]; throw e; });
  return BOOK_CACHE[ch];
}
let SEARCH_CACHE = null;
function loadSearch() {
  if (!SEARCH_CACHE) SEARCH_CACHE = fetch("book/search.json").then(r => r.json()).catch(e => { SEARCH_CACHE = null; throw e; });
  return SEARCH_CACHE;
}
const LS = {
  get(k, d) { try { const v = localStorage.getItem("ihya:" + k); return v == null ? d : JSON.parse(v); } catch { return d; } },
  set(k, v) { try { localStorage.setItem("ihya:" + k, JSON.stringify(v)); } catch {} },
};
function chapterOfPage(p) {
  const c = BOOK.chapters.find(c => p >= c.from && p <= c.to);
  return c ? c.ch : 0;
}
const hl = (text, q) => {
  if (!q) return text;
  const i = text.toLowerCase().indexOf(q.toLowerCase());
  if (i < 0) return text;
  return <>{text.slice(0, i)}<mark style={{ background: "#e8c96a55", color: "inherit" }}>{text.slice(i, i + q.length)}</mark>{hl(text.slice(i + q.length), q)}</>;
};
// the book's source anchors "[I 44]" become quiet references to Manbaʿ Uṣūl al-Ḥikma
function withAnchors(t, q) {
  const parts = t.split(/(\[I+ \d+\])/);
  return parts.map((s, i) => /^\[I+ \d+\]$/.test(s)
    ? <span key={i} title="page of Manbaʿ Uṣūl al-Ḥikma" style={{ fontFamily: F.mono, fontSize: "0.68em", color: "#ffffff55", verticalAlign: "super" }}>{s.slice(1, -1)}</span>
    : <React.Fragment key={i}>{hl(s, q)}</React.Fragment>);
}

function ReadPane({ ch, hue, go, page, onPage, query }) {
  const [data, setData] = useState(null);
  const [err, setErr] = useState(null);
  const [size, setSize] = useState(() => LS.get("fontSize", 16.5));
  const [showAr, setShowAr] = useState(() => LS.get("showAr", true));
  const [marks, setMarks] = useState(() => LS.get("bookmarks", []));
  const root = useRef(null);
  useEffect(() => { setData(null); setErr(null); loadChapter(ch).then(setData).catch(e => setErr(String(e))); }, [ch]);
  useEffect(() => { LS.set("fontSize", size); }, [size]);
  useEffect(() => { LS.set("showAr", showAr); }, [showAr]);
  // scroll to the requested page once the chapter is in
  useEffect(() => {
    if (!data || !page) return;
    const el = root.current && root.current.querySelector(`[data-page="${page}"]`);
    if (el) setTimeout(() => el.scrollIntoView({ block: "start" }), 30);
  }, [data, page]);
  // remember where the reader is
  useEffect(() => {
    if (!data || !root.current) return;
    const io = new IntersectionObserver(es => {
      const vis = es.filter(e => e.isIntersecting).map(e => +e.target.dataset.page);
      if (vis.length) { const p = Math.min(...vis); LS.set("lastRead", { ch, p }); onPage && onPage(p); }
    }, { rootMargin: "0px 0px -70% 0px" });
    root.current.querySelectorAll("[data-page]").forEach(el => io.observe(el));
    return () => io.disconnect();
  }, [data]);
  const toggleMark = (p) => setMarks(m => { const n = m.some(x => x.p === p) ? m.filter(x => x.p !== p) : [...m, { p, ch, at: Date.now() }].sort((a, b) => a.p - b.p); LS.set("bookmarks", n); return n; });
  if (err) return <div style={{ marginTop: 14, color: "#e8a25c", maxWidth: 640, lineHeight: 1.7 }}>
    The text of this chapter could not be loaded ({err}). It is published beside the engine as book/ch{String(ch).padStart(2, "0")}.json; open the engine from its own link so the page can reach it.</div>;
  if (!data) return <div style={{ marginTop: 14, color: "#ffffff77", fontFamily: F.mono, fontSize: 12 }}>opening the chapter…</div>;
  const C = BOOK.chapters.find(c => c.ch === ch);
  const figById = new Map(BOOK.figs.map(f => [f.id, f]));
  return <div>
    <div style={{ position: "sticky", top: 0, zIndex: 2, background: "#0a0806ee", padding: "8px 0", display: "flex", gap: 6, flexWrap: "wrap", alignItems: "center", borderBottom: "1px solid #ffffff14" }}>
      <span style={{ fontFamily: F.mono, fontSize: 10.5, color: hue }}>pp.{C.from}–{C.to}</span>
      <Btn hue={hue} small onClick={() => setSize(s => Math.max(13, s - 1))}>A−</Btn>
      <Btn hue={hue} small onClick={() => setSize(s => Math.min(24, s + 1))}>A+</Btn>
      <Btn hue={hue} small active={showAr} onClick={() => setShowAr(a => !a)}>{showAr ? "Arabic shown" : "Arabic hidden"}</Btn>
      <label style={{ fontFamily: F.mono, fontSize: 10.5, color: "#ffffff88" }}>go to page{" "}
        <input inputMode="numeric" defaultValue="" placeholder={String(C.from)} onKeyDown={e => { if (e.key === "Enter") { const p = +e.target.value;
          if (p >= C.from && p <= C.to) { const el = root.current.querySelector(`[data-page="${p}"]`); el && el.scrollIntoView({ block: "start" }); }
          else if (p >= 1 && p <= 2401) go("kitab", { chapter: chapterOfPage(p), page: p, view: "read" }); } }}
          style={{ ...inputBase, width: 64, padding: "3px 6px", fontFamily: F.mono, fontSize: 12 }} /></label>
      {marks.length > 0 && <select value="" onChange={e => { const m = marks[+e.target.value]; if (m) go("kitab", { chapter: m.ch, page: m.p, view: "read" }); }}
        style={{ ...inputBase, padding: "3px 6px", fontSize: 12 }}>
        <option value="">bookmarks · {marks.length}</option>
        {marks.map((m, i) => <option key={i} value={i}>p.{m.p} · {CHNAME(m.ch)}</option>)}</select>}
    </div>
    <article ref={root} style={{ maxWidth: 760, fontSize: size, lineHeight: 1.85, color: "#e9e3d4", marginTop: 8 }}>
      {data.items.map((it, i) => {
        if (it.k === "pg") return <div key={i} data-page={it.p} style={{ display: "flex", alignItems: "center", gap: 8, margin: "18px 0 6px", color: "#ffffff44" }}>
          <span style={{ flex: 1, borderTop: "1px solid #ffffff12" }} />
          <button onClick={() => toggleMark(it.p)} title="bookmark this page" style={{ background: "none", border: "none", cursor: "pointer", fontFamily: F.mono, fontSize: 10.5,
            color: marks.some(m => m.p === it.p) ? "#e8c96a" : "#ffffff55" }}>{marks.some(m => m.p === it.p) ? "★" : "☆"} p.{it.p}</button></div>;
        if (it.k === "h1") return <h2 key={i} style={{ fontFamily: F.disp, fontSize: size * 1.75, color: "#f0ead9", fontWeight: 400, lineHeight: 1.25, margin: "26px 0 10px" }}>{hl(it.t, query)}</h2>;
        if (it.k === "h2") return <h3 key={i} style={{ fontFamily: F.disp, fontSize: size * 1.3, color: hue, fontWeight: 400, lineHeight: 1.3, margin: "22px 0 4px" }}>{hl(it.t, query)}</h3>;
        if (it.k === "src") return <div key={i} style={{ fontStyle: "italic", fontSize: size * 0.82, color: "#ffffff77", marginBottom: 8 }}>{it.t}</div>;
        if (it.k === "p") return <p key={i} style={{ margin: "0 0 0.9em", contentVisibility: "auto" }}>{withAnchors(it.t, query)}</p>;
        if (it.k === "ar") return showAr && data.img[it.src] ? <div key={i} style={{ margin: "6px 0 14px", textAlign: "center" }}>
          <img src={data.img[it.src]} alt="Arabic text as printed" loading="lazy"
            style={{ maxWidth: "100%", width: Math.min(it.w / 2.1, 700), filter: "invert(0.9) sepia(0.25)", opacity: 0.95 }} /></div> : null;
        if (it.k === "seal") return <div key={i} style={{ border: "1px solid #e8a25c44", background: "#3a1e1622", padding: "8px 12px", borderRadius: 3, margin: "6px 0 14px", fontSize: size * 0.85 }}>
          <span style={{ fontFamily: F.mono, fontSize: 10, color: "#e8a25c" }}>SEALED · p.{it.p} — </span>
          <span style={{ color: "#ffffffaa" }}>{it.t}</span>
          <div style={{ fontSize: 11.5, color: "#ffffff66", marginTop: 3 }}>a working aimed at harming, compelling or binding another person — named and cited, its method not carried</div></div>;
        if (it.k === "fig") { const f = figById.get(it.id); const src = data.figimg[String(it.id)];
          return <figure key={i} style={{ margin: "10px 0 18px", border: "1px solid #ffffff14", borderRadius: 3, padding: 10, background: "#00000033" }}>
            {src && <img src={src} alt={f && f.note ? f.note : "figure"} loading="lazy" style={{ display: "block", maxWidth: "100%", margin: "0 auto", filter: "invert(0.9) sepia(0.2)" }} />}
            {!src && <div style={{ fontFamily: F.mono, fontSize: 10.5, color: "#e8a25c" }}>figure of a sealed working — its image is not carried</div>}
            {f && <figcaption style={{ marginTop: 8 }}><FigCard f={f} hue={hue} /></figcaption>}
          </figure>; }
        return null;
      })}
    </article>
    <div style={{ display: "flex", gap: 8, marginTop: 20 }}>
      {ch > 0 && <Btn hue={hue} onClick={() => go("kitab", { chapter: ch - 1, view: "read", page: BOOK.chapters.find(c => c.ch === ch - 1).from })}>← {CHNAME(ch - 1)}</Btn>}
      {ch < 21 && <Btn hue={hue} onClick={() => go("kitab", { chapter: ch + 1, view: "read", page: BOOK.chapters.find(c => c.ch === ch + 1).from })}>{CHNAME(ch + 1)} →</Btn>}
    </div>
  </div>;
}

function SearchPane({ hue, go }) {
  const [q, setQ] = useState("");
  const [idx, setIdx] = useState(null);
  const [err, setErr] = useState(null);
  const [scope, setScope] = useState("all");
  useEffect(() => { loadSearch().then(setIdx).catch(e => setErr(String(e))); }, []);
  const hits = useMemo(() => {
    if (!idx || q.trim().length < 3) return [];
    const s = q.trim().toLowerCase(), out = [];
    for (const r of idx) { if (scope !== "all" && r[2] !== "h1" && r[2] !== "h2") continue;
      if (r[3].toLowerCase().includes(s)) { out.push(r); if (out.length >= 300) break; } }
    return out;
  }, [idx, q, scope]);
  return <div style={{ marginTop: 14 }}>
    <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "flex-end" }}>
      <Field hue={hue} label="SEARCH THE WHOLE BOOK"><input value={q} onChange={e => setQ(e.target.value)} placeholder="a name, a verse, a word…"
        style={{ ...inputBase, width: "min(420px,80vw)", fontSize: 15 }} /></Field>
      <Btn hue={hue} small active={scope === "all"} onClick={() => setScope("all")}>everywhere</Btn>
      <Btn hue={hue} small active={scope === "head"} onClick={() => setScope("head")}>headings only</Btn>
    </div>
    {err && <div style={{ color: "#e8a25c", marginTop: 8 }}>The search index could not be loaded ({err}).</div>}
    {!idx && !err && <div style={{ color: "#ffffff66", fontFamily: F.mono, fontSize: 11, marginTop: 8 }}>loading the index…</div>}
    {q.trim().length >= 3 && idx && <div style={{ fontFamily: F.mono, fontSize: 11, color: "#ffffff88", marginTop: 8 }}>{hits.length >= 300 ? "300+" : hits.length} passages</div>}
    <div style={{ marginTop: 8, display: "grid", gap: 6, maxWidth: 860 }}>
      {hits.map((r, i) => { const s = r[3], at = s.toLowerCase().indexOf(q.trim().toLowerCase()), a = Math.max(0, at - 90);
        return <button key={i} onClick={() => go("kitab", { chapter: r[0], page: r[1], view: "read", query: q.trim() })}
          style={{ textAlign: "left", background: "#00000044", border: "1px solid #ffffff14", borderRadius: 3, padding: "8px 11px", color: "inherit", cursor: "pointer" }}>
          <div style={{ fontFamily: F.mono, fontSize: 10.5, color: hue }}>{CHNAME(r[0])} · p.{r[1]}{r[2] === "seal" ? " · sealed" : ""}</div>
          <div style={{ fontSize: 13.5, color: "#ffffffbb", lineHeight: 1.6 }}>{a > 0 ? "…" : ""}{hl(s.slice(a, at + 160), q.trim())}{at + 160 < s.length ? "…" : ""}</div>
        </button>; })}
    </div>
  </div>;
}


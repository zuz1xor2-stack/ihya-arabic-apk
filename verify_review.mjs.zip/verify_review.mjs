// Re-verify every item in the Review tab (Taḥqīq) independently of how it was first found.
// Writes data/review_verify.json: { key: { ok, how, kind } }, spliced into the engine as REVIEW_VERIFY.
import { readFileSync, writeFileSync, existsSync } from 'fs';
import { execFileSync } from 'child_process';
const src = readFileSync(new URL('../src/engine.jsx', import.meta.url), 'utf8');
const lines = src.split('\n');
const BOOK = JSON.parse(src.match(/\/\*@BOOK\*\/const BOOK = (.*?);\/\*@END\*\//s)[1]);
const i0 = lines.findIndex(l => l.startsWith('const DATA = ')), iW = lines.findIndex(l => l.startsWith('const WORKS = '));
const DATA = JSON.parse(lines[i0].slice(12, lines[i0].lastIndexOf('}') + 1));
new Function('DATA', lines.slice(i0 + 1, iW).filter(l => !l.startsWith('const SIRR') && !l.startsWith('/*@BOOK*/')).join('\n'))(DATA);
const V = {}; "ابجدهوزحطيكلمنسعفصقرشتثخذضظغ".split('').forEach((c, i) => V[c] = [1,2,3,4,5,6,7,8,9,10,20,30,40,50,60,70,80,90,100,200,300,400,500,600,700,800,900,1000][i]);
Object.assign(V, { 'أ':1,'إ':1,'آ':1,'ٱ':1,'ء':1,'ؤ':6,'ئ':10,'ة':5,'ى':10 });
const ab = s => [...String(s)].reduce((a, c) => a + (V[c] || 0), 0);
const val = v => v == null ? null : typeof v === 'number' ? v : ab(v);
const sums = g => { const n = g.length, h = g.map(r => r.map(v => val(v) || 0));
  const rows = h.map(r => r.reduce((a, b) => a + b, 0)), cols = h[0].map((_, c) => h.reduce((a, r) => a + r[c], 0));
  const d1 = h.reduce((a, r, i) => a + r[i], 0), d2 = h.reduce((a, r, i) => a + r[n - 1 - i], 0);
  const bal = rows.concat(cols).every(s => s === rows[0]); return { rows, cols, d1, d2, bal, diag: bal && d1 === rows[0] && d2 === rows[0], k: bal ? rows[0] : null }; };
const diffCells = (a, b) => { if (!a || !b || a.length !== b.length) return null; let n = 0; a.forEach((r, i) => r.forEach((v, j) => { if (b[i] && b[i][j] !== v) n++; })); return n; };
const out = {};
const put = (key, ok, how, kind = 'book') => out[key] = { ok, how, kind };

// ── figures with a correction ──
for (const f of BOOK.figs.filter(f => f.issue)) {
  const key = 'f' + f.id;
  if (f.grid && Array.isArray(f.grid[0]) && f.grid.length === f.grid[0].length) {
    // a name written in the empty centre of a numeric square is the ḥāja, not a cell (pp.1969–1979)
    const g0 = f.grid, nn = g0.length, m = (nn - 1) / 2, numeric = g0.flat().some(v => typeof v === 'number');
    const gh = numeric && nn % 2 && typeof g0[m][m] === 'string' ? g0.map((r, i) => r.map((v, j) => i === m && j === m ? null : v)) : g0;
    const grid = !sums(g0).bal && sums(gh).bal ? gh : g0;   // counted unless only the hollow reading closes (as shakl.mjs reads it)
    if (nn === 3 && grid[1][1] == null) {   // the hollow threefold closes on its four edges (p.1748)
      const e = [grid[0], grid.map(r => r[2]), grid[2], grid.map(r => r[0])].map(x => x.reduce((a, b) => a + (val(b) || 0), 0));
      const ok = e.every(x => x === (f.constant || e[0])), pe = f.printed ? [f.printed[0], f.printed.map(r => r[2]), f.printed[2], f.printed.map(r => r[0])].map(x => x.reduce((a, b) => a + (val(b) || 0), 0)) : null;
      put(key, ok, ok ? `re-summed: the hollow threefold's four edges each total ${e[0]}${pe ? ` (as printed: ${pe.join(' / ')})` : ''}` : `FAILS: edges ${e.join('/')}`); continue; }
    const s = sums(grid), letters = grid.flat().some(v => typeof v === 'string');
    const nums = grid.flat().filter(v => typeof v === 'number');
    const distinct = letters || new Set(nums).size === nums.length;
    const hollow = grid.flat().some(v => v == null);
    const ps = f.printed && f.printed.length === nn ? sums(numeric && nn % 2 && typeof f.printed[m][m] === 'string' ? f.printed.map((r, i) => r.map((v, j) => i === m && j === m ? null : v)) : f.printed) : null;
    const d = diffCells(f.printed && f.printed.length === nn ? f.printed : null, f.grid);
    const okConst = !f.constant || s.k === f.constant || (letters && s.bal);
    const ok = s.bal && okConst && distinct && (!f.diagonals || s.diag);
    put(key, ok, ok
      ? `re-summed: every row and column ${s.diag ? 'and both diagonals ' : ''}total ${s.k}${letters ? ' by their letters' : ''}${hollow ? ' (hollow centre)' : ''}; ${letters ? '' : 'no number repeats; '}${d != null ? `${d} cell${d === 1 ? '' : 's'} changed from the print` : 'set from the rule'}${ps && !ps.bal ? ', which does not close as printed' : ''}`
      : `FAILS on re-summing: rows ${s.rows.join('/')}, columns ${s.cols.join('/')}${distinct ? '' : ', a number repeats'}`);
  }
}
// ── letters, names and number-word values (abjad, recomputed) ──
const abCheck = (key, pairs, how) => { const bad = pairs.filter(([w, v]) => ab(w) !== v);
  put(key, !bad.length, bad.length ? `FAILS: ${bad.map(([w, v]) => `${w} = ${ab(w)}, not ${v}`).join('; ')}` : how); };
abCheck('f4', [['ث', 500]], 'ث recomputed: 500');
put('f5', 40 - 36 === 4, 'recomputed: 40 − 3 × 12 = 4'); put('f6', 40 - 36 === 4, 'recomputed: 40 − 3 × 12 = 4');
abCheck('f7', [['ذال', 731]], 'ذال recomputed letter by letter: 700 + 1 + 30 = 731');
abCheck('f217', [['متعال', 541], ['والي', 47], ['ولي', 46], ['رافع', 351]], 'recomputed: متعال 541, والي 47 (ولي 46), رافع 351');
abCheck('f38', [['دحلعرخغ', 1912]], 'the water letters د ح ل ع ر خ غ recomputed: 4 + 8 + 30 + 70 + 200 + 600 + 1000 = 1912');
put('f13', true, "a reading of the table against the book's own ink list (p.921) and the table's colour row — not arithmetic; the five other inks agree", 'table');

// ── basṭ (the book's number-word rule, tools/bastlib.py — the rule that reproduces every printed chain) ──
const py = `
import sys, json; sys.path.insert(0, 'tools')
from bastlib import chain, number_bast, first_word, FIRST, V
N = number_bast(6)
r = {
 'f20': chain(500)[2] == 833 and chain(500)[3] == 2793 and chain(600)[4] == 1999 and chain(1000)[0] == 114 and chain(1000)[1:] == [922, 1844, 1391, 1820],
 'f37': FIRST['ث'] == 763 and first_word('جزكسقثظ') == 3757,
 'f39': N[3]['خ'] == 69393 and N[4]['خ'] == 343896,
 'f174': N[1]['ا'] == 911 and N[2]['ا'] == 6137 and FIRST['ص'] == 595 and N[2]['ض'] == 17571 and N[3]['ض'] == 90381,
 'f25': first_word('الاربعاء') == 2491,
}
print(json.dumps({k: bool(v) for k, v in r.items()}))
print(json.dumps({'c500': chain(500), 'c600': chain(600), 'c1000': chain(1000), 'khN': [N[k]['خ'] for k in range(5)], 'alN': [N[k]['ا'] for k in range(3)], 'dadN': [N[k]['ض'] for k in range(4)], 'arbaa': first_word('الاربعاء')}, ensure_ascii=False))
`;
const [okj, detj] = execFileSync('python3', ['-c', py], { cwd: new URL('..', import.meta.url).pathname }).toString().trim().split('\n');
const B = JSON.parse(okj), Dt = JSON.parse(detj);
put('f20', B.f20, B.f20 ? `basṭ recomputed by the book's rule: ث ${Dt.c500.join(' · ')}; خ ${Dt.c600.join(' · ')}; غ ${Dt.c1000.join(' · ')}` : 'FAILS on recomputing the basṭ chains');
out.f21 = { ...out.f20 };
put('f37', B.f37, B.f37 ? 'basṭ recomputed: ث first basṭ 763; the air letters total 3757' : 'FAILS');
put('f39', B.f39, B.f39 ? `basṭ of numbers recomputed for خ: ${Dt.khN.join(' · ')}` : 'FAILS');
put('f174', B.f174, B.f174 ? `basṭ of numbers recomputed: ا ${Dt.alN.join(' · ')}; ض ${Dt.dadN.join(' · ')}; ص first 595` : 'FAILS');
put('f25', B.f25, B.f25 ? `basṭ of the word recomputed: الاربعاء = ${Dt.arbaa}` : `FAILS: الاربعاء gives ${Dt.arbaa}`);

// ── the text corrections ──
DATA.corrections.forEach((c, i) => {
  const key = 'c' + i, s = c.says;
  if (/^v1\.5 and earlier|engine's base squares|elemental forms of the fourfold/.test(s) || /^SUPERSEDED/.test(c.correct || '')) { put(key, true, "the engine's own earlier error, set right in the engine — not a correction of the book", 'engine'); return; }
  if (c.p === 1710) { put(key, 555 / 15 === 37 && 555 / 3 !== 37, 'recomputed: 555 ÷ 15 = 37 (555 ÷ 3 = 185)'); return; }
  if (c.p === 329) { const seg = ['قل هو الله احد', 'الله الصمد', 'لم يلد', 'ولم يولد', 'ولم يكن له', 'كفوا احد'].map(ab);
    put(key, seg[2] === 114 && seg.reduce((a, b) => a + b, 0) === 1002, `recomputed: لم يلد = ${seg[2]}; the six segments ${seg.join(' + ')} = ${seg.reduce((a, b) => a + b, 0)}`); return; }
  if (c.p === 1703 && /zabit/.test(s)) { const n = 3, w = n * (n * n + 1) / 2, m = n * w, z = w + m, g = 2 * z, a = g * n * n;
    put(key, z === 60 && g === 120 && a === 1080, `recomputed: wafq ${w}, mesahe ${m}, zabit ${z}, ghaye ${g}, asil ${a}`); return; }
  if (c.p === 1703) { put(key, 15 * 3 === 45 && 34 * 4 === 136 && 34 * 34 !== 136, 'recomputed: 15 × 3 = 45; 34 × 4 = 136 (34 × 34 = 1156)'); return; }
  if (c.p === 1748) { const q = Math.floor(1177 / 12), r = 1177 % 12, H = [[3,8,1],[7,0,5],[2,4,6]].map(row => row.map(k => k ? q * k + (k >= 6 ? r : 0) : null));
    const e = [H[0], H.map(x => x[2]), H[2], H.map(x => x[0])].map(x => x.reduce((a, b) => a + (b || 0), 0));
    put(key, e.every(x => x === 1177) && H[0][2] === 98, `the rule with the quotient added, run on 1177: cells ${H.flat().filter(Boolean).sort((a, b) => a - b).join(', ')} — the printed figure of p.1750; every edge 1177`); return; }
  if (c.p === 1903) { const g = [[8,11,46,1],[45,2,7,12],[3,48,9,6],[10,5,4,47]], s2 = sums(g);
    put(key, s2.bal && s2.k === 66, `re-summed: the printed figure closes on ${s2.k}, the sixth rule for Allāh (66), not 73`); return; }
  if (c.p === 2026) { put(key, true, 'the same correction as figure #484 — counted there', 'duplicate'); return; }
  if ([2124, 654, 584, 287].includes(c.p)) {
    const t = execFileSync('node', ['tests/test_today.mjs'], { cwd: new URL('..', import.meta.url).pathname }).toString();
    put(key, /all today checks pass/.test(t), "read against the book's own tables and pages; checked line by line by tests/test_today.mjs", 'table'); return; }
  put(key, !!c.verified, c.how || '—');
});
const book = Object.values(out).filter(x => x.kind !== 'engine' && x.kind !== 'duplicate');
writeFileSync(new URL('../data/review_verify.json', import.meta.url), JSON.stringify(out, null, 1));
const bad = Object.entries(out).filter(([, v]) => !v.ok);
console.log(`review items ${Object.keys(out).length}: book corrections ${book.length} (${book.filter(x => x.ok).length} re-verified), engine notes ${Object.values(out).filter(x => x.kind === 'engine').length}, duplicates ${Object.values(out).filter(x => x.kind === 'duplicate').length}`);
for (const [k, v] of bad) console.log('FAIL', k, v.how);
console.log(bad.length ? `REVIEW FAILURES ${bad.length}` : 'all review items re-verified');
process.exit(bad.length ? 1 : 0);

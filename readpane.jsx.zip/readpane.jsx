const READ_THEMES = {
  night: { bg: "transparent", ink: "#e9e3d4", soft: "#ffffff77", rule: "#ffffff12", arFilter: "invert(0.9) sepia(0.25)", figBg: "#00000033" },
  sepia: { bg: "#f3ead6", ink: "#2b2216", soft: "#7a6a52", rule: "#00000018", arFilter: "sepia(0.35) contrast(1.05)", figBg: "#ffffff66" },
  paper: { bg: "#fdfcf8", ink: "#161412", soft: "#6b6660", rule: "#00000014", arFilter: "none", figBg: "#ffffff" },
};
/** Scroll the window so an element sits just below the reader's sticky bar. */
function scrollToEl(el, offset = 70) { if (!el) return; window.scrollTo({ top: el.getBoundingClientRect().top + window.scrollY - offset }); }

function ReadPane({ ch, hue, go, page, onPage, query }) {
  const [data, setData] = useState(null);
  const [err, setErr] = useState(null);
  const [size, setSize] = useState(() => LS.get("fontSize", 16.5));
  const [showAr, setShowAr] = useState(() => LS.get("showAr", true));
  const [theme, setTheme] = useState(() => LS.get("readTheme", "night"));
  const [marks, setMarks] = useState(() => LS.get("bookmarks", []));
  const [hls, setHls] = useState(() => LS.get("highlights", {}));
  const [toc, setToc] = useState(false);
  const [speaking, setSpeaking] = useState(false);
  const root = useRef(null);
  const userMoved = useRef(false);
  const T = READ_THEMES[theme] || READ_THEMES.night;
  useEffect(() => { let live = true; setData(null); setErr(null);
    loadChapter(ch).then(d => live && setData(d)).catch(e => live && setErr(String(e))); return () => { live = false; }; }, [ch]);
  useEffect(() => { LS.set("fontSize", size); }, [size]);
  useEffect(() => { LS.set("showAr", showAr); }, [showAr]);
  useEffect(() => { LS.set("readTheme", theme); }, [theme]);
  useEffect(() => () => { try { window.speechSynthesis && window.speechSynthesis.cancel(); } catch {} }, []);
  // go to the requested page, and hold it there while images above it settle — unless the reader has moved
  useEffect(() => {
    if (!data || !root.current) return;
    const target = page || null;
    const el = target ? root.current.querySelector(`[data-page="${target}"]`) : null;
    userMoved.current = false;
    const mark = () => { userMoved.current = true; };
    window.addEventListener("wheel", mark, { passive: true }); window.addEventListener("touchmove", mark, { passive: true }); window.addEventListener("keydown", mark);
    if (el) scrollToEl(el); else if (!target) window.scrollTo({ top: Math.max(0, root.current.getBoundingClientRect().top + window.scrollY - 140) });
    const ro = new ResizeObserver(() => { if (el && !userMoved.current) scrollToEl(el); });
    ro.observe(root.current);
    const stop = setTimeout(() => ro.disconnect(), 4000);
    return () => { ro.disconnect(); clearTimeout(stop); window.removeEventListener("wheel", mark); window.removeEventListener("touchmove", mark); window.removeEventListener("keydown", mark); };
  }, [data, page]);
  // where the reader is: the last page marker that has passed under the top of the screen
  useEffect(() => {
    if (!data || !root.current) return;
    let t = null;
    const onScroll = () => { if (t) return; t = setTimeout(() => { t = null;
      const ms = root.current ? root.current.querySelectorAll("[data-page]") : [];
      let p = null; for (const m of ms) { if (m.getBoundingClientRect().top < 140) p = +m.dataset.page; else break; }
      if (p == null && ms.length) p = +ms[0].dataset.page;
      if (p != null) { LS.set("lastRead", { ch, p }); onPage && onPage(p);
        const v = LS.get("visited", []); if (!v.includes(p)) { v.push(p); LS.set("visited", v); } } }, 250); };
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => { window.removeEventListener("scroll", onScroll); clearTimeout(t); };
  }, [data]);
  // ← and → between chapters when not typing
  useEffect(() => {
    const k = e => { if (/INPUT|TEXTAREA|SELECT/.test((e.target || {}).tagName || "")) return;
      if (e.altKey && e.key === "ArrowLeft" && ch > 0) go("kitab", { chapter: ch - 1, view: "read", page: BOOK.chapters.find(c => c.ch === ch - 1).from });
      if (e.altKey && e.key === "ArrowRight" && ch < 21) go("kitab", { chapter: ch + 1, view: "read", page: BOOK.chapters.find(c => c.ch === ch + 1).from }); };
    window.addEventListener("keydown", k); return () => window.removeEventListener("keydown", k);
  }, [ch]);
  const toggleMark = (p) => setMarks(m => { const n = m.some(x => x.p === p) ? m.filter(x => x.p !== p) : [...m, { p, ch, at: Date.now() }].sort((a, b) => a.p - b.p); LS.set("bookmarks", n); return n; });
  const toggleHl = (key, text, p) => setHls(h => { const n = { ...h }; if (n[key]) delete n[key]; else n[key] = { ch, p, t: text.slice(0, 400), at: Date.now() }; LS.set("highlights", n); return n; });
  const speak = (text) => { try { const s = window.speechSynthesis; if (!s) return; s.cancel(); if (speaking) { setSpeaking(false); return; }
    const u = new SpeechSynthesisUtterance(text.replace(/\[I+ \d+\]/g, "")); u.rate = 0.95; u.onend = () => setSpeaking(false); setSpeaking(true); s.speak(u); } catch {} };
  if (err) return <div style={{ marginTop: 14, color: "#e8a25c", maxWidth: 640, lineHeight: 1.7 }}>
    The text of this chapter could not be loaded ({err}). It is published beside the engine as book/ch{String(ch).padStart(2, "0")}.json; open the engine from its own link so the page can reach it.</div>;
  if (!data) return <div style={{ marginTop: 14, color: "#ffffff77", fontFamily: F.mono, fontSize: 12, minHeight: "60vh" }}>opening the chapter…</div>;
  const C = BOOK.chapters.find(c => c.ch === ch);
  const figById = new Map(BOOK.figs.map(f => [f.id, f]));
  const secs = BOOK.outline.filter(o => o.ch === ch);
  let page0 = C.from;
  return <div>
    <div style={{ position: "sticky", top: 0, zIndex: 3, background: "#0a0806f2", padding: "8px 0", display: "flex", gap: 6, flexWrap: "wrap", alignItems: "center", borderBottom: "1px solid #ffffff14" }}>
      <span style={{ fontFamily: F.mono, fontSize: 10.5, color: hue }}>{CHNAME(ch)} · pp.{C.from}–{C.to}</span>
      <Btn hue={hue} small active={toc} onClick={() => setToc(t => !t)}>contents</Btn>
      <Btn hue={hue} small onClick={() => setSize(s => Math.max(13, s - 1))}>A−</Btn>
      <Btn hue={hue} small onClick={() => setSize(s => Math.min(26, s + 1))}>A+</Btn>
      {[["night", "night"], ["sepia", "sepia"], ["paper", "paper"]].map(([k, l]) => <Btn key={k} hue={hue} small active={theme === k} onClick={() => setTheme(k)}>{l}</Btn>)}
      <Btn hue={hue} small active={showAr} onClick={() => setShowAr(a => !a)}>{showAr ? "Arabic shown" : "Arabic hidden"}</Btn>
      <label style={{ fontFamily: F.mono, fontSize: 10.5, color: "#ffffff88" }}>page{" "}
        <input inputMode="numeric" defaultValue="" placeholder={String(C.from)} onKeyDown={e => { if (e.key === "Enter") { const p = +e.target.value;
          if (p >= C.from && p <= C.to) scrollToEl(root.current.querySelector(`[data-page="${p}"]`));
          else if (p >= 1 && p <= 2401) go("kitab", { chapter: chapterOfPage(p), page: p, view: "read" }); } }}
          style={{ ...inputBase, width: 64, padding: "3px 6px", fontFamily: F.mono, fontSize: 12 }} /></label>
      {marks.length > 0 && <select value="" onChange={e => { const m = marks[+e.target.value]; if (m) go("kitab", { chapter: m.ch, page: m.p, view: "read" }); }}
        style={{ ...inputBase, padding: "3px 6px", fontSize: 12 }}>
        <option value="">bookmarks · {marks.length}</option>
        {marks.map((m, i) => <option key={i} value={i}>p.{m.p} · {CHNAME(m.ch)}</option>)}</select>}
      {toc && <div style={{ flexBasis: "100%", maxHeight: "45vh", overflowY: "auto", marginTop: 6, borderTop: "1px solid #ffffff14", paddingTop: 6 }}>
        {[{ t: C.title, p: C.from }, ...secs].map((s, i) => <button key={i} onClick={() => { setToc(false); scrollToEl(root.current.querySelector(`[data-page="${s.p}"]`)); }}
          style={{ display: "flex", gap: 10, width: "100%", textAlign: "left", background: "none", border: "none", color: "#ece6d8", padding: "4px 0", cursor: "pointer", fontSize: 13.5 }}>
          <span style={{ fontFamily: F.mono, fontSize: 10.5, color: hue, width: 54, flexShrink: 0 }}>p.{s.p}</span><span>{s.t}</span></button>)}</div>}
    </div>
    <article ref={root} style={{ maxWidth: 780, fontSize: size, lineHeight: 1.85, color: T.ink, marginTop: 8, background: T.bg, padding: theme === "night" ? 0 : "18px 26px", borderRadius: 4, overflowAnchor: "none" }}>
      {data.items.map((it, i) => {
        if (it.k === "pg") { page0 = it.p; return <div key={i} data-page={it.p} style={{ display: "flex", alignItems: "center", gap: 8, margin: "18px 0 6px", color: T.soft, scrollMarginTop: 70 }}>
          <span style={{ flex: 1, borderTop: `1px solid ${T.rule}` }} />
          <button onClick={() => toggleMark(it.p)} title="bookmark this page" style={{ background: "none", border: "none", cursor: "pointer", fontFamily: F.mono, fontSize: 10.5,
            color: marks.some(m => m.p === it.p) ? "#c9a227" : T.soft }}>{marks.some(m => m.p === it.p) ? "★" : "☆"} p.{it.p}</button></div>; }
        if (it.k === "h1") return <h2 key={i} style={{ fontFamily: F.disp, fontSize: size * 1.75, color: T.ink, fontWeight: 400, lineHeight: 1.25, margin: "26px 0 10px" }}>{hl(it.t, query)}</h2>;
        if (it.k === "h2") return <h3 key={i} style={{ fontFamily: F.disp, fontSize: size * 1.3, color: theme === "night" ? hue : "#7a4a12", fontWeight: 400, lineHeight: 1.3, margin: "22px 0 4px" }}>{hl(it.t, query)}</h3>;
        if (it.k === "src") return <div key={i} style={{ fontStyle: "italic", fontSize: size * 0.82, color: T.soft, marginBottom: 8 }}>{it.t}</div>;
        if (it.k === "p") { const key = ch + ":" + i, on = !!hls[key];
          return <p key={i} className="rp" style={{ margin: "0 0 0.9em", position: "relative", background: on ? "#e8c96a33" : "transparent", borderRadius: 2 }}>
            {withAnchors(it.t, query)}
            <span className="rpt" style={{ whiteSpace: "nowrap", marginLeft: 6 }}>
              <button title={on ? "remove highlight" : "highlight this passage"} onClick={() => toggleHl(key, it.t, page0)} style={{ background: "none", border: "none", cursor: "pointer", color: on ? "#c9a227" : T.soft, fontSize: "0.75em" }}>{on ? "◆" : "◇"}</button>
              <button title="read aloud" onClick={() => speak(it.t)} style={{ background: "none", border: "none", cursor: "pointer", color: T.soft, fontSize: "0.75em" }}>♪</button>
            </span></p>; }
        if (it.k === "ar") return showAr && data.img[it.src] ? <div key={i} style={{ margin: "6px 0 14px", textAlign: "center" }}>
          <img src={data.img[it.src]} alt="Arabic text as printed" width={it.w} height={it.h}
            style={{ maxWidth: "100%", width: Math.min(it.w / 2.1, 700), height: "auto", aspectRatio: `${it.w} / ${it.h}`, filter: T.arFilter, opacity: 0.97 }} /></div> : null;
        if (it.k === "corr") return <div key={i} style={{ border: "1px solid #8fce7f55", background: "#8fce7f12", padding: "8px 12px", borderRadius: 3, margin: "4px 0 14px", fontSize: size * 0.82, lineHeight: 1.6, color: T.ink }}>
          <span style={{ fontFamily: F.mono, fontSize: 10, color: "#4f9a3f" }}>CORRECTED · </span>{it.t.replace(/^Corrected in this edition:\s*/, "")}</div>;
        if (it.k === "seal") return <div key={i} style={{ border: "1px solid #e8a25c55", background: "#e8a25c14", padding: "8px 12px", borderRadius: 3, margin: "6px 0 14px", fontSize: size * 0.85 }}>
          <span style={{ fontFamily: F.mono, fontSize: 10, color: "#c97a2c" }}>SEALED · p.{it.p} — </span>
          <span style={{ color: T.ink }}>{it.t}</span>
          <div style={{ fontSize: 11.5, color: T.soft, marginTop: 3 }}>a working aimed at harming, compelling or binding another person — named and cited, its method not carried</div></div>;
        if (it.k === "fig") { const f = figById.get(it.id); const src = !it.sealed;
          return <figure key={i} style={{ margin: "10px 0 18px", border: `1px solid ${T.rule}`, borderRadius: 3, padding: 10, background: theme === "night" ? T.figBg : "#0d0b08" }}>
            {src && <FigImage id={it.id} alt={f && f.note ? f.note : "figure"} />}
            {!src && <div style={{ fontFamily: F.mono, fontSize: 10.5, color: "#e8a25c" }}>figure of a sealed working — its image is not carried</div>}
            {f && <figcaption style={{ marginTop: 8 }}><FigCard f={f} hue={hue} /></figcaption>}
            <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginTop: 6 }}>
              {src && (BOOK.talismans || []).some(t => t.id === it.id) && <Btn hue={hue} small onClick={() => go("talasim", { id: it.id })}>open in Ṭalāsim · to read and sketch</Btn>}
              {src && !(BOOK.sealedFigs || []).includes(it.id) && <Btn hue={hue} small onClick={() => go("shakl", { id: it.id })}>forge it</Btn>}
            </div>
          </figure>; }
        return null;
      })}
    </article>
    <div style={{ display: "flex", gap: 8, marginTop: 20, flexWrap: "wrap" }}>
      {ch > 0 && <Btn hue={hue} onClick={() => go("kitab", { chapter: ch - 1, view: "read", page: BOOK.chapters.find(c => c.ch === ch - 1).from })}>← {CHNAME(ch - 1)}</Btn>}
      {ch < 21 && <Btn hue={hue} onClick={() => go("kitab", { chapter: ch + 1, view: "read", page: BOOK.chapters.find(c => c.ch === ch + 1).from })}>{CHNAME(ch + 1)} →</Btn>}
      <span style={{ fontFamily: F.mono, fontSize: 10.5, color: "#ffffff55", alignSelf: "center" }}>Alt + ← / → moves between chapters</span>
    </div>
  </div>;
}


"""v2.7 — corrections found by reading the book's correspondence tables against one another.
Run from the folder holding book/ and kit/. Edits the reading text (book/chNN.json), the search index
(book/search.json) and the figure record (kit/data/figs_book.json); every change inserts a visible
'corr' note into the reading text so nothing is silently altered. Idempotent: a second run changes nothing."""
import json, re, os

CORR_NOTES = {}   # (ch, page) -> list of notes inserted after the paragraph/heading

def load(ch): return json.load(open(f"book/ch{ch:02d}.json", encoding="utf-8"))
def save(ch, d): json.dump(d, open(f"book/ch{ch:02d}.json", "w", encoding="utf-8"), ensure_ascii=False, separators=(",", ":"))

def has_corr(items, i, key):
    return i + 1 < len(items) and items[i + 1].get("k") == "corr" and items[i + 1].get("key") == key

# ── 1. Chapter 20, the daily litanies: Tuesday–Friday angels; Tuesday, Wednesday, Thursday tahṭīl ──
CH20 = {
    "Tuesday":   {"subs": [("Mīkāʾīl", "Samsamāʾīl"), ("Fahṭahayṭal", "Qahṭayṭīl")],
                  "note": "Corrected in this edition: the angel of Tuesday is Samsamāʾīl and its tahṭīl Qahṭayṭīl. The print has Mīkāʾīl (Wednesday's angel) and Fahṭahayṭal. The day tables of the book give Samsamāʾīl for Tuesday seven times (pp.113, 115, 584, 821, 921, 1945, and this same litany on p.2220), and the tahṭīl with qāf (p.115 قهطهطيل; pp.838, 861, 2220 Kahtaytīl). The king named here, al-Aḥmar (Abū Muḥriz), is Samsamāʾīl's on every one of those pages."},
    "Wednesday": {"subs": [("Samsamāʾīl", "Mīkāʾīl"), ("Fahṭahṭīl", "Fahṭayṭīl")],
                  "note": "Corrected in this edition: the angel of Wednesday is Mīkāʾīl and its tahṭīl Fahṭayṭīl. The print has Samsamāʾīl (Tuesday's angel) and Fahṭahṭīl. The book's day tables give Mīkāʾīl for Wednesday (pp.113, 115, 584, 821, 921, 654, 662), paired with this same king Burqān; the tahṭīl as p.115 فهطيطيل and pp.838, 2223 Fehtaytīl."},
    "Thursday":  {"subs": [("Isrāfīl", "Ṣarfiyāʾīl"), ("Lahaṭṭīl", "Nahṭahṭīl")],
                  "note": "Corrected in this edition: the angel of Thursday is Ṣarfiyāʾīl and its tahṭīl Nahṭahṭīl. The print has Isrāfīl and Lahaṭṭīl. The book's day tables give Ṣarfiyāʾīl for Thursday (pp.113, 115, 584, 821, 921, 1893, 2173), each time with this same king Shamhūrash; the tahṭīl as p.115 نهطهطيل and pp.838, 2173 Nehhattīl (Lahaṭṭīl is Saturday's)."},
    "Friday":    {"subs": [("ʿAzrāʾīl", "ʿAnyāʾīl")],
                  "note": "Corrected in this edition: the angel of Friday is ʿAnyāʾīl. The print has ʿAzrāʾīl. The book's day tables give ʿAnyāʾīl for Friday (pp.113, 115, 584, 821, 921, 2005, 2174), each time with this same king al-Abyaḍ."},
}
def patch_ch20():
    d = load(20); items = d["items"]; day = None; n = 0; out = []
    for i, it in enumerate(items):
        if it["k"] == "h2":
            m = re.search(r"day of (Sunday|Monday|Tuesday|Wednesday|Thursday|Friday|Saturday)", it["t"])
            day = m.group(1) if m else None
            out.append(it)
            if day in CH20 and not (i + 1 < len(items) and items[i + 1].get("k") == "corr"):
                out.append({"k": "corr", "key": "ch20-" + day, "t": CH20[day]["note"]}); n += 1
            continue
        if it["k"] == "p" and day in CH20 and it.get("p") is None:
            t = it["t"]
            for a, b in CH20[day]["subs"]: t = t.replace(a, b)
            it["t"] = t
        if it["k"] == "pg" and it["p"] >= 2137: day = None
        out.append(it)
    d["items"] = out; save(20, d); return n

# ── 2. p.654 (ch.14): the Friday and Saturday names of the roll-call rotated by one place ──
P654 = [("Answer, O Zawbaʿa, by the right of Friday", "Answer, O ʿAyniyāʾīl, by the right of Friday"),
        ("Answer, O Kasfiyāʾīl, by the right of the king whose command prevails over you, ʿAyniyāʾīl", "Answer, O Zawbaʿa, by the right of the king whose command prevails over you, ʿAyniyāʾīl"),
        ("Answer, O ʿAyniyāʾīl, by the right of the clouds", "Answer, O Kasfiyāʾīl, by the right of the clouds")]
NOTE654 = ("Corrected in this edition: in the roll-call of the seven angels and their kings the print rotates three names at Friday and Saturday "
           "(it reads Zawbaʿa … Kasfiyāʾīl … ʿAyniyāʾīl). Every other day of the same passage runs 'Answer, O [angel] … Answer, O [king], by the right of the king "
           "whose command prevails over you, [angel]', and the same pairs are given on p.662 (ʿAyniyāʾīl with Zawbaʿa, Kasfiyāʾīl with Maymūn); set right accordingly.")
def subs_seq(t, pairs):
    # placeholders so the three rotations do not overwrite one another
    for k, (a, _) in enumerate(pairs): t = t.replace(a, f"{k}")
    for k, (_, b) in enumerate(pairs): t = t.replace(f"{k}", b)
    return t

# ── 3. p.584 (ch.13): Saturday's king's kunya ──
NOTE584 = ("Corrected in this edition: Saturday's king is Maymūn Abū Nūkh. The print has Abā Fūkh — fāʾ for nūn; the book gives "
           "Maymūn Abū Nūkh on p.1566 and Abū Nūḥ Maymūn on p.1371. Note also that this page names Monday's king al-Abyaḍ and Friday's Zawbaʿa, "
           "where pp.114–115, 920–922 and chapter 20 name them Murra and al-Abyaḍ: the book carries both traditions (see pp.654, 820–821), so that is left as printed.")

# ── 4. pp.287–288 (ch.5): the planets named in the captions of the archangels' squares ──
P287 = [("This is the wafq of the Moon, for ʿAzrāʾīl.", "This is the wafq of Saturn, for ʿAzrāʾīl."),
        ("This is the wafq of Mercury, for Isrāfīl.", "This is the wafq of Jupiter, for Isrāfīl."),
        ("This is the wafq of Saturn, for Jibrāʾīl", "This is the wafq of the Moon, for Jibrāʾīl")]
NOTE287 = ("Corrected in this edition: the captions name the wrong planets. The squares beneath them are the threefold, the fourfold and the ninefold, "
           "which p.287 itself gives to ʿAzrāʾīl (Saturday), Isrāfīl (Thursday) and Jibrāʾīl (Monday) — that is, to Saturn, Jupiter and the Moon, as "
           "chapter 19 assigns them (pp.1732, 1893, 2026). The print has the Moon, Mercury and Saturn.")

def patch_simple(ch, page, pairs, note, key, seq=False):
    d = load(ch); items = d["items"]; p = 0; out = []; hit = 0
    for i, it in enumerate(items):
        if it["k"] == "pg": p = it["p"]
        if it["k"] == "p" and (p in page) and any(a in it["t"] for a, _ in pairs):
            it["t"] = subs_seq(it["t"], pairs) if seq else _subs(it["t"], pairs); hit += 1
            out.append(it)
            if not any(x.get("key") == key for x in items) and not any(x.get("key") == key for x in out):
                out.append({"k": "corr", "key": key, "t": note})
            continue
        out.append(it)
    d["items"] = out; save(ch, d); return hit
def _subs(t, pairs):
    for a, b in pairs: t = t.replace(a, b)
    return t

def patch_search():
    S = json.load(open("book/search.json", encoding="utf-8")); n = 0
    day = None
    for r in S:
        ch, pg, k, t = r[0], r[1], r[2], r[3]
        if ch == 20:
            if k == "h2":
                m = re.search(r"day of (Sunday|Monday|Tuesday|Wednesday|Thursday|Friday|Saturday)", t); day = m.group(1) if m else None
            elif day in CH20 and 2124 <= pg <= 2136:
                for a, b in CH20[day]["subs"]: t = t.replace(a, b)
        if pg == 654: t = subs_seq(t, P654)
        if pg == 584: t = t.replace("Abā Fūkh", "Abā Nūkh")
        if pg in (287, 288): t = _subs(t, P287)
        if t != r[3]: r[3] = t; n += 1
    json.dump(S, open("book/search.json", "w", encoding="utf-8"), ensure_ascii=False, separators=(",", ":"))
    return n

# ── 5. p.115, the table of the days: Tuesday's ink ──
ISSUE115 = ("Tuesday's ink is printed ZENCEBİL (ginger), which is no ink. Read zincifre (cinnabar): p.921 gives Mars's ink as cinnabar, "
            "'a red dye', and this table's own colour for Tuesday is red; every other ink in the row agrees with pp.921–922 (orpiment, verdigris, sarcocolla, camphor, vitriol).")
def patch_figs():
    p = "kit/data/figs_book.json"; F = json.load(open(p, encoding="utf-8")); n = 0
    for f in F:
        if f["id"] == 13 and f.get("issue") != ISSUE115:
            f["issue"] = ISSUE115; f["corrected"] = True; n += 1
            t = f.get("table")
            if isinstance(t, list):
                for row in t:
                    if row and row[0] == "ink" and row[3] == "ginger": row[3] = "cinnabar (printed: ginger)"
    json.dump(F, open(p, "w", encoding="utf-8"), ensure_ascii=False, indent=0)
    return n

if __name__ == "__main__":
    print("ch20 notes", patch_ch20())
    print("p.654", patch_simple(14, (654,), P654, NOTE654, "p654", seq=True))
    print("p.584", patch_simple(13, (584,), [("Abā Fūkh", "Abā Nūkh")], NOTE584, "p584"))
    print("pp.287–288", patch_simple(5, (287, 288), P287, NOTE287, "p287"))
    print("search rows", patch_search())
    print("figure 13", patch_figs())

# The squares of seal-signs (pp.738, 876–884), re-set clean: each sign taken from its clearest printing and set in every
# cell by the square's rule — every row the row above shifted one place to the right (read from the facsimiles).
import json, os
BOX = {123: (23, 28, 452, 422), 124: (20, 25, 468, 431), 125: (23, 24, 455, 371), 126: (22, 23, 447, 383),
       127: (29, 23, 446, 388), 128: (29, 23, 446, 388), 129: (29, 20, 447, 371), 130: (28, 29, 449, 412), 131: (19, 21, 447, 408)}
# the signs, by their look: B bracket ⊐ · X dotted cross · E the stacked ʿayn · L the loop · M mīm with its tail ·
# W wāw · V the angle-stroke · D the half-disc · A the open angle < · H the hourglass · G the reversed wāw
SEQ = {123: "B X E L E B B", 124: "B X E L E L M", 125: "B X E X E L W", 126: "B X E X E L V", 127: "B X E E L L D",
       128: "B X E E L L D", 129: "B X E E B L A", 130: "B X E E L H B", 131: "B A D V G M B"}
for fid, seq in SEQ.items():
    seq = seq.split(); tw, th = trace_dims(fid); sc = 1000 / max(tw, th); bx = BOX[fid]
    names = {"B": "the bracket", "X": "the dotted cross", "E": "the stacked ʿayn", "L": "the loop", "M": "the mīm with its tail",
             "W": "the wāw", "V": "the angle-stroke", "D": "the half-disc", "A": "the open angle", "H": "the hourglass", "G": "the turned wāw"}
    distinct = list(dict.fromkeys(seq))
    add(id=f"f{fid}", fig=fid, page=None, title=None, desc=None, group="seal", w=round(tw * sc), h=round(th * sc) + 60,
        els=[dict(t="signgrid", fig=fid, s=sc, box=list(bx), n=7, seq=seq, shift=1, double=True)],
        how=[f"Rule the 7×7 square. The first row runs (left to right as printed): " + ", ".join(names[k] for k in seq) + ".",
             "Each row below is the row above moved one place to the right, the last sign coming round to the front — so every sign stands once in each row and each column.",
             f"{len(distinct)} distinct signs; each is drawn here from its clearest printing in the first row."],
        notes=["Read from the facsimile cell by cell: all seven rows follow the one-place shift exactly as printed."])
# #82 — to nullify sorcery: the 3×3 of three seals in the archangels' frame
tw, th = trace_dims(82); sc = 1000 / max(tw, th)
add(id="f82", fig=82, page=738, group="seal", title=None, desc=None, w=round(tw * sc), h=round(th * sc) + 60,
    els=[dict(t="trace", fig=82, s=sc, cut=[100, 95, 350, 325], n=3, m=3), dict(t="signgrid", fig=82, s=sc, box=[100, 95, 350, 325], n=3, seq=["lattice", "comb", "star"], shift=1, rules=False)],
    how=["Draw the seal on a piece of paper: a 3×3 in the archangels' frame (Jibrāʾīl above, Mīkāʾīl left, ʿAzrāʾīl right, Isrāfīl below).",
         "The first row: the lattice, the comb (three strokes under a bar), the star; each row below moves one place to the right.",
         "For the nullifying of sorcery (p.738)."],
    notes=["Each of the three seals stands once in every row and column, as printed."])

import pymupdf, json, os, io
from PIL import Image
parts = json.load(open('edition/parts.json')); C = json.load(open('chapters.json'))
pdf = lambda f: pymupdf.open(f.replace('.html', '.pdf'))
front, chs, corr = parts[0], [f for f in parts if '/ch' in f], parts[-1]
counts = {f: pdf(f).page_count for f in parts}
def chno(f): return int(f.split('/ch')[-1][:2])
def build(vol, chapter_files, with_corr, dst, first_page):
    out = pymupdf.open(); toc = [[1, "Title, contents and note", 1]]
    out.insert_pdf(pdf(front)); nfront = out.page_count
    for f in chapter_files:
        s = out.page_count; out.insert_pdf(pdf(f)); c = [x for x in C if x['ch'] == chno(f)][0]
        toc.append([1, (f"Chapter {c['ch']}: " if 0 < c['ch'] < 21 else "") + c['short'] + f"  (p.{c['from']})", s + 1])
    nbook = out.page_count - nfront
    labels = [{"startpage": 0, "prefix": "", "style": "r", "firstpagenum": 1},
              {"startpage": nfront, "prefix": "", "style": "D", "firstpagenum": first_page}]
    if with_corr:
        s = out.page_count; out.insert_pdf(pdf(corr)); toc.append([1, "Corrections", s + 1])
        labels.append({"startpage": s, "prefix": "Corrections ", "style": "D", "firstpagenum": 1})
    out.set_page_labels(labels); out.set_toc(toc)
    out.set_metadata({"title": f"Iḥyāʾ Uṣūl al-Ḥikmah — corrected edition, Volume {vol}", "subject": "Page for page with the original; prepared with the Iḥyāʾ Engine; reissue of 10 October 2026"})
    done = set()
    for p in out:
        for x in p.get_images(full=True):
            xr = x[0]
            if xr in done: continue
            done.add(xr)
            try:
                pix = pymupdf.Pixmap(out, xr)
                if pix.alpha: pix = pymupdf.Pixmap(pix, 0)
                im = Image.open(io.BytesIO(pix.tobytes('png'))).convert('L')
                if im.width > 950: im = im.resize((950, int(im.height * 950 / im.width)), Image.LANCZOS)
                b = io.BytesIO(); im.save(b, 'JPEG', quality=45, optimize=True); p.replace_image(xr, stream=b.getvalue())
            except Exception: pass
    out.save(dst, garbage=4, deflate=True)
    print(dst, out.page_count, 'pages,', nbook, 'book pages from p.', first_page, round(os.path.getsize(dst) / 1048576, 1), 'MiB')
    return nbook
v1 = [f for f in chs if chno(f) <= 15]; v2 = [f for f in chs if chno(f) >= 16]
n1 = build("I", v1, False, 'edition/Ihya-usul-al-hikmah-corrected-edition-volume-I.pdf', 1)
n2 = build("II", v2, True, 'edition/Ihya-usul-al-hikmah-corrected-edition-volume-II.pdf', n1 + 1)
print('total book pages', n1 + n2)

/* ═══ The Forge of the Ashkāl — every square of the book rebuilt for another name, number or text ═══
 * Pure functions, no UI. Grids are in the book's visual orientation (as printed, column 0 on the left).
 * Nothing here is the book's own output: each result is the book's figure carried to a new value by a stated
 * operation, and every line is re-summed before it is shown.
 *
 * Methods
 *  own   — on its own arrangement (tarḥ): the figure's cells ranked 1…n² give its base; subtract n(n²−1)/2,
 *          divide by n, add the quotient less one to every cell, and lift the top r·n cells by one (the Ch.19 rule
 *          on the figure's own form). Only when the ranks themselves form a magic square and can take the lift.
 *  carry — the figure's own numbers carried: every cell takes the same addition, and any remainder goes by one
 *          into each line through a Latin arrangement (each row, column — and diagonal when the figure closes on
 *          them — receives it exactly once).
 *  top   — the book's squares whose top row is a name's letters: the top row becomes the new text's segments and
 *          the rest is carried so every line still closes.
 *  darb  — multiplied (the book's second way, p.1970): the quotient of the number by the figure's constant
 *          multiplies every cell, and the remainder goes once into each line along one transversal; for a number
 *          below the constant the number itself multiplies, and the square closes on constant × number.
 *  letters — letter squares: the new text's letters or words take the places of the book's, in the same cycle.
 */

export const sumsOf = (g) => {
  const n = g.length, h = g.map(r => r.map(v => (typeof v === "number" ? v : 0)));
  const rows = h.map(r => r.reduce((a, b) => a + b, 0));
  const cols = h[0].map((_, c) => h.reduce((a, r) => a + r[c], 0));
  const d1 = h.reduce((a, r, i) => a + r[i], 0), d2 = h.reduce((a, r, i) => a + r[n - 1 - i], 0);
  const balanced = rows.concat(cols).every(s => s === rows[0]);
  return { rows, cols, d1, d2, balanced, diagonals: balanced && d1 === rows[0] && d2 === rows[0], constant: balanced ? rows[0] : null };
};
const isSq = (g) => Array.isArray(g) && g.length >= 3 && g.every(r => Array.isArray(r) && r.length === g.length);
const distinct = (g) => { const f = g.flat().filter(v => v != null); return new Set(f).size === f.length; };
const positive = (g) => g.flat().every(v => v == null || (Number.isInteger(v) && v > 0));

/** The ranks of the cells, 1…n² (only for distinct whole numbers). */
export function rankOf(g) {
  const n = g.length, flat = g.flat().map((v, i) => [v, i]).sort((a, b) => a[0] - b[0]), P = new Array(n * n);
  flat.forEach(([, i], k) => (P[i] = k + 1));
  return Array.from({ length: n }, (_, r) => P.slice(r * n, r * n + n));
}

/* ───────── Latin arrangements and transversals, found by search ───────── */
/** Latin squares with first row 0…n−1 (and, with diag, both diagonals permutations too). A generator: a known
 *  construction first where one exists, then a seeded randomized search with restarts (the same order every time). */
export function* latinSquares(n, diag, limit = 4000) {
  const seen = new Set(); let k = 0;
  const emit = (L) => { const key = L.map(r => r.join(",")).join(";"); if (seen.has(key)) return false; seen.add(key); return true; };
  if (!diag || (n % 2 === 1 && n % 3 !== 0)) {
    for (let s = 1; s < n; s++) {
      if (gcd(s, n) !== 1 || (diag && (gcd(s + 1, n) !== 1 || gcd(Math.abs(s - 1), n) !== 1))) continue;
      const L = Array.from({ length: n }, (_, r) => Array.from({ length: n }, (_, c) => (c + r * s) % n));
      if (emit(L)) { yield L; if (++k >= limit) return; }
    }
  }
  let seed = 2166136261 ^ (n * 7919 + (diag ? 1 : 0));
  const rnd = () => { seed ^= seed << 13; seed >>>= 0; seed ^= seed >>> 17; seed ^= seed << 5; seed >>>= 0; return seed / 4294967296; };
  for (let restart = 0; restart < 400 && k < limit; restart++) {
    const L = Array.from({ length: n }, (_, r) => r === 0 ? [...Array(n).keys()] : new Array(n).fill(-1));
    const col = Array.from({ length: n }, (_, c) => new Set([c])), row = Array.from({ length: n }, () => new Set());
    const d1 = new Set([0]), d2 = new Set([n - 1]); let steps = 0, found = false;
    const order = Array.from({ length: n }, () => [...Array(n).keys()]);
    const fill = (pos) => {
      if (++steps > 30000) return false;
      if (pos === n * n) return true;
      const r = Math.floor(pos / n), c = pos % n;
      if (c === 0) { const o = order[r]; for (let i = n - 1; i > 0; i--) { const j = Math.floor(rnd() * (i + 1)); [o[i], o[j]] = [o[j], o[i]]; } }
      for (const s of order[r]) {
        if (row[r].has(s) || col[c].has(s)) continue;
        const a = diag && r === c, b = diag && r + c === n - 1;
        if ((a && d1.has(s)) || (b && d2.has(s))) continue;
        L[r][c] = s; row[r].add(s); col[c].add(s); if (a) d1.add(s); if (b) d2.add(s);
        if (fill(pos + 1)) return true;
        L[r][c] = -1; row[r].delete(s); col[c].delete(s); if (a) d1.delete(s); if (b) d2.delete(s);
      }
      return false;
    };
    found = fill(n);
    if (found && emit(L)) { yield L.map(r => r.slice()); k++; }
  }
}
const gcd = (a, b) => b ? gcd(b, a % b) : a;
/** Found once per order and kept: the arrangements every forging of that order draws on. */
const LATIN_CACHE = new Map();
export function latinList(n, diag, want = 40) {
  if (diag && n === 3) return [];
  const key = n + (diag ? "d" : "");
  let c = LATIN_CACHE.get(key);
  if (!c) { c = { list: [], gen: latinSquares(n, diag, 400), done: false }; LATIN_CACHE.set(key, c); }
  while (!c.done && c.list.length < want) { const x = c.gen.next(); if (x.done) c.done = true; else c.list.push(x.value); }
  return c.list;
}
/** Transversals: one cell in every row and column, none on a hollow cell; with diag, exactly one on each diagonal. */
export function* transversals(g, diag, limit = 400) {
  const n = g.length, used = new Array(n).fill(false), p = new Array(n);
  let k = 0, steps = 0;
  function* go(r, m1, m2) {
    if (++steps > 200000) return;
    if (r === n) { if (!diag || (m1 === 1 && m2 === 1)) yield p.slice(); return; }
    for (let t = 0; t < n; t++) {
      const c = (t + r) % n;
      if (used[c] || g[r][c] == null) continue;
      const a = m1 + (r === c ? 1 : 0), b = m2 + (r + c === n - 1 ? 1 : 0);
      if (diag && (a > 1 || b > 1)) continue;
      used[c] = true; p[r] = c; yield* go(r + 1, a, b); used[c] = false;
    }
  }
  for (const x of go(0, 0, 0)) { yield x; if (++k >= limit) return; }
}

/* ───────── reading a figure ───────── */
/** Turn a book grid into values. Strings count by their abjad (ab), null stays hollow. A word written in the very
 *  centre of an odd square that otherwise does not close is read as the hollow centre with its name. */
export function analyse(grid, ab) {
  if (!isSq(grid)) return { kind: "plate", why: "not a square grid" };
  const n = grid.length, flat = grid.flat();
  const allStr = flat.every(v => typeof v === "string");
  const toVal = (v) => v == null ? null : typeof v === "number" ? v : ab(v);
  let values = grid.map(r => r.map(toVal)), centre = null;
  let s = sumsOf(values);
  if (!s.balanced && n % 2 === 1 && typeof grid[(n - 1) / 2][(n - 1) / 2] === "string" && !allStr) {
    const m = (n - 1) / 2, v2 = values.map(r => r.slice()); v2[m][m] = null;
    const s2 = sumsOf(v2);
    if (s2.balanced) { values = v2; s = s2; centre = grid[m][m]; }
  }
  const hollow = values.flat().some(v => v == null);
  const out = { n, values, hollow, centre, constant: s.constant, closes: s.balanced, diagonals: s.diagonals, methods: [] };
  // letter squares
  if (allStr) {
    const L = letterPattern(grid);
    if (L) { out.letters = L; out.methods.push("letters"); }
  }
  // a name's letters across the top row of a numeric square
  if (!allStr && grid[0].every(v => typeof v === "string") && grid.slice(1).every(r => r.every(v => typeof v === "number"))) out.topRow = true;
  if (!s.balanced || values.flat().some(v => v != null && !Number.isInteger(v))) {
    if (!out.methods.length) { out.kind = "plate"; out.why = "its lines do not close as printed"; }
    else out.kind = "letters";
    return out;
  }
  out.kind = allStr ? "letters" : hollow ? "hollow" : "numeric";
  // a square printed already multiplied (every cell sharing a factor) is multiplied again from its base
  const g = values.flat().filter(v => v != null).reduce((a, b) => gcd(a, Math.abs(b)), 0);
  if (g > 1) { out.unit = g; out.base = values.map(r => r.map(v => v == null ? null : v / g)); }
  if (!hollow && distinct(values)) {
    const P = rankOf(values), sp = sumsOf(P);
    if (sp.balanced && sp.constant === n * (n * n + 1) / 2 && (sp.diagonals || !s.diagonals)) { out.pattern = P; out.methods.push("own"); }
  }
  if (out.topRow && !hollow) out.methods.push("top");
  if (!hollow) out.methods.push("carry");
  out.methods.push("darb");
  return out;
}

/** How a letter square repeats: each row a turn of the first (cycle), or each letter once in every row and column (latin). */
export function letterPattern(grid) {
  const n = grid.length, r0 = grid[0];
  const offs = grid.map(row => [...Array(n).keys()].filter(k => row.every((x, c) => x === r0[(c + k) % n])));
  if (offs.every(o => o.length)) {
    // prefer a steady step from row to row, so columns carry every place once
    for (let s = 0; s < n; s++) if (offs.every((o, r) => o.includes((r * s) % n))) return { type: "cycle", offsets: offs.map((_, r) => (r * s) % n), places: n };
    return { type: "cycle", offsets: offs.map(o => o[0]), places: n };
  }
  const syms = [...new Set(grid.flat())];
  if (syms.length === n && grid.every(r => new Set(r).size === n) && r0.every((_, c) => new Set(grid.map(r => r[c])).size === n)) {
    const order = r0.slice().reverse();          // the name as it reads, right to left
    return { type: "latin", index: grid.map(r => r.map(x => order.indexOf(x))), places: n };
  }
  return null;
}

/** +1 along r disjoint transversals that each cross both diagonals once, keeping every cell distinct. */
function liftPaths(base, r) {
  const n = base.length;
  for (const L of latinList(n, true)) {
    const g = base.map((row, i) => row.map((v, j) => v + (L[i][j] < r ? 1 : 0)));
    if (distinct(g)) return g;
  }
  return null;
}

/* ───────── the methods ───────── */
export const floorOf = (n) => n * (n * n - 1) / 2 + n;   // least number the tarḥ can take (k ≥ 1)

export function forgeOwn(A, P) {
  const n = P.length, sub = n * (n * n - 1) / 2, diff = A - sub;
  if (!Number.isInteger(A) || A <= 0) return { error: "the number must be a whole positive number" };
  if (diff < n) return { error: `below this figure's floor — it needs at least ${sub + n}` };
  const k = Math.floor(diff / n), rem = diff % n, th = n * n - rem * n;
  if (rem) {
    const rows = P.map(r => r.filter(v => v > th).length), cols = P[0].map((_, c) => P.filter(r => r[c] > th).length);
    if (!rows.concat(cols).every(x => x === rem)) return { error: `this arrangement cannot take a remainder of ${rem} — its top ${rem * n} cells do not fall ${rem} to every row and column` };
  }
  let grid = P.map(r => r.map(v => v + (k - 1) + (rem && v > th ? 1 : 0)));
  let note = null;
  if (rem && sumsOf(P).diagonals && !sumsOf(grid).diagonals) {
    // the book's lift keeps rows and columns; look for a lift through r paths that keeps the diagonals too
    const base = P.map(r => r.map(v => v + (k - 1)));
    const alt = liftPaths(base, rem);
    if (alt) { grid = alt; note = `the remainder goes by one into ${rem} cell${rem > 1 ? "s" : ""} of every line (rows, columns and both diagonals) instead of the top ${rem * n} — the book's lift would leave the diagonals off`; }
    else note = n === 3 ? "with a remainder the threefold closes on its rows and columns only — as the book's own rule does (p.1703)" : "with this remainder the lift closes rows and columns; the diagonals differ";
  }
  return { grid, k, rem, note, how: `${A} − ${sub} = ${diff}; ÷ ${n} = ${k}${rem ? ` remainder ${rem}` : ""}; ${k - 1 >= 0 ? `+${k - 1}` : k - 1} to every rank${rem ? `, +1 to the top ${rem * n}` : ""}` };
}

/** Add Δ = d[L] to G: every line with each symbol once gains Σd. Searches Latin squares until the cells stay distinct and positive. */
function addLatin(G, d, diag, keepTop) {
  const n = G.length; let best = null;
  for (const L of latinList(n, diag)) {
    const g = G.map((r, i) => r.map((v, j) => v + d[L[i][j]]));
    if (!positive(g)) { best = best || { grid: g, bad: "positive" }; continue; }
    if (distinct(g) || keepTop) return { grid: g, L };
    best = best && best.bad === "distinct" ? best : { grid: g, L, bad: "distinct" };
  }
  return best;
}

export function forgeCarry(A, values, diag) {
  const n = values.length, C = sumsOf(values).constant, D = A - C;
  if (!Number.isInteger(A) || A <= 0) return { error: "the number must be a whole positive number" };
  const k = Math.floor(D / n), r = ((D % n) + n) % n;
  if (!r) {
    const grid = values.map(row => row.map(v => v + k));
    if (!positive(grid)) return { error: `too small: carrying ${C} down to ${A} takes a cell below one` };
    return { grid, k, rem: 0, how: `${A} − ${C} = ${D}; ÷ ${n} = ${k}: ${k >= 0 ? "+" : ""}${k} to every cell` };
  }
  if (diag && n === 3) return { error: "a 3×3 closing on its diagonals carries only in steps of 3 — use its own arrangement" };
  // r symbols take k+1, the rest k
  const d = [...Array(n).keys()].map(j => k + (j < r ? 1 : 0));
  const res = addLatin(values, d, diag);
  if (!res) return { error: "no Latin arrangement found for this order" };
  if (res.bad === "positive") return { error: `too small: carrying ${C} down to ${A} takes a cell below one` };
  return { grid: res.grid, k, rem: r, repeats: res.bad === "distinct",
    how: `${A} − ${C} = ${D}; ÷ ${n} = ${k} remainder ${r}: ${k >= 0 ? "+" : ""}${k} to every cell and one more to ${r} cell${r > 1 ? "s" : ""} of every line` };
}

/** The top row becomes the new segments' values (segVals given in reading order, right to left). */
export function forgeTop(values, segVals, diag) {
  const n = values.length;
  if (segVals.length !== n) return { error: `the top row has ${n} places — the text gives ${segVals.length}` };
  const u = segVals.slice().reverse();                 // visual left-to-right
  const d = u.map((x, j) => x - values[0][j]);
  if (diag && n === 3) return { error: "no 3×3 arrangement carries a new top row and keeps both diagonals" };
  const res = addLatin(values, d, diag, true);
  if (!res) return { error: "no Latin arrangement found for this order" };
  if (res.bad === "positive") return { error: "this text's letters are too far from the book's — a cell falls below one" };
  return { grid: res.grid, repeats: !distinct(res.grid), how: `each top cell moves to its letter's value; the same moves are carried through every line once` };
}

export function forgeDarb(A, values, diag, byNumber) {
  const n = values.length, C = sumsOf(values).constant;
  if (!Number.isInteger(A) || A <= 0) return { error: "the number must be a whole positive number" };
  if (byNumber || A < C) {
    const grid = values.map(r => r.map(v => v == null ? null : v * A));
    return { grid, q: A, rem: 0, byNumber: true, constant: C * A, how: `every cell × ${A}: the square closes on ${C} × ${A} = ${C * A}` };
  }
  const q = Math.floor(A / C), r = A - q * C;
  const base = values.map(row => row.map(v => v == null ? null : v * q));
  if (!r) return { grid: base, q, rem: 0, constant: A, how: `${A} ÷ ${C} = ${q}: every cell × ${q}` };
  let fallback = null;
  for (const dg of diag ? [true, false] : [false]) {
  for (const p of transversals(values, dg)) {
    const g = base.map((row, i) => row.map((v, j) => (j === p[i] ? v + r : v)));
    if (distinct(g)) { const o = { grid: g, q, rem: r, constant: A, cells: p, how: `${A} ÷ ${C} = ${q} remainder ${r}: every cell × ${q}, and ${r} into one cell of every line` };
      if (!diag || dg) return o; fallback = fallback || o; continue; }
    fallback = fallback || { grid: g, q, rem: r, constant: A, cells: p, repeats: true, how: `${A} ÷ ${C} = ${q} remainder ${r}: every cell × ${q}, and ${r} into one cell of every line` };
  }
  if (fallback) break;
  }
  if (fallback && diag && !sumsOf(fallback.grid).diagonals) fallback.note = `no single path crosses every row, column and both diagonals of this ${n}×${n} once, so the remainder closes rows and columns only; for the diagonals too, give a multiple of ${C}`;
  return fallback || { error: `no path through every line for the remainder ${r}` };
}

/** Letter squares: the segments (in reading order) take the book's places. */
export function forgeLetters(grid, L, segs) {
  const n = grid.length;
  if (segs.length !== L.places) return { error: `this square has ${L.places} places — the text gives ${segs.length}` };
  if (L.type === "cycle") {
    const seq = segs.slice().reverse();                 // the first row as printed, left to right
    return { grid: grid.map((row, r) => row.map((_, c) => seq[(c + L.offsets[r]) % n])) };
  }
  return { grid: L.index.map(r => r.map(i => segs[i])) };
}

/** Run a method. opts: { A, segs, segVals, byNumber } */
export function forge(an, method, opts, ab) {
  const diag = !!an.diagonals;
  let res;
  if (method === "own") res = forgeOwn(opts.A, an.pattern);
  else if (method === "carry") res = forgeCarry(opts.A, an.values, diag);
  else if (method === "top") res = forgeTop(an.values, opts.segVals || [], diag);
  else if (method === "darb") {
    res = forgeDarb(opts.A, an.base || an.values, diag, opts.byNumber);
    if (!res.error && an.base) res.how = `the printed square is its base of ${sumsOf(an.base).constant} × ${an.unit}; ` + res.how;
  }
  else if (method === "letters") res = forgeLetters(an.values, an.letters, opts.segs || []);
  else res = { error: "unknown method" };
  if (res.error) return res;
  // the top row written in letters again
  let shown = res.grid;
  if (method === "top" && opts.segs) { const u = opts.segs.slice().reverse(); shown = res.grid.map((r, i) => i ? r : u); }
  const values = method === "letters" ? res.grid.map(r => r.map(x => ab(x))) : res.grid;
  const s = sumsOf(values);
  return { ...res, shown, values, sums: s, keepsDiagonals: !diag || s.diagonals };
}

import { chromium } from 'playwright';
const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' });
const p = await b.newPage({ viewport: { width: 1300, height: 1400 } }); p.setDefaultTimeout(10000);
const errs=[]; p.on('pageerror', e => errs.push(e.message)); p.on('response', r => r.status()>=400 && errs.push(r.status()+' '+r.url()));
await p.goto('http://localhost:8766/index.html'); await p.waitForTimeout(1500);
let total=0, figb=0;
const chs = await p.$$('main button[style*="text-align: left"]'); console.log('chapters', chs.length);
for (let i=0;i<chs.length;i++) { const cs = await p.$$('main button[style*="text-align: left"]'); if (!cs[i] || i>21) break; await cs[i].click(); await p.waitForTimeout(250);
  const wb = await p.$('main button:has-text("Workings ·")'); if (!wb) continue; await wb.click(); await p.waitForTimeout(300);
  const n = (await p.$$('main button:has-text("craft card")')).length, f = (await p.$$('main button:has-text("forge figure")')).length; total+=n; figb+=f; }
console.log('craft cards', total, 'figure links', figb);
await p.screenshot({ path: '/home/claude/live/dist/q_work.png' });
const [dl] = await Promise.all([p.waitForEvent('download'), p.click('main button:has-text("craft card") >> nth=0')]);
await dl.saveAs('/home/claude/live/dist/card.svg');
await b.close(); console.log('ERRS', errs);

// The Forge of the Ashkāl: every open square of the book, rebuilt on every method it offers, for many numbers and texts.
import * as S from '../src/shakl.mjs';
import { readFileSync } from 'fs';
const src = readFileSync(new URL('../src/engine.jsx', import.meta.url), 'utf8');
const line = src.split('\n').find(l => l.startsWith('/*@BOOK*/const BOOK = '));
const BOOK = JSON.parse(line.slice('/*@BOOK*/const BOOK = '.length, line.lastIndexOf(';/*@END*/')));
const V = {}; "ابجدهوزحطيكلمنسعفصقرشتثخذضظغ".split('').forEach((c, i) => V[c] = [1,2,3,4,5,6,7,8,9,10,20,30,40,50,60,70,80,90,100,200,300,400,500,600,700,800,900,1000][i]);
Object.assign(V, { 'أ':1,'إ':1,'آ':1,'ٱ':1,'ء':1,'ؤ':6,'ئ':10,'ة':5,'ى':10 });
const ab = (s) => [...String(s)].reduce((a, c) => a + (V[c] || 0), 0);
let fail = 0, runs = 0; const bad = (m) => { fail++; if (fail < 40) console.log('FAIL', m); };
const sealed = new Set(BOOK.sealedFigs);
const open = BOOK.figs.filter(f => !sealed.has(f.id));
const counts = {}; let squares = 0, plates = 0;
const TEXTS = ['حسبنا الله ونعم الوكيل', 'يا لطيف', 'محمد', 'الرزاق', 'قل هو الله احد'];
for (const f of open) {
  if (!f.grid) { plates++; continue; }
  const an = S.analyse(f.grid, ab);
  if (an.kind === 'plate') { plates++; counts.plateOnly = (counts.plateOnly || 0) + 1; continue; }
  squares++;
  for (const m of an.methods) counts[m] = (counts[m] || 0) + 1;
  // the figure's own constant must come back cell for cell where the method is exact
  if (an.methods.includes('own')) {
    const r = S.forge(an, 'own', { A: an.constant }, ab);
    if (r.error || JSON.stringify(r.values) !== JSON.stringify(S.rankOf(an.values).map(row => row.map(v => v + (an.values.flat().sort((a,b)=>a-b)[0] - 1)))) && !r.error && !r.sums.balanced) bad(`#${f.id} own at its own constant`);
  }
  for (const m of an.methods) {
    if (m === 'letters' || m === 'top') {
      for (const t of TEXTS) {
        const letters = [...t].filter(c => V[c]);
        const words = t.split(/\s+/);
        const segs = letters.length === an.n ? letters : words.length === an.n ? words : letters.slice(0, an.n).length === an.n ? letters.slice(0, an.n) : null;
        if (!segs) continue;
        const r = S.forge(an, m, { segs, segVals: segs.map(ab) }, ab); runs++;
        if (r.error) { if (m === 'top' && /below one/.test(r.error)) continue; bad(`#${f.id} ${m} "${t}": ${r.error}`); continue; }
        if (m === 'letters' && an.letters.type === 'latin' && !r.sums.balanced) bad(`#${f.id} letters latin does not close`);
        if (m === 'top' && !(r.sums.balanced && r.sums.constant === segs.map(ab).reduce((a,b)=>a+b,0))) bad(`#${f.id} top "${t}" lines ${JSON.stringify(r.sums.rows)}`);
        if (m === 'top' && !r.keepsDiagonals) bad(`#${f.id} top lost its diagonals`);
      }
      continue;
    }
    for (const A of [an.constant, an.constant + 1, an.constant + an.n - 1, 786, 1002, 2401, 99999, 450, 13685]) {
      const r = S.forge(an, m, { A }, ab); runs++;
      if (r.error) { if (/below|too small|steps of 3|cannot take/.test(r.error)) continue; bad(`#${f.id} ${m} ${A}: ${r.error}`); continue; }
      const want = r.byNumber ? r.constant : A;
      if (!r.sums.balanced || r.sums.constant !== want) { bad(`#${f.id} ${m} ${A}: rows/cols ${JSON.stringify(r.sums.rows)} ${JSON.stringify(r.sums.cols)}`); continue; }
      if (!r.keepsDiagonals && !r.note) bad(`#${f.id} ${m} ${A}: diagonals lost`);
      if (!r.keepsDiagonals) counts.diagNoted = (counts.diagNoted || 0) + 1;
      if (r.values.flat().some(v => v != null && (!Number.isInteger(v) || v <= 0))) bad(`#${f.id} ${m} ${A}: non-whole or non-positive cell`);
      if (m === 'own' && new Set(r.values.flat()).size !== an.n * an.n) bad(`#${f.id} own ${A}: repeated cell`);
    }
  }
}
// own arrangement at the figure's own constant reproduces a consecutive figure exactly
let exact = 0, exactTried = 0;
for (const f of open) { if (!f.grid) continue; const an = S.analyse(f.grid, ab); if (!an.methods || !an.methods.includes('own')) continue;
  const flat = an.values.flat().slice().sort((a, b) => a - b); if (!flat.every((v, i) => i === 0 || v === flat[i - 1] + 1)) continue;
  exactTried++; const r = S.forge(an, 'own', { A: an.constant }, ab); if (!r.error && JSON.stringify(r.values) === JSON.stringify(an.values)) exact++; else bad(`#${f.id} own does not reproduce its own consecutive figure`); }
// the hollow fivefold of p.1978: 1503 multiplied with remainder closes on 1503
console.log(`open figures ${open.length} · squares forged ${squares} · plate-only ${plates} · method counts ${JSON.stringify(counts)} · runs ${runs} · own reproduces ${exact}/${exactTried} consecutive figures`);
console.log(fail ? `SHAKL FAILURES ${fail}` : 'all shakl checks pass'); process.exit(fail ? 1 : 0);

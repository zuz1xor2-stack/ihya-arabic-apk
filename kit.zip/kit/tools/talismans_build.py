"""The talismans, seals and circles of the book as a catalogue: each with its page, the book's own words that go with it,
a clear image and a line-art tracing for sketching. Sealed workings are not included."""
import json, re, os, base64, io
from PIL import Image, ImageOps, ImageFilter
F = json.load(open('figs_book.json')); S = set(json.load(open('reader/sealed_figs.json'))); FI = json.load(open('figs_index.json'))
C = json.load(open('chapters.json'))
chof = lambda p: next((c['ch'] for c in C if c['from'] <= p <= c['to']), 21)
tal = [f for f in F if f['status'] == 'figure' and f['id'] not in S]
ctx = {}
for ch in range(22):
    L = json.load(open(f'reader/ch{ch:02d}.json'))
    for i, it in enumerate(L):
        if it['k'] == 'fig' and not it.get('sealed'):
            before = []; j = i - 1; head = None
            while j >= 0 and len(before) < 3:
                x = L[j]
                if x['k'] == 'seal': break
                if x['k'] in ('h1', 'h2'): head = x['t']; break
                if x['k'] == 'p': before.insert(0, x['t'])
                j -= 1
            after = []; j = i + 1
            while j < len(L) and len(after) < 1:
                x = L[j]
                if x['k'] in ('h1', 'h2', 'seal', 'fig'): break
                if x['k'] == 'p': after.append(x['t'])
                j += 1
            ctx[it['id']] = {'head': head, 'before': before, 'after': after}
out = []; packs = {}
for f in tal:
    c = ctx.get(f['id'], {'head': None, 'before': [], 'after': []}); note = f.get('note') or ''
    after = [a for a in c['after'] if not (note and a[:40] in note) and not re.match(r'^(Table|Two|A |Plain|Unlabelled|Circular|Pair|Manuscript|\d+\s*[x×])', a)]
    last = c['before'][-1] if c['before'] else ''
    m = re.match(r"^(?:\[I+ \d+\]\s*)?(?:\d{1,3}\.\s+)?(.{8,140}?)[:.]", last)
    title = (m.group(1) if m and re.match(r'(To|For|If|Whoever|Against|In order)', m.group(1)) else None) or c['head'] or re.split(r'[:(—;]', note)[0][:90]
    out.append({"id": f['id'], "page": f['page'], "ch": chof(f['page']), "title": title.strip(), "note": note, "text": c['before'][-2:] + after})
    im = ImageOps.autocontrast(Image.open(FI[f['id']]['file']).convert('L'), cutoff=2)
    sc = 1600 / max(im.size)
    if sc > 1: im = im.resize((int(im.width * sc), int(im.height * sc)), Image.LANCZOS)
    im = im.filter(ImageFilter.MedianFilter(3)).point(lambda v: 0 if v < 150 else 255).convert('1')
    b = io.BytesIO(); im.save(b, 'PNG', optimize=True)
    packs.setdefault(f['id'] // 100, {})[str(f['id'])] = "data:image/png;base64," + base64.b64encode(b.getvalue()).decode()
json.dump(out, open('talismans.json', 'w'), ensure_ascii=False)
for k, v in packs.items():
    fn = f'pub/book/sketch_{k}.json'; json.dump(v, open(fn, 'w'), separators=(',', ':')); print(fn, len(v), round(os.path.getsize(fn) / 1e6, 1))
print(len(out))

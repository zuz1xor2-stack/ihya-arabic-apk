"""Pack the reader into one file per chapter (text, Arabic line images, figure images) plus a text-only search index."""
import json, os, base64, re
OUT = "pub/book"; os.makedirs(OUT, exist_ok=True)
SEALED = set(json.load(open("reader/sealed_figs.json")))
FIGS = json.load(open("figs_index.json"))
b64 = lambda p: "data:image/webp;base64," + base64.b64encode(open(p, "rb").read()).decode()
search = []
for ch in range(22):
    items = json.load(open(f"reader/ch{ch:02d}.json"))
    img, figimg = {}, {}
    page = None
    for it in items:
        if it["k"] == "pg": page = it["p"]
        if it["k"] == "ar": img[it["src"]] = b64(f"reader/ar/{it['src']}")
        if it["k"] in ("p", "h1", "h2", "src", "seal"): search.append([ch, page, it["k"], it["t"]])
    json.dump({"ch": ch, "items": items, "img": img, "figimg": figimg}, open(f"{OUT}/ch{ch:02d}.json", "w"), ensure_ascii=False, separators=(",", ":"))
json.dump(search, open(f"{OUT}/search.json", "w"), ensure_ascii=False, separators=(",", ":"))
for f in sorted(os.listdir(OUT)): print(f, round(os.path.getsize(f"{OUT}/{f}") / 1e6, 2))

packs = {}
for f in sorted(os.listdir("clear")):
    i = int(f[:3])
    if i in SEALED: continue
    packs.setdefault(i // 100, {})[str(i)] = b64(f"clear/{f}")
for k, v in packs.items(): json.dump(v, open(f"{OUT}/figs_{k}.json", "w"), separators=(",", ":"))
print("figure packs", {k: len(v) for k, v in packs.items()})

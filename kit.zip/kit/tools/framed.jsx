/** A square set in the book's standard plate: the ruled frame crossing at the corners and the four archangels on its
 *  sides (Jibrāʾīl above, ʿAzrāʾīl right, Mīkāʾīl left, Isrāfīl below — as on the plates of chapter 19). Grid as printed. */
function FramedPlate({ grid, hue = "#ece6d8", size = 300 }) {
  const n = grid.length, cs = Math.max(18, Math.min(56, Math.floor((size - 90) / n))), side = n * cs;
  const pad = Math.round(cs * 0.9) + 26, W = side + pad * 2, o = pad;
  const off = Math.round(cs * 0.45) + 6, over = Math.round(cs * 0.35) + 6, a = o - off, b = o + side + off;
  const fs = Math.max(11, Math.min(18, cs * 0.42));
  return <svg viewBox={`0 0 ${W} ${W}`} width={W} height={W} style={{ maxWidth: "100%", height: "auto" }}>
    {grid.map((row, r) => row.map((v, c) => {
      const x = o + c * cs, y = o + r * cs, s = v == null ? "" : String(v), ar = /[؀-ۿ]/.test(s);
      return <g key={r + "-" + c}>
        <rect x={x} y={y} width={cs} height={cs} fill="none" stroke="#ffffff44" strokeWidth="0.8" />
        <text x={x + cs / 2} y={y + cs / 2} textAnchor="middle" dominantBaseline="central" fill="#ece6d8"
          fontFamily={ar ? F.ar : F.mono}
          fontSize={ar ? Math.min(cs * 0.5, cs * 1.7 / Math.max(2, [...s].length)) : cs * (s.length > 4 ? 0.22 : s.length > 3 ? 0.27 : 0.33)}>{s}</text>
      </g>; }))}
    {[[a - over, a, b + over, a], [a - over, b, b + over, b], [a, a - over, a, b + over], [b, a - over, b, b + over]].map(([x1, y1, x2, y2], i) =>
      <line key={i} x1={x1} y1={y1} x2={x2} y2={y2} stroke={hue} strokeWidth="1.6" />)}
    <text x={W / 2} y={a - 8} textAnchor="middle" fontFamily={F.ar} fontSize={fs} fill={hue}>جبرائيل</text>
    <text x={W / 2} y={b + fs + 4} textAnchor="middle" fontFamily={F.ar} fontSize={fs} fill={hue}>اسرافيل</text>
    <text x={a - 8} y={W / 2} textAnchor="middle" fontFamily={F.ar} fontSize={fs} fill={hue} transform={`rotate(-90,${a - 8},${W / 2})`}>ميكائيل</text>
    <text x={b + 8} y={W / 2} textAnchor="middle" fontFamily={F.ar} fontSize={fs} fill={hue} transform={`rotate(90,${b + 8},${W / 2})`}>عزرائيل</text>
  </svg>;
}

/** Figure images, cleaned and enlarged from the page, published beside the engine in packs of a hundred. */
const FIGPACK_CACHE = {};
function loadFigPack(k) {
  if (!FIGPACK_CACHE[k]) FIGPACK_CACHE[k] = fetch(`book/figs_${k}.json`)
    .then(r => { if (!r.ok) throw new Error(r.status); return r.json(); })
    .catch(e => { delete FIGPACK_CACHE[k]; throw e; });
  return FIGPACK_CACHE[k];
}
function FigImage({ id, alt, style }) {
  const [src, setSrc] = useState(null);
  useEffect(() => { let live = true; loadFigPack(Math.floor(id / 100)).then(p => live && setSrc(p[String(id)] || "")).catch(() => live && setSrc("")); return () => { live = false; }; }, [id]);
  if (src === null) return <div style={{ fontFamily: F.mono, fontSize: 10.5, color: "#ffffff55", padding: 8 }}>loading the figure…</div>;
  if (!src) return null;
  return <img src={src} alt={alt || "figure"} loading="lazy" style={{ display: "block", maxWidth: "100%", margin: "0 auto", filter: "invert(0.92) sepia(0.18)", ...style }} />;
}

/** The figures of the whole book in one place: talismans, seals, circles, squares — each clear, captioned and cited. */
function Gallery({ hue, go }) {
  const [kind, setKind] = useState("talismans");
  const [ch, setCh] = useState("all");
  const [open, setOpen] = useState(null);
  const sealed = useMemo(() => new Set(BOOK.sealedFigs || []), []);
  const list = BOOK.figs.filter(f => !sealed.has(f.id)
    && (kind === "all" || (kind === "talismans" ? f.status === "figure" : kind === "squares" ? !!f.grid : kind === "corrected" ? !!f.corrected : !!f.plain))
    && (ch === "all" || f.ch === +ch));
  return <div>
    <H2 hue={hue} sub="every figure of the book, cleaned and enlarged from the page — talismans, seals, circles and squares">Ashkāl</H2>
    <div style={{ display: "flex", gap: 6, flexWrap: "wrap", alignItems: "center" }}>
      {[["talismans", "talismans, seals & circles"], ["squares", "squares"], ["plain", "squares given their frame"], ["corrected", "corrected squares"], ["all", "everything"]].map(([k, l]) =>
        <Btn key={k} hue={hue} small active={kind === k} onClick={() => setKind(k)}>{l}</Btn>)}
      <select value={ch} onChange={e => setCh(e.target.value)} style={{ ...inputBase, padding: "4px 8px", fontSize: 12 }}>
        <option value="all">all chapters</option>
        {BOOK.chapters.map(c => <option key={c.ch} value={c.ch}>{CHNAME(c.ch)}</option>)}</select>
      <span style={{ fontFamily: F.mono, fontSize: 11, color: "#ffffff88" }}>{list.length} figures</span>
    </div>
    <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(240px,1fr))", gap: 10, marginTop: 14 }}>
      {list.map(f => <button key={f.id} onClick={() => setOpen(f)} style={{ textAlign: "left", background: "#00000044", border: "1px solid #ffffff18",
        borderRadius: 3, padding: 8, cursor: "zoom-in", color: "inherit" }}>
        <div style={{ height: 190, overflow: "hidden", display: "flex", alignItems: "center", justifyContent: "center" }}>
          {f.plain && f.grid ? <FramedPlate grid={f.grid} hue={hue} size={200} /> : <FigImage id={f.id} style={{ maxHeight: 186 }} />}</div>
        <div style={{ fontFamily: F.mono, fontSize: 10, color: hue, marginTop: 6 }}>#{f.id} · p.{f.page} · {CHNAME(f.ch)}</div>
        <div style={{ fontSize: 12, color: "#ffffffaa", lineHeight: 1.45, maxHeight: 52, overflow: "hidden" }}>{f.note || ""}</div>
      </button>)}
    </div>
    {open && <div onClick={() => setOpen(null)} style={{ position: "fixed", inset: 0, background: "#000000e6", zIndex: 50, overflowY: "auto", padding: "24px 16px" }}>
      <div onClick={e => e.stopPropagation()} style={{ maxWidth: 980, margin: "0 auto", background: "#0d0b08", border: `1px solid ${hue}55`, borderRadius: 4, padding: 16 }}>
        <div style={{ display: "flex", justifyContent: "space-between", gap: 8, flexWrap: "wrap", alignItems: "center" }}>
          <span style={{ fontFamily: F.mono, fontSize: 11, color: hue }}>#{open.id} · p.{open.page} · {CHNAME(open.ch)}</span>
          <span style={{ display: "flex", gap: 6 }}>
            <Btn hue={hue} small onClick={() => { setOpen(null); go("kitab", { chapter: open.ch, page: open.page, view: "read" }); }}>read the page</Btn>
            <Btn hue={hue} small onClick={() => setOpen(null)}>close</Btn></span>
        </div>
        <div style={{ marginTop: 12 }}><FigImage id={open.id} style={{ maxHeight: "75vh" }} /></div>
        {open.grid && <div style={{ display: "flex", justifyContent: "center", marginTop: 14 }}><FramedPlate grid={open.grid} hue={hue} size={460} /></div>}
        <div style={{ marginTop: 10 }}><FigCard f={open} hue={hue} /></div>
      </div>
    </div>}
  </div>;
}


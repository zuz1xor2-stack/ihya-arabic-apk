const SIGNS12 = ["Aries","Taurus","Gemini","Cancer","Leo","Virgo","Libra","Scorpio","Sagittarius","Capricorn","Aquarius","Pisces"];
/** p.242: the day of the Arabic month × 2 + 5, counted off five to a sign from the sign the Sun is in. */
function bookMoonSign(date = new Date()) {
  const h = hijri(date); if (!h) return null;
  const n = 2 * h.d + 5, steps = Math.ceil(n / 5), sun = Math.floor(sunLongitude(date) / 30);
  return { day: h.d, n, steps, sun: SIGNS12[sun], sign: SIGNS12[(sun + steps - 1) % 12] };
}

function MyRecords({ hue }) {
  const [msg, setMsg] = useState("");
  const keys = () => { const out = {}; try { for (let i = 0; i < localStorage.length; i++) { const k = localStorage.key(i); if (k.startsWith("ihya:")) out[k] = localStorage.getItem(k); } } catch {} return out; };
  const exp = () => { const d = keys(); download(`ihya-my-records-${new Date().toISOString().slice(0, 10)}.json`, JSON.stringify(d, null, 1), "application/json"); setMsg(`${Object.keys(d).length} records saved to a file`); };
  const imp = (file) => { const r = new FileReader(); r.onload = () => { try { const d = JSON.parse(r.result); let n = 0;
    for (const [k, v] of Object.entries(d)) if (k.startsWith("ihya:")) { localStorage.setItem(k, v); n++; } setMsg(`${n} records restored — reopen the engine to see them`); } catch { setMsg("that file is not an Iḥyāʾ records file"); } }; r.readAsText(file); };
  const c = keys(), n = k => { try { const v = JSON.parse(c["ihya:" + k] || "null"); return Array.isArray(v) ? v.length : v && typeof v === "object" ? Object.keys(v).length : 0; } catch { return 0; } };
  return <div style={{ border: `1px solid ${hue}55`, padding: 14, borderRadius: 3 }}>
    <div style={{ fontFamily: F.mono, fontSize: 10, color: hue }}>YOUR RECORDS · KEPT ON THIS DEVICE</div>
    <div style={{ fontSize: 13, color: "#ffffffaa", lineHeight: 1.7, marginTop: 6 }}>
      {n("bookmarks")} bookmarks · {n("highlights")} highlighted passages · {n("talismanNotes")} talisman notes · {n("visited")} pages read · {n("review")} review verdicts</div>
    <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginTop: 8, alignItems: "center" }}>
      <Btn hue={hue} small onClick={exp}>save to a file</Btn>
      <label style={{ fontFamily: F.mono, fontSize: 11, color: hue, border: `1px solid ${hue}77`, padding: "5px 10px", borderRadius: 2, cursor: "pointer", textTransform: "uppercase" }}>restore from a file
        <input type="file" accept="application/json" onChange={e => e.target.files[0] && imp(e.target.files[0])} style={{ display: "none" }} /></label>
      {msg && <span style={{ fontSize: 12, color: "#8fce7f" }}>{msg}</span>}</div>
    <div style={{ fontSize: 11.5, color: "#ffffff66", marginTop: 6 }}>Move them to another phone or computer by saving here and restoring there.</div>
  </div>;
}

function Highlights({ hue, go }) {
  const [h, setH] = useState(() => LS.get("highlights", {}));
  const list = Object.entries(h).sort((a, b) => (a[1].ch - b[1].ch) || (a[1].p - b[1].p));
  if (!list.length) return null;
  return <div style={{ border: `1px solid ${hue}55`, padding: 14, borderRadius: 3 }}>
    <div style={{ fontFamily: F.mono, fontSize: 10, color: hue }}>PASSAGES YOU HIGHLIGHTED · {list.length}</div>
    {list.slice(0, 30).map(([k, v]) => <div key={k} style={{ display: "flex", gap: 8, alignItems: "baseline", padding: "5px 0", borderBottom: "1px solid #ffffff0d" }}>
      <button onClick={() => go("kitab", { chapter: v.ch, page: v.p, view: "read" })} style={{ background: "none", border: "none", color: hue, fontFamily: F.mono, fontSize: 10.5, cursor: "pointer", flexShrink: 0 }}>p.{v.p}</button>
      <span style={{ fontSize: 13, color: "#ffffffaa", lineHeight: 1.5 }}>{v.t.slice(0, 180)}{v.t.length > 180 ? "…" : ""}</span>
      <button onClick={() => { const n = { ...h }; delete n[k]; setH(n); LS.set("highlights", n); }} style={{ background: "none", border: "none", color: "#ffffff55", cursor: "pointer" }}>×</button></div>)}
  </div>;
}


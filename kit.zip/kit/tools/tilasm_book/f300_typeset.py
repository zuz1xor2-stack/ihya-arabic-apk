# Talismans re-set in type: the book's words in clean Amiri on freshly drawn lines, laid out as printed.
import math
VERSE_86_4 = "ان كل نفس لما عليها حافظ"

# ── #56 · p.352 · the Greatest Signet ──
add(id="f56", fig=56, page=352, group="seal", title="The Greatest Signet — the circle of the Names",
    desc="The Greatest Signet (p.352): an open ring inscribed «Allāh lā ilāha illā huwa l-ḥayyu l-qayyūm» above and «wa-ʿanati l-wujūhu li-l-ḥayyi l-qayyūm» (Q 20:111) below, holding columns of the Names — written for love and reconciliation, with the names of the two parties, on Sunday in the hour of the Sun or of Mercury, after fumigating with aloeswood, ambergris, benzoin, musk and mastic.",
    els=[dict(t="circle", r=440, a0=110, a1=430), dict(t="circle", r=360, a0=110, a1=430),
         dict(t="line", pts=[[500 + 440 * math.sin(math.radians(110)), 500 - 440 * math.cos(math.radians(110))], [500 + 360 * math.sin(math.radians(110)), 500 - 360 * math.cos(math.radians(110))]]),
         dict(t="line", pts=[[500 + 440 * math.sin(math.radians(70)), 500 - 440 * math.cos(math.radians(70))], [500 + 360 * math.sin(math.radians(70)), 500 - 360 * math.cos(math.radians(70))]]),
         dict(t="ring", r=400, text="الله لا اله الا هو الحي القيوم", size=40, fit="natural", center=0, label="upper arc"),
         dict(t="ring", r=400, text="وعنت الوجوه للحي القيوم", size=40, fit="natural", center=180, inward=True, label="lower arc (Q 20:111)"),
         *[dict(t="text", x=500, y=y, text=w, size=46, label="middle column") for y, w in zip((200, 330, 460, 590, 720), ("عليم", "عظيم", "سميع", "غفور", "باعث"))],
         *[dict(t="text", x=330, y=y, text=w, size=46, rot=-90, label="left column") for y, w in zip((230, 420, 610), ("سريع", "عدل", "عزيز"))],
         *[dict(t="text", x=670, y=y, text=w, size=46, rot=90, label="right column") for y, w in zip((210, 380, 550, 700), ("رفيع", "نافع", "واسع", "فعال"))],
         dict(t="line", pts=[[415, 170], [415, 760]]), dict(t="line", pts=[[585, 170], [585, 760]]),
         text(500, 880, "{person}", 36, maxw=420, off=True, label="the two names (for reconciliation)")],
    how=["Draw the open ring, its opening to the right; write «Allāh lā ilāha illā huwa l-ḥayyu l-qayyūm» along its top and «wa-ʿanati l-wujūhu li-l-ḥayyi l-qayyūm» along its foot.",
         "Within, set the Names in three columns.",
         "For love or reconciliation, write with it the names of the two parties; dissolve in water and give it to them to drink (p.351).",
         "Write by day on Sunday, in the hour of the Sun or of Mercury, after fumigating with aloeswood, nadd, ambergris, benzoin, musk and mastic."],
    notes=["Re-set from the facsimile: the Names follow the figure's columns where legible (ʿAlīm, ʿAẓīm, Samīʿ, Ghafūr; Sarīʿ, ʿAdl, ʿAzīz; Rafīʿ, Nāfiʿ, Wāsiʿ). The fifth of the middle column is worn and is supplied as al-Bāʿith from the book's list of twenty (p.352).",
           "The small worn words at the foot of the figure and the side word at the left are not reproduced."])

# ── #297 · p.1721 · Q 86:4 — typeset whole ──
add(id="f297", fig=297, page=1721, group="square", title="Every soul has a guardian — the 3×3 of Q 86:4",
    desc="The threefold on 1467 — ﴿in kullu nafsin lammā ʿalayhā ḥāfiẓ﴾ (Q 86:4) with the Basmala — in the archangels' frame, the verse written seven times round it (p.1721). Carried on the person, so cast in its air form.",
    forge=dict(cells=[[486, 491, 490], [493, 489, 485], [488, 487, 492]], book=1467),
    els=[*angel_frame(330, 300, 690, 660, size=40, over=40),
         grid(350, 320, 320, fs=46),
         dict(t="ltext", x1=70, y1=110, x2=930, y2=110, text=VERSE_86_4, size=40, rep=2, sep="   ", label="the verse · above"),
         dict(t="ltext", x1=110, y1=150, x2=110, y2=860, text=VERSE_86_4, size=30, rep=2, sep="  ", label="the verse · left"),
         dict(t="ltext", x1=890, y1=150, x2=890, y2=860, text=VERSE_86_4, size=40, rep=1, label="the verse · right"),
         dict(t="ltext", x1=70, y1=905, x2=930, y2=905, text=VERSE_86_4, size=40, rep=2, sep="   ", label="the verse · below"),
         dict(t="rect", x=40, y=60, w=920, h=890), dict(t="rect", x=160, y=170, w=680, h=680)],
    how=["Value of the verse with the Basmala: 1467. Subtract 12, divide by 3: 485 in the first cell, adding one each step (the first rule of the threefold).",
         "Set the square in its air form, since it is carried; the four archangels on its sides.",
         "Write the verse seven times round it — twice above, twice on the left, once on the right, twice below — then recite it over the square."],
    notes=["The printed square closes on 1467 every way.", "Typeset from the book; the print's lower band is in mirrored writing."])

# ── #106 · p.822 · the back of the mirror ──
add(id="f106", fig=106, page=822, group="seal", title="The talisman for the back of the mirror",
    desc="Written on the back of a mirror to call the angel of the day (pp.821–822): a square of lines that run past its corners, a row of hāʾ above and below, and the angel's name in the centre.",
    slots=dict(angel="اسم الملك"),
    els=[line((170, 180), (830, 180)), line((170, 760), (830, 760)), line((230, 120), (230, 820)), line((770, 120), (770, 820)),
         dict(t="ltext", x1=300, y1=260, x2=700, y2=260, text="هـــ", size=56, rep=4, sep="   ", label="hāʾ above"),
         text(500, 470, "{angel}", 66, maxw=430, label="the angel's name"),
         dict(t="ltext", x1=300, y1=690, x2=700, y2=690, text="هـــ", size=56, rep=4, sep="   ", label="hāʾ below"),
         text(500, 900, "{name}", 36, maxw=600, off=True, label="your line (not in the book)")],
    how=["Rule the square with its lines running past the corners.", "Write four hāʾ above and four below.",
         "In the centre write the name of the angel of the day — Sarfiyāʾīl on Thursday, ʿAnyāʾīl on Friday, Kasfiyāʾīl on Saturday …",
         "Write it on the back of the mirror."],
    notes=["The four hooked corner-letters of the print are not legible enough to set in type; they are omitted here (see the printed figure)."])

# ── #132 · p.909 and #505 · p.2140 · the cross of five letters ──
for fid, page, L in ((132, 909, dict(c="هـ", t="ط", b="ا", r="ز", l="ج")), (505, 2140, None)):
    if L is None: continue
    add(id=f"f{fid}", fig=fid, page=page, group="seal", title="The cross of five cells", desc="A cross of five cells, a letter in each: ṭāʾ above, hāʾ in the centre, alif below, zāy right and jīm left — the odd letters of budūḥ (p.909).",
        els=[dict(t="rect", x=380, y=120, w=240, h=240), dict(t="rect", x=140, y=360, w=720, h=240), dict(t="rect", x=380, y=600, w=240, h=240),
             line((380, 360), (380, 600)), line((620, 360), (620, 600)),
             text(500, 240, L["t"], 120), text(500, 480, L["c"], 120), text(500, 720, L["b"], 120), text(740, 480, L["r"], 120), text(260, 480, L["l"], 120)],
        notes=["Letters as printed: ط · ج هـ ز · ا."])

# ── #2 · p.17 · Chart II — the twenty-eight mansions in a ring (set from the engine's mansion table) ──
import json as _json, os as _os, re as _re
_src = open(_os.path.join(_os.path.dirname(__file__), "..", "..", "src", "engine.jsx"), encoding="utf-8").read()
_i = _src.index("const DATA = "); _D = _json.loads(_src[_i + 13:_src.index("\n", _i)].rstrip().rstrip(";"))
M = _D["manazil"]
add(id="f2", fig=2, page=17, group="table", title="Chart II — the twenty-eight lunar mansions in their ring",
    desc="The twenty-eight mansions round the zodiac from al-Sharaṭayn at 0° Aries, each with its letter, the letter's value and its element (p.17).",
    els=[dict(t="circle", r=470), dict(t="circle", r=380), dict(t="circle", r=290), dict(t="circle", r=215),
         dict(t="segments", r1=380, r2=470, labels=[m["ar"] for m in M], size=24, radial=True, maxw=80, label="the mansions"),
         dict(t="segments", r1=290, r2=380, labels=[m["letter"] for m in M], size=44, upright=True, spokes=True),
         dict(t="segments", r1=215, r2=290, labels=["".join("٠١٢٣٤٥٦٧٨٩"[int(c)] for c in str(m["letter_value"])) for m in M], size=24, upright=True, spokes=True),
         dict(t="segments", r1=160, r2=215, labels=[{"fire": "ن", "air": "ه", "water": "م", "earth": "ت"}.get(m["element"], "") for m in M], size=30, upright=True, spokes=False),
         text(500, 470, "منازل القمر", 54), text(500, 545, "٢٨", 40)],
    how=["From the top, clockwise: each mansion's name, its letter, the letter's value, and its element (ن fire · ه air · م water · ت earth)."],
    notes=["Set from the engine's mansion table (chapter 3, pp.214–245), the same order as the printed chart."])

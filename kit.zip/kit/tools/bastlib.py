"""The book's basṭ (pp.124–129): a number is spoken in Arabic number-words, the words' letters are summed and
the count of letters added. First basṭ of a letter = B(its value); each further basṭ = B(previous).
Number-words as the book's own table spells them (tens in the -īn form, hundreds with مائة, a thousand الف)."""
V = {"ا":1,"ب":2,"ج":3,"د":4,"ه":5,"و":6,"ز":7,"ح":8,"ط":9,"ي":10,"ك":20,"ل":30,"م":40,"ن":50,"س":60,"ع":70,"ف":80,"ص":90,
     "ق":100,"ر":200,"ش":300,"ت":400,"ث":500,"خ":600,"ذ":700,"ض":800,"ظ":900,"غ":1000,"ة":5,"ى":10,"أ":1,"إ":1,"آ":1,"ء":1,"ئ":10,"ؤ":6}
UNITS = {1:"احد",2:"اثنين",3:"ثلاثة",4:"اربعة",5:"خمسة",6:"ستة",7:"سبعة",8:"ثمانية",9:"تسعة"}
TENS = {10:"عشرة",20:"عشرين",30:"ثلاثين",40:"اربعين",50:"خمسين",60:"ستين",70:"سبعين",80:"ثمانين",90:"تسعين"}
HUND = {100:"مائة",200:"مائتين",300:"ثلاثمائة",400:"اربعمائة",500:"خمسمائة",600:"ستمائة",700:"سبعمائة",800:"ثمانمائة",900:"تسعمائة"}
def ab(s): return sum(V.get(c, 0) for c in s)
def words(n):
    """istinṭāq into letters, each letter's value spoken: units, tens, hundreds, then thousands as الف (with its multiplier spoken)."""
    out = []
    th, n = divmod(n, 1000)
    if th: out += (words(th) if th > 1 else []) + ["الف"]
    h, n = divmod(n, 100); t, u = divmod(n, 10)
    if h: out.append(HUND[h * 100])
    if t: out.append(TENS[t * 10])
    if u: out.append(UNITS[u])
    return out
def B(n):
    w = words(n); return sum(ab(x) for x in w) + sum(len(x) for x in w)
FIRST = {ch: B(v) for ch, v in V.items() if ch in "ابجدهوزحطيكلمنسعفصقرشتثخذضظغ"}
FIRST.update({"ء": FIRST["ا"], "أ": FIRST["ا"], "إ": FIRST["ا"], "آ": FIRST["ا"], "ة": FIRST["ه"], "ى": FIRST["ي"]})  # the book: hamza as alif, tāʾ marbūṭa as hā (p.134)
def first_word(s): return sum(FIRST.get(c, 0) for c in s if c in FIRST)
def chain(n, k=5):
    out = [B(n)]
    for _ in range(k - 1): out.append(B(out[-1]))
    return out
if __name__ == "__main__":
    print(chain(1))           # the book's Alif: 16, 1047, 594, 1641, 991
    print(FIRST)

# ── the basṭ of numbers (basṭ al-ʿadad, pp.176–178) ──
# N1 = the first basṭ; N(k) of a letter = the sum of N(k−1) over the letters of its number-word.
LET = "ابجدهوزحطيكلمنسعفصقرشتثخذضظغ"
NORM = {"ة": "ه", "ء": "ا", "ئ": "ي", "أ": "ا", "إ": "ا", "آ": "ا", "ى": "ي", "ؤ": "و"}
def word_of(ch): return "".join(words(V[ch]))
def number_bast(k_max=5):
    N = [dict((ch, FIRST[ch]) for ch in LET)]
    for _ in range(k_max - 1):
        prev = N[-1]
        N.append({ch: sum(prev[NORM.get(c, c)] for c in word_of(ch)) for ch in LET})
    return N

"""Build book/tilasm.json — every talisman as a composition spec for the Ṭilasm Studio.
Coordinates: a 1000-unit box, centre 500,500. Element types are drawn by tools/tilasm.jsx.
Run: python3 tools/tilasm_specs.py   (the build runs it)."""
import json, os, glob, importlib.util
ROOT = os.path.join(os.path.dirname(__file__), "..")

ANGELS = {"top": "جبرائيل", "right": "عزرائيل", "left": "ميكائيل", "bottom": "اسرافيل"}
BASMALA = "بسم الله الرحمن الرحيم"
FATH = "محمد رسول الله والذين معه اشداء على الكفار رحماء بينهم تراهم ركعا سجدا"
SEALS7 = ["star", "comb", "mim", "lattice", "ladder", "ha", "waw"]

# ── helpers ──
def circle(r, cx=500, cy=500, **k): return dict(t="circle", r=r, cx=cx, cy=cy, **k)
def ring(r, text, size=30, fit="fill", **k): return dict(t="ring", r=r, text=text, size=size, fit=fit, **k)
def text(x, y, s, size=40, **k): return dict(t="text", x=x, y=y, text=s, size=size, **k)
def grid(x, y, size, cells="$forge", **k): return dict(t="grid", x=x, y=y, size=size, cells=cells, **k)
def rect(x, y, w, h, **k): return dict(t="rect", x=x, y=y, w=w, h=h, **k)
def line(*pts, **k): return dict(t="line", pts=[list(p) for p in pts], **k)
def seal(g, x, y, size, **k): return dict(t="seal", g=g, x=x, y=y, size=size, **k)

def angel_frame(x0, y0, x1, y1, names=ANGELS, size=40, over=36, gap=None, label="angels"):
    """The archangels' frame of ch.19's plates: four ruled lines running past the corners, a name on each side."""
    g = gap if gap is not None else size * 0.55
    els = [line((x0 - over, y0), (x1 + over, y0)), line((x0 - over, y1), (x1 + over, y1)),
           line((x0, y0 - over), (x0, y1 + over)), line((x1, y0 - over), (x1, y1 + over))]
    cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
    if names.get("top"): els.append(text(cx, y0 - g - size * 0.35, names["top"], size, label=label + " · top"))
    if names.get("bottom"): els.append(text(cx, y1 + g + size * 0.35, names["bottom"], size, label=label + " · bottom"))
    if names.get("left"): els.append(text(x0 - g - size * 0.35, cy, names["left"], size, rot=-90, label=label + " · left"))
    if names.get("right"): els.append(text(x1 + g + size * 0.35, cy, names["right"], size, rot=90, label=label + " · right"))
    return els

def basmala_cross(r_arm=330, size=34, off=24, centre=True):
    """Course 11: the Basmala on the four arms from the centre outward, once upright and once mirrored."""
    els = []
    for deg in (0, 90, 180, 270):
        import math
        a = math.radians(deg); mid = r_arm / 2 + 40
        x, y = 500 + mid * math.sin(a), 500 - mid * math.cos(a)
        nx, ny = math.cos(a) * off, math.sin(a) * off            # offset across the arm
        rot = deg - 90                                            # text runs outward along the arm
        els.append(text(x - nx, y - ny, BASMALA, size, rot=rot, maxw=r_arm - 40, label=f"arm {deg}° upright"))
        els.append(text(x + nx, y + ny, BASMALA, size, rot=rot, mirror=True, maxw=r_arm - 40, label=f"arm {deg}° mirrored"))
    if centre:
        els.append(circle(62))
        els.append(text(500, 500, "{centre}", 26, maxw=110, label="centre"))
    return els

SPECS = []
def add(**s):
    s.setdefault("els", []); SPECS.append(s); return s

# ═══════════════ Durūs — the lessons' constructions ═══════════════
add(id="d3", src="durus", lesson=3, group="square", title="The Saturn 3×3, written chronologically",
    desc="The 3×3 of Saturn carrying your name or the Basmala, in the archangels' frame. Write the cells in the order of their numbers, 1 to 9 as the book's fill runs, and draw the rules from the top-right corner for fire.",
    forge=dict(order=3), slots=dict(),
    how=["Draw the four horizontal rules, then the verticals, starting at the top-right corner (fire); start at another corner for air, water or earth.",
         "Fill the cells in the order of their numbers — the first, then the second, and so on — not scattered: the course holds this raises its potency.",
         "Write the name above and its value below; the four archangels go on the four sides."],
    els=[*angel_frame(260, 260, 740, 740, size=44), grid(290, 290, 420),
         text(500, 150, "{name}", 54, maxw=600, label="above"), text(500, 862, "{valueIndic}", 44, label="below")])
add(id="d4", src="durus", lesson=4, group="square", title="The Mars 5×5 with its angel",
    desc="The 5×5 of Mars on your value, with Samsamāʾīl, the angel of Mars, written above it.",
    forge=dict(order=5),
    els=[*angel_frame(250, 250, 750, 750, size=40), grid(270, 270, 460),
         text(500, 140, "سمسمائيل", 46, label="angel of Mars"), text(500, 870, "{name}", 44, maxw=560, label="below")])
add(id="d5a", src="durus", lesson=5, group="seal", title="The seven seals — the Greatest Name in a row",
    desc="The seven planetary seals of Solomon in their order: the star, the three strokes under the wave, the mīm, the lattice, the four strokes, the hāʾ and the wāw. Imam ʿAlī called them the Greatest Name.",
    els=[dict(t="seals", x=60, y=430, w=880, size=96), line((60, 520), (940, 520)),
         text(500, 600, "{name}", 50, maxw=760, label="beneath"), text(500, 300, "الاسم الاعظم", 50, label="above")])
add(id="d5b", src="durus", lesson=5, group="seal", title="The seven seals ringed round a name",
    desc="The seven seals set round a circle with your name, or the need, at its heart.",
    els=[circle(440), circle(300), *[seal(g, 500 + 370 * __import__('math').sin(i * 2 * 3.14159265 / 7), 500 - 370 * __import__('math').cos(i * 2 * 3.14159265 / 7), 100) for i, g in enumerate(SEALS7)],
         text(500, 470, "{name}", 50, maxw=480, label="centre"), text(500, 560, "{need}", 34, maxw=480, label="the need")])
add(id="d8", src="durus", lesson=8, group="square", title="The hollow square with a name at its heart",
    desc="The hollow threefold: the border closes on your value by itself, and the open centre carries the name — or the person and the mother's name, which the course says empowers the one named.",
    forge=dict(rule="hollow3"),
    els=[*angel_frame(270, 270, 730, 730, size=42), grid(300, 300, 400), text(500, 160, "{person} بن {mother}", 40, maxw=600, when="person", label="the person"),
         text(500, 860, "{valueIndic}", 40, label="below")])
add(id="d10", src="durus", lesson=10, group="square", title="The ḥurūf talisman of jīm",
    desc="Jīm spelt in full is 53; the 3×3 runs 49–57 with jīm itself in the centre and closes on 159. Round it jīm is written 53 times and Allah round that 66 times — the same figure the book prints on p.88 for the mansion al-Thurayyā.",
    forge=dict(rule="second", order=3, value=53, centre="ج"),
    how=["Take the letter at its spelled value: جيم = 3 + 10 + 40 = 53.",
         "Build the 3×3 with 53 in the centre: 52 57 50 / 51 53 55 / 56 49 54. Every line is 159.",
         "Write the letter jīm itself in the centre in place of 53.",
         "Round the square write jīm 53 times, and Allah round that 66 times.",
         "Keep the intention open — the course warns against aiming it at one named person."],
    els=[grid(380, 380, 240, fs=40), circle(205), ring(232, "ج", 30, rep=53, label="jīm × 53"), circle(262),
         ring(292, "الله", 28, rep=66, label="Allah × 66"), circle(326), text(500, 880, "{name}", 40, maxw=600, label="below")])
add(id="d11", src="durus", lesson=11, group="seal", title="The Basmala cross — the seal of Solomon",
    desc="The Basmala on the four arms, once upright and once mirrored so it reads as a cross of fire; the closing verse of al-Fatḥ round the circle; lā ilāha illā Allāh — or a name — at the centre.",
    slots=dict(centre="لا اله الا الله"),
    els=[circle(470), circle(420), ring(446, FATH, 30, fit="stretch", label="al-Fatḥ ring"), *basmala_cross()])
add(id="d12", src="durus", lesson=12, group="seal", title="The composite Seal of Victory",
    desc="The Basmala cross in its ring, set in a square: the four archangels on the sides (Jibrāʾīl right, Mīkāʾīl left), the four Rightly-Guided Caliphs in the corners, and the name of Imam al-Shādhilī split across two sides. Used with an open intention.",
    slots=dict(centre="لا اله الا الله"),
    how=["Draw the Basmala cross and the ring of al-Fatḥ (course 11).",
         "Set it in a square: Jibrāʾīl on the right, Mīkāʾīl on the left, Isrāfīl above, ʿAzrāʾīl below.",
         "Write the caliphs in the corners: Abū Bakr and ʿUmar above, ʿUthmān and ʿAlī below.",
         "Write al-Shādhilī's name split, “al-” on one side and “Shādhilī” on another.",
         "Optionally ring in maraja l-baḥrayni yaltaqiyān, baynahumā barzakhun lā yabghiyān with the openings."],
    els=[*angel_frame(90, 90, 910, 910, names=dict(top="اسرافيل", bottom="عزرائيل", right="جبرائيل", left="ميكائيل"), size=38, over=0, gap=8),
         text(150, 150, "ابو بكر", 30, rot=-45, label="corner"), text(850, 150, "عمر", 32, rot=45, label="corner"),
         text(150, 850, "عثمان", 30, rot=45, label="corner"), text(850, 850, "علي", 32, rot=-45, label="corner"),
         text(300, 130, "ابو الحسن", 26, label="al-Shādhilī"), text(700, 130, "الشاذلي", 26, label="al-Shādhilī"),
         circle(400), ring(386, "مرج البحرين يلتقيان بينهما برزخ لا يبغيان", 20, fit="fill", off=True, label="the two seas (optional)"),
         circle(372), ring(352, FATH, 26, fit="stretch", label="al-Fatḥ ring"), circle(330), *basmala_cross(r_arm=270, size=27, off=19)])


# ── traced figures with parts rebuilt: coordinates for `els`/`cut`/`cuts` are given in the tracing's own units ──
_TR = None
def trace_dims(fid):
    global _TR
    if _TR is None:
        _TR = {}
        for k in range(6):
            p = os.path.join(ROOT, "book", f"plot_{k}.json")
            if os.path.exists(p):
                for i, e in json.load(open(p)).items(): _TR[int(i)] = (e["w"], e["h"])
    return _TR[fid]
_SCALE_KEYS = ("x", "y", "x1", "y1", "x2", "y2", "r", "cx", "cy", "size", "maxw", "w", "h", "r1", "r2")
def traced(fid, page, title, desc, els=(), cut=None, cuts=(), n=3, m=3, forge=None, extra_h=90, **kw):
    tw, th = trace_dims(fid); sc = 1000 / max(tw, th)
    out = [dict(t="trace", fig=fid, s=sc, cut=cut, cuts=[list(c) for c in cuts], n=n, m=m, label="the printed figure")]
    if cut: out.append(dict(t="grid", x=cut[0] * sc, y=cut[1] * sc, size=(cut[2] - cut[0]) * sc, h=(cut[3] - cut[1]) * sc, cells="$forge", lines=False))
    for e in els:
        e = dict(e)
        for k in _SCALE_KEYS:
            if k in e and isinstance(e[k], (int, float)): e[k] = e[k] * sc
        if "pts" in e: e["pts"] = [[a * sc, b * sc] for a, b in e["pts"]]
        out.append(e)
    W, H = round(tw * sc), round(th * sc)
    out.append(text(W / 2, H + 45, "{name}", 40, maxw=W * 0.8, off=True, label="your line (not in the book)"))
    return add(id=f"f{fid}", fig=fid, page=page, title=title, desc=desc, w=W, h=H + extra_h, els=out, forge=forge, **kw)

# ═══════════════ The book's figures (authored figure by figure from the facsimiles) ═══════════════
for f in sorted(glob.glob(os.path.join(os.path.dirname(__file__), "tilasm_book", "*.py"))):
    spec = importlib.util.spec_from_file_location(os.path.basename(f)[:-3], f); m = importlib.util.module_from_spec(spec)
    m.__dict__.update(dict(add=add, circle=circle, ring=ring, text=text, grid=grid, rect=rect, line=line, seal=seal, angel_frame=angel_frame,
                           basmala_cross=basmala_cross, traced=traced, trace_dims=trace_dims, ANGELS=ANGELS, BASMALA=BASMALA, FATH=FATH, SEALS7=SEALS7))
    spec.loader.exec_module(m)


# ═══════════════ every other figure of the book: the printed figure as vector, its square rebuilt in place ═══════════════
def _book():
    src = open(os.path.join(ROOT, "src", "engine.jsx"), encoding="utf-8").read()
    i = src.index("const BOOK = "); j = src.index("/*@END*/", i)
    return json.loads(src[i + 13:j].rstrip().rstrip(";"))
BOOKD = _book()
TRACES = {}
for k in range(6):
    p = os.path.join(ROOT, "book", f"plot_{k}.json")
    if os.path.exists(p):
        for fid, e in json.load(open(p)).items(): TRACES[int(fid)] = (e["w"], e["h"])
GRIDBOX = json.load(open(os.path.join(os.path.dirname(__file__), "tilasm_gridbox.json")))
SEALED_HERE = {364, 365, 390}   # taskhīr of a named person: indexed, never made operable (house rule 5)
TABLES = {0, 1, 3, 15, 17, 24, 51, 52, 110, 140, 163, 164, 165, 168, 169, 170, 171, 172, 173, 207, 208, 209, 218, 222, 223, 234, 383, 455, 456, 534, 535, 536, 537, 538, 33, 34}
sealed = set(BOOKD.get("sealedFigs", []))
tal = {t["id"]: t for t in BOOKD.get("talismans", [])}
done = {s.get("fig") for s in SPECS if s.get("fig") is not None}
def _title(f):
    if f["id"] in tal: return tal[f["id"]]["title"]
    n = (f.get("note") or "").split(":")[0].split(";")[0].split(" (")[0].strip()
    return (n[:88] + "…") if len(n) > 90 else (n or f"Figure {f['id']}")
for f in BOOKD["figs"]:
    fid = f["id"]
    if fid in sealed or fid in done or fid not in TRACES or fid in SEALED_HERE: continue
    tw, th = TRACES[fid]; sc = 1000 / max(tw, th); W, H = round(tw * sc), round(th * sc)
    spec = dict(id=f"f{fid}", fig=fid, page=f["page"], ch=f["ch"], title=_title(f), desc=f.get("note", ""), auto=True,
                group="table" if fid in TABLES else ("square" if f.get("grid") else "seal"), w=W, h=H + 90, els=[])
    gb = GRIDBOX.get(str(fid))
    if f.get("grid") and gb and gb.get("bbox") and fid not in TABLES:
        k = tw / gb["iw"]; x0, y0, x1, y1 = [v * k for v in gb["bbox"]]
        spec["forge"] = dict(fig=fid)
        n = len(f["grid"]); m = len(f["grid"][0])
        spec["els"].append(dict(t="trace", fig=fid, s=sc, cut=[x0, y0, x1, y1], n=n, m=m, label="the printed figure"))
        spec["els"].append(dict(t="grid", x=x0 * sc, y=y0 * sc, size=(x1 - x0) * sc, h=(y1 - y0) * sc, cells="$forge", lines=False))
        spec["how"] = ["The square is rebuilt for your name or number on the book's own figure and re-summed; everything around it — the frame, the angels, the rings and the written lines — is the printed figure itself, carried as vector."]
    else:
        spec["els"].append(dict(t="trace", fig=fid, s=sc, label="the printed figure"))
        spec["how"] = ["The figure as printed, carried as vector line so it prints and plots cleanly at any size. Add your own lines below."]
    spec["els"].append(text(W / 2, H + 45, "{name}", 40, maxw=W * 0.8, off=True, label="your line (not in the book)"))
    SPECS.append(spec)

_seen = {}
for _s in SPECS: _seen[_s["id"]] = _s          # a later definition of the same figure replaces the earlier
SPECS[:] = list(_seen.values())
for s in SPECS:
    if s.get("fig") is not None and (not s.get("title") or not s.get("desc") or not s.get("page")):
        f = next((x for x in BOOKD["figs"] if x["id"] == s["fig"]), {}); t = tal.get(s["fig"], {})
        s["title"] = s.get("title") or t.get("title") or _title(f); s["desc"] = s.get("desc") or f.get("note", ""); s["page"] = s.get("page") or f.get("page"); s.setdefault("ch", f.get("ch"))
    s.setdefault("src", "book")
    for e in s["els"]: e.pop("r_", None)
json.dump({"version": 1, "list": SPECS}, open(os.path.join(ROOT, "book", "tilasm.json"), "w", encoding="utf-8"), ensure_ascii=False, separators=(",", ":"))
print(f"tilasm: {len(SPECS)} specs ({sum(1 for s in SPECS if not s.get('auto') and s['src']=='book')} reconstructed by hand) ({sum(1 for s in SPECS if s['src'] == 'book')} from the book)")

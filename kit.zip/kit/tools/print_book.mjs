import { chromium } from 'playwright';
import fs from 'fs';
const parts = JSON.parse(fs.readFileSync('edition/parts.json'));
const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' });
const p = await b.newPage();
for (const f of parts) {
  await p.goto('file://' + process.cwd() + '/' + f, { waitUntil: 'load', timeout: 120000 });
  await p.waitForTimeout(300);
  await p.waitForFunction(() => document.title === 'ready' || !document.querySelector('section.page'), null, { timeout: 300000 }); await p.pdf({ path: f.replace('.html', '.pdf'), preferCSSPageSize: true, printBackground: true });
  console.log('printed', f);
}
await b.close();

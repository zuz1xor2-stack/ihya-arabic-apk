"""Corrections to the figure records (BOOK.figs / BOOK.talismans) found while deciphering the figures for the
Ṭilasm Studio. Idempotent: run by the build after the splice."""
import json, os, re
ROOT = os.path.join(os.path.dirname(__file__), "..")
SRC = os.path.join(ROOT, "src", "engine.jsx")
FIX = {
  9: dict(title="The wafq of al-Thurayyā (letter jīm) under its hood",
          note="The wafq of the third mansion, al-Thurayyā, whose letter is jīm (p.88): a 3×3 of 49–57 round the letter jīm (53) — ٥٢ ٥٧ ٥٠ / ٥١ ج ٥٥ / ٥٦ ٤٩ ٥٤, every line 159 — ringed by bismillāh, a band of jīm and Allah, under a hooded triangle of the same bands. Made in the mansion's exaltation and carried, for access to the great.",
          text=["The third of the mansions is the mansion of al-Thurayyā, and to it belongs the letter (jīm). … It has a mighty wafq, which is made during its exaltation and is carried, and with it one goes in upon the nobles; whoever carries it attains his object from them, and they love him and obey him in his affair … This is the form of its layout, as you see."],
          fix="the figure had been attached to the paragraph on al-Buṭayn (p.87); it belongs to al-Thurayyā (p.88)"),
  8: dict(title="The wafq of the letter alif, ringed by alifs",
          note="The wafq of the letter alif (Fig. 5, p.87): a 4×4 in manuscript numerals with a word in one cell, ringed by a band of alifs (the upright strokes) and a ring of Allah, with a stem of strokes beneath and marginal lines. The numerals are too worn to rebuild with certainty."),
  75: dict(title="Barhashin — the name in the seal-script",
           note="The eighth name, Barhashin, written in the seal-script (pp.720–721) — the same line as figure 76, printed on both pages.",
           fix="the record described a 4×4 square in the archangels' frame; the figure is the name's line of seal-signs"),
  202: dict(title="The fourfold of Q 6:122 (784)", note="The fourfold of ﴿awa-man kāna maytan fa-aḥyaynāhu﴾ (Q 6:122), value 784: ١٩٥ ١٩٩ ٢٠٢ ١٨٨ / ٢٠١ ١٨٩ ١٩٤ ٢٠٠ / ١٩٠ ٢٠٤ ١٩٧ ١٩٣ / ١٩٨ ١٩٢ ١٩١ ٢٠٣ — every line 784; set at the centre of the Junnat al-Asmāʾ circle (p.1353)."),
  203: dict(title="Junnat al-Asmāʾ — the circle of the Names"),
  226: dict(title="The circle of the Basmala, for the bearer"),
  238: dict(title="The Seal of Obedience (khātam al-ṭāʿa)"),
  297: dict(title="Every soul has a guardian — the 3×3 of Q 86:4"),
  512: dict(title="The mirror working of al-Fātiḥa — budūḥ in the angels' frame"),
  106: dict(title="The talisman for the back of the mirror"),
}
GENERIC = {"Faṣl", "A manuscript figure", "A manuscript seal", "A manuscript facsimile", "Reference Charts", "A ruled frame",
           "A manuscript circle", "A manuscript table", "A circular figure", "Circular talisman", "3×3 wafq"}
def better(note):
    n = re.split(r" \(p\.\d+\)|: | — |; ", note or "")[0].strip().rstrip(".")
    return n[:88] + "…" if len(n) > 90 else n
s = open(SRC, encoding="utf-8").read()
i = s.index("const BOOK = "); j = s.index("/*@END*/", i)
B = json.loads(s[i + 13:j].rstrip().rstrip(";"))
fixes = []
tal = {t["id"]: t for t in B["talismans"]}
for f in B["figs"]:
    x = FIX.get(f["id"], {})
    if "note" in x: f["note"] = x["note"]
    if x.get("fix"): f["fixed"] = x["fix"]
for t in B["talismans"]:
    x = FIX.get(t["id"], {})
    for k in ("title", "note", "text"):
        if k in x: t[k] = x[k]
    if t["title"] in GENERIC and t["id"] not in FIX:
        t["title"] = better(t["note"]) or t["title"]
B["figFixes"] = [dict(id=k, fix=v["fix"]) for k, v in FIX.items() if v.get("fix")]
s = s[:i + 13] + json.dumps(B, ensure_ascii=False, separators=(",", ":")) + ";" + s[j:]
open(SRC, "w", encoding="utf-8").write(s)
print(f"figure records corrected: {len(FIX)} by hand, generic titles rewritten from their notes")

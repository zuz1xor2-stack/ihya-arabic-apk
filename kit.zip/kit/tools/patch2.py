"""v1.5: the engine organised as the book. engine_v14.jsx → engine_v15.jsx (BOOK data spliced by build_data.py)."""
src = open('engine_v14.jsx', encoding='utf-8').read()
kit = open('kitab.jsx', encoding='utf-8').read()
def rep(old, new, count=1):
    global src
    n = src.count(old); assert n == count, f"{n}× {old[:60]!r}"
    src = src.replace(old, new)

rep("/* ═══ shell ═══ */", kit + "\n/* ═══ shell ═══ */")
rep('const TABS = [["majlis","Majlis",Majlis],', 'const TABS = [["kitab","Kitāb",Kitab],["majlis","Majlis",Majlis],')
rep('export default function App() {\n  const [tab, setTab] = useState("majlis");',
'''const GROUPS = [["kitab","Kitāb","the book, in its order"],["alat","Ālāt","instruments"],["tahqiq","Taḥqīq","verification & apparatus"]];
const GROUP_OF = { kitab:"kitab", haqaiq:"kitab", shart:"kitab", book:"kitab", index:"kitab",
  majlis:"alat", forge:"alat", qawaid:"alat", huruf:"alat", bast:"alat", hours:"alat", manazil:"alat", falak:"alat", asma:"alat",
  fawatih:"alat", shields:"alat", sawaqit:"alat", khatam:"alat", wird:"alat", grimoire:"alat", plate:"alat",
  atlas:"tahqiq", tashihat:"tahqiq", method:"tahqiq", concordance:"tahqiq", shurut:"tahqiq", chambers:"tahqiq", works:"tahqiq", glossary:"tahqiq" };
export default function App() {
  const [tab, setTab] = useState("kitab");''')
rep('''    if (e.key === "ArrowRight") j = (i + 1) % TABS.length;
    if (e.key === "ArrowLeft") j = (i - 1 + TABS.length) % TABS.length;
    if (e.key === "Home") j = 0;
    if (e.key === "End") j = TABS.length - 1;
    if (j !== null) { e.preventDefault(); setTab(TABS[j][0]); refs.current[j]?.focus(); }
  }, []);''', '''    const list = TABS.filter(t => GROUP_OF[t[0]] === GROUP_OF[tab]);
    if (e.key === "ArrowRight") j = (i + 1) % list.length;
    if (e.key === "ArrowLeft") j = (i - 1 + list.length) % list.length;
    if (e.key === "Home") j = 0;
    if (e.key === "End") j = list.length - 1;
    if (j !== null) { e.preventDefault(); setTab(list[j][0]); refs.current[j]?.focus(); }
  }, [tab]);''')
rep('''      <nav role="tablist" aria-label="Modules" style={{ display: "flex", gap: 2, marginTop: 16, flexWrap: "wrap" }}>
        {TABS.map(([k, label], i) => <button key={k} role="tab" aria-selected={tab === k}''',
'''      <div style={{ display: "flex", gap: 6, marginTop: 16, flexWrap: "wrap" }}>
        {GROUPS.map(([g, label, sub]) => { const on = GROUP_OF[tab] === g;
          return <button key={g} onClick={() => setTab(TABS.find(t => GROUP_OF[t[0]] === g)[0])}
            style={{ background: on ? hue + "22" : "transparent", border: `1px solid ${on ? hue : "#ffffff22"}`, color: on ? "#f0ead9" : "#ffffff99",
              padding: "7px 14px", borderRadius: 2, cursor: "pointer", textAlign: "left" }}>
            <span style={{ fontFamily: F.disp, fontSize: 18 }}>{label}</span>
            <span style={{ fontFamily: F.mono, fontSize: 9.5, letterSpacing: "0.1em", color: on ? hue : "#ffffff66", marginLeft: 8 }}>{sub}</span></button>; })}
      </div>
      <nav role="tablist" aria-label="Modules" style={{ display: "flex", gap: 2, marginTop: 8, flexWrap: "wrap" }}>
        {TABS.filter(t => GROUP_OF[t[0]] === GROUP_OF[tab]).map(([k, label], i) => <button key={k} role="tab" aria-selected={tab === k}''')
rep("      @media print{nav,header>div>div:last-child{display:none}body{background:#fff}}",
    "      @media print{nav,header>div>div:last-child{display:none}body{background:#fff}}\n      @media (max-width:760px){.kitab-grid{grid-template-columns:minmax(0,1fr)!important}.kitab-grid nav{max-height:240px!important}}")
rep('''            uṣūl al-ḥikmah · {DATA.coverage.pct.toFixed(1)}% page coverage · {SPINE.length} records · {DATA.atlas.length} transcribed + {DATA.reconstructed.length} reconstructed squares</div>''',
'''            uṣūl al-ḥikmah · organised as the book · {BOOK.outline.length} headings · {BOOK.workings.length} numbered workings · {BOOK.figs.filter(f => f.status !== "unread" && f.status !== "queued").length} of {BOOK.figs.length} figures read</div>''')
rep("function VisGrid({ vis, hue, mark, hollowText }) {\n  const n = vis.length;\n  const cs = n <= 3",
    "function VisGrid({ vis, hue, mark, hollowText, fit }) {\n  const n = vis.length;\n  const cs = fit ? Math.max(18, Math.min(48, Math.floor(fit / n))) : n <= 3")
rep('DATA.version = "1.4";', 'DATA.version = "1.5";')
open('engine_v15.jsx', 'w', encoding='utf-8').write(src)
print("ok")

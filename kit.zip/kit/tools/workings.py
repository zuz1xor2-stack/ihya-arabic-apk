"""Extract every numbered working (khawāṣṣ item) from the English text, as a structured record.
Fields are facts the text states (purpose phrase, day, hour, element form, square, material, ink, incense,
counts, recitations, page). Harm-directed and person-compelling items keep only title, page and category."""
import re, json, glob

OUT = json.load(open("outline.json"))
CH = sorted({(h["p"], int(h["t"].split()[1])) for h in json.load(open("headings.json")) if h["lvl"] == 1 and h["t"].startswith("Chapter ")}, key=lambda x: x[0])
def chapter_of(p):
    c = 0
    for start, n in CH:
        if p >= start: c = n
    return 21 if p >= 2155 else (c if p >= 58 else 0)
SECS = sorted([o for o in OUT if o["p"]], key=lambda o: o["p"])
def section_of(p):
    c = chapter_of(p); s = None
    for o in SECS:
        if o["p"] <= p and chapter_of(o["p"]) == c: s = o
    return s

pages = {int(f[6:10]): open(f, encoding="utf-8").read() for f in glob.glob("pages/*.txt")}
txt = []
for p in sorted(pages):
    for ln in pages[p].split("\n"):
        s = ln.strip()
        if not s or re.fullmatch(r"\d{1,4}", s): continue
        if re.search(r"[؀-ۿ]", s) and not re.search(r"[A-Za-z]{3}", s): continue  # garbled Arabic layer
        txt.append((p, s))

START = re.compile(r"^(?:\[I+ \d+\]\s*)?(\d{1,3})\.\s+(.*)$")
items, cur = [], None
for p, s in txt:
    m = START.match(s)
    if m and int(m.group(1)) < 200 and re.match(r"(If|For|To|When|Whoever|Write|Should|Against|In order|Take|Recite|On|Whosoever|Anyone|A |The )", m.group(2)):
        if cur: items.append(cur)
        cur = {"n": int(m.group(1)), "p": p, "text": m.group(2)}
    elif cur:
        if re.match(r"^(Chapter \d+|Faṣl|The (First|Second|Third|Fourth|Fifth|Sixth) Rule|How the wafq is made|Manbaʿ)", s) or p - cur["p"] > 3:
            if s.startswith("How the wafq is made"): cur["text"] += " " + s; continue
            items.append(cur); cur = None
        else:
            cur["text"] += " " + s
if cur: items.append(cur)

DAYS = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"]
PLAN = {"Sun":"sun","Shams":"sun","Moon":"moon","Qamar":"moon","Mars":"mars","Mirrīkh":"mars","Mercury":"mercury","ʿUṭārid":"mercury",
        "Jupiter":"jupiter","Mushtarī":"jupiter","Venus":"venus","Zuhra":"venus","Saturn":"saturn","Zuḥal":"saturn"}
INC = ["frankincense","lubān","musk","saffron","oud","agarwood","aloeswood","ambergris","amber","mastic","benzoin","sandalwood","myrrh",
       "storax","labdanum","coriander","rue","wild rue","camphor","cloves","rose","jāwī","kusṭ","costus","sandarac","ṣabr","aloe"]
MAT = ["tin","copper","lead","silver","gold","iron","steel","paper","parchment","deerskin","gazelle","silk","glass","clay","pottery",
       "plate","ring","cloth","egg","candle","wax","leather","tablet","bone"]
SQUARE = [("threefold",3),("three-by-three",3),("3×3",3),("fourfold",4),("four-by-four",4),("4×4",4),("fivefold",5),("five-celled",5),
          ("5×5",5),("5x5",5),("sixfold",6),("six-by-six",6),("6×6",6),("sevenfold",7),("7×7",7),("eightfold",8),("wafq of eight",8),
          ("8×8",8),("ninefold",9),("wafq of nine",9),("9×9",9),("tenfold",10),("10×10",10)]
# Default-seal: an item that acts upon another person is sealed unless its purpose is plainly
# protective, healing, releasing, or a reconciliation of spouses. Only the purpose clause is judged.
OTHER = re.compile(r"\b(someone|a person|another|him|her|them|man|woman|enem\w*|maṭlūb|husband|wife|girl|boy|judge|ruler|sultan|oppressor|tyrant|people|group)\b", re.I)
BENIGN = re.compile(r"\b(heal(?:ing|ed|s)?\b|cure|protect|protected|safe|release|releas|nullify|undo|break (?:a |the )?(?:spell|talisman)|ward off|evil eye|"
                    r"bewitched|miscarriage|offspring|child|pregnan|birth|reconcile[^.]{0,40}husband|between husband and wife|"
                    r"well received|stop[^.]{0,30}bleeding|afflicted|sick|patient|stolen|calamit|sorcery|siḥr)", re.I)
RISK = re.compile(r"\b(harm|bleed|seiz|bind|love|draw|bring|send|strike|influence|overcome|prevail|ill|enem|revenge|destroy|punish|vanquish|fever|throw|inflict|command|subdue)\w*", re.I)
def is_sealed(head):
    head = re.sub(r"^(?:If you wish (?:to|for)|If you want to|Whoever wishes to|To|For)\s+", "", head.strip())
    if re.match(r"(?:love|draw|jalb|bring back|draw back)", head, re.I) and not re.search(r"between husband and wife|reconcile", head[:80], re.I): return True
    other, benign, risk = OTHER.search(head), BENIGN.search(head), RISK.search(head)
    if other and not benign: return True
    if risk and not benign: return True
    if risk and other and re.search(r"\b(love|draw|bring|send|bind|strike|influence|overcome|prevail|enem|revenge|fever|bleed|inflict|punish|vanquish|destroy)\w*", head, re.I) \
       and not re.search(r"\b(release|cure|heal|protect|reconcile[^.]{0,40}husband|between husband and wife|missing)", head, re.I): return True
    return False
HEAL = re.compile(r"\b(headache|healing|heal|fever|illness|disease|pain|epilep|bleeding|boils|smallpox|toothache|eye ailments|colic|sick)\b", re.I)

PROT = re.compile(r"\b(safe from|protect|protected|ward(?:ing)? off|shield|be delivered from|safety from)", re.I)
OPENED = {(int(k.split("|",1)[0]), k.split("|",1)[1]) for k in (json.load(open("seal_open.json")) if __import__("os").path.exists("seal_open.json") else [])}
def cat(t, p=None):
    tl = t.lower(); head = t[:220]
    pc = re.split(r"[:;.]", t, maxsplit=1)[0][:40]
    if is_sealed(t[:160]) and (p, pc) not in OPENED: return "sealed"
    if HEAL.search(t): return "healing"
    for k, v in [("rizq","provision"),("sustenance","provision"),("provision","provision"),("debt","provision"),("trade","provision"),("shop","provision"),
                 ("protect","protection"),("safe from","protection"),("thief","protection"),("evil eye","protection"),("sorcery","protection"),("calamit","protection"),
                 ("prison","release"),("freed","release"),("release","release"),("knowledge","knowledge"),("memor","knowledge"),("understand","knowledge"),
                 ("travel","travel"),("journey","travel"),("sea","travel"),("child","family"),("pregnan","family"),("birth","family"),("marri","family"),
                 ("awe","standing"),("respect","standing"),("well received","standing"),("acceptance","standing"),("wish","need"),("need","need"),("request","need"),
                 ("jinn","jinn"),("dream","dreams"),("hunt","hunting"),("fish","hunting")]:
        if re.search(r"\b" + re.escape(k) + (r"\b" if len(k) <= 4 else ""), tl): return v
    return "other"

recs = []
for it in items:
    t = re.sub(r"\s+", " ", it["text"])
    sec = section_of(it["p"])
    c = cat(t, it["p"])
    head = re.split(r"(?<=[:.;])\s", t, maxsplit=1)[0][:110]
    r = {"id": f"w{it['p']}.{it['n']}", "n": it["n"], "p": it["p"], "ch": chapter_of(it["p"]),
         "sec": sec["t"] if sec else None, "secP": sec["p"] if sec else None, "cat": c, "title": head}
    if c != "sealed":
        r["days"] = [d for d in DAYS if d in t]
        hp = re.findall(r"hour of (?:the )?(\w+)|(?:the )?\b(first|second|third) hour\b", t)
        r["hour"] = sorted({PLAN.get(a, a) for a, b in hp if a and a in PLAN} | {b + " hour" for a, b in hp if b})
        r["element"] = sorted(set(re.findall(r"\b(fire|air|water|earth)-element\b", t)))
        r["square"] = sorted({v for k, v in SQUARE if k.lower() in t.lower()})
        named = [k for k in ["Kamālī","Mufradāt","mufradāt","Muzdawijāt","muzdawijāt","hollow-centre","hollow-centered","budūh","Bedūh"] if k in t]
        r["form"] = sorted({k.lower().replace("centered","centre") for k in named})
        r["material"] = sorted({m for m in MAT if re.search(r"\b" + m + r"\b", t, re.I)})
        r["incense"] = sorted({i for i in INC if re.search(r"\b" + re.escape(i) + r"\b", t, re.I)})
        r["counts"] = [int(x) for x in re.findall(r"\b(\d{1,5})\s*\)?\s*times\b", t)][:8]
        r["recite"] = sorted({k for k in ["Fātiḥa","Yā-Sīn","Ikhlāṣ","Āyat al-Kursī","Āyāt al-Kursī","Five Verses","Āyāt-i Hamse","Basmala","Muawwidh","al-Falaq","al-Nās","al-Wāqiʿa","Wākia"] if k in t})
        mz = re.findall(r"Moon is in (?:the )?(?:mansion of |manzil of )?([A-Z][\w\-ʿʾ]+)", t)
        r["moon"] = mz[:3]
        r["values"] = [int(x) for x in re.findall(r"(?:value|number) (?:of [^,.;]{1,40} )?(?:is|was|,)\s*(\d{2,6})", t)][:4]
    recs.append(r)

json.dump(recs, open("workings.json", "w"), ensure_ascii=False)
import collections
print(len(recs), collections.Counter(r["cat"] for r in recs).most_common())
print(collections.Counter(r["ch"] for r in recs))

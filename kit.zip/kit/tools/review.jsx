/* ═══ review — Al's own verdict on every correction ═══ */
function Review({ hue, go }) {
  const items = useMemo(() => [
    ...DATA.corrections.map((c, i) => ({ key: "c" + i, p: c.p, title: c.says, body: c.correct + (c.how ? ` — ${c.how}` : ""), kind: "text" })),
    ...BOOK.figs.filter(f => f.issue).map(f => ({ key: "f" + f.id, p: f.page, title: `Figure #${f.id}${f.n ? ` · ${f.n}×${f.n}` : ""} — ${f.held ? "held" : "corrected"}`, body: f.issue, kind: "figure", f })),
  ].sort((a, b) => (a.p || 0) - (b.p || 0)), []);
  const [st, setSt] = useState(() => LS.get("review", {}));
  const [filter, setFilter] = useState("all");
  const set = (k, v) => setSt(s => { const n = { ...s, [k]: { ...(s[k] || {}), ...v, at: Date.now() } }; LS.set("review", n); return n; });
  const count = (v) => items.filter(i => (st[i.key]?.v || "approved") === v).length;
  const shown = items.filter(i => filter === "all" || (st[i.key]?.v || "approved") === filter);
  return <div>
    <H2 hue={hue} sub="every correction the engine makes to the book, for you to approve or query">Review</H2>
    <div style={{ fontSize: 14, color: "#ffffff99", lineHeight: 1.7, maxWidth: 760 }}>
      Each item is a place where the engine departs from the printed page — a misprinted square, a slip in a table, a rule
      read differently. Every one listed here has been established by the book's own arithmetic or its own rule, and is
      approved; anything that could not be established (a disagreement between two of the book's tables, a discrepancy
      with no unique repair, a square held as printed) is not counted as a correction and stands as a remark on its figure.
      You may still query any item with a note; your verdicts stay in this browser and can be downloaded.</div>
    <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginTop: 12, alignItems: "center" }}>
      {[["all", "all"], ["approved", "approved"], ["queried", "queried"]].map(([k, l]) =>
        <Btn key={k} hue={hue} small active={filter === k} onClick={() => setFilter(k)}>{l} · {k === "all" ? items.length : count(k)}</Btn>)}
      <Btn hue="#e8c96a" small onClick={() => download("ihya-review.json", JSON.stringify(items.map(i => ({ key: i.key, page: i.p, item: i.title, correction: i.body, verdict: st[i.key]?.v || "approved", note: st[i.key]?.note || "" })), null, 1), "application/json")}>download verdicts</Btn>
    </div>
    <div style={{ display: "grid", gap: 8, marginTop: 14, maxWidth: 900 }}>
      {shown.map(i => { const s = st[i.key] || {}; const v = s.v || "approved";
        return <div key={i.key} style={{ border: `1px solid ${v === "approved" ? "#8fce7f55" : v === "queried" ? "#e58a7a66" : hue + "33"}`, padding: 11, borderRadius: 3, background: "#00000033" }}>
          <div style={{ display: "flex", justifyContent: "space-between", gap: 8, flexWrap: "wrap" }}>
            <span style={{ fontFamily: F.disp, fontSize: 16, color: "#f0ead9" }}>{i.title}</span><Cite page={i.p} hue={hue} /></div>
          <div style={{ fontSize: 13.5, color: "#ffffffa8", marginTop: 4, lineHeight: 1.6 }}>{i.body}</div>
          {i.f && i.f.grid && <details style={{ marginTop: 6 }}><summary style={{ cursor: "pointer", fontFamily: F.mono, fontSize: 11, color: hue }}>see the square</summary>
            <div style={{ marginTop: 6 }}><FigCard f={i.f} hue={hue} /></div></details>}
          <div style={{ display: "flex", gap: 6, marginTop: 8, flexWrap: "wrap", alignItems: "center" }}>
            <Btn hue="#8fce7f" small active={v === "approved"} onClick={() => set(i.key, { v: "approved" })}>✓ approve</Btn>
            <Btn hue="#e58a7a" small active={v === "queried"} onClick={() => set(i.key, { v: "queried" })}>? query</Btn>
            {s.v && <Btn hue={hue} small onClick={() => set(i.key, { v: null })}>reset</Btn>}
            <input value={s.note || ""} onChange={e => set(i.key, { note: e.target.value })} placeholder="note"
              style={{ ...inputBase, flex: 1, minWidth: 180, padding: "4px 8px", fontSize: 13 }} />
          </div>
        </div>; })}
      {shown.length === 0 && <div style={{ color: "#ffffff77" }}>Nothing here.</div>}
    </div>
  </div>;
}


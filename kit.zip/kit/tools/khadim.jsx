
/* ═══ Khādim — the practitioner's assistant (Claude, through the artifact's `sample` capability, with the engine as its tools) ═══ */
const KHADIM_HOME = "https://claude.ai/artifact/LzY1UDQcRpVCyVka6iXeZH";
const KH_KEY = "khadim";
const ucf = (s) => s ? s[0].toUpperCase() + s.slice(1) : s;
const isoLocal = (d) => `${ymd(d)} ${d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}`;

function khHoursFor(date, loc) {
  const noon = new Date(date); noon.setHours(12, 0, 0, 0);
  try { return loc ? planetaryHoursAt(noon, loc.lat, loc.lon, offsetFor(noon, loc)) : planetaryHours(noon, "06:00", "18:00"); }
  catch { return planetaryHours(noon, "06:00", "18:00"); }
}
function khNow(loc) {
  const now = new Date(), { hours, ruler } = khHoursFor(now, loc);
  const cur = hours.find(h => now >= h.start && now < h.end);
  const H = hijri(now), M = moon(now), Z = manzilNow(now), L = lunarDay(now);
  const mz = (DATA.manazil || []).find(x => x.n === Z.n) || {};
  return {
    now: isoLocal(now), weekday: WEEKDAYS[now.getDay()], hijri: `${H.d} ${H.month} ${H.y}`,
    day_ruler: ruler, location: loc ? (loc.name || `${loc.lat.toFixed(2)},${loc.lon.toFixed(2)}`) : "not set — hours approximate (06:00/18:00)",
    current_hour: cur ? { n: cur.i, planet: cur.planet, night: cur.night, from: fmt(cur.start), until: fmt(cur.end) } : null,
    hours_today: hours.map(h => `${h.i}. ${h.planet} ${fmt(h.start)}–${fmt(h.end)}${h.night ? " (night)" : ""}`),
    moon: { phase: M.phase, illumination: Math.round(M.illum * 100) + "%", lunar_day: L.day, lunar_day_manhus: L.manhus, waxing: M.waxing },
    mansion: { n: Z.n, name: mz.tr, ar: mz.ar, sign: mz.sign, element: mz.element, letter: mz.letter, hours_to_next: Math.round(Z.hoursToNext) },
  };
}
function khSnippet(t, q) { const f = fold(t), i = f.indexOf(fold(q)); const a = Math.max(0, i - 110); return (a ? "…" : "") + t.slice(a, a + 260) + (t.length > a + 260 ? "…" : ""); }

function khTools({ go, loc, onStep }) {
  const step = (s) => { try { onStep && onStep(s); } catch {} };
  return [
    { name: "search_book", description: "Full-text search of the whole book (English reading text of Iḥyāʾ Uṣūl al-Ḥikmah, 2,401 pp.). Returns up to `limit` hits as {chapter, page, kind, snippet}. Use short distinctive terms (a name, an ingredient, a topic), several calls if needed.",
      inputSchema: { type: "object", properties: { query: { type: "string" }, limit: { type: "number" } }, required: ["query"] },
      async execute(i) { const q = String(i.query || "").trim(); if (q.length < 2) throw new Error("query too short");
        step(`Searching the book for “${q}”`);
        const idx = await loadSearch(), s = fold(q), out = [], lim = Math.min(25, Number(i.limit) || 12);
        for (const r of idx) { if (fold(r[3]).includes(s)) { out.push({ chapter: r[0], page: r[1], kind: r[2] === "seal" ? "sealed (title only)" : r[2], snippet: khSnippet(r[3], q) }); if (out.length >= lim) break; } }
        return { query: q, hits: out, note: out.length ? undefined : "no hits — try another spelling or a shorter term" }; } },
    { name: "read_book_pages", description: "Read the book's reading text for a page range (max 4 pages). Returns the text with [p.N] markers. Arabic passages are images and appear as [Arabic]; figures as [figure #id]; sealed (harm-directed) items appear only as their title.",
      inputSchema: { type: "object", properties: { page: { type: "number" }, count: { type: "number" } }, required: ["page"] },
      async execute(i) { const p0 = Math.max(1, Math.min(2401, Math.round(Number(i.page)))), n = Math.max(1, Math.min(4, Math.round(Number(i.count) || 2)));
        step(n > 1 ? `Reading pp.${p0}–${p0 + n - 1}` : `Reading p.${p0}`);
        const out = []; let ch = chapterOfPage(p0); const chs = new Set([ch, chapterOfPage(p0 + n - 1)]);
        for (const c of chs) { const d = await loadChapter(c); let pg = BOOK.chapters.find(x => x.ch === c).from;
          for (const it of d.items) { if (it.k === "pg") { pg = it.p; if (pg >= p0 && pg < p0 + n) out.push(`\n[p.${pg}]`); continue; }
            if (pg < p0 || pg >= p0 + n) continue;
            if (it.k === "p" || it.k === "h1" || it.k === "h2") out.push((it.k !== "p" ? "## " : "") + it.t);
            else if (it.k === "ar") out.push("[Arabic]"); else if (it.k === "fig") out.push(`[figure #${it.id}]`);
            else if (it.k === "seal") out.push(`[SEALED working — “${it.t}” — indexed only; its procedure is not carried]`);
            else if (it.k === "corr") out.push(`[Correction in this edition: ${it.t}]`); else if (it.k === "src") out.push(`[source: ${it.t}]`); } }
        const text = out.join("\n"); return text.length > 24000 ? text.slice(0, 24000) + "\n…[cut — read fewer pages]" : text || "No text carried for those pages."; } },
    { name: "engine_lookup", description: "Search the engine's own datasets. dataset: talismans (the book's 140 talismans, seals, circles: id, page, title, description, words), figures (all 539 figures: squares with grids and constants, seals, tables, with notes and any corrections), corrections (every correction to the book), conditions (stated conditions of time/purity/materials by page), mansions (28 lunar mansions), letters (28 letters: values, elements, natures, planets), zodiac, glossary, lessons (the Durūs occult-squares course), sirr (al-Sirr al-Jalīl workings), index (the book's spine of records). Returns matching records (by `query` words, or `id`/`page`).",
      inputSchema: { type: "object", properties: { dataset: { type: "string", enum: ["talismans","figures","corrections","conditions","mansions","letters","zodiac","glossary","lessons","sirr","index"] }, query: { type: "string" }, id: { type: "number" }, page: { type: "number" }, limit: { type: "number" } }, required: ["dataset"] },
      execute(i) { const ds = String(i.dataset); step(`Looking in ${ds}${i.query ? ` for “${i.query}”` : ""}`);
        const sealedF = new Set(BOOK.sealedFigs || []);
        const sets = {
          talismans: () => BOOK.talismans.filter(t => !sealedF.has(t.id)).map(t => ({ id: t.id, page: t.page, chapter: t.ch, title: t.title, description: t.note, words: t.text })),
          figures: () => BOOK.figs.filter(f => !sealedF.has(f.id)).map(f => ({ id: f.id, page: f.page, chapter: f.ch, status: f.status, caption: f.caption, note: f.note, constant: f.constant, order: f.n, grid: f.grid, closes: f.closes, issue: f.issue, corrected: f.corrected })),
          corrections: () => DATA.corrections.map(c => ({ page: c.p, says: c.says, correct: c.correct, how: c.how })).concat(BOOK.figs.filter(f => f.issue).map(f => ({ page: f.page, figure: f.id, issue: f.issue, corrected: f.corrected }))),
          conditions: () => COND.filter(c => c.tier !== "sealed").map(c => ({ page: c.page, kind: c.kind, value: c.value, binds: c.binds, tier: c.tier })),
          mansions: () => DATA.manazil, letters: () => DATA.huruf, zodiac: () => DATA.zodiac, glossary: () => DATA.glossary,
          lessons: () => LESSONS, sirr: () => (SIRR.workings || []).filter(w => w.tier !== "sealed"), index: () => SPINE,
        };
        if (!sets[ds]) throw new Error("unknown dataset");
        let rows = sets[ds]();
        if (i.id != null) rows = rows.filter(r => r.id === Number(i.id) || r.n === Number(i.id));
        if (i.page != null) rows = rows.filter(r => (r.page ?? r.p) === Number(i.page));
        if (i.query) { const ws = fold(String(i.query)).split(/\s+/).filter(w => w.length > 1); rows = rows.filter(r => { const f = fold(JSON.stringify(r)); return ws.every(w => f.includes(w)); }); }
        const lim = Math.min(40, Number(i.limit) || 15), out = rows.slice(0, lim);
        let j = JSON.stringify(out); while (j.length > 28000 && out.length > 1) { out.pop(); j = JSON.stringify(out); }
        return { dataset: ds, total_matches: rows.length, returned: out.length, records: out }; } },
    { name: "find_workings", description: "Find the book's numbered workings by words in their title and/or category (healing, protection, provision, need, family, standing, knowledge, travel, release, jinn, dreams, other). Optional `day` (e.g. Friday) and `planet` filter on stated days/hours. Returns {id, page, chapter, category, title, days, hour, counts, material, recite}; sealed ones return only title and page.",
      inputSchema: { type: "object", properties: { query: { type: "string" }, category: { type: "string" }, day: { type: "string" }, planet: { type: "string" }, limit: { type: "number" } } },
      execute(i) { const q = fold(String(i.query || "")), cat = String(i.category || "").toLowerCase(), day = String(i.day || "").toLowerCase(), pl = String(i.planet || "").toLowerCase();
        step(`Finding workings${q ? ` for “${i.query}”` : ""}${cat ? ` · ${cat}` : ""}`);
        const words = q.split(/\s+/).filter(w => w.length > 2), out = [];
        for (const w of BOOK.workings) {
          if (cat && w.cat !== cat && !(cat !== "sealed" && false)) continue;
          if (words.length && !words.some(x => fold(w.title).includes(x))) continue;
          if (day && !(w.days || []).some(d => d.toLowerCase() === day)) continue;
          if (pl && !(w.hour || []).some(h => h.toLowerCase().includes(pl))) continue;
          out.push(w.cat === "sealed" ? { id: w.id, page: w.p, sealed: true, title: w.title } :
            { id: w.id, page: w.p, chapter: w.ch, category: w.cat, title: w.title, days: w.days, hour: w.hour, counts: w.counts, material: w.material, recite: w.recite });
          if (out.length >= Math.min(40, Number(i.limit) || 20)) break; }
        return { count: out.length, workings: out }; } },
    { name: "divine_names", description: "Look up the 99 Divine Names: by text (transliteration/English/Arabic), by abjad value, or by purpose (provision, opening, protection, healing, knowledge — a traditional map, not the book's). Returns {n, tr, en, ar, value_bare, value_with_al, page}.",
      inputSchema: { type: "object", properties: { query: { type: "string" }, value: { type: "number" }, purpose: { type: "string" } } },
      execute(i) { step("Consulting the Names"); let list = DATA.names;
        if (i.purpose) { const p = PURPOSE_NAMES[String(i.purpose).toLowerCase()] || []; list = list.filter(n => p.some(x => fold(x) === fold(n.tr) || fold(n.tr).endsWith(fold(x).replace(/^al-/, "")))); }
        if (i.value != null) list = list.filter(n => [n.mb, n.mw].includes(Number(i.value)));
        if (i.query) { const q = fold(String(i.query)); list = list.filter(n => fold(`${n.tr} ${n.en || ""} ${n.ab || ""}`).includes(q)); }
        return { source: i.purpose ? "purpose map is tradition, not the book" : "book", names: list.slice(0, 30).map(n => ({ n: n.o, tr: n.tr, en: n.en, ar: n.ab, value_bare: n.mb, value_with_al: n.mw, page: n.p })) }; } },
    { name: "abjad", description: "Compute the abjad value of Arabic text, recomputed letter by letter: mashriqī (default) and maghribī, letter count, predominant element, and the istinṭāq (letters) of the value. Always use this rather than computing values yourself.",
      inputSchema: { type: "object", properties: { text: { type: "string" } }, required: ["text"] },
      execute(i) { const t = String(i.text || ""); if (!hasArabic(t)) throw new Error("give Arabic script"); step(`Reckoning ${t}`);
        const v = abjad(t); return { text: t, mashriqi: v, maghribi: abjad(t, "maghribi"), letters: letterCount(t), element: nameElement(t), istintaq: (istintaq(v) || []).join(" ") }; } },
    { name: "make_square", description: "Build a wafq (magic square) of order 3–10 on a value or Arabic text by the book's first rule (ch.19). Returns the grid as printed (left to right), the constant, whether it balances, and the base form's source. Set open=true to also open it in the Forge for the user.",
      inputSchema: { type: "object", properties: { value: { type: "number" }, text: { type: "string" }, order: { type: "number" }, open: { type: "boolean" } }, required: ["order"] },
      execute(i) { const n = Math.round(Number(i.order)); if (n < 3 || n > 10) throw new Error("order must be 3–10");
        const A = i.text && hasArabic(String(i.text)) ? abjad(String(i.text)) : Math.round(Number(i.value)); step(`Building the ${n}×${n} on ${A}`);
        const w = wafq(A, n); if (w.error) return { value: A, order: n, error: w.error, fits: fitAll(A).filter(f => f.ok).map(f => f.n) };
        const c = checkSums(w.grid);
        if (i.open) go("forge", i.text ? { text: String(i.text), order: n } : { value: A, order: n });
        return { value: A, order: n, grid: toVisual(w.grid), constant: c.constant, balanced: c.balanced, diagonals: c.diagonals, base: baseSource(n), planet_of_order: ORDER_PLANET[n] || null, opened_in_forge: !!i.open }; } },
    { name: "find_times", description: "Upcoming planetary hours of a planet over the next `days` (max 14), with each hour's weekday, the day's ruler, the lunar day (and whether it is manḥūs) and the mansion. Use to choose when to do a working.",
      inputSchema: { type: "object", properties: { planet: { type: "string", enum: ["saturn","jupiter","mars","sun","venus","mercury","moon"] }, days: { type: "number" }, daytime_only: { type: "boolean" } }, required: ["planet"] },
      execute(i) { const pl = String(i.planet).toLowerCase(), nd = Math.max(1, Math.min(14, Math.round(Number(i.days) || 7))); step(`Finding the hours of ${pl}`);
        const now = new Date(), out = [], seen = new Set();
        for (let d = 0; d < nd; d++) { const day = new Date(now.getTime() + d * 86400000), { hours, ruler } = khHoursFor(day, loc);
          for (const h of hours) { if (h.planet !== pl || h.end <= now || seen.has(+h.start)) continue; if (i.daytime_only && h.night) continue; seen.add(+h.start);
            const L = lunarDay(h.start); out.push({ start: isoLocal(h.start), end: fmt(h.end), weekday: WEEKDAYS[h.start.getDay()], day_ruler: ruler, hour_n: h.i, night: h.night, lunar_day: L.day, manhus: L.manhus, mansion: manzilNow(h.start).n }); } }
        return { planet: pl, location: loc ? "set" : "not set — approximate", hours: out.slice(0, 40) }; } },
    { name: "journal", description: "The user's private practice journal. action 'list' returns recent entries (optionally filtered by `query`). action 'add' saves a new entry {title, kind (working|dhikr|dream|study|note), name (Arabic), intent, count, body} stamped with the current day, hour, mansion and lunar day — only when the user asks you to log something.",
      inputSchema: { type: "object", properties: { action: { type: "string", enum: ["list", "add"] }, query: { type: "string" }, entry: { type: "object" } }, required: ["action"] },
      async execute(i) { const list = await loadJournal();
        if (i.action === "add") { const e = i.entry || {}, now = new Date(), { hours, ruler } = khHoursFor(now, loc), h = hours.find(x => now >= x.start && now < x.end);
          const kinds = JOURNAL_KINDS.map(k => k[0]);
          const x = { id: "j" + now.getTime(), at: now.getTime(), kind: kinds.includes(e.kind) ? e.kind : "working", title: String(e.title || "").slice(0, 200), name: String(e.name || "").slice(0, 200),
            intent: String(e.intent || "").slice(0, 300), count: String(e.count || "").slice(0, 100), body: String(e.body || "").slice(0, 4000), outcome: "",
            hourPlanet: h ? h.planet : null, dayPlanet: ruler, mansion: manzilNow(now).n, lunar: lunarDay(now).day, by: "khadim" };
          step("Writing to your journal"); await saveJournal([x, ...list]); return { saved: true, entry: x }; }
        step("Reading your journal"); const q = fold(String(i.query || ""));
        return { entries: list.filter(x => !q || fold([x.title, x.name, x.intent, x.body, x.outcome].join(" ")).includes(q)).slice(0, 25)
          .map(x => ({ date: isoLocal(new Date(x.at)), kind: x.kind, title: x.title, name: x.name, intent: x.intent, count: x.count, notes: (x.body || "").slice(0, 400), outcome: (x.outcome || "").slice(0, 300), hour: x.hourPlanet, day: x.dayPlanet })) }; } },
    { name: "compose_talisman", description: "Open a talisman in the Ṭilasm Studio, composed whole for the user: any figure of the book by its figure number (e.g. 203, 9, 226), or a lesson construction (d3 Saturn 3×3, d4 Mars 5×5, d5a/d5b the seven seals, d8 hollow square with a name, d10 the jīm letter-talisman, d11 Basmala cross seal, d12 composite Seal of Victory). Optional `text` (Arabic name/verse it is made for) and `need`. Squares inside are rebuilt for that value; rings and frames come with them.",
      inputSchema: { type: "object", properties: { figure: { type: "number" }, lesson: { type: "string" }, text: { type: "string" }, need: { type: "string" } } },
      execute(i) { const id = i.lesson ? String(i.lesson) : i.figure != null ? "f" + Math.round(Number(i.figure)) : null; if (!id) throw new Error("give figure or lesson");
        if (i.figure != null && (BOOK.sealedFigs || []).includes(Number(i.figure))) throw new Error("that figure is sealed — indexed only, not composed");
        step(`Composing ${id} in the Ṭilasm Studio`); khPending = () => go("studio", { id, text: i.text ? String(i.text) : undefined, need: i.need ? String(i.need) : undefined });
        return { will_open: "Ṭilasm Studio", id }; } },
    { name: "open_in_engine", description: "Show something to the user in the engine. module: forge (focus {text|value, order}), kitab (focus {page}), shakl (focus {id}: forge a book figure), talasim (focus {id}), hours, manazil, asma, huruf, bast, khatam, journal, alyawm, majlis, tashihat. Use at the end when it helps the user see the result.",
      inputSchema: { type: "object", properties: { module: { type: "string" }, focus: { type: "object" } }, required: ["module"] },
      execute(i) { const m = String(i.module), f = i.focus || {};
        if (!NAV_ITEM[m]) throw new Error("unknown module");
        const o = m === "kitab" && f.page ? { chapter: chapterOfPage(Number(f.page)), page: Number(f.page), view: "read" } : f;
        step(`Opening ${NAV_ITEM[m].label}`); khPending = () => go(m, o); return { will_open: NAV_ITEM[m].label }; } },
  ];
}
let khPending = null;   // navigation is deferred until the answer has finished, so the chat isn't torn down mid-reply

const KH_RULES = (ctx) => `You are al-Muʿallim (the Teacher), Al's private teacher and assistant inside his Iḥyāʾ Engine — a computational edition of Amin Patel's compiled "Iḥyāʾ Uṣūl al-Ḥikmah" (2nd ed., 2,401 pages; drawn from al-Būnī's Shams al-Maʿārif al-Kubrā and Manbaʿ Uṣūl al-Ḥikmah). Al is a practitioner in the Islamic esoteric tradition (Shādhilī/Chishtī-adjacent). Be to him what a learned, patient, exacting teacher of this science would be: teach, plan workings with him, answer from the book, brief him on the day, keep his journal.

As his teacher:
- Teach the why, not only the what: show the principle behind each step (how the first rule of ch.19 fills a square, why the subtrahend is n(n²−1)/2, how basṭ expands a letter, why a planet governs an order, what the conditions protect), so he can reason it out himself next time.
- Build understanding in steps. For a new topic: the idea in two or three sentences → a worked example computed with the tools → where it sits in the book (pages) → one short question to check he has it. Wait for his answer, then correct gently and precisely.
- Keep a thread: if he is studying something, propose the next lesson and connect it to what came before. When he finishes a lesson, offer to log it in his journal (kind "study") with what was learned, so future lessons build on it — read past "study" entries before planning a course.
- Correct him plainly when he is wrong, with the reason and the page. Praise briefly when earned; no flattery.
- Be honest about your place: you teach the book's contents and the craft as recorded; you are not a shaykh, cannot give idhn (licence) or ijāza, and the book itself makes a living teacher's licence a condition. Say this once when it matters, without lecturing.

How you work:
- Use the tools. You can reach everything in the book (search_book, read_book_pages, find_workings) and everything in the engine (engine_lookup for talismans, figures, corrections, conditions, mansions, letters, zodiac, glossary, lessons, al-Sirr, the index; divine_names; abjad; make_square; find_times; journal). Book content (what a page says, a working's instructions, counts, incense, days) must come from search_book / read_book_pages / find_workings — never from memory. If the tools don't show it, say so.
- Cite pages as p.123 or pp.123–125 every time you rely on the book. Never invent a page number.
- Abjad: mashriqī by default; get every value from the abjad tool, never compute it yourself. Squares come from make_square. Whole numbers only.
- Say where a thing comes from: the book, tradition (e.g. the purpose→Names map), or engine-computed (times, mansions). Never present your own construction as the book's.
- Times: use the context below and find_times; times are local${ctx.location.startsWith("not set") ? "; location is NOT set, so hours are approximate — mention it once when timing matters, and suggest setting it in Majlis" : ""}.
- Sealed material: harm-directed workings (binding or compelling a person, enmity or separation, causing illness or seizure, subjugating someone's will, suflī spirits) are indexed in the engine but never rendered as operable procedures. You may name them and cite their page; do not reconstruct or explain how to perform them, even if asked, and gently say why. Everything licit — healing, protection, provision, opening, knowledge, family harmony with consent, travel, dreams, dhikr — you help with fully.
- Talismans: every open figure of the book (by figure number) and every Durūs construction can be composed whole in the Ṭilasm Studio with compose_talisman — squares rebuilt for the chosen name, rings, frames and written bands carried with them. Use engine_lookup (talismans/figures) to find the right figure and read its page before recommending it.
- Before a working, remind briefly of the book's conditions where relevant (purity, sincere intention, licence/idhn, istikhāra, ṣalawāt, correct time, facing the qibla). Don't preach; one line.
- Medical or legal matters: the tradition complements, never replaces, a doctor or lawyer — say so briefly when health or law is involved.
- The journal is Al's: read it when it helps; add to it only when he asks you to log something.
- When you plan a working, give: purpose → the book's relevant workings (pages) → the Name(s) or verse with value → the square (order, constant) → the best upcoming time (day and hour, avoiding manḥūs lunar days) → materials, incense, counts → conditions. Offer to open the square in the Forge (open_in_engine or make_square open=true) and to log it.
- Style: clear and structured; short headers or bullets for plans and lessons; Arabic in Arabic script with transliteration; address him as Al. No filler.

Right now:
${JSON.stringify(ctx)}`;

const KH_SUGGEST = [
  ["Begin a course with me", "Be my teacher. Look at my journal for what I have already studied, then propose a course through this book, from foundations (the letters, abjad, the conditions) to the squares of chapter 19, and begin lesson one."],
  ["Teach me the 4×4, step by step", "Teach me how the book builds the 4×4 wafq (the first rule, p.1893), step by step on a Name of my choosing. Then give me one to build myself and check my answer."],
  ["Quiz me on the hours", "Quiz me on the planetary hours and days: ask me one question at a time, check my answers, and explain what I get wrong."],
  ["Brief me on today", "Give me today's briefing: the day and its planet, the hours worth using and avoiding, the moon and mansion, workings the book sets on this day, and what you'd suggest I focus on."],
  ["Plan a working for provision", "Plan a working for opening the doors of provision (rizq), using the book. Pick the Name, the square and the best time in the next week."],
  ["Protection for my home", "What does the book give for protecting a home and family? Find the workings, then plan the best one for me."],
  ["Study al-Laṭīf", "Teach me about the Name al-Laṭīf from the book: its value, its square, its properties and the workings that use it, with pages."],
  ["When is the next Jupiter hour?", "When are the next Jupiter hours this week, and which are on a good lunar day?"],
  ["Review my journal", "Look through my journal and tell me what patterns you see, and what I should follow up on."],
];

/* tiny markdown → React, with page citations made live and Arabic set in Amiri */
function khInline(s, hue, key) {
  const out = []; let k = 0;
  const re = /(\*\*[^*]+\*\*|\*[^*\n]+\*|`[^`]+`|\bpp?\.\s?\d{1,4}(?:\s?[–-]\s?\d{1,4})?|[؀-ۿ][؀-ۿً-ْ\s]*[؀-ۿ]|[؀-ۿ])/g;
  let last = 0, m;
  while ((m = re.exec(s))) { if (m.index > last) out.push(s.slice(last, m.index)); const t = m[0];
    if (t.startsWith("**")) out.push(<strong key={key + "b" + k++} style={{ color: "#f6efdf", fontWeight: 600 }}>{t.slice(2, -2)}</strong>);
    else if (t.startsWith("`")) out.push(<code key={key + "c" + k++} style={{ fontFamily: F.mono, fontSize: "0.88em", background: "#ffffff10", padding: "1px 5px", borderRadius: 4 }}>{t.slice(1, -1)}</code>);
    else if (t.startsWith("*")) out.push(<em key={key + "i" + k++}>{t.slice(1, -1)}</em>);
    else if (/^pp?\./.test(t)) { const p = +t.match(/\d+/)[0];
      out.push(<button key={key + "p" + k++} onClick={() => window.__ihyaGo && window.__ihyaGo("kitab", { chapter: chapterOfPage(p), page: p, view: "read" })}
        style={{ background: "none", border: "none", borderBottom: `1px dotted ${hue}`, color: hue, padding: 0, cursor: "pointer", fontFamily: F.mono, fontSize: "0.86em" }} title="open in the book">{t}</button>); }
    else out.push(<span key={key + "a" + k++} dir="rtl" style={{ fontFamily: F.ar, fontSize: "1.22em", color: "#f3e6c4", unicodeBidi: "isolate" }}>{t}</span>);
    last = m.index + t.length; }
  if (last < s.length) out.push(s.slice(last));
  return out;
}
function KhMarkdown({ text, hue }) {
  const lines = String(text || "").split("\n"), blocks = []; let list = null, para = [];
  const flushP = () => { if (para.length) { blocks.push(<p key={"p" + blocks.length} style={{ margin: "0 0 12px", lineHeight: 1.7 }}>{khInline(para.join(" "), hue, "p" + blocks.length)}</p>); para = []; } };
  const flushL = () => { if (list) { const L = list; const Tag = L.ol ? "ol" : "ul";
    blocks.push(<Tag key={"l" + blocks.length} style={{ margin: "0 0 12px", paddingLeft: 22, lineHeight: 1.65 }}>{L.items.map((t, i) => <li key={i} style={{ margin: "3px 0" }}>{khInline(t, hue, "l" + blocks.length + "_" + i)}</li>)}</Tag>); list = null; } };
  for (const raw of lines) { const l = raw.replace(/\s+$/, "");
    const h = l.match(/^(#{1,4})\s+(.*)$/), ul = l.match(/^\s*[-*•]\s+(.*)$/), ol = l.match(/^\s*\d+[.)]\s+(.*)$/);
    if (!l.trim()) { flushP(); flushL(); continue; }
    if (/^\s*\|.*\|\s*$/.test(l)) { flushP(); flushL(); if (/^\s*\|[\s:|-]+\|\s*$/.test(l)) continue;
      const cells = l.trim().slice(1, -1).split("|").map(c => c.trim());
      blocks.push(<div key={"t" + blocks.length} style={{ display: "grid", gridTemplateColumns: `repeat(${cells.length},minmax(0,1fr))`, gap: 8, padding: "5px 0", borderBottom: "1px solid #ffffff12", fontSize: 13.5 }}>
        {cells.map((c, i) => <span key={i}>{khInline(c, hue, "t" + blocks.length + i)}</span>)}</div>); continue; }
    if (h) { flushP(); flushL(); blocks.push(<div key={"h" + blocks.length} style={{ fontFamily: F.disp, fontSize: h[1].length <= 2 ? 22 : 18.5, color: "#f6efdf", margin: "16px 0 6px" }}>{khInline(h[2], hue, "h" + blocks.length)}</div>); continue; }
    if (ul || ol) { flushP(); const t = (ul || ol)[1]; const isOl = !!ol; if (!list || list.ol !== isOl) { flushL(); list = { ol: isOl, items: [] }; } list.items.push(t); continue; }
    flushL(); para.push(l.trim()); }
  flushP(); flushL();
  return <div style={{ fontSize: 15.5, color: "#e9e2d1" }}>{blocks}</div>;
}

function Khadim({ hue, go, loc }) {
  const [sample, setSample] = useState(undefined);   // undefined: checking · null: unavailable · fn
  const [turns, setTurns] = useState(() => LS.get(KH_KEY, []));
  const [draft, setDraft] = useState("");
  const [busy, setBusy] = useState(false);
  const [live, setLive] = useState("");
  const [steps, setSteps] = useState([]);
  const [err, setErr] = useState(null);
  const [deep, setDeep] = useState(() => LS.get("khadimDeep2", true));
  const ctl = useRef(null), endRef = useRef(null), boxRef = useRef(null);
  useEffect(() => { let on = true;
    (async () => { try { if (!window.claude || !window.claude.use) { on && setSample(null); return; }
      const s = await window.claude.use("sample"); on && setSample(() => s || null); } catch { on && setSample(null); } })();
    return () => { on = false; }; }, []);
  useEffect(() => { LS.set(KH_KEY, turns.slice(-40)); }, [turns]);
  useEffect(() => { endRef.current && endRef.current.scrollIntoView({ block: "end", behavior: "smooth" }); }, [turns.length, live, steps.length]);
  useEffect(() => () => ctl.current && ctl.current.abort(), []);

  const send = async (text) => {
    const msg = String(text || "").trim(); if (!msg || busy || !sample) return;
    const history = [...turns, { role: "user", content: msg, at: Date.now() }];
    setTurns(history); setDraft(""); setBusy(true); setLive(""); setSteps([]); setErr(null); khPending = null;
    const c = new AbortController(); ctl.current = c;
    const used = [];
    const ctx = khNow(loc);
    const convo = history.slice(-16).map(t => ({ role: t.role, content: t.content }));
    while (convo.length && convo[0].role !== "user") convo.shift();
    try {
      const r = await sample([{ role: "user", content: KH_RULES(ctx) }, ...convo], {
        cache: false, signal: c.signal, modelTier: deep ? "complex" : "default",
        tools: khTools({ go, loc, onStep: (s) => { used.push(s); setSteps(x => [...x, s]); } }),
        onText: ({ text }) => setLive(text) });
      setTurns(t => [...t, { role: "assistant", content: r.text, at: Date.now(), steps: used, truncated: r.truncated }]);
      if (khPending) { const f = khPending; khPending = null; setTimeout(f, 700); }
    } catch (e) {
      const code = e && e.code;
      if (e && e.text) setTurns(t => [...t, { role: "assistant", content: e.text, at: Date.now(), steps: used, interrupted: code !== "cancelled" }]);
      if (code === "not_granted" || code === "sampling_disabled" || code === "capability_disabled" || code === "not_declared" || code === "tools_unavailable") setErr("Claude isn't allowed for this page right now. Allow it from the page's permissions, then try again.");
      else if (code === "rate_limited") setErr("Claude is busy or your usage limit was reached — try again in a little while.");
      else if (code === "session_expired") setErr("Your Claude session expired — sign in again.");
      else if (code === "refused") setErr("Claude declined that request. Try asking it differently.");
      else if (code === "prompt_too_large") setErr("The conversation got too long — start a new chat.");
      else if (code !== "cancelled") setErr("Something interrupted the answer. Try again.");
    } finally { setBusy(false); setLive(""); setSteps([]); ctl.current = null; }
  };
  const stop = () => ctl.current && ctl.current.abort();
  const reset = () => { if (busy) stop(); setTurns([]); setErr(null); };

  const ctxNow = khNow(loc);
  const Header = <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", gap: 12, flexWrap: "wrap", marginBottom: 16 }}>
    <div>
      <h2 style={{ fontFamily: F.disp, fontWeight: 500, fontSize: "clamp(28px,4vw,36px)", margin: 0 }}>al-Muʿallim <span style={{ fontFamily: F.ar, color: hue, fontSize: "0.8em" }}>المعلّم</span></h2>
      <div style={{ color: "#ffffff88", fontSize: 14, marginTop: 4 }}>Your teacher and assistant: the whole book, the Names, the squares, the hours and your journal at hand.</div>
    </div>
    {sample && <div style={{ display: "flex", gap: 8 }}>
      <Pill hue={hue} active={deep} onClick={() => { setDeep(!deep); LS.set("khadimDeep2", !deep); }} title="Use Claude's most capable model — slower, deeper">{deep ? "Deep thought" : "Quick replies"}</Pill>
      {turns.length > 0 && <Pill hue={hue} icon="plus" onClick={reset}>New chat</Pill>}
    </div>}
  </div>;

  if (sample === undefined) return <div>{Header}<div style={{ ...S.card, color: "#ffffff88" }}>Connecting to Claude…</div></div>;
  if (sample === null) return <div>{Header}
    <div style={{ ...S.card, padding: 28, borderColor: hue + "44", background: `radial-gradient(700px 240px at 0 0, ${hue}1c, transparent 60%), #120f0b` }}>
      <div style={{ fontFamily: F.disp, fontSize: 24 }}>al-Muʿallim teaches inside Claude</div>
      <div style={{ color: "#ffffffaa", lineHeight: 1.7, marginTop: 8, maxWidth: 640 }}>
        This copy of the engine is the public website, which can't reach Claude safely. Open your engine from the Claude sidebar (it's pinned there as Iḥyāʾ Engine) and your teacher will be here, using your own Claude account.
        Everything else on this site works the same.</div>
      <div style={{ display: "flex", gap: 10, marginTop: 18, flexWrap: "wrap" }}>
        <a href={KHADIM_HOME} target="_blank" rel="noopener" style={{ textDecoration: "none" }}><Btn hue={hue} active>Open the engine in Claude</Btn></a>
        <Btn hue={hue} onClick={() => go("alyawm")}>Today's instruments</Btn>
        <Btn hue={hue} onClick={() => go("majlis")}>Majlis · this hour</Btn>
      </div>
    </div></div>;

  return <div style={{ display: "flex", flexDirection: "column", minHeight: "calc(100vh - 210px)" }}>
    {Header}
    <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 14 }}>
      <span style={{ ...S.label, fontSize: 9.5, alignSelf: "center" }}>it sees</span>
      {[`day of ${ctxNow.day_ruler}`, ctxNow.current_hour && `hour of ${ctxNow.current_hour.planet} until ${ctxNow.current_hour.until}`, `mansion ${ctxNow.mansion.n} · ${ctxNow.mansion.name || ""}`, `lunar day ${ctxNow.moon.lunar_day}`, loc ? null : "no location set"].filter(Boolean).map((t, i) =>
        <span key={i} style={{ fontFamily: F.mono, fontSize: 11, color: t === "no location set" ? "#e8a25c" : "#ffffffaa", border: "1px solid #ffffff17", borderRadius: 999, padding: "4px 10px" }}>{t}</span>)}
    </div>

    <div style={{ flex: 1, display: "flex", flexDirection: "column", gap: 16 }}>
      {turns.length === 0 && !busy && <div style={{ ...S.card, padding: 24 }}>
        <div style={{ fontFamily: F.disp, fontSize: 22 }}>What shall we study, Al?</div>
        <div style={{ color: "#ffffff88", fontSize: 14, marginTop: 4, lineHeight: 1.6 }}>Ask in your own words, or let me lead a lesson. I search and read the book, reckon values, build squares, find the right hours and keep your journal, and I cite the page for anything from the book.</div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(min(100%,240px),1fr))", gap: 10, marginTop: 18 }}>
          {KH_SUGGEST.map(([label, q]) => <button key={label} onClick={() => send(q)} className="ih-tile" style={{ ...S.card, padding: "13px 15px", textAlign: "left", cursor: "pointer", color: "inherit", fontSize: 14.5 }}>
            <span style={{ color: hue, marginRight: 8 }}>✦</span>{label}</button>)}
        </div>
      </div>}
      {turns.map((t, i) => t.role === "user"
        ? <div key={i} style={{ alignSelf: "flex-end", maxWidth: "min(620px,88%)", background: hue + "1f", border: `1px solid ${hue}44`, borderRadius: "16px 16px 4px 16px", padding: "11px 15px", fontSize: 15.5, lineHeight: 1.6, whiteSpace: "pre-wrap" }}>{khInline(t.content, hue, "u" + i)}</div>
        : <div key={i} style={{ display: "grid", gridTemplateColumns: "34px minmax(0,1fr)", gap: 12 }}>
            <div style={{ width: 34, height: 34, borderRadius: 10, display: "grid", placeItems: "center", background: hue + "22", color: hue, fontFamily: F.ar, fontSize: 18 }}>م</div>
            <div style={{ minWidth: 0 }}>
              {t.steps && t.steps.length > 0 && <details style={{ marginBottom: 8 }}><summary style={{ cursor: "pointer", fontFamily: F.mono, fontSize: 10.5, color: "#ffffff55" }}>{t.steps.length} step{t.steps.length > 1 ? "s" : ""} · how I worked this out</summary>
                <div style={{ fontFamily: F.mono, fontSize: 11, color: "#ffffff77", lineHeight: 1.9, marginTop: 6 }}>{t.steps.map((s, j) => <div key={j}>· {s}</div>)}</div></details>}
              <KhMarkdown text={t.content} hue={hue} />
              {(t.truncated || t.interrupted) && <div style={{ fontFamily: F.mono, fontSize: 10.5, color: "#e8a25c" }}>{t.truncated ? "cut short — ask me to continue" : "interrupted"}</div>}
            </div></div>)}
      {busy && <div style={{ display: "grid", gridTemplateColumns: "34px minmax(0,1fr)", gap: 12 }}>
        <div style={{ width: 34, height: 34, borderRadius: 10, display: "grid", placeItems: "center", background: hue + "22", color: hue, fontFamily: F.ar, fontSize: 18 }} className="kh-breathe">م</div>
        <div style={{ minWidth: 0 }}>
          {steps.length > 0 && <div style={{ fontFamily: F.mono, fontSize: 11, color: "#ffffff77", lineHeight: 1.9, marginBottom: 8 }}>{steps.map((s, j) => <div key={j} style={{ color: j === steps.length - 1 && !live ? hue : undefined }}>{j === steps.length - 1 && !live ? "◌ " : "✓ "}{s}</div>)}</div>}
          {live ? <KhMarkdown text={live} hue={hue} /> : <div style={{ color: "#ffffff77", fontStyle: "italic" }}>{steps.length ? "Working…" : "Thinking…"}</div>}
        </div></div>}
      {err && <div style={{ ...S.card, borderColor: "#e8a25c55", color: "#f0c9a0", padding: "12px 16px", fontSize: 14 }}>{err}</div>}
      <div ref={endRef} />
    </div>

    <div style={{ position: "sticky", bottom: 12, marginTop: 18, zIndex: 5 }} className="kh-composer">
      <div style={{ display: "flex", gap: 10, alignItems: "flex-end", background: "#15110ce8", backdropFilter: "blur(12px)", WebkitBackdropFilter: "blur(12px)", border: `1px solid ${hue}44`, borderRadius: 16, padding: 10, boxShadow: "0 16px 40px -12px #000" }}>
        <textarea ref={boxRef} value={draft} onChange={e => setDraft(e.target.value)} rows={1} placeholder="Ask your teacher — a lesson, a working, a Name, a page, the best hour…"
          onKeyDown={e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(draft); } }}
          onInput={e => { e.target.style.height = "auto"; e.target.style.height = Math.min(180, e.target.scrollHeight) + "px"; }}
          dir={hasArabic(draft) && !/[a-z]/i.test(draft) ? "rtl" : "ltr"}
          style={{ flex: 1, resize: "none", background: "none", border: "none", outline: "none", color: "#f3ecdc", fontSize: 15.5, lineHeight: 1.5, padding: "6px 6px", maxHeight: 180, fontFamily: F.body }} />
        {busy ? <button onClick={stop} aria-label="Stop" style={{ background: "#ffffff14", border: "1px solid #ffffff2a", color: "#f3ecdc", borderRadius: 12, padding: "9px 14px", cursor: "pointer", fontFamily: F.mono, fontSize: 11.5 }}>■ Stop</button>
          : <button onClick={() => send(draft)} disabled={!draft.trim()} aria-label="Send" style={{ background: draft.trim() ? hue : "#ffffff14", border: "none", color: draft.trim() ? "#120f0a" : "#ffffff55", borderRadius: 12, padding: 10, cursor: draft.trim() ? "pointer" : "default", display: "inline-flex" }}><Icon n="arrow" size={18} stroke={2} /></button>}
      </div>
      <div style={{ fontFamily: F.mono, fontSize: 10, color: "#ffffff44", textAlign: "center", marginTop: 6 }}>Uses your Claude account · sealed workings stay sealed · check what matters against the cited page</div>
    </div>
  </div>;
}

/* ═══ Maṣnaʿ al-Ashkāl — the Forge of the Ashkāl: every open figure of the book forged for your own name, number or need ═══
 *  Squares are rebuilt on the book's own figure (SHAKL, src/shakl.mjs) and re-summed; talismans, seals, circles and
 *  tables are set as plates — the figure's clean line in the angels' frame with your lines written above and below.
 *  Sealed workings are not here. Nothing forged is presented as the book's: every plate names its figure, page and method. */
const SHAKL_METHOD = {
  own: ["on its own arrangement", "the figure's cells ranked 1…n² are its base; the Ch.19 tarḥ and lift are worked on that base (pp.1701–1703)"],
  carry: ["its own numbers carried", "every cell of the printed square takes the same addition; a remainder goes by one into each line"],
  top: ["your text across the top row", "the top row becomes your letters, as the book writes the name's letters there; the rest is carried so every line still closes"],
  darb: ["multiplied (ḍarb)", "your number divided by the figure's constant: the quotient multiplies every cell and the remainder goes once into each line — the book's way with the hollow fivefold (p.1970)"],
  letters: ["your letters in its places", "your letters or words take the book's places in the same cycle, so every line carries your whole text"],
};
const SHAKL_KINDS = [["all", "everything"], ["squares", "squares"], ["letters", "letter squares"], ["talismans", "talismans, seals & circles"], ["tables", "tables & charts"]];
const ANGELS_STD = { top: "جبرائيل", right: "عزرائيل", left: "ميكائيل", bottom: "اسرافيل" };   // as on the plates of ch.19

function shaklKind(f) {
  if (f.an && f.an.kind !== "plate") return f.an.kind === "letters" ? "letters" : "squares";
  return f.status === "figure" ? "talismans" : "tables";
}
function shaklTitle(f, tal) {
  if (tal) return tal.title;
  const n = (f.note || "").split(/[:;(—]|\.\s/)[0].trim();
  return n.length > 90 ? n.slice(0, 88) + "…" : n || `Figure ${f.id}`;
}

/** A plate around a printed figure: its clean line (the tracing where there is one) in the ruled frame with the four
 *  angels, and the written lines above and below — drawn on a canvas so it can be saved as an image. */
function ImagePlate({ id, sketch, above, below, frame, paper, onReady }) {
  const ref = useRef(null);
  const [src, setSrc] = useState(null);
  useEffect(() => { let live = true; setSrc(null);
    (sketch ? loadSketch(Math.floor(id / 100)) : loadFigPack(Math.floor(id / 100)))
      .then(p => live && setSrc(p[String(id)] || "")).catch(() => live && setSrc(""));
    return () => { live = false; }; }, [id, sketch]);
  useEffect(() => {
    if (!src || !ref.current) return;
    let live = true;
    const img = new Image();
    img.onload = async () => {
      try { await document.fonts.load("40px Amiri"); } catch {}
      if (!live) return;
      const sc = Math.min(1, 1100 / Math.max(img.width, img.height)), iw = Math.round(img.width * sc), ih = Math.round(img.height * sc);
      const u = Math.max(iw, ih) / 22;                                   // the plate's unit
      const afs = Math.round(u * 0.95), lfs = (t) => t ? Math.round(Math.min(u * 1.5, (iw + 8 * u) / Math.max(4, [...t].length * 0.5))) : 0;
      const fa = lfs(above), fb = lfs(below);
      const off = frame ? u * 0.9 : 0, over = u * 0.7, ring = frame ? off + afs * 1.9 : u * 0.6;
      const padX = Math.round(ring + u * 0.8), top = Math.round(ring + (fa ? fa * 1.7 : 0) + u * 0.6), bot = Math.round(ring + (fb ? fb * 1.9 : 0) + u * 0.6);
      const cv = ref.current; cv.width = iw + padX * 2; cv.height = ih + top + bot;
      const g = cv.getContext("2d"), ink = paper ? "#111111" : "#ece6d8", gold = paper ? "#5a3c08" : "#e8c96a";
      g.fillStyle = paper ? "#fdfcf8" : "#0d0b08"; g.fillRect(0, 0, cv.width, cv.height);
      if (!paper) g.filter = "invert(0.92) sepia(0.18)";
      g.drawImage(img, padX, top, iw, ih); g.filter = "none";
      g.textAlign = "center"; g.direction = "rtl";
      if (frame) {
        const a = padX - off, b = padX + iw + off, c = top - off, d = top + ih + off;
        g.strokeStyle = ink; g.lineWidth = Math.max(1.5, u * 0.09);
        for (const [x1, y1, x2, y2] of [[a - over, c, b + over, c], [a - over, d, b + over, d], [a, c - over, a, d + over], [b, c - over, b, d + over]]) {
          g.beginPath(); g.moveTo(x1, y1); g.lineTo(x2, y2); g.stroke(); }
        g.fillStyle = ink; g.font = `${afs}px Amiri, serif`;
        g.fillText(ANGELS_STD.top, (a + b) / 2, c - afs * 0.45);
        g.fillText(ANGELS_STD.bottom, (a + b) / 2, d + afs * 1.15);
        const side = (t, x, y, rot) => { g.save(); g.translate(x, y); g.rotate(rot); g.fillText(t, 0, 0); g.restore(); };
        side(ANGELS_STD.left, a - afs * 0.45, (c + d) / 2, -Math.PI / 2);
        side(ANGELS_STD.right, b + afs * 0.45, (c + d) / 2, Math.PI / 2);
      }
      g.fillStyle = gold;
      if (fa) { g.font = `${fa}px Amiri, serif`; g.fillText(above, cv.width / 2, top - ring - fa * 0.45); }
      if (fb) { g.font = `${fb}px Amiri, serif`; g.fillText(below, cv.width / 2, top + ih + ring + fb * 1.05); }
      onReady && onReady(cv);
    };
    img.src = src;
    return () => { live = false; };
  }, [src, above, below, frame, paper]);
  if (src === null) return <div style={{ fontFamily: F.mono, fontSize: 11, color: "#ffffff66", padding: 10 }}>setting the plate…</div>;
  if (!src) return <div style={{ color: "#ffffff77", fontSize: 13 }}>No image for this figure.</div>;
  return <canvas ref={ref} style={{ width: "100%", maxWidth: 720, height: "auto", display: "block", margin: "0 auto", borderRadius: 3, border: "1px solid #ffffff22" }} />;
}

function ShaklForge({ hue, go, focus }) {
  const sealed = useMemo(() => new Set(BOOK.sealedFigs || []), []);
  const talBy = useMemo(() => new Map((BOOK.talismans || []).map(t => [t.id, t])), []);
  const figs = useMemo(() => BOOK.figs.filter(f => !sealed.has(f.id)).map(f => {
    const an = f.grid ? SHAKL.analyse(f.grid, abjad) : null;
    const x = { ...f, an, tal: talBy.get(f.id) || null };
    return { ...x, kind: shaklKind(x), title: shaklTitle(x, x.tal) };
  }), []);
  const [sel, setSel] = useState(() => LS.get("shaklSel", null));
  const [q, setQ] = useState("");
  const [kind, setKind] = useState("all");
  const [ch, setCh] = useState("all");
  // what it is forged for
  const [src, setSrc] = useState(() => LS.get("shaklSrc", "name"));
  const [nameOrd, setNameOrd] = useState(() => LS.get("shaklName", 18));
  const [withAl, setWithAl] = useState(false);
  const [text, setText] = useState(() => LS.get("shaklText", "حسبنا الله ونعم الوكيل"));
  const [num, setNum] = useState(() => LS.get("shaklNum", "786"));
  // how
  const [method, setMethod] = useState(null);
  const [byNumber, setByNumber] = useState(false);
  const [split, setSplit] = useState("auto");
  const [rot, setRot] = useState(0);
  const [mir, setMir] = useState(false);
  const [frame, setFrame] = useState(true);
  const [asPlate, setAsPlate] = useState(false);
  const [paper, setPaper] = useState(true);
  const [above, setAbove] = useState(null);     // null: written from what it is forged for
  const [below, setBelow] = useState(null);
  const [showPrinted, setShowPrinted] = useState(false);
  const canvasRef = useRef(null);
  useEffect(() => { if (focus && focus.id != null) { setSel(focus.id); setQ(""); setKind("all"); setCh("all"); } }, [focus]);
  useEffect(() => { LS.set("shaklSel", sel); }, [sel]);
  useEffect(() => { LS.set("shaklSrc", src); LS.set("shaklName", nameOrd); LS.set("shaklText", text); LS.set("shaklNum", num); }, [src, nameOrd, text, num]);
  useEffect(() => { setMethod(null); setRot(0); setMir(false); setAbove(null); setBelow(null); setShowPrinted(false); setAsPlate(false); }, [sel]);

  const list = figs.filter(f => (kind === "all" || f.kind === kind) && (ch === "all" || f.ch === +ch)
    && (!q || fold(f.title + " " + (f.note || "")).includes(fold(q)) || String(f.page) === q.trim() || "#" + f.id === q.trim()));
  const cur = sel != null ? figs.find(f => f.id === sel) : null;
  const idx = cur ? list.findIndex(f => f.id === cur.id) : -1;

  const rec = DATA.names.find(x => x.o === +nameOrd) || DATA.names[0];
  const forText = src === "name" ? ((withAl && rec.aw) || rec.ab) : src === "text" ? text.trim() : "";
  const A = src === "number" ? (parseInt(String(num).replace(/\D/g, ""), 10) || 0)
    : src === "name" ? ((withAl && rec.mw) || rec.mb) : abjad(text);
  const an = cur && cur.an && cur.an.kind !== "plate" ? cur.an : null;
  const methods = an ? an.methods : [];
  const segs = useMemo(() => {
    if (!forText || !an) return [];
    if (forText.includes("|")) return forText.split("|").map(s => s.trim()).filter(Boolean);
    const L = splitText(forText, "letter"), W = splitText(forText, "word");
    if (split === "letter") return L; if (split === "word") return W;
    return L.length === an.n ? L : W.length === an.n ? W : L;
  }, [forText, split, an]);
  // the chosen way, or else the first way that works for this number
  const res = useMemo(() => {
    if (!an || asPlate || !methods.length) return null;
    const run = (k) => (k === "letters" || k === "top") && !forText
      ? { error: "this way writes letters — forge it for a name or a text, not a bare number" }
      : SHAKL.forge(an, k, { A, segs, segVals: segs.map(s => abjad(s)), byNumber }, abjad);
    if (method && methods.includes(method)) return { ...run(method), m: method };
    let first = null;
    for (const k of methods) { const r = run(k); if (!r.error) return { ...r, m: k, skipped: first }; if (!first) first = { k, error: r.error }; }
    return { ...run(methods[0]), m: methods[0] };
  }, [an, method, A, segs, byNumber, asPlate, forText]);
  const m = res ? res.m : methods[0];
  const needsSegs = m === "letters" || m === "top";
  const shown = res && !res.error ? orient(res.shown, rot, mir) : null;
  const sums = shown ? checkSums(orient(res.values, rot, mir)) : null;
  const valueLabel = (v) => `${v} · ${toIndic(v)} · ${(jummal(v) || []).join("")}`;
  const aboveT = above != null ? above : forText || (A ? toIndic(A) : "");
  const belowT = below != null ? below : forText && A ? toIndic(A) : "";
  const L = shown ? layoutPlate({ grid: toStore(shown), above: aboveT, below: belowT, angels: DATA.angels4, element: 0, frame,
    centre: an.hollow ? (forText || an.centre || "") : "" }) : null;
  const fileStem = cur ? `ashkal-${cur.id}-p${cur.page}-${(forText || String(A)).replace(/\s+/g, "_").slice(0, 24)}` : "";
  const provenance = cur ? `forged by the engine on figure #${cur.id} of the Iḥyāʾ, p.${cur.page}${res && !res.error ? ` · ${SHAKL_METHOD[m][0]}` : asPlate || !an ? " · set as a plate" : ""} · not printed in the book` : "";
  const dlSvg = () => L && download(`${fileStem}.svg`, svgFromLayout(L, cur.title.replace(/[<&>]/g, ""), provenance, hue), "image/svg+xml");
  const dlPng = () => L && svgToPng(svgFromLayout(L, cur.title.replace(/[<&>]/g, ""), provenance, hue), `${fileStem}.png`);
  const dlPlate = () => { const cv = canvasRef.current; if (cv) cv.toBlob(b => b && saveBlob(`${fileStem}-plate.png`, b), "image/png"); };
  const counts = useMemo(() => Object.fromEntries(SHAKL_KINDS.map(([k]) => [k, figs.filter(f => k === "all" || f.kind === k).length])), [figs]);
  const label = { fontFamily: F.mono, fontSize: 10.5, letterSpacing: "0.12em", color: hue + "bb", marginTop: 14 };

  return <div>
    <H2 hue={hue} sub="every open figure of the book forged for your own name, number or need — squares rebuilt on the book's own figure and re-summed, talismans and seals set as plates in the angels' frame">Ashkāl Forge</H2>
    <div style={{ display: "flex", gap: 6, flexWrap: "wrap", alignItems: "center" }}>
      {SHAKL_KINDS.map(([k, l]) => <Btn key={k} hue={hue} small active={kind === k} onClick={() => setKind(k)}>{l} · {counts[k]}</Btn>)}
    </div>
    <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "flex-end", marginTop: 8 }}>
      <Field hue={hue} label="FIND A FIGURE"><input value={q} onChange={e => setQ(e.target.value)} placeholder="seal, threefold, Laṭīf, a page…" style={{ ...inputBase, width: "min(280px,80vw)" }} /></Field>
      <select value={ch} onChange={e => setCh(e.target.value)} style={{ ...inputBase, padding: "6px 8px", fontSize: 12.5 }}>
        <option value="all">all chapters</option>
        {BOOK.chapters.filter(c => figs.some(f => f.ch === c.ch)).map(c => <option key={c.ch} value={c.ch}>{CHNAME(c.ch)}</option>)}</select>
      <span style={{ fontFamily: F.mono, fontSize: 11, color: "#ffffff88" }}>{list.length} of {figs.length}</span>
    </div>

    {/* what it is forged for — shared by every figure */}
    <div style={{ border: `1px solid ${hue}33`, background: hue + "0c", borderRadius: 3, padding: "10px 12px", marginTop: 12 }}>
      <div style={{ display: "flex", gap: 6, flexWrap: "wrap", alignItems: "center" }}>
        <span style={{ fontFamily: F.mono, fontSize: 10.5, letterSpacing: "0.12em", color: hue }}>FORGE FOR</span>
        {[["name", "a name of Allah"], ["text", "a name, need or verse"], ["number", "a number"]].map(([k, l]) =>
          <Btn key={k} hue={hue} small active={src === k} onClick={() => setSrc(k)}>{l}</Btn>)}
      </div>
      <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center", marginTop: 8 }}>
        {src === "name" && <>
          <select value={nameOrd} onChange={e => setNameOrd(+e.target.value)} style={{ ...inputBase, padding: "6px 8px", fontSize: 13, maxWidth: "min(360px,90vw)" }}>
            {DATA.names.map(x => <option key={x.o} value={x.o}>{x.o}. {x.tr} — {x.en}</option>)}</select>
          {rec.aw && <Btn hue={hue} small active={withAl} onClick={() => setWithAl(w => !w)}>{withAl ? "with al-" : "bare"}</Btn>}</>}
        {src === "text" && <input dir="rtl" value={text} onChange={e => setText(e.target.value)} placeholder="اكتب الاسم او الحاجة"
          style={{ ...inputBase, fontFamily: F.ar, fontSize: 18, width: "min(420px,90vw)" }} />}
        {src === "number" && <input inputMode="numeric" value={num} onChange={e => setNum(e.target.value)} style={{ ...inputBase, width: 140 }} />}
        <span style={{ fontFamily: F.ar, fontSize: 20, color: "#f0ead9" }} dir="rtl">{forText}</span>
        {A > 0 && <span style={{ fontFamily: F.mono, fontSize: 12, color: hue }}>{valueLabel(A)}</span>}
      </div>
      <div style={{ fontSize: 11.5, color: "#ffffff77", marginTop: 6 }}>Mashriqī abjad, every value recomputed from the letters. Separate segments with | to set them yourself.</div>
    </div>

    <div style={{ display: "grid", gridTemplateColumns: cur ? "minmax(0,320px) minmax(0,1fr)" : "1fr", gap: 18, marginTop: 14 }} className="kitab-grid">
      <div style={{ maxHeight: cur ? "86vh" : "70vh", overflowY: "auto" }}>
        <table style={{ borderCollapse: "collapse", width: "100%", fontSize: 13 }}>
          <tbody>{list.map(f => <tr key={f.id} onClick={() => setSel(f.id)} style={{ cursor: "pointer", borderBottom: "1px solid #ffffff11", background: sel === f.id ? hue + "1e" : "transparent" }}>
            <td style={{ padding: "6px 8px 6px 0", fontFamily: F.mono, fontSize: 10.5, color: "#ffffff66", verticalAlign: "top", whiteSpace: "nowrap" }}>#{f.id}</td>
            <td style={{ padding: "6px 8px 6px 0", color: "#f0ead9", verticalAlign: "top" }}>{f.title}
              <div style={{ fontFamily: F.mono, fontSize: 10, color: "#ffffff66" }}>{f.kind === "squares" || f.kind === "letters" ? `${f.an.n}×${f.an.n}${f.an.constant ? " · " + f.an.constant : ""} · ${f.an.methods.length} way${f.an.methods.length > 1 ? "s" : ""}` : f.kind === "talismans" ? "plate" : "table · plate"}</div></td>
            <td style={{ padding: "6px 0", fontFamily: F.mono, fontSize: 11, color: hue, whiteSpace: "nowrap", verticalAlign: "top" }}>p.{f.page}</td></tr>)}</tbody>
        </table>
      </div>

      {cur && <div style={{ minWidth: 0 }}>
        <div style={{ display: "flex", justifyContent: "space-between", gap: 8, flexWrap: "wrap", alignItems: "center" }}>
          <div><div style={{ fontFamily: F.mono, fontSize: 10.5, color: hue }}>figure #{cur.id} · {CHNAME(cur.ch)} · <Cite page={cur.page} hue={hue} /></div>
            <div style={{ fontFamily: F.disp, fontSize: 23, color: "#f0ead9", lineHeight: 1.25 }}>{cur.title}</div></div>
          <div style={{ display: "flex", gap: 5 }}>
            <Btn hue={hue} small disabled={idx <= 0} onClick={() => setSel(list[idx - 1].id)}>‹ prev</Btn>
            <Btn hue={hue} small disabled={idx < 0 || idx >= list.length - 1} onClick={() => setSel(list[idx + 1].id)}>next ›</Btn>
            <Btn hue={hue} small onClick={() => setSel(null)}>close</Btn></div>
        </div>

        {an && <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginTop: 12, alignItems: "center" }}>
          {methods.map(k => <Btn key={k} hue={hue} small active={!asPlate && m === k} onClick={() => { setMethod(k); setAsPlate(false); }}>{SHAKL_METHOD[k][0]}</Btn>)}
          <Btn hue={hue} small active={asPlate} onClick={() => setAsPlate(p => !p)}>the printed figure as a plate</Btn>
        </div>}
        {an && !asPlate && m && <div style={{ fontSize: 12.5, color: "#ffffff88", lineHeight: 1.6, marginTop: 6 }}>{SHAKL_METHOD[m][1]}.</div>}

        {/* squares, rebuilt */}
        {an && !asPlate && <>
          {needsSegs && forText && <div style={{ display: "flex", gap: 6, flexWrap: "wrap", alignItems: "center", marginTop: 10 }}>
            <span style={{ fontFamily: F.mono, fontSize: 10.5, color: hue }}>{an.n} PLACES ·</span>
            {[["auto", "fit"], ["letter", "letters"], ["word", "words"]].map(([k, l]) => <Btn key={k} hue={hue} small active={split === k} onClick={() => setSplit(k)}>{l}</Btn>)}
            <span dir="rtl" style={{ fontFamily: F.ar, fontSize: 16 }}>{segs.map((s, i) => <span key={i} style={{ border: `1px solid ${hue}44`, borderRadius: 2, padding: "1px 6px", margin: "0 2px" }}>{s}<sub style={{ fontFamily: F.mono, fontSize: 9, color: hue }}>{abjad(s)}</sub></span>)}</span>
          </div>}
          {m === "darb" && <div style={{ marginTop: 8 }}><Btn hue={hue} small active={byNumber} onClick={() => setByNumber(b => !b)}>{byNumber ? "the number itself multiplies every cell" : "divide by the constant (the book's first way)"}</Btn></div>}
          {res && res.error && <div style={{ marginTop: 12, padding: "10px 12px", border: "1px solid #e58a7a55", color: "#f0c0b4", borderRadius: 3, fontSize: 13.5 }}>{res.error}.
            {/places/.test(res.error) && ` Give a name or text of ${an.n} letters or ${an.n} words, or set the ${an.n} parts yourself with |.`}
            {methods.length > 1 && " Or choose another way above."}</div>}
          {shown && <>
            <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginTop: 12, alignItems: "center" }}>
              {ELEMENTS.map((e, i) => <Btn key={e.key} hue={hue} small active={rot === i} onClick={() => setRot(i)}>{e.key} · {e.ar}</Btn>)}
              <Btn hue={hue} small active={mir} onClick={() => setMir(x => !x)}>mirrored</Btn>
              <Btn hue={hue} small active={frame} onClick={() => setFrame(x => !x)}>{frame ? "frame on" : "frame off"}</Btn>
            </div>
            <div style={{ marginTop: 12, textAlign: "center" }}><PlateView L={L} onHover={() => {}} /></div>
            <div style={{ fontFamily: F.mono, fontSize: 11.5, color: sums.balanced ? "#9fd8a8" : "#f0a090", marginTop: 8, lineHeight: 1.7 }}>
              {sums.balanced ? `✓ every row and column ${sums.constant}` : "✗ the lines do not agree"}
              {sums.balanced && (sums.diagonals ? ` · both diagonals ${sums.constant}` : ` · diagonals ${sums.d1} / ${sums.d2}`)}
              {an.hollow && " · the centre left for the name"}
              {res.repeats && <span style={{ color: "#e8b84f" }}> · a number repeats in two cells{methods.includes("own") ? " — on its own arrangement every cell differs" : ""}</span>}</div>
            {res.how && <div style={{ fontFamily: F.mono, fontSize: 11, color: "#ffffff88", marginTop: 2 }}>{res.how}</div>}
            {res.note && <div style={{ fontSize: 12.5, color: "#e8b84f", marginTop: 4 }}>{res.note}.</div>}
            {res.skipped && <div style={{ fontSize: 12.5, color: "#e8b84f", marginTop: 4 }}>“{SHAKL_METHOD[res.skipped.k][0]}” cannot be worked for this: {res.skipped.error}{/places/.test(res.skipped.error) ? ` (give ${an.n} letters or ${an.n} words, or set ${an.n} parts with |)` : ""} — so it is shown {SHAKL_METHOD[res.m][0]}.</div>}
            <div style={{ fontSize: 12, color: "#ffffff66", marginTop: 4 }}>The book's figure closes on {an.constant}{an.diagonals ? " with its diagonals" : ", rows and columns"}; the cells are written in the engine-wide script chosen at the top of the page.</div>
          </>}
        </>}

        {/* talismans, seals, circles, tables — and any square as printed */}
        {(!an || asPlate) && <>
          <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginTop: 12, alignItems: "center" }}>
            <Btn hue={hue} small active={frame} onClick={() => setFrame(x => !x)}>{frame ? "angels' frame on" : "frame off"}</Btn>
            <Btn hue={hue} small active={paper} onClick={() => setPaper(p => !p)}>{paper ? "on paper" : "on dark"}</Btn>
            <Btn hue="#e8c96a" small onClick={dlPlate}>download plate (PNG)</Btn>
          </div>
          <div style={{ marginTop: 10 }}><ImagePlate id={cur.id} sketch={!!cur.tal} above={aboveT} below={belowT} frame={frame} paper={paper} onReady={cv => (canvasRef.current = cv)} /></div>
          <div style={{ fontSize: 12.5, color: "#ffffff88", lineHeight: 1.6, marginTop: 6 }}>
            The figure is the printed one{cur.tal ? " reduced to clean line" : ", cleaned from the page"}; nothing inside it is changed. Your lines are written above and below it, and the frame carries Jibrāʾīl above, ʿAzrāʾīl right, Mīkāʾīl left and Isrāfīl below, as the plates of chapter 19 set them.
            {cur.an && cur.an.kind === "plate" && cur.grid && ` Its numbers do not close as printed (${cur.an.why}), so it is forged only as a plate.`}</div>
        </>}

        <div style={label}>WRITTEN LINES</div>
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginTop: 4 }}>
          <Field hue={hue} label="ABOVE"><input dir="rtl" value={aboveT} onChange={e => setAbove(e.target.value)} style={{ ...inputBase, fontFamily: F.ar, fontSize: 16, width: "min(300px,85vw)" }} /></Field>
          <Field hue={hue} label="BELOW"><input dir="rtl" value={belowT} onChange={e => setBelow(e.target.value)} style={{ ...inputBase, fontFamily: F.ar, fontSize: 16, width: "min(300px,85vw)" }} /></Field>
          {(above != null || below != null) && <Btn hue={hue} small onClick={() => { setAbove(null); setBelow(null); }}>reset</Btn>}
        </div>
        <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginTop: 10 }}>
          {shown && !asPlate && <><Btn hue="#e8c96a" small onClick={dlSvg}>download SVG</Btn><Btn hue="#e8c96a" small onClick={dlPng}>download PNG</Btn></>}
          <Btn hue={hue} small onClick={() => go("kitab", { chapter: cur.ch, page: cur.page, view: "read" })}>read it in the book · p.{cur.page}</Btn>
          {cur.tal && <Btn hue={hue} small onClick={() => go("talasim", { id: cur.id })}>open in Ṭalāsim · to sketch</Btn>}
          {an && <Btn hue={hue} small active={showPrinted} onClick={() => setShowPrinted(s => !s)}>{showPrinted ? "hide" : "show"} the printed figure</Btn>}
        </div>
        {showPrinted && an && <div style={{ marginTop: 10, background: "#00000055", padding: 10, borderRadius: 3 }}><FigImage id={cur.id} style={{ maxHeight: "50vh" }} /></div>}
        <div style={label}>WHAT IT IS</div>
        <div style={{ fontSize: 14, color: "#ffffffb8", lineHeight: 1.7, marginTop: 4 }}>{cur.note}</div>
        {cur.tal && cur.tal.text.length > 0 && <>
          <div style={label}>THE BOOK'S WORDS WITH IT</div>
          {cur.tal.text.map((t, i) => <p key={i} style={{ fontSize: 14, color: "#e9e3d4", lineHeight: 1.75, margin: "6px 0" }}>{withAnchors(t, "")}</p>)}</>}
        <div style={{ fontFamily: F.mono, fontSize: 10.5, color: "#ffffff55", marginTop: 12, lineHeight: 1.6 }}>{provenance}.</div>
      </div>}
    </div>
  </div>;
}

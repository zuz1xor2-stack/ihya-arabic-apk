"""v1.5.1: the Forge's four cell-bands are replaced by the book's own ḥāshiya.
The cycling letter rings, the invented 'seven seals' ring and the Buduh corners were not drawn from the book and
left remainders, collisions and a frame that cut through them. The book's plates (e.g. p.2009) write the verse
above the ruled frame and further text outside the angels' names; that is what the plate now does."""
src = open('engine_v15.jsx', encoding='utf-8').read()
def rep(old, new, count=1):
    global src
    n = src.count(old); assert n == count, f"{n}× {old[:70]!r}"
    src = src.replace(old, new)

# ── layout: no cell rings; written lines above and below ──
a = src.index("/** Buduh — ب د و ح, the corner stamp")
b = src.index("/** No two drawn cells may occupy the same slot")
src = src[:a] + '''/**
 * Plate layout: the grid inside the book's ruled frame (angels on the four sides, the rules crossing and
 * overshooting at the corners), with the ḥāshiya written as whole lines of text outside it — the verse above,
 * the name or petition below — as the book's plates set them (e.g. p.2009). Nothing is cut into letters or cycled.
 * Returns primitives only, so the same layout drives the on-screen SVG and the exported file.
 */
function layoutPlate({ grid, above = "", below = "", angels = [], element = 0, cell = null, frame = true }) {
  const n = grid.length;
  const cs = cell || Math.max(16, Math.min(52, Math.round(520 / n)));
  const side = n * cs;
  const fpad = frame ? Math.round(cs * 1.9) + 14 : 0;
  const lineFs = (t, width) => t ? Math.max(9, Math.min(Math.round(cs * 0.62), Math.floor(width / Math.max(4, [...t].length * 0.52)))) : 0;
  const width = side + fpad * 2;
  const fa = lineFs(above, width), fb = lineFs(below, width);
  const G0 = frame ? frameGeometry(n, cs, 0, side) : null;
  const ring = frame ? G0.off + G0.over + G0.fs * 1.9 : cs * 0.3;      // what the frame and its angels occupy
  const padX = Math.round(cs * 0.5) + (frame ? fpad : 0);
  const topRoom = Math.round(Math.max(padX, ring + (fa ? fa * 1.6 : 0) + 10));
  const botRoom = Math.round(Math.max(padX, ring + (fb ? fb * 1.6 : 0) + 10));
  const W = side + padX * 2, H = side + topRoom + botRoom;
  const org = padX, orgY = topRoom;
  const items = [];
  const XY = (r, c) => [org + (n - 1 - c) * cs, orgY + r * cs];   // RTL: column 0 on the right
  grid.forEach((row, r) => row.forEach((v, c) => {
    const [x, y] = XY(r, c);
    items.push({ t: "cell", x, y, w: cs, h: cs, text: v == null ? "" : String(v), fs: cs * (String(v).length > 4 ? 0.24 : 0.32), kind: "grid", v });
  }));
  if (above) items.push({ t: "label", x: W / 2, y: Math.round(orgY - ring - fa * 0.35), rot: 0, text: above, fs: fa, kind: "hashiya", ar: true,
                          meta: { ch: above, v: abjad(above), tr: "written above the frame" } });
  if (below) items.push({ t: "label", x: W / 2, y: Math.round(orgY + side + ring + fb * 1.0), rot: 0, text: below, fs: fb, kind: "hashiya", ar: true,
                          meta: { ch: below, v: abjad(below), tr: "written below the frame" } });
  if (frame) {
    const G = frameGeometry(n, cs, 0, side);
    // frameGeometry works on a square origin; shift it to the grid's real origin
    const sh = (x, y) => [x + org, y + orgY];
    const seat = frameAngels(angels.length ? angels : [{ tr: "", ar: "" }], element);
    for (const r of G.rules) { const [x1, y1] = sh(r.x1, r.y1), [x2, y2] = sh(r.x2, r.y2);
      items.push({ t: "rule", x1, y1, x2, y2, kind: "frame" }); }
    for (const a2 of seat) {
      const L2 = G.labels[a2.side]; const [x, y] = sh(L2.x, L2.y);
      items.push({ t: "label", x, y, rot: L2.rot, text: a2.ar || a2.tr, fs: G.fs, kind: "angel", ar: true,
                   meta: { ch: a2.ar, v: a2.kabir, tr: a2.tr, side: a2.side, el: a2.element, dir: a2.direction } });
    }
    return { W, H, cs, items, frame: G, seat };
  }
  return { W, H, cs, items, seat: [] };
}

''' + src[b:]

# ── renderers ──
rep('const KINDCOL = { grid:"#ece6d8", band1:"#e8c96a", band2:"#5fc98f", band3:"#b58fe8", band4:"#8fb8e8", buduh:"#e8a25c" };',
    'const KINDCOL = { grid:"#ece6d8", hashiya:"#e8c96a", angel:"#b58fe8" };')
rep('''    if (it.t === "corner") { out += it.text ? `<text x="${it.x}" y="${it.y+4}" text-anchor="middle" font-family="Amiri, serif" font-size="11" fill="#111">${it.text}</text>` : ""; continue; }
''', '')
rep('''       + `grid: computed from the book's stated rule · band 1 &amp; 2: canonical orthography, computed here · `
       + `band 3 angels: tradition-attested · band 4 seals: tradition-attested, drawn schematically · corners: not legible in the source</text>`;''',
'''       + `grid: computed from the book's stated rule · frame and angels as the book's plates set them · written lines in canonical orthography</text>`;''')
rep('''      : it.t === "corner"
      ? <text key={i} x={it.x} y={it.y + 4} textAnchor="middle" fontFamily={F.ar} fontSize="11" fill="#e8a25c">{it.text}</text>
''', '')
rep('''          fill="#b58fe8" transform={`rotate(${it.rot},${it.x},${it.y})`}''',
    '''          fill={KINDCOL[it.kind] || "#b58fe8"} transform={`rotate(${it.rot},${it.x},${it.y})`} direction="rtl"''')

# ── Forge state and wiring ──
rep('const [bands, setBands] = useState({ 1: false, 2: false, 3: false, 4: false, buduh: false });',
    'const [bands, setBands] = useState({ 1: false, 2: false });   // 1: the formula above · 2: the name below')
rep('''    grid, bands, formula: formula.ar, nameText, angels: DATA.angels4, element: elem, frame
  }) : null, [grid, bands, formula, nameText, elem, frame]);''',
'''    grid, above: bands[1] ? formula.ar : "", below: bands[2] ? nameText : "", angels: DATA.angels4, element: elem, frame
  }) : null, [grid, bands, formula, nameText, elem, frame]);
  const plateAt = (cellPx) => layoutPlate({ grid, above: bands[1] ? formula.ar : "", below: bands[2] ? nameText : "",
    angels: DATA.angels4, element: elem, frame, cell: cellPx });''')
rep('setBands({ 1: true, 2: true, 3: true, 4: true, buduh: true });', 'setBands({ 1: true, 2: true }); setFrame(true);')
rep('''    bands[3] && "angels: " + DATA.angels4.map(a => a.page ? `${a.tr} p.${a.page}` : `${a.tr} tradition`).join(", "),
    bands[4] && "seven seals — tradition-attested, drawn schematically",''',
'''    frame && "angels: " + DATA.angels4.map(a => a.page ? `${a.tr} p.${a.page}` : `${a.tr} tradition`).join(", "),
    (bands[1] || bands[2]) && "written lines as on the plate of p.2009",''')
rep('''    ["Band 1 · formula", !!bands[1]],
    ["Band 1 closes evenly", !!(bands[1] && L?.perim[1]?.closes)],
    ["Band 2 · name letters", !!bands[2]],
    ["Band 2 closes evenly", !!(bands[2] && L?.perim[2]?.closes)],
    ["Band 3 · four angels", !!bands[3]],
    ["Band 4 · seven seals", !!bands[4]],
    ["Buduh corners", !!bands.buduh],''',
'''    ["Formula written above", !!bands[1]],
    ["Name written below", !!bands[2]],''')
rep('''      {[[1, "Band 1 · formula"], [2, "Band 2 · name"], [3, "Band 3 · angels"], [4, "Band 4 · seals"], ["buduh", "Buduh corners"]].map(([k, l]) =>
        <Btn key={k} hue={KINDCOL["band" + k] || "#e8a25c"} small active={!!bands[k]}
          onClick={() => setBands(b => ({ ...b, [k]: !b[k] }))}>{l}</Btn>)}
      <Field hue={hue} label="BAND 1 FORMULA">''',
'''      {[[1, "Formula above the frame"], [2, mode === "number" ? "Number below" : "Name below the frame"]].map(([k, l]) =>
        <Btn key={k} hue="#e8c96a" small active={!!bands[k]}
          onClick={() => setBands(b => ({ ...b, [k]: !b[k] }))}>{l}</Btn>)}
      <Field hue={hue} label="FORMULA WRITTEN ABOVE">''')
rep('title="forge the band-1 formula\'s own square"', 'title="forge the formula\'s own square"')
rep('''            setMode(c.m); setOrder(c.o); setElem(c.e); setBands(c.b); setFIdx(c.f); setMir(c.r);''',
    '''            setMode(c.m); setOrder(c.o); setElem(c.e); setBands({ 1: !!(c.b || {})[1], 2: !!(c.b || {})[2] }); setFIdx(c.f); setMir(c.r);''')
rep('''            : "hover any border letter for its value and element"}''', '''            : "hover the angels or the written lines for their values"}''')
rep('''          <div style={{ alignSelf: "center", maxWidth: 210, fontSize: 11.5, color: "#e8a25c", lineHeight: 1.5 }}>
            Corner glyphs are not legible in the source and are left empty rather than invented.
          </div>''',
'''          <div style={{ alignSelf: "center", maxWidth: 230, fontSize: 11.5, color: "#ffffff88", lineHeight: 1.5 }}>
            The four angels stand on the four sides as on every plate of chapter 19; the marks the book prints at the
            corners are not reproduced.
          </div>''')
rep('''            svgFromLayout(layoutPlate({ grid, bands, formula: formula.ar, nameText, angels: DATA.angels4, element: elem, cell: Math.floor(1500 / (order + 2 * Math.max(0, ...[1,2,3,4].filter(k=>bands[k]), 0))) }), title, pagesUsed, hue), "image/svg+xml")}>SVG · A2</Btn>''',
'''            svgFromLayout(plateAt(Math.floor(1500 / (order + 4))), title, pagesUsed, hue), "image/svg+xml")}>SVG · A2</Btn>''')
rep('''            svgFromLayout(layoutPlate({ grid, bands, formula: formula.ar, nameText, angels: DATA.angels4, element: elem, cell: Math.floor(1060 / (order + 2 * Math.max(0, ...[1,2,3,4].filter(k=>bands[k]), 0))) }), title, pagesUsed, hue), "image/svg+xml")}>SVG · A3</Btn>''',
'''            svgFromLayout(plateAt(Math.floor(1060 / (order + 4))), title, pagesUsed, hue), "image/svg+xml")}>SVG · A3</Btn>''')
a = src.index("        {L && Object.keys(L.perim).length > 0 && <div style={{ marginBottom: 10 }}>")
b = src.index('        <div style={{ fontFamily: F.mono, fontSize: 10.5, color: hue + "bb", letterSpacing: "0.1em" }}>COMPOSITION AUDIT</div>')
src = src[:a] + src[b:]
open('engine_v15.jsx', 'w', encoding='utf-8').write(src)
print("ok")
src = open('engine_v15.jsx', encoding='utf-8').read()
a = src.index("// ─────────── the border (ḥāshiya) ───────────"); b = src.index("/**\n * Plate layout: the grid inside")
src = src[:a] + "// ─────────── the plate ───────────\n" + src[b:]
a = src.index("/** No two drawn cells may occupy the same slot"); b = src.index("\n}\n", a) + 3
src = src[:a] + src[b:]
open('engine_v15.jsx', 'w', encoding='utf-8').write(src)
print("dead ring code removed")
# ── the tenfold: the dropped row belongs eighth, not sixth (only there do the diagonals close on 505) ──
src = open('engine_v15.jsx', encoding='utf-8').read()
old = """  [44,9,13,80,66,36,21,86,95,55],
  [24,70,54,99,83,18,5,49,31,72],
  [6,17,30,35,42,59,67,71,85,93],
  [57,97,81,23,38,63,75,20,3,48],
  [61,52,98,84,28,73,16,8,45,40],"""
new = """  [44,9,13,80,66,36,21,86,95,55],
  [6,17,30,35,42,59,67,71,85,93],
  [57,97,81,23,38,63,75,20,3,48],
  [61,52,98,84,28,73,16,8,45,40],
  [24,70,54,99,83,18,5,49,31,72],"""
assert src.count(old) == 1
src = src.replace(old, new)
src = src.replace("fix the dropped row uniquely.", "fix the dropped row uniquely, and only as the ninth row do both diagonals also close on 505 (v1.5.1).")
open('engine_v15.jsx', 'w', encoding='utf-8').write(src)
print("SQ10 row placed")
# ── the letters' elements and planets as the book gives them (p.76; p.16 Chart I; p.111) ──
import json as _json
src = open('engine_v15.jsx', encoding='utf-8').read()
i = src.index('const DATA = '); j = src.index('\n', i)
line = src[i:j]; body = line[len('const DATA = '):].rstrip().rstrip(';')
D = _json.loads(body)
GROUP = {"fire": "اهطمفشذ", "earth": "بوينصتض", "air": "جزكسقثظ", "water": "دحلعرخغ"}
NAT = {"fire": "hot & dry", "earth": "cold & dry", "air": "hot & moist", "water": "cold & moist"}
PL = ["saturn", "jupiter", "mars", "sun", "venus", "mercury", "moon"]
for h in D["huruf"]:
    el = next(k for k, v in GROUP.items() if h["ch"] in v)
    h["element"] = el; h["nature"] = NAT[el]
    h["planet"] = PL[(h["rank"] - 1) // 4]
for m in D.get("manazil", []):
    m["element"] = next(k for k, v in GROUP.items() if m["letter"] in v)
D["corrections"].append({"p": 76, "says": "v1.5 and earlier: letters assigned to the elements in the cycle fire · air · water · earth (ب air, ج water, د earth), and to the planets one letter at a time",
  "correct": "the book's own table (p.76, Chart I p.16, the basṭ tables pp.131 and 179–182): fire ا ه ط م ف ش ذ · earth ب و ي ن ص ت ض · air ج ز ك س ق ث ظ · water د ح ل ع ر خ غ; and the planets' letters four at a time in abjad order (p.111): Saturn ابجد, Jupiter هوزح, Mars طيكل, Sun منسع, Venus فصقر, Mercury شتثخ, Moon ذضظغ",
  "how": "read from the book's chapter 1 and its tables; v1.5.1"})
src = src[:i] + 'const DATA = ' + _json.dumps(D, ensure_ascii=False, separators=(",", ":")) + ';' + src[j:]
old = 'const ELEM_CYCLE = ["fire", "air", "water", "earth"];'
assert src.count(old) == 1
src = src.replace(old, 'const ELEM_CYCLE = ["fire", "earth", "air", "water"];   // p.76: ا fire, ب earth, ج air, د water')
src = src.replace('nature: ["hot & dry", "hot & moist", "cold & moist", "cold & dry"][i % 4],', 'nature: ["hot & dry", "cold & dry", "hot & moist", "cold & moist"][i % 4],')
src = src.replace('{["fire","air","water","earth"].map(el => { const set = H.filter(h => h.element === el);', '{["fire","earth","air","water"].map(el => { const set = H.filter(h => h.element === el);')
open('engine_v15.jsx', 'w', encoding='utf-8').write(src)
print("letter elements and planets set from the book")
# ── the basṭ instrument ──
src = open('engine_v15.jsx', encoding='utf-8').read()
calc = open('bastcalc.jsx', encoding='utf-8').read()
anchor = "function Bast({ hue, go, loc, tz }) {"
assert src.count(anchor) == 1
src = src.replace(anchor, calc + anchor)
old = '''    <div style={{ fontFamily: F.mono, fontSize: 10.5, letterSpacing: "0.12em", color: hue + "bb", marginTop: 18 }}>THE NINE MĪZĀN</div>'''
assert src.count(old) == 1
src = src.replace(old, '''    <BastCalc hue={hue} cur={cur} ruler={PH.ruler} now={now} />
''' + old.replace("marginTop: 18", "marginTop: 26"))
open('engine_v15.jsx', 'w', encoding='utf-8').write(src)
print("basṭ instrument added")
src = open('engine_v15.jsx', encoding='utf-8').read()
old = '''      This edition gives the degrees of the four elements but does not tabulate the letters against
      them. The grouping shown is the standard Shams-tradition table — seven letters to each element in
      abjad rank — carried here under that tag and never as this book's own. The values, the ṣaghīr
      reduction and the joint totals are computed from the letters.
      <Cite page={141} anchor="I 52" hue={hue} />{" "}'''
new = '''      The book's own table (chapter 1, pp.76–77; Chart I, p.16): fire — the open letters, hot and dry, east;
      earth — the cut letters, cold and dry, south; air — the closed letters, hot and moist, west; water — the
      broken letters, cold and moist, north. Seven to each, in abjad order fire · earth · air · water. Earlier
      versions of this engine used the cycle fire · air · water · earth, which is not the book's; corrected in v1.6.
      The planets' letters are four to each in abjad order (p.111).
      <Cite page={76} hue={hue} />{" "}<Cite page={111} hue={hue} />{" "}'''
assert src.count(old) == 1, "huruf note"
src = src.replace(old, new)
src = src.replace('DATA.version = "1.5";', 'DATA.version = "2.1";')
open('engine_v15.jsx', 'w', encoding='utf-8').write(src)
print("Ḥurūf note and version")
# ── every page citation opens the book at that page ──
src = open('engine_v15.jsx', encoding='utf-8').read()
old = '''function Cite({ page, anchor, hue }) {
  if (!page) return null;
  return <span style={{ fontFamily: F.mono, fontSize: 10.5, color: hue + "aa", whiteSpace: "nowrap" }}>
    p.{page}{anchor ? " · " + anchor : ""}</span>;
}'''
new = '''function Cite({ page, anchor, hue }) {
  if (!page) return null;
  const open = () => window.__ihyaGo && window.__ihyaGo("kitab", { chapter: chapterOfPage(page), page, view: "read" });
  return <button onClick={open} title={`read p.${page} in the book`} style={{ fontFamily: F.mono, fontSize: 10.5, color: hue + "cc", whiteSpace: "nowrap",
    background: "none", border: "none", borderBottom: `1px dotted ${hue}66`, padding: 0, cursor: "pointer" }}>
    p.{page}{anchor ? " · " + anchor : ""}</button>;
}'''
assert src.count(old) == 1
src = src.replace(old, new)
old2 = '  const go = useCallback((m, o) => { setTab(m); setFocus(o || null); }, []);'
assert src.count(old2) == 1
src = src.replace(old2, old2 + '\n  useEffect(() => { window.__ihyaGo = (m, o) => { go(m, o); window.scrollTo && window.scrollTo(0, 0); }; }, [go]);')
open('engine_v15.jsx', 'w', encoding='utf-8').write(src)
print("citations open the book")
# ── the hollow-centre fivefold (pp.1969–1979) ──
src = open('engine_v15.jsx', encoding='utf-8').read()
def R(old, new, n=1):
    global src
    assert src.count(old) == n, old[:70]
    src = src.replace(old, new)
R('''function checkSums(grid) {
  const n = grid.length;''', '''function checkSums(grid0) {
  const grid = grid0.map(r => r.map(v => (typeof v === "number" ? v : 0)));   // the hollow centre counts nothing
  const n = grid.length;''')
R('''function wafq(A, n) {''', '''/** The hollow-centre fivefold, "muḥammas khālī al-wasaṭ jalālī" (pp.1969–1970): the centre is left for the name or
 *  the need. Air and water form on 66 (the square of p.1971), fire and earth on 65 (the square of p.1978).
 *  Divide the number by the form's constant: the quotient multiplies every cell; any remainder goes once into each
 *  row, column and diagonal — the five cells where the book itself places it (p.1978, the 1503 square). Or, the
 *  book's second way: the number itself multiplies every cell, and the square closes on 66 or 65 times it. */
const HOLLOW5 = {
  66: { base: [[7,3,30,15,11],[26,16,12,8,4],[13,9,null,27,17],[1,28,18,14,5],[19,10,6,2,29]], page: 1971, forms: "air and water" },
  65: { base: [[16,10,1,12,26],[9,21,19,13,3],[15,11,null,14,25],[5,6,23,24,7],[20,17,22,2,4]], page: 1978, forms: "fire and earth" },
};
const HOLLOW5_REM = [[0,2],[1,4],[2,1],[3,3],[4,0]];
function wafqHollow5(A, S0, multiply = false) {
  const H = HOLLOW5[S0];
  if (!Number.isInteger(A) || A <= 0) return { error: "the number must be a whole positive number" };
  if (multiply) return { grid: H.base.map(r => r.map(v => v == null ? null : v * A)), q: A, r: 0, constant: S0 * A, S0, page: H.page, mode: "hollow" };
  const q = Math.floor(A / S0), r = A - q * S0;
  if (q < 1) return { error: `the number must be at least ${S0} to divide by ${S0}` };
  const grid = H.base.map(row => row.map(v => v == null ? null : v * q));
  for (const [i, j] of HOLLOW5_REM) grid[i][j] += r;
  return { grid, q, r, constant: A, S0, page: H.page, mode: "hollow" };
}
function wafq(A, n) {''')
# Forge
R('''  const res = useMemo(() => build === "kalimat" ? (kres && !kres.error ? { grid: kres.grid, ...kres } : { error: kres?.error || "" })
    : build === "mudarrab" ? wafqMudarrab(A, order) : wafq(A, order), [A, order, build, kres]);''',
'''  const [hollowS, setHollowS] = useState(66);
  const [hollowMul, setHollowMul] = useState(false);
  const res = useMemo(() => build === "kalimat" ? (kres && !kres.error ? { grid: kres.grid, ...kres } : { error: kres?.error || "" })
    : build === "hollow" ? wafqHollow5(A, hollowS, hollowMul)
    : build === "mudarrab" ? wafqMudarrab(A, order) : wafq(A, order), [A, order, build, kres, hollowS, hollowMul]);
  useEffect(() => { if (build === "hollow" && order !== 5) setOrder(5); }, [build, order]);''')
R('''  const grid = res.grid ? (order === 4 && bookEl && build !== "kalimat"''', '''  const grid = res.grid ? (order === 4 && bookEl && build !== "kalimat" && build !== "hollow"''')
R('''    grid, above: bands[1] ? formula.ar : "", below: bands[2] ? nameText : "", angels: DATA.angels4, element: elem, frame
  }) : null, [grid, bands, formula, nameText, elem, frame]);''', '''    grid, above: bands[1] ? formula.ar : "", below: bands[2] ? nameText : "", angels: DATA.angels4, element: elem, frame,
    centre: build === "hollow" ? (mode === "number" ? "" : nameText) : ""
  }) : null, [grid, bands, formula, nameText, elem, frame, build, mode]);''')
R('''  const plateAt = (cellPx) => layoutPlate({ grid, above: bands[1] ? formula.ar : "", below: bands[2] ? nameText : "",
    angels: DATA.angels4, element: elem, frame, cell: cellPx });''', '''  const plateAt = (cellPx) => layoutPlate({ grid, above: bands[1] ? formula.ar : "", below: bands[2] ? nameText : "",
    angels: DATA.angels4, element: elem, frame, cell: cellPx, centre: build === "hollow" && mode !== "number" ? nameText : "" });''')
R('''    ["Grid verifies", sums.balanced && sums.constant === (build === "mudarrab" ? res.constant : A)],''',
  '''    ["Grid verifies", sums.balanced && sums.constant === (build === "mudarrab" || build === "hollow" ? res.constant : A)],''')
R('''      <Btn hue={hue} small active={build === "kalimat"} onClick={() => setBuild("kalimat")}>Kalimāt — cycling</Btn>''',
  '''      <Btn hue={hue} small active={build === "kalimat"} onClick={() => setBuild("kalimat")}>Kalimāt — cycling</Btn>
      <Btn hue={hue} small active={build === "hollow"} onClick={() => setBuild("hollow")}>Hollow centre — 5×5</Btn>''')
R('''    {build !== "kalimat" && <div style={{ display: "flex", gap: 5, flexWrap: "wrap", marginTop: 16 }}>''',
  '''    {build === "hollow" && <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginTop: 16, alignItems: "center" }}>
      <Btn hue={hue} small active={hollowS === 66} onClick={() => setHollowS(66)}>air & water · ÷66</Btn>
      <Btn hue={hue} small active={hollowS === 65} onClick={() => setHollowS(65)}>fire & earth · ÷65</Btn>
      <Btn hue={hue} small active={!hollowMul} onClick={() => setHollowMul(false)}>divide — closes on the number</Btn>
      <Btn hue={hue} small active={hollowMul} onClick={() => setHollowMul(true)}>multiply — closes on {hollowS} × the number</Btn>
      <span style={{ fontSize: 12, color: "#ffffff88" }}>the centre is left for the name or the need · <Cite page={1969} hue={hue} /></span>
    </div>}
    {build !== "kalimat" && build !== "hollow" && <div style={{ display: "flex", gap: 5, flexWrap: "wrap", marginTop: 16 }}>''')
R('''          {build === "mudarrab"
            ? `unit ${res.unit} × the classical ${order}×${order} base (constant ${res.baseConstant}) → ${res.baseConstant} × ${res.unit} = ${res.constant}`''',
  '''          {build === "hollow"
            ? (hollowMul ? `${res.S0} × ${A} = ${res.constant}: every cell of the hollow square of p.${res.page} times ${A}`
              : `${A} ÷ ${res.S0} = ${res.q}${res.r ? ` remainder ${res.r}, added once to each row, column and diagonal` : ", no remainder"} · square of p.${res.page}`)
            : build === "mudarrab"
            ? `unit ${res.unit} × the classical ${order}×${order} base (constant ${res.baseConstant}) → ${res.baseConstant} × ${res.unit} = ${res.constant}`''')
R('''<div style={{ fontFamily: F.mono, fontSize: 10.5, color: BOOK_FORMS[order] || order === 10 ? "#8fce7f" : "#e8b84f", marginTop: 4 }}>base: {build === "kalimat" ? "the text's own cycle" : baseSource(order)}</div>''',
  '''<div style={{ fontFamily: F.mono, fontSize: 10.5, color: BOOK_FORMS[order] || order === 10 || build === "hollow" ? "#8fce7f" : "#e8b84f", marginTop: 4 }}>base: {build === "kalimat" ? "the text's own cycle" : build === "hollow" ? `the book's hollow fivefold, ${HOLLOW5[hollowS].forms} form, p.${HOLLOW5[hollowS].page}` : baseSource(order)}</div>''')
# layout: centre text
R('''function layoutPlate({ grid, above = "", below = "", angels = [], element = 0, cell = null, frame = true }) {''',
  '''function layoutPlate({ grid, above = "", below = "", angels = [], element = 0, cell = null, frame = true, centre = "" }) {''')
R('''    items.push({ t: "cell", x, y, w: cs, h: cs, text: v == null ? "" : String(v), fs: cs * (String(v).length > 4 ? 0.24 : 0.32), kind: "grid", v });''',
  '''    if (v == null) { items.push({ t: "cell", x, y, w: cs, h: cs, text: centre || "", fs: centre ? Math.min(cs * 0.42, cs * 1.6 / Math.max(2, [...centre].length)) : 0, kind: "hashiya", ar: true,
      meta: centre ? { ch: centre, v: abjad(centre), tr: "written in the empty centre" } : null }); return; }
    items.push({ t: "cell", x, y, w: cs, h: cs, text: String(v), fs: cs * (String(v).length > 4 ? 0.24 : 0.32), kind: "grid", v });''')
open('engine_v15.jsx', 'w', encoding='utf-8').write(src)
print("hollow fivefold in the Forge")
src = open('engine_v15.jsx', encoding='utf-8').read()
old = '''  useEffect(() => { if (!fits.some(f => f.ok && f.n === order)) { const f = fits.find(x => x.ok); if (f) setOrder(f.n); } }, [fits, order]);'''
assert src.count(old) == 1
src = src.replace(old, '''  useEffect(() => { if (build === "hollow" || build === "kalimat") return; if (!fits.some(f => f.ok && f.n === order)) { const f = fits.find(x => x.ok); if (f) setOrder(f.n); } }, [fits, order, build]);''')
open('engine_v15.jsx', 'w', encoding='utf-8').write(src)
src = open('engine_v15.jsx', encoding='utf-8').read()
src = src.replace('''    : build === "hollow" ? wafqHollow5(A, hollowS, hollowMul)''', '''    : build === "hollow" ? wafqHollow5(A, hollowS, hollowMul || A < hollowS)''')
src = src.replace('''  if (multiply) return { grid: H.base.map(r => r.map(v => v == null ? null : v * A)), q: A, r: 0, constant: S0 * A, S0, page: H.page, mode: "hollow" };''',
 '''  if (multiply) return { grid: H.base.map(r => r.map(v => v == null ? null : v * A)), q: A, r: 0, constant: S0 * A, S0, page: H.page, mode: "hollow", multiplied: true };''')
src = src.replace('''            ? (hollowMul ? `${res.S0} × ${A} = ${res.constant}: every cell of the hollow square of p.${res.page} times ${A}`''',
 '''            ? (res.multiplied ? `${res.S0} × ${A} = ${res.constant}: every cell of the hollow square of p.${res.page} times ${A}${!hollowMul ? ` (${A} is below ${res.S0}, so the book's second way is used)` : ""}`''')
open('engine_v15.jsx', 'w', encoding='utf-8').write(src)
src = open('engine_v15.jsx', encoding='utf-8').read()
src = src.replace("/* ═══ shell ═══ */", open('review.jsx', encoding='utf-8').read() + "\n/* ═══ shell ═══ */", 1)
old = 'const TABS = [["kitab","Kitāb",Kitab],'
assert src.count(old) == 1
src = src.replace(old, 'const TABS = [["kitab","Kitāb",Kitab],["review","Review",Review],')
src = src.replace('atlas:"tahqiq", tashihat:"tahqiq",', 'atlas:"tahqiq", review:"tahqiq", tashihat:"tahqiq",')
open('engine_v15.jsx', 'w', encoding='utf-8').write(src)
print("review tab")
# ── Manāzil: the book's own words on each mansion (ch.3, pp.214–245) ──
src = open('engine_v15.jsx', encoding='utf-8').read()
MB = _json.dumps(_json.load(open('manazil_book.json', encoding='utf-8')), ensure_ascii=False, separators=(",", ":"))
src = src.replace("function Manazil({ hue }) {", "const MANZIL_BOOK = " + MB + ";\nfunction Manazil({ hue }) {", 1)
old = '''    {cur && (() => {
      const tied = COND.filter(c => c.kind === "mansion" && c.tier === "stated"'''
new = '''    {cur && (() => { const B = MANZIL_BOOK.mansions[cur.n - 1]; if (!B) return null;
      const omenCol = B.omen === "auspicious" ? "#8fce7f" : "#e58a7a";
      return <div style={{ marginTop: 16, maxWidth: 760 }}>
        <div style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap" }}>
          <span style={{ fontFamily: F.mono, fontSize: 10.5, letterSpacing: "0.12em", color: hue + "bb" }}>WHAT THE BOOK SAYS OF THIS MANSION</span>
          <span style={{ fontFamily: F.mono, fontSize: 11, color: omenCol, border: `1px solid ${omenCol}66`, padding: "1px 8px", borderRadius: 10 }}>{B.omen}</span>
          <Cite page={MANZIL_BOOK.omenPage} hue={hue} /></div>
        <div style={{ fontFamily: F.mono, fontSize: 10, color: hue, marginTop: 10 }}>ITS JUDGEMENT</div>
        <p style={{ fontSize: 14.5, lineHeight: 1.8, color: "#e9e3d4", margin: "4px 0" }}>{B.judge.t} <Cite page={B.judge.p} hue={hue} /></p>
        {B.stars && <><div style={{ fontFamily: F.mono, fontSize: 10, color: hue, marginTop: 10 }}>ITS STARS</div>
          <p style={{ fontSize: 14, lineHeight: 1.8, color: "#ffffffb0", margin: "4px 0" }}>{B.stars.t} <Cite page={B.stars.p} hue={hue} /></p></>}
        {B.rising && <><div style={{ fontFamily: F.mono, fontSize: 10, color: hue, marginTop: 10 }}>ITS RISING</div>
          <p style={{ fontSize: 14, lineHeight: 1.8, color: "#ffffffb0", margin: "4px 0" }}>{B.rising} <Cite page={238} hue={hue} /></p></>}
      </div>; })()}
    {cur && (() => {
      const tied = COND.filter(c => c.kind === "mansion" && c.tier === "stated"'''
assert src.count(old) == 1
src = src.replace(old, new)
old = '''      Names, degree spans and letter pairings are the standard set of the tradition, carried under that
      tag; this edition treats the mansions but does not tabulate them in a form this pipeline can lift.
      Degrees divide the circle evenly at 12°51′26″ each. Every total is computed from the letters.'''
assert src.count(old) == 1
src = src.replace(old, '''      The book gives each mansion its letter, element and omen (pp.244–245), its judgement (pp.214–228), its stars
      (pp.230–237), its rising (pp.238–240) and its season (p.240): spring, al-Sharaṭayn to al-Dhirāʿ; and so on round
      the year. Degrees divide the circle evenly at 12°51′26″ each; the moon's place is computed. Every total is computed
      from the letters.''')
open('engine_v15.jsx', 'w', encoding='utf-8').write(src)
print("manazil from the book")
# ── Asmāʾ: every name opens its own faṣl of chapter 16 ──
src = open('engine_v15.jsx', encoding='utf-8').read()
FP = _json.load(open('fasl_pages.json'))
src = src.replace("function Asma({ hue, go }) {", "const FASL_PAGE = " + _json.dumps({int(k): v for k, v in FP.items()}) + ";   // ch.16, one faṣl to each name\nfunction Asma({ hue, go }) {", 1)
old = '''              <td style={{ padding: "6px 12px 6px 0" }}>
                <Cite page={x.p} anchor={x.a} hue={hue} />'''
assert src.count(old) == 1
src = src.replace(old, '''              <td style={{ padding: "6px 12px 6px 0" }}>
                {FASL_PAGE[x.o] ? <button onClick={() => go("kitab", { chapter: 16, page: FASL_PAGE[x.o], view: "read" })}
                  style={{ marginRight: 8, background: hue + "22", border: `1px solid ${hue}88`, color: hue,
                    fontFamily: F.mono, fontSize: 9.5, padding: "1px 6px", borderRadius: 2, cursor: "pointer" }}>faṣl {x.o} · p.{FASL_PAGE[x.o]}</button> : null}
                <Cite page={x.p} anchor={x.a} hue={hue} />''')
open('engine_v15.jsx', 'w', encoding='utf-8').write(src)
print("asma faṣl links")
# ── Falak: the book's own passages on each sign (chapters 3–4) ──
src = open('engine_v15.jsx', encoding='utf-8').read()
old = '''          The sign the sun stands in is our arithmetic; everything in the table is the book's.
        </div>
      </div>
    </div>}
  </div>;
}'''
assert src.count(old) == 1
src = src.replace(old, '''          The sign the sun stands in is our arithmetic; everything in the table is the book's.
        </div>
      </div>
    </div>}
    {cur && <BookMentions chapters={[3, 4]} hue={hue} title={`WHAT CHAPTERS 3 AND 4 SAY OF ${cur.name.toUpperCase()}`}
      terms={[cur.name, ...(SIGN_AR[cur.n - 1] || [])]} />}
  </div>;
}
const SIGN_AR = [["al-Ḥamal","Hamel"],["al-Thawr","Sevr"],["al-Jawzāʾ","Cevza"],["al-Saraṭān","Seretan"],["al-Asad","Esed"],["al-Sunbula","Sunbule"],
  ["al-Mīzān"],["al-ʿAqrab","Akrep"],["al-Qaws","Kavs"],["al-Jady","Cedi"],["al-Dalw","Deliv"],["al-Ḥūt"]];''')
open('engine_v15.jsx', 'w', encoding='utf-8').write(src)
print("falak passages")
# ── location that works inside claude.ai: device location when allowed, else time zone, a gazetteer, or typed ──
src = open('engine_v15.jsx', encoding='utf-8').read()
def R(old, new):
    global src
    assert src.count(old) == 1, old[:80]
    src = src.replace(old, new)
R("function Majlis({ hue, go, loc, setLoc }) {", open('cities.js', encoding='utf-8').read() + "\nfunction Majlis({ hue, go, loc, setLoc }) {")
R('''  const useMyLocation = () => {
    if (typeof navigator === "undefined" || !navigator.geolocation) {
      setGeoMsg("this browser offers no geolocation — type a latitude and longitude instead"); return;
    }
    setGeoMsg("asking the browser…");
    navigator.geolocation.getCurrentPosition(
      p => { const v = { lat: +p.coords.latitude.toFixed(4), lon: +p.coords.longitude.toFixed(4),
                         utc: tzOffsetFor(new Date()), label: "from this device", fixedOffset: false };
             setLoc(v); saveLoc(v); setLat(String(v.lat)); setLon(String(v.lon)); setUtc(String(v.utc));
             setGeoMsg("set from this device — nothing left it"); },
      e => setGeoMsg("location refused or unavailable — type it instead"),
      { enableHighAccuracy: false, timeout: 10000, maximumAge: 600000 });
  };''', '''  const [cityQ, setCityQ] = useState("");
  const place = (v, msg) => { setLoc(v); saveLoc(v); setLat(String(v.lat)); setLon(String(v.lon)); setUtc(""); if (msg) setGeoMsg(msg); };
  const fallback = (why) => {
    const z = cityFromZone();
    if (z) place(z, `${why} — placed you at ${z.label}. Search your own town below for exact times.`);
    else setGeoMsg(`${why} — search your town below, or type a latitude and longitude.`);
  };
  const useMyLocation = () => {
    let allowed = true;
    try { const fp = document.permissionsPolicy || document.featurePolicy; if (fp && fp.allowsFeature && !fp.allowsFeature("geolocation")) allowed = false; } catch {}
    if (typeof navigator === "undefined" || !navigator.geolocation || !allowed) {
      fallback("this page runs inside claude.ai, which does not pass your device's location to it"); return;
    }
    setGeoMsg("asking the browser…");
    let done = false;
    const guard = setTimeout(() => { if (!done) { done = true; fallback("no answer from the browser's location service"); } }, 8000);
    try {
      navigator.geolocation.getCurrentPosition(
        p => { if (done) return; done = true; clearTimeout(guard);
               place({ lat: +p.coords.latitude.toFixed(4), lon: +p.coords.longitude.toFixed(4), label: "from this device", fixedOffset: false },
                     "set from this device — nothing left it"); },
        e => { if (done) return; done = true; clearTimeout(guard);
               fallback(e && e.code === 1 ? "location permission was not given here (claude.ai may block it for pages)" : "the device could not find its position"); },
        { enableHighAccuracy: false, timeout: 10000, maximumAge: 600000 });
    } catch { done = true; clearTimeout(guard); fallback("the browser refused the location request"); }
  };
  const cityHits = cityQ.trim().length < 2 ? [] : CITIES.filter(c => fold(c[0]).includes(fold(cityQ.trim()))).slice(0, 12);''')
R('''      {PRESET_CITIES.map(([nm, a, b, u]) => <Btn key={nm} hue={hue} small
        onClick={() => { const v = { lat: a, lon: b, utc: u, label: nm, fixedOffset: false };
          setLat(String(a)); setLon(String(b)); setUtc(String(u)); setLoc(v); saveLoc(v); }}>{nm}</Btn>)}''',
'''      <Field hue={hue} label="FIND YOUR TOWN"><input value={cityQ} onChange={e => setCityQ(e.target.value)} placeholder="Tigard, Mecca, Dakar…"
        style={{ ...inputBase, width: 200 }} /></Field>
      {cityHits.map(c => <Btn key={c[0]} hue={hue} small onClick={() => { place({ lat: c[1], lon: c[2], label: c[0], fixedOffset: false }, `set to ${c[0]}`); setCityQ(""); }}>{c[0]}</Btn>)}
      {cityHits.length === 0 && ["Tigard, Oregon", "Salem, Oregon", "Portland, Oregon", "Mecca", "Madina"].map(nm => { const c = CITIES.find(x => x[0] === nm);
        return <Btn key={nm} hue={hue} small active={loc && loc.label === nm} onClick={() => place({ lat: c[1], lon: c[2], label: nm, fixedOffset: false }, `set to ${nm}`)}>{nm}</Btn>; })}''')
R('''      {geoMsg && <span style={{ fontSize: 11.5, color: "#8fce7f" }}>{geoMsg}</span>}''',
  '''      {geoMsg && <div style={{ flexBasis: "100%", fontSize: 12.5, color: "#8fce7f" }}>{geoMsg}</div>}''')
# App: if nothing saved, stand at the time zone's city
R('''  useEffect(() => { loadLoc().then(v => { if (v) setLoc(v); }); }, []);''',
  '''  useEffect(() => { loadLoc().then(v => { if (v) setLoc(v); else { const z = cityFromZone(); if (z) setLoc(z); } }); }, []);''')
open('engine_v15.jsx', 'w', encoding='utf-8').write(src)
print("location")
# ── corrections: only what is established; the rest is not a correction ──
src = open('engine_v15.jsx', encoding='utf-8').read()
i = src.index('const DATA = '); j = src.index('\n', i)
D = _json.loads(src[i + 13:j].rstrip().rstrip(';'))
def keep(c):
    p = c.get("p"); says = c.get("says", "")
    if p is None: return False                                  # working notes of the engine, not corrections to the book
    if p in (365, 627, 1131, 1198, 1267) and "as printed" in says: return False   # v1.3 extraction artefacts; the squares were since read by eye
    if p == 2036: return False                                  # superseded by the figure corrections of pp.2034–2037
    if p == 1119: return False                                  # the centre 57→58 is figure #175; the shadda note is an explanation
    return True
D["corrections"] = [dict(c, verified=True) for c in D["corrections"] if keep(c)]
src = src[:i] + 'const DATA = ' + _json.dumps(D, ensure_ascii=False, separators=(",", ":")) + ';' + src[j:]
open('engine_v15.jsx', 'w', encoding='utf-8').write(src)
print("corrections kept:", len(D["corrections"]))
# ── Ashkāl: every figure, cleaned and enlarged ──
src = open('engine_v15.jsx', encoding='utf-8').read()
old = 'const TABS = [["kitab","Kitāb",Kitab],["review","Review",Review],'
assert src.count(old) == 1
src = src.replace(old, 'const TABS = [["kitab","Kitāb",Kitab],["ashkal","Ashkāl",Gallery],["review","Review",Review],')
src = src.replace('const GROUP_OF = { kitab:"kitab",', 'const GROUP_OF = { kitab:"kitab", ashkal:"kitab",')
open('engine_v15.jsx', 'w', encoding='utf-8').write(src)
print("gallery tab")
# ── Ṭalāsim ──
src = open('engine_v15.jsx', encoding='utf-8').read()
old = '["ashkal","Ashkāl",Gallery],'
assert src.count(old) == 1
src = src.replace(old, '["talasim","Ṭalāsim",Talismans],["ashkal","Ashkāl",Gallery],')
src = src.replace('const GROUP_OF = { kitab:"kitab", ashkal:"kitab",', 'const GROUP_OF = { kitab:"kitab", talasim:"kitab", ashkal:"kitab",')
open('engine_v15.jsx', 'w', encoding='utf-8').write(src)
print("talasim tab")

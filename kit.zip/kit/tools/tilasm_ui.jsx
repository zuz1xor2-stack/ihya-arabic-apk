
/* ═══ Ṭilasm Studio — forge any talisman of the book, or of the Durūs lessons, whole: rings, frames, seals, squares and
 *  the written lines, for your own name, need and person. ═══ */
const TL_GROUPS = [["all", "everything"], ["durus", "from the lessons"], ["seal", "talismans, seals & circles"], ["square", "squares, whole"], ["table", "tables & charts"]];

function tlForgeGrid(spec, A0, text, useBook) {
  const fg = spec.forge; if (!fg) return { grid: null };
  const A = fg.value || (useBook && fg.book) || A0; if (!A) return { grid: null };
  if (useBook && fg.book) text = fg.bookText || "";
  const r = tlForgeGrid0(spec, fg, A, text);
  if (r.grid && fg.centre) { const n = r.grid.length, c = (n - 1) / 2; if (Number.isInteger(c)) r.grid = r.grid.map((row, i) => row.map((v, j) => i === c && j === c ? fg.centre : v)); }
  if (fg.value) r.how = (r.how || "") + ` · on ${fg.value}${fg.centre ? `, with ${fg.centre} written in the centre` : ""}`;
  if (useBook && fg.book) r.how = (r.how || "") + ` · on the book's own value, ${fg.book}`;
  return r;
}
function tlForgeGrid0(spec, fg, A, text) {
  if (fg.fixed) return { grid: fg.fixed, how: "the figure's own cells, unchanged" };
  const src = fg.cells || (fg.fig != null ? (BOOK.figs.find(x => x.id === fg.fig) || {}).grid : null);
  if (src) { const an = SHAKL.analyse(src, abjad);
    if (an && an.kind !== "plate" && an.hollow && src.length === 3 && A >= 12 && (() => { const E = hollowEdges(src)[0], h0 = hollow3_first(E); return !h0.error && JSON.stringify(h0.grid) === JSON.stringify(src.map(r => r.map(v => v == null || typeof v !== "number" ? null : v))); })()) {
      const h = hollow3_first(A);
      if (!h.error) return { grid: h.grid.map(row => row.map(v => v == null ? "{centreText}" : v)), how: `the hollow threefold's first rule: ${A} ÷ 12 = ${h.q}${h.r ? ` remainder ${h.r}` : ""} (p.1748); each edge closes on ${A}`, sums: null, hollow: true };
    }
    if (an && an.kind !== "plate") {
      const segs = text ? splitText(text, "letter") : [];
      for (const m of (fg.methods || (an.kind === "letters" ? ["letters", ...an.methods.filter(x => x !== "letters")] : an.methods))) {
        if ((m === "letters" || m === "top") && !text) continue;
        const r = SHAKL.forge(an, m, { A, segs, segVals: segs.map(s => abjad(s)) }, abjad);
        if (!r.error) { let g = r.shown;
          if (an.hollow) { const c = (g.length - 1) / 2; g = g.map((row, i) => row.map((v, j) => i === c && j === c && (v == null || v === "") ? "{centreText}" : v)); }
          return { grid: g, how: SHAKL_METHOD[m] ? SHAKL_METHOD[m][0] : m, sums: checkSums(r.values), hollow: an.hollow }; }
      }
      return { grid: null, error: `the figure's square cannot carry ${A} by any of its ways` };
    } }
  const n = fg.order || 4;
  if (fg.rule === "third" && n === 3) { const r = three_third(A); return { grid: r.grid, how: "third rule: cell k = k × the value (p.1709)", sums: checkSums(r.grid) }; }
  if (fg.rule === "second" && n === 3) { const r = three_second(A); return { grid: r.grid, how: "second rule: the value in the centre (p.1705)", sums: checkSums(r.grid) }; }
  if (fg.rule === "hollow3") { const r = hollow3_first(A); if (r.error) return { grid: null, error: r.error };
    const g = r.grid.map(row => row.map(v => v == null ? (text || "") : v)); return { grid: g, how: "hollow-centre first rule (p.1748)", sums: null, hollow: true }; }
  const w = wafq(A, n); if (w.error) return { grid: null, error: w.error };
  return { grid: toVisual(w.grid), how: `the ${n}×${n} by the first rule of ch.19`, sums: checkSums(w.grid) };
}

function TilasmStudio({ hue, go, focus, onKeep }) {
  const [specs, setSpecs] = useState(null);
  const [font, setFont] = useState(null);
  const [err, setErr] = useState(null);
  const [sel, setSel] = useState(() => LS.get("tlSel", null));
  const [q, setQ] = useState("");
  const [grp, setGrp] = useState("all");
  const [nameOrd, setNameOrd] = useState(() => LS.get("tlName", 18));
  const [src, setSrc] = useState(() => LS.get("tlSrc", "name"));
  const [text, setText] = useState(() => LS.get("tlText", "حسبنا الله ونعم الوكيل"));
  const [num, setNum] = useState(() => LS.get("tlNum", ""));
  const [need, setNeed] = useState(() => LS.get("tlNeed", ""));
  const [person, setPerson] = useState(() => LS.get("tlPerson", ""));
  const [mother, setMother] = useState(() => LS.get("tlMother", ""));
  const [paper, setPaper] = useState(true);
  const [compare, setCompare] = useState(false);
  const [over, setOver] = useState({});        // element index → text override
  const [hide, setHide] = useState({});        // element index → hidden
  const [traces, setTraces] = useState({});
  const [useBook, setUseBook] = useState(true);
  const [asPrinted, setAsPrinted] = useState(false);
  const [clean, setClean] = useState(() => LS.get("tlClean2", false));
  const [penW, setPenW] = useState(() => LS.get("tlPenW", 1));
  useEffect(() => { LS.set("tlClean2", clean); LS.set("tlPenW", penW); }, [clean, penW]);
  useEffect(() => { loadTilasm().then(setSpecs).catch(e => setErr(String(e))); loadPlotFont().then(setFont).catch(() => setFont(false)); }, []);
  useEffect(() => { if (focus && focus.id != null) { setSel(String(focus.id)); setQ(""); setGrp("all"); }
    if (focus && focus.text) { setSrc("text"); setText(focus.text); } if (focus && focus.need) setNeed(focus.need); }, [focus]);
  useEffect(() => { LS.set("tlSel", sel); setOver({}); setHide({}); }, [sel]);
  useEffect(() => { if (!specs || sel == null) return; const sp = specs.list.find(s => s.id === sel); if (sp) setHide(Object.fromEntries(sp.els.map((e, i) => [i, !!e.off]).filter(x => x[1]))); }, [specs, sel]);
  useEffect(() => { LS.set("tlName", nameOrd); LS.set("tlSrc", src); LS.set("tlText", text); LS.set("tlNum", num); LS.set("tlNeed", need); LS.set("tlPerson", person); LS.set("tlMother", mother); }, [nameOrd, src, text, num, need, person, mother]);

  const list = useMemo(() => !specs ? [] : specs.list.filter(s => (grp === "all" || s.group === grp || (grp === "book" && s.src === "book") || (grp === "durus" && s.src === "durus"))
    && (!q || fold(`${s.title} ${s.desc || ""} ${s.page || ""} #${s.fig ?? ""}`).includes(fold(q)))), [specs, grp, q]);
  const spec = specs && sel != null ? specs.list.find(s => s.id === sel) : null;
  const needTr = spec ? [...new Set(spec.els.filter(e => e.t === "trace" || e.t === "signgrid").map(e => e.fig))] : [];
  useEffect(() => { for (const id of needTr) if (!traces[id]) loadPlotPack(Math.floor(id / 100)).then(p => setTraces(t => ({ ...t, [id]: p[String(id)] || { o: [], c: [] } }))).catch(() => setTraces(t => ({ ...t, [id]: { o: [], c: [] } }))); }, [needTr.join(",")]);
  const tracesReady = needTr.every(id => traces[id]);
  const rec = DATA.names.find(x => x.o === +nameOrd) || DATA.names[0];
  const forText = src === "name" ? rec.ab : src === "text" ? text.trim() : "";
  const A = src === "number" ? (parseInt(String(num).replace(/\D/g, ""), 10) || 0) : src === "name" ? rec.mb : abjad(text);
  const forged = useMemo(() => spec && !asPrinted ? tlForgeGrid(spec, A, forText, useBook) : { grid: null }, [spec, A, forText, useBook, asPrinted]);
  const P = useMemo(() => spec ? {
    ...(spec.slots || {}), name: forText || (spec.slots && spec.slots.name) || "", value: A || "", need: need.trim() || (spec.slots && spec.slots.need) || "",
    person: person.trim() || (spec.slots && spec.slots.person) || "", mother: mother.trim() || (spec.slots && spec.slots.mother) || "",
    grid: forged.grid, script: CELL_SCRIPT, on: true, traces, clean, penW,
    centreText: person.trim() ? `${person.trim()}${mother.trim() ? " بن " + mother.trim() : ""}` : (need.trim() || forText || "حاجة"),
  } : null, [spec, forText, A, need, person, mother, forged, traces]);
  const spec2 = useMemo(() => spec ? { ...spec, els: spec.els.map((e, i) => hide[i] ? { t: "skip" } : asPrinted && e.cells === "$forge" ? { t: "skip" } : asPrinted && e.t === "trace" ? { ...e, cut: null, cuts: null } : over[i] != null ? { ...e, text: over[i] } : e) } : null, [spec, over, hide, asPrinted]);
  const G = useMemo(() => (spec2 && font !== null && tracesReady) ? tlBuild(spec2, font || null, P) : null, [spec2, font, P, tracesReady]);
  const ink = paper ? "#141210" : "#efe7d4", bg = paper ? "#fbf8f0" : "#0d0b08";
  const svg = G ? tlSVG(G, { ink, paper: bg, title: spec.title }) : "";
  const stem = spec ? `tilasm-${spec.id}-${(forText || String(A || "")).replace(/\s+/g, "_").slice(0, 24)}` : "tilasm";
  const prov = spec ? `${spec.title}${spec.page ? ` · Iḥyāʾ p.${spec.page}` : ""}${spec.src === "durus" ? " · from the Durūs course" : ""} · composed by the engine${forText ? " for " + forText : ""}` : "";
  const dlSvg = () => G && download(`${stem}.svg`, tlSVG(G, { ink: "#111", paper: "#fff", title: spec.title, foot: prov }), "image/svg+xml");
  const dlPng = () => G && svgToPng(tlSVG(G, { ink: "#111", paper: "#fff", title: spec.title, foot: prov }), `${stem}.png`, 2);
  const toPlot = () => G && go("qalam", { job: { kind: "geom", G: tlPlotSrc(G), title: spec.title, stem } });
  const editable = spec ? spec.els.map((e, i) => [e, i]).filter(([e]) => (e.t === "ring" || e.t === "text") && (e.off || !/^\{\w+\}$/.test(String(e.text || "")))) : [];
  const label = { fontFamily: F.mono, fontSize: 10.5, letterSpacing: "0.12em", color: hue + "bb", marginTop: 14, marginBottom: 6 };
  const counts = specs ? Object.fromEntries(TL_GROUPS.map(([k]) => [k, specs.list.filter(s => k === "all" || s.group === k || s.src === k).length])) : {};

  if (err) return <div><H2 hue={hue}>Ṭilasm Studio</H2><div style={{ color: "#f0a090" }}>The talisman specs could not be loaded ({err}).</div></div>;
  return <div>
    <H2 hue={hue} sub="every talisman of the book and of the lessons, composed whole — rings, frames, seals, squares and the written lines — for your own name and need">Ṭilasm Studio</H2>
    <div style={{ display: "flex", gap: 6, flexWrap: "wrap", alignItems: "center" }}>
      {TL_GROUPS.map(([k, l]) => <Pill key={k} hue={hue} active={grp === k} onClick={() => setGrp(k)}>{l}{specs ? ` · ${counts[k]}` : ""}</Pill>)}
      <div style={{ position: "relative", flex: "1 1 220px", maxWidth: 340 }}>
        <Icon n="search" size={15} style={{ position: "absolute", left: 12, top: "50%", transform: "translateY(-50%)", color: "#ffffff55" }} />
        <input value={q} onChange={e => setQ(e.target.value)} placeholder="seal, ring, Solomon, a page…" style={{ ...S.input, padding: "8px 12px 8px 34px", fontSize: 14 }} /></div>
    </div>

    <div style={{ ...S.card, padding: 14, marginTop: 14 }}>
      <div style={{ display: "flex", gap: 6, flexWrap: "wrap", alignItems: "center" }}>
        <span style={{ ...S.label, color: hue }}>For</span>
        {[["name", "a Name of Allah"], ["text", "a name, verse or need"], ["number", "a number"]].map(([k, l]) => <Pill key={k} hue={hue} active={src === k} onClick={() => setSrc(k)}>{l}</Pill>)}
        {src === "name" && <select value={nameOrd} onChange={e => setNameOrd(+e.target.value)} style={{ ...S.input, width: "auto", padding: "7px 10px", fontSize: 13.5 }}>
          {DATA.names.map(x => <option key={x.o} value={x.o}>{x.o}. {x.tr} — {x.en}</option>)}</select>}
        {src === "text" && <input dir="rtl" value={text} onChange={e => setText(e.target.value)} style={{ ...S.input, width: "min(360px,100%)", fontFamily: F.ar, fontSize: 19, padding: "5px 12px" }} />}
        {src === "number" && <input inputMode="numeric" value={num} onChange={e => setNum(e.target.value)} style={{ ...S.input, width: 130, padding: "7px 10px" }} />}
        {A > 0 && <span style={{ fontFamily: F.mono, fontSize: 12, color: hue }}>{forText && <span dir="rtl" style={{ fontFamily: F.ar, fontSize: 19, color: "#f3ecdc", marginRight: 8 }}>{forText}</span>}{A} · {toIndic(A)}</span>}
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(min(100%,200px),1fr))", gap: 8, marginTop: 10 }}>
        <input dir="rtl" value={need} onChange={e => setNeed(e.target.value)} placeholder="الحاجة · the need (optional)" style={{ ...S.input, fontFamily: F.ar, fontSize: 17, padding: "6px 12px" }} />
        <input dir="rtl" value={person} onChange={e => setPerson(e.target.value)} placeholder="فلان · the person's name" style={{ ...S.input, fontFamily: F.ar, fontSize: 17, padding: "6px 12px" }} />
        <input dir="rtl" value={mother} onChange={e => setMother(e.target.value)} placeholder="فلانة · the mother's name" style={{ ...S.input, fontFamily: F.ar, fontSize: 17, padding: "6px 12px" }} />
      </div>
    </div>

    <div style={{ display: "grid", gridTemplateColumns: spec ? "minmax(0,300px) minmax(0,1fr)" : "1fr", gap: 18, marginTop: 14 }} className="kitab-grid">
      <div style={{ maxHeight: spec ? "92vh" : "70vh", overflowY: "auto", display: "grid", gap: 6, alignContent: "start" }}>
        {!specs && <div style={{ color: "#ffffff77" }}>Loading the talismans…</div>}
        {list.map(s => <button key={s.id} onClick={() => setSel(s.id)} className="ih-row" style={{ textAlign: "left", background: sel === s.id ? hue + "1f" : "#ffffff05", border: `1px solid ${sel === s.id ? hue + "77" : "#ffffff12"}`, borderRadius: 10, padding: "9px 11px", color: "inherit", cursor: "pointer" }}>
          <div style={{ fontFamily: F.mono, fontSize: 10, color: sel === s.id ? hue : "#ffffff66" }}>{s.src === "durus" ? `Durūs ${s.lesson || ""}` : `#${s.fig} · p.${s.page}`}{s.status === "partial" ? " · partly read" : ""}</div>
          <div style={{ fontSize: 14, color: "#f0ead9", lineHeight: 1.35 }}>{s.title}</div></button>)}
        {specs && !list.length && <div style={{ color: "#ffffff77", padding: 8 }}>Nothing matches.</div>}
      </div>

      {spec && <div style={{ minWidth: 0 }}>
        <div style={{ display: "flex", justifyContent: "space-between", gap: 10, flexWrap: "wrap", alignItems: "flex-start" }}>
          <div style={{ minWidth: 0 }}>
            <div style={{ fontFamily: F.mono, fontSize: 10.5, color: hue }}>{spec.src === "durus" ? `the Durūs course · lesson ${spec.lesson}` : <>figure #{spec.fig} · <Cite page={spec.page} hue={hue} /></>}</div>
            <div style={{ fontFamily: F.disp, fontSize: 25, lineHeight: 1.2 }}>{spec.title}</div></div>
          <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
            <Pill hue={hue} active={paper} onClick={() => setPaper(p => !p)}>{paper ? "on paper" : "on dark"}</Pill>
            {spec.els.some(e => e.t === "trace" || e.t === "signgrid") && <Pill hue={hue} active={clean} onClick={() => setClean(c => !c)} title="redraw the printed figure's lines with an even pen">{clean ? "redrawn clean" : "printed ink"}</Pill>}
            {clean && spec.els.some(e => e.t === "trace" || e.t === "signgrid") && <span style={{ display: "inline-flex", gap: 4 }}>{[0.7, 1, 1.4].map(w => <Pill key={w} hue={hue} active={penW === w} onClick={() => setPenW(w)}>{w < 1 ? "fine" : w > 1 ? "bold" : "pen"}</Pill>)}</span>}
            {spec.fig != null && <Pill hue={hue} active={compare} onClick={() => setCompare(c => !c)}>beside the printed figure</Pill>}
            {spec.forge && spec.els.some(e => e.t === "trace") && <Pill hue={hue} active={asPrinted} onClick={() => setAsPrinted(a => !a)}>as printed</Pill>}
            {spec.forge && spec.forge.book && !asPrinted && <Pill hue={hue} active={useBook} onClick={() => setUseBook(b => !b)}>{useBook ? `the book's value · ${spec.forge.book}` : "your value"}</Pill>}
          </div>
        </div>
        {spec.desc && <div style={{ color: "#ffffffaa", fontSize: 14.5, lineHeight: 1.6, marginTop: 8 }}>{spec.desc}</div>}
        <div style={{ display: "grid", gridTemplateColumns: compare ? "repeat(auto-fit,minmax(min(100%,300px),1fr))" : "1fr", gap: 12, marginTop: 12 }}>
          <div style={{ background: bg, borderRadius: 12, border: "1px solid #ffffff1a", padding: 8, lineHeight: 0 }}>
            {G ? <div style={{ width: "100%", maxWidth: 720, margin: "0 auto" }} dangerouslySetInnerHTML={{ __html: svg.replace(/width="[\d.]+" height="[\d.]+"/, 'width="100%" style="height:auto;display:block"') }} />
              : <div style={{ color: "#888", padding: 30, lineHeight: 1.5 }}>Composing…</div>}</div>
          {compare && spec.fig != null && <div style={{ background: "#0d0b08", borderRadius: 12, border: "1px solid #ffffff1a", padding: 8 }}><FigImage id={spec.fig} /></div>}
        </div>
        {forged.how && <div style={{ fontFamily: F.mono, fontSize: 11.5, color: forged.sums && !forged.sums.balanced ? "#f0a090" : "#9fd8a8", marginTop: 8 }}>
          square: {forged.how}{forged.sums && forged.sums.balanced ? ` · every row and column ${forged.sums.constant}${forged.sums.diagonals ? " · diagonals too" : ""}` : ""}{forged.hollow ? " · the centre carries the name" : ""}</div>}
        {forged.error && <div style={{ color: "#f0b090", fontSize: 13.5, marginTop: 8 }}>{forged.error} — choose another name or number.</div>}
        <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginTop: 12 }}>
          <Btn hue="#e8c96a" small onClick={dlSvg}>download SVG</Btn>
          <Btn hue="#e8c96a" small onClick={dlPng}>download PNG</Btn>
          <Btn hue="#e8c96a" small onClick={toPlot}>✒ send to the plotter</Btn>
          {onKeep && <Btn hue={hue} small onClick={() => onKeep({ kind: "tilasm", title: spec.title, spec: spec.id, for: forText, value: A, need, person, mother })}>keep in the grimoire</Btn>}
          {spec.page && <Btn hue={hue} small onClick={() => go("kitab", { chapter: chapterOfPage(spec.page), page: spec.page, view: "read" })}>read it · p.{spec.page}</Btn>}
          {spec.lesson && <Btn hue={hue} small onClick={() => go("durus")}>the lesson</Btn>}
        </div>
        {editable.length > 0 && <>
          <div style={label}>ITS WRITTEN PARTS — edit any line; the composition follows</div>
          <div style={{ display: "grid", gap: 6 }}>
            {editable.map(([e, i]) => <div key={i} style={{ display: "grid", gridTemplateColumns: "auto minmax(0,1fr) auto", gap: 8, alignItems: "center" }}>
              <span style={{ fontFamily: F.mono, fontSize: 10, color: "#ffffff66", width: 70 }}>{e.label || (e.t === "ring" ? "ring" : "line")}</span>
              <input dir="rtl" value={over[i] != null ? over[i] : String(e.text || "")} onChange={ev => setOver(o => ({ ...o, [i]: ev.target.value }))}
                style={{ ...S.input, fontFamily: F.ar, fontSize: 16, padding: "5px 10px", opacity: hide[i] ? 0.4 : 1 }} />
              <button onClick={() => setHide(h => ({ ...h, [i]: !h[i] }))} title={hide[i] ? "show" : "leave out"} style={{ background: "none", border: "1px solid #ffffff22", borderRadius: 8, color: hide[i] ? "#ffffff55" : hue, cursor: "pointer", padding: "4px 8px", fontFamily: F.mono, fontSize: 10.5 }}>{hide[i] ? "off" : "on"}</button>
            </div>)}
            {(Object.keys(over).length > 0 || Object.keys(hide).length > 0) && <div><Btn hue={hue} small onClick={() => { setOver({}); setHide({}); }}>restore the book's text</Btn></div>}
          </div></>}
        {spec.how && <><div style={label}>HOW IT IS MADE</div>
          <ol style={{ margin: 0, paddingLeft: 20, color: "#e9e3d4", lineHeight: 1.7, fontSize: 14.5 }}>{spec.how.map((h, i) => <li key={i}>{withAnchors(h, "")}</li>)}</ol></>}
        {spec.notes && spec.notes.length > 0 && <><div style={label}>WHAT WAS READ, AND WHAT WAS CORRECTED</div>
          {spec.notes.map((n, i) => <div key={i} style={{ fontSize: 13.5, color: "#ffffffaa", lineHeight: 1.6, margin: "3px 0" }}>· {n}</div>)}</>}
        <div style={{ fontFamily: F.mono, fontSize: 10.5, color: "#ffffff55", marginTop: 12, lineHeight: 1.6 }}>{prov}. Geometry, not a picture: the same lines go to the screen, the files and the pen.</div>
      </div>}
    </div>
  </div>;
}

/** A book figure composed whole with a square already forged elsewhere (the Ashkāl Forge): frame, rings and lines as
 *  printed, the rebuilt square in its place. */
function TilasmWhole({ figId, grid, hue, go, stem, title, P0, fallback }) {
  const [spec, setSpec] = useState(undefined);
  const [font, setFont] = useState(null);
  const [tr, setTr] = useState(null);
  const [paper, setPaper] = useState(true);
  useEffect(() => { let on = true; setSpec(undefined); setTr(null);
    loadTilasm().then(d => on && setSpec(d.list.find(s => s.fig === figId) || null)).catch(() => on && setSpec(null));
    loadPlotPack(Math.floor(figId / 100)).then(p => on && setTr(p[String(figId)] || { o: [], c: [] })).catch(() => on && setTr({ o: [], c: [] }));
    return () => { on = false; }; }, [figId]);
  useEffect(() => { loadPlotFont().then(setFont).catch(() => setFont(false)); }, []);
  const G = useMemo(() => spec && tr && font !== null ? tlBuild({ ...spec, els: spec.els.filter(e => !e.off) }, font || null, { ...(P0 || {}), centreText: (P0 && P0.name) || "", grid, traces: { [figId]: tr }, script: CELL_SCRIPT }) : null, [spec, tr, font, grid, P0]);
  if (spec === null || (spec && !spec.forge)) return fallback || null;
  if (!G) return <div style={{ fontFamily: F.mono, fontSize: 11, color: "#ffffff66", padding: 10 }}>composing the whole figure…</div>;
  const ink = paper ? "#141210" : "#efe7d4", bg = paper ? "#fbf8f0" : "#0d0b08";
  const svg = tlSVG(G, { ink, paper: bg });
  const foot = `${title || ""} · composed by the engine on the book's figure #${figId} · not printed in the book`;
  return <div>
    <div style={{ background: bg, borderRadius: 10, border: "1px solid #ffffff1a", padding: 8, lineHeight: 0 }}>
      <div style={{ width: "100%", maxWidth: 680, margin: "0 auto" }} dangerouslySetInnerHTML={{ __html: svg.replace(/width="[\d.]+" height="[\d.]+"/, 'width="100%" style="height:auto;display:block"') }} /></div>
    <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginTop: 8 }}>
      <Btn hue={hue} small active={paper} onClick={() => setPaper(p => !p)}>{paper ? "on paper" : "on dark"}</Btn>
      <Btn hue="#e8c96a" small onClick={() => download(`${stem || "figure-" + figId}-whole.svg`, tlSVG(G, { ink: "#111", paper: "#fff", foot }), "image/svg+xml")}>download whole (SVG)</Btn>
      <Btn hue="#e8c96a" small onClick={() => svgToPng(tlSVG(G, { ink: "#111", paper: "#fff", foot }), `${stem || "figure-" + figId}-whole.png`, 2)}>download whole (PNG)</Btn>
      <Btn hue="#e8c96a" small onClick={() => go("qalam", { job: { kind: "geom", G: tlPlotSrc(G), title: title || `figure #${figId}`, stem: (stem || "figure-" + figId) + "-whole" } })}>✒ plot the whole</Btn>
      {go && <Btn hue={hue} small onClick={() => go("studio", { id: spec.id })}>open in the Ṭilasm Studio</Btn>}
    </div>
  </div>;
}

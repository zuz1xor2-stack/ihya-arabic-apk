// Today: every chapter-20 fact in the table is found on its own pages of the engine's text, and the hour table matches pp.116–117.
import { readFileSync, existsSync } from 'fs';
const src = readFileSync(new URL('../tools/today.jsx', import.meta.url), 'utf8');
const grab = (name) => { const a = src.indexOf(`const ${name} = `); let i = src.indexOf('[', a) >= 0 && src.indexOf('[', a) < src.indexOf('{', a) ? src.indexOf('[', a) : src.indexOf('{', a);
  let d = 0, j = i; for (; j < src.length; j++) { const c = src[j]; if (c === '[' || c === '{') d++; if (c === ']' || c === '}') { d--; if (!d) break; } } return eval('(' + src.slice(i, j + 1) + ')'); };
const CH20 = grab('CH20'), HOUR_BOOK = grab('HOUR_BOOK');
let fail = 0; const ok = (c, m) => { if (!c) { fail++; console.log('FAIL', m); } };
const bookPath = new URL('../../book/ch20.json', import.meta.url);
ok(CH20.length === 7, 'seven days');
if (existsSync(bookPath)) {
  const B = JSON.parse(readFileSync(bookPath, 'utf8')); let p = 0; const pages = {};
  for (const x of B.items) { if (x.k === 'pg') { p = x.p; continue; } if (x.t) pages[p] = (pages[p] || '') + ' ' + x.t; }
  const fold = s => s.normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[ʿʾ]/g, '');
  CH20.forEach((w, i) => {
    const txt = fold(Object.entries(pages).filter(([q]) => +q >= w.pp[0] && +q <= w.pp[1]).map(e => e[1]).join(' '));
    for (const k of ['tahtil', 'adjured', 'master']) if (w[k]) for (const part of w[k].split(', ')) ok(txt.includes(fold(part)), `day ${i} ${k} "${part}" on pp.${w.pp}`);
    ok(txt.includes(fold(w.angel)), `day ${i} angel "${w.angel}" in the reading text`);
    if (w.printed) { ok(txt.includes('Corrected in this edition'), `day ${i} carries its correction note`);
      const body = txt.replace(/Corrected in this edition[^\n]*?(?=  |$)/g, '');
      ok(!new RegExp('O ' + fold(w.printed)).test(body), `day ${i} no longer invokes the printed ${w.printed}`); }
    ok(txt.includes(fold(w.king.split(' (')[0].split(',')[0])), `day ${i} king`);
    ok(txt.includes('Q ' + w.yasin) || txt.includes(w.yasin), `day ${i} Yā-Sīn ${w.yasin}`);
    ok(txt.includes('Q ' + w.seal) || txt.includes(w.seal), `day ${i} sealing verse ${w.seal}`);
    if (w.group) ok(txt.includes(fold(w.group)), `day ${i} group ${w.group}`);
  });
} else console.log('(book text not present; text checks skipped)');
// the corrected angels: each must be the one the book's own day tables give (p.584 and pp.920–921), beside ch.20's own king
const sp = new URL('../../book/search.json', import.meta.url);
if (existsSync(sp)) {
  const S = JSON.parse(readFileSync(sp, 'utf8')), at = (pg) => S.filter(r => r[1] === pg).map(r => r[3]).join(' ');
  const f = s => s.normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[ʿʾ]/g, '').toLowerCase();
  const T584 = f(at(584)), T920 = f(at(920) + ' ' + at(921) + ' ' + at(922) + ' ' + at(923));
  const DAYS = ['sunday','monday','tuesday','wednesday','thursday','friday','saturday'];
  const alt = { 'Samsamāʾīl': ['samsamail','semsemail'], 'Mīkāʾīl': ['mikail'], 'Ṣarfiyāʾīl': ['sarfiyail','sarfeyail'], 'ʿAnyāʾīl': ['aynayail','anyail'] };
  CH20.forEach((w, i) => { if (!w.printed) return;
    const seg = T584.slice(T584.indexOf(DAYS[i] + ' belongs'), T584.indexOf(DAYS[(i + 1) % 7] + ' belongs') > 0 ? T584.indexOf(DAYS[(i + 1) % 7] + ' belongs') : undefined);
    ok(alt[w.angel].some(a => seg.includes(a)), `p.584 gives ${w.angel} for ${DAYS[i]}`);
    ok(!seg.includes(f(w.printed).replace(/[^a-z]/g, '')), `p.584 does not give the printed ${w.printed} for ${DAYS[i]}`);
    ok(alt[w.angel].some(a => T920.includes(a)), `pp.920–922 carry ${w.angel}`); });
  ok(CH20.filter(w => w.printed).length === 4, 'four days corrected (Tue–Fri)');
}
const figsP = new URL('../data/figs_book.json', import.meta.url);
if (existsSync(figsP)) { const F = JSON.parse(readFileSync(figsP, 'utf8')); const f13 = F.find(f => f.id === 13);
  const jinn = f13.table.find(r => r[0] === 'jinn name').slice(1); CH20.forEach((w, i) => ok(w.tahtilAr === jinn[i], `day ${i} tahṭīl Arabic = p.115 ${jinn[i]}`));
  ok(/cinnabar/.test(f13.issue || ''), 'p.115 Tuesday ink corrected to cinnabar'); }
const pageText = (ch, pg) => { const B = JSON.parse(readFileSync(new URL(`../../book/ch${String(ch).padStart(2,'0')}.json`, import.meta.url), 'utf8')); let p = 0, o = '';
  for (const x of B.items) { if (x.k === 'pg') { p = x.p; continue; } if (p === pg && x.t && x.k !== 'corr') o += ' ' + x.t; } return o; };
if (existsSync(new URL('../../book/ch14.json', import.meta.url))) {
  const t654 = pageText(14, 654);
  ok(t654.includes('Answer, O ʿAyniyāʾīl, by the right of Friday') && t654.includes('Answer, O Zawbaʿa, by the right of the king whose command prevails over you, ʿAyniyāʾīl') && t654.includes('Answer, O Kasfiyāʾīl, by the right of the clouds'), 'p.654 roll-call set right');
  // every "king … prevails over you, angel" pair on p.654 and p.662 now pairs a king with its own angel
  const PAIR = { Mudhhib: 'Rūqiyāʾīl', Abyaḍ: 'Jibrāʾīl', Aḥmar: 'Samsamāʾīl', Burqān: 'Mīkāʾīl', Samhūras: 'Ṣarfiyāʾīl', Shamhūrish: 'Ṣarfiyāʾīl', Zawbaʿa: 'ʿAyniyāʾīl', Maymūn: 'Kasfiyāʾīl' };
  for (const pg of [654, 662]) for (const m of (pg === 654 ? t654 : pageText(14, 662)).matchAll(/O ([\wʿʾāīūḥṣḍṭẓ\-]+), by the right of the king whose command prevails over you,? ([\wʿʾāīūḥṣḍṭẓ\-]+)/g))
    ok(PAIR[m[1]] === m[2], `p.${pg}: ${m[1]} under ${m[2]}`);
  ok(pageText(13, 584).includes('Abā Nūkh') && !pageText(13, 584).includes('Fūkh'), 'p.584 Abā Nūkh');
  const t287 = pageText(5, 287) + pageText(5, 288);
  ok(/wafq of Saturn, for ʿAzrāʾīl/.test(t287) && /wafq of Jupiter, for Isrāfīl/.test(t287) && /wafq of the Moon, for Jibrāʾīl/.test(t287), 'pp.287–288 captions');
}
const all = Object.values(HOUR_BOOK).flatMap(h => [...h.open, ...h.named]);
ok(Object.keys(HOUR_BOOK).length === 7 && all.length === 45, `hour table carries all 45 uses of pp.116–117 (${all.length})`);
ok(HOUR_BOOK.saturn.open.length === 0 && HOUR_BOOK.mars.open.length === 0, 'Saturn and Mars: nothing open');
ok(HOUR_BOOK.sun.el === 'fire' && HOUR_BOOK.venus.el === 'earth' && HOUR_BOOK.mercury.el === 'air' && HOUR_BOOK.moon.el === 'water', 'p.115 element of the hours');
console.log(fail ? `TODAY FAILURES ${fail}` : 'all today checks pass'); process.exit(fail ? 1 : 0);

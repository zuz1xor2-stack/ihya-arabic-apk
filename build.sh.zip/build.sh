#!/usr/bin/env bash
# Rebuild ihya-engine.html from src/engine.jsx. Run from the folder that holds src/, build/, tests/.
set -e
python3 tools/splice_shell.py
python3 tools/patch_figs.py
python3 tools/tilasm_specs.py
[ -d node_modules/esbuild ] || npm i esbuild react@18 react-dom@18 >/dev/null 2>&1
node tests/test19.mjs | tail -1
python3 tests/test_bast.py | tail -1
node tests/test_shakl.mjs | tail -1
node tests/test_today.mjs | tail -1
node tools/verify_review.mjs | tail -1 && python3 tools/splice_rv.py
npx esbuild build/entry.jsx --bundle --format=iife --minify --alias:react=./build/shim-react.js \
  --alias:react-dom/client=./build/shim-rdc.js --loader:.jsx=jsx --outfile=build/app.js
python3 - <<'PY'
js=open('build/app.js',encoding='utf-8').read().replace('</script','<\\/script')
open('ihya-engine.html','w',encoding='utf-8').write(f'''<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<title>Iḥyāʾ Engine</title>
<meta name="robots" content="noindex,nofollow,noarchive">
<meta name="theme-color" content="#0a0806">
<link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E%3Crect width='64' height='64' rx='14' fill='%230a0806'/%3E%3Ccircle cx='32' cy='32' r='15' fill='none' stroke='%23e8b84f' stroke-width='2.5'/%3E%3Ccircle cx='32' cy='32' r='6' fill='%23e8b84f'/%3E%3C/svg%3E">
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<style>:root{{color-scheme:dark}} html,body{{background:#0a0806;color:#ece6d8}} body{{margin:0}}</style></head><body>
<div id="root"></div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/react/18.3.1/umd/react.production.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/react-dom/18.3.1/umd/react-dom.production.min.js"></script>
<script>{js}</script>
''')
PY
echo built ihya-engine.html

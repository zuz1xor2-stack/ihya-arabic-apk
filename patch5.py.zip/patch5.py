"""v2.11 on the live engine: a steady reader (no jumps), a richer reader, and your own records."""
import re
P = '/home/claude/live/src/engine.jsx'
src = open(P, encoding='utf-8').read()
def R(old, new, cnt=1):
    global src
    assert src.count(old) == cnt, (src.count(old), old[:90])
    src = src.replace(old, new)
# 1. the reader
a = src.index('function ReadPane('); b = src.index('\n}\n', a) + 3
src = src[:a] + open('/home/claude/live/readpane_live.jsx', encoding='utf-8').read() + src[b:]
# 2. figure images keep their space while loading
R('''function FigImage({ id, alt, style }) {
  const [src, setSrc] = useState(null);
  useEffect(() => { let live = true; loadFigPack(Math.floor(id / 100)).then(p => live && setSrc(p[String(id)] || "")).catch(() => live && setSrc("")); return () => { live = false; }; }, [id]);
  if (src === null) return <div style={{ fontFamily: F.mono, fontSize: 10.5, color: "#ffffff55", padding: 8 }}>loading the figure…</div>;
  if (!src) return null;
  return <img src={src} alt={alt || "figure"} loading="lazy" style={{ display: "block", maxWidth: "100%", margin: "0 auto", filter: "invert(0.92) sepia(0.18)", ...style }} />;
}''', open('/home/claude/live/figdims.js').read() + '''function FigImage({ id, alt, style }) {
  const [src, setSrc] = useState(null);
  useEffect(() => { let live = true; loadFigPack(Math.floor(id / 100)).then(p => live && setSrc(p[String(id)] || "")).catch(() => live && setSrc("")); return () => { live = false; }; }, [id]);
  const f = FIG_DIMS[id]; const ar = f ? `${f[0]} / ${f[1]}` : "4 / 3";
  const box = { display: "block", maxWidth: "100%", width: f ? Math.min(f[0] * 1.6, 760) : 520, margin: "0 auto", aspectRatio: ar, height: "auto", objectFit: "contain", ...style };
  if (src === null) return <div style={{ ...box, background: "#ffffff08", borderRadius: 3 }} />;
  if (!src) return null;
  return <img src={src} alt={alt || "figure"} style={{ ...box, filter: "invert(0.92) sepia(0.18)" }} />;
}''')
# 3. a tab change starts clean — no old page carried back into the book
R('onClick={() => setTab(TABS.find(t => GROUP_OF[t[0]] === g)[0])}', 'onClick={() => { setFocus(null); setTab(TABS.find(t => GROUP_OF[t[0]] === g)[0]); }}')
R('          onClick={() => setTab(k)} style={{ background: tab === k ? "#00000055" : "transparent",', '          onClick={() => { setFocus(null); setTab(k); }} style={{ background: tab === k ? "#00000055" : "transparent",')
R('if (j !== null) { e.preventDefault(); setTab(list[j][0]);', 'if (j !== null) { e.preventDefault(); setFocus(null); setTab(list[j][0]);')
R('      @media print{nav,header>div>div:last-child{display:none}body{background:#fff}}',
  '      @media print{nav,header>div>div:last-child{display:none}body{background:#fff}}\n      .rp .rpt{opacity:.3;transition:opacity .15s}.rp:hover .rpt{opacity:1}html{overflow-anchor:none}')
# 4. Kitāb opens where you left off
src = re.sub(r'const \[ch, setCh\] = useState\(focus && focus\.chapter != null \? focus\.chapter : 19\);',
             'const [ch, setCh] = useState(focus && focus.chapter != null ? focus.chapter : (LS.get("lastRead", null) || { ch: 0 }).ch);', src)
# 5. Today: the moon by the book's own rule, your highlighted passages, your records
R('function TodayPane({ hue, go, cur, hours, loc, tz }) {', open('/home/claude/live/extras_live.jsx', encoding='utf-8').read() + 'function TodayPane({ hue, go, cur, hours, loc, tz }) {')
R('''    {/* ── your reading ── */}''', '''    {/* ── the moon by the book's own reckoning ── */}
    {(() => { const B = bookMoonSign(new Date()); if (!B) return null; const real = SIGNS12[Math.floor(moonLongitude(new Date()) / 30)];
      return <TSection id="moonrule" title="The moon by the book's reckoning" sub={`p.242 · ${B.sign}`} hue={hue} open={false}>
        <div style={{ fontSize: 14, color: "#ffffffb0", lineHeight: 1.75, maxWidth: 720 }}>
          Take the day of the Arabic month, double it and add five, then count five to a sign from the sign the Sun is in. Today: day {B.day} × 2 + 5 = {B.n};
          from {B.sun}, {B.steps} signs — the moon is in <b style={{ color: "#f0ead9" }}>{B.sign}</b>. Reckoned from the sky it is in {real}; the book's rule is an approximation of the
          moon's daily course, and the two can differ by a sign. <Cite page={242} hue={hue} /></div>
      </TSection>; })()}
    <TSection id="mine" title="Your highlights and records" sub="kept on this device" hue={hue} open={false}>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(300px,1fr))", gap: 10 }}>
        <Highlights hue={hue} go={go} />
        <MyRecords hue={hue} />
      </div>
    </TSection>
    {/* ── your reading ── */}''')
open(P, 'w', encoding='utf-8').write(src)
print("v2.11 applied")

/* Places to stand without device location: a searchable gazetteer, and each time zone's own city so the engine can
   place you approximately from the clock alone. Coordinates to four places; the offset always comes from the device or the zone. */
const CITIES = [
  ["Salem, Oregon",44.9429,-123.0351,"America/Los_Angeles"],["Tigard, Oregon",45.4312,-122.7715,"America/Los_Angeles"],
  ["Portland, Oregon",45.5152,-122.6784,"America/Los_Angeles"],["Gresham, Oregon",45.4983,-122.4318,"America/Los_Angeles"],
  ["Beaverton, Oregon",45.4871,-122.8037,"America/Los_Angeles"],["Hillsboro, Oregon",45.5229,-122.9898,"America/Los_Angeles"],
  ["Eugene, Oregon",44.0521,-123.0868,"America/Los_Angeles"],["Bend, Oregon",44.0582,-121.3153,"America/Los_Angeles"],
  ["Vancouver, Washington",45.6387,-122.6615,"America/Los_Angeles"],["Seattle",47.6062,-122.3321,"America/Los_Angeles"],
  ["San Francisco",37.7749,-122.4194,"America/Los_Angeles"],["Los Angeles",34.0522,-118.2437,"America/Los_Angeles"],
  ["San Diego",32.7157,-117.1611,"America/Los_Angeles"],["Las Vegas",36.1699,-115.1398,"America/Los_Angeles"],
  ["Boise",43.615,-116.2023,"America/Boise"],["Phoenix",33.4484,-112.074,"America/Phoenix"],["Denver",39.7392,-104.9903,"America/Denver"],
  ["Salt Lake City",40.7608,-111.891,"America/Denver"],["Dallas",32.7767,-96.797,"America/Chicago"],["Houston",29.7604,-95.3698,"America/Chicago"],
  ["Chicago",41.8781,-87.6298,"America/Chicago"],["Minneapolis",44.9778,-93.265,"America/Chicago"],["New Orleans",29.9511,-90.0715,"America/Chicago"],
  ["Atlanta",33.749,-84.388,"America/New_York"],["Detroit",42.3314,-83.0458,"America/Detroit"],["Philadelphia",39.9526,-75.1652,"America/New_York"],
  ["New York",40.7128,-74.006,"America/New_York"],["Washington, D.C.",38.9072,-77.0369,"America/New_York"],["Boston",42.3601,-71.0589,"America/New_York"],
  ["Miami",25.7617,-80.1918,"America/New_York"],["Anchorage",61.2181,-149.9003,"America/Anchorage"],["Honolulu",21.3069,-157.8583,"Pacific/Honolulu"],
  ["Toronto",43.6532,-79.3832,"America/Toronto"],["Montreal",45.5017,-73.5673,"America/Toronto"],["Vancouver",49.2827,-123.1207,"America/Vancouver"],
  ["Mexico City",19.4326,-99.1332,"America/Mexico_City"],["Havana",23.1136,-82.3666,"America/Havana"],["Bogotá",4.711,-74.0721,"America/Bogota"],
  ["Lima",-12.0464,-77.0428,"America/Lima"],["Caracas",10.4806,-66.9036,"America/Caracas"],["São Paulo",-23.5505,-46.6333,"America/Sao_Paulo"],
  ["Buenos Aires",-34.6037,-58.3816,"America/Argentina/Buenos_Aires"],["Santiago",-33.4489,-70.6693,"America/Santiago"],
  ["Dakar",14.7167,-17.4677,"Africa/Dakar"],["Banjul",13.4549,-16.579,"Africa/Banjul"],["Serrekunda",13.4383,-16.6781,"Africa/Banjul"],
  ["Bamako",12.6392,-8.0029,"Africa/Bamako"],["Conakry",9.6412,-13.5784,"Africa/Conakry"],["Freetown",8.4657,-13.2317,"Africa/Freetown"],
  ["Nouakchott",18.0735,-15.9582,"Africa/Nouakchott"],["Abidjan",5.36,-4.0083,"Africa/Abidjan"],["Accra",5.6037,-0.187,"Africa/Accra"],
  ["Lagos",6.5244,3.3792,"Africa/Lagos"],["Kano",12.0022,8.592,"Africa/Lagos"],["Niamey",13.5116,2.1254,"Africa/Niamey"],
  ["Timbuktu",16.7666,-3.0026,"Africa/Bamako"],["Fez",34.0181,-5.0078,"Africa/Casablanca"],["Marrakesh",31.6295,-7.9811,"Africa/Casablanca"],
  ["Casablanca",33.5731,-7.5898,"Africa/Casablanca"],["Algiers",36.7538,3.0588,"Africa/Algiers"],["Tunis",36.8065,10.1815,"Africa/Tunis"],
  ["Tripoli",32.8872,13.1913,"Africa/Tripoli"],["Cairo",30.0444,31.2357,"Africa/Cairo"],["Alexandria",31.2001,29.9187,"Africa/Cairo"],
  ["Khartoum",15.5007,32.5599,"Africa/Khartoum"],["Addis Ababa",9.03,38.74,"Africa/Addis_Ababa"],["Mogadishu",2.0469,45.3182,"Africa/Mogadishu"],
  ["Nairobi",-1.2921,36.8219,"Africa/Nairobi"],["Dar es Salaam",-6.7924,39.2083,"Africa/Dar_es_Salaam"],["Zanzibar",-6.1659,39.2026,"Africa/Dar_es_Salaam"],
  ["Johannesburg",-26.2041,28.0473,"Africa/Johannesburg"],["Cape Town",-33.9249,18.4241,"Africa/Johannesburg"],
  ["Mecca",21.4225,39.8262,"Asia/Riyadh"],["Madina",24.4672,39.6111,"Asia/Riyadh"],["Riyadh",24.7136,46.6753,"Asia/Riyadh"],
  ["Jeddah",21.4858,39.1925,"Asia/Riyadh"],["Jerusalem",31.7683,35.2137,"Asia/Jerusalem"],["Amman",31.9454,35.9284,"Asia/Amman"],
  ["Damascus",33.5138,36.2765,"Asia/Damascus"],["Beirut",33.8938,35.5018,"Asia/Beirut"],["Baghdad",33.3152,44.3661,"Asia/Baghdad"],
  ["Najaf",32.0259,44.3462,"Asia/Baghdad"],["Kuwait",29.3759,47.9774,"Asia/Kuwait"],["Doha",25.2854,51.531,"Asia/Qatar"],
  ["Dubai",25.2048,55.2708,"Asia/Dubai"],["Abu Dhabi",24.4539,54.3773,"Asia/Dubai"],["Muscat",23.588,58.3829,"Asia/Muscat"],
  ["Sanaa",15.3694,44.191,"Asia/Aden"],["Tarim",16.0546,49.0034,"Asia/Aden"],["Tehran",35.6892,51.389,"Asia/Tehran"],
  ["Mashhad",36.2605,59.6168,"Asia/Tehran"],["Istanbul",41.0082,28.9784,"Europe/Istanbul"],["Konya",37.8746,32.4932,"Europe/Istanbul"],
  ["Ankara",39.9334,32.8597,"Europe/Istanbul"],["Bursa",40.1826,29.0665,"Europe/Istanbul"],["Kabul",34.5553,69.2075,"Asia/Kabul"],
  ["Karachi",24.8607,67.0011,"Asia/Karachi"],["Lahore",31.5204,74.3587,"Asia/Karachi"],["Islamabad",33.6844,73.0479,"Asia/Karachi"],
  ["Delhi",28.6139,77.209,"Asia/Kolkata"],["Ajmer",26.4499,74.6399,"Asia/Kolkata"],["Mumbai",19.076,72.8777,"Asia/Kolkata"],
  ["Hyderabad",17.385,78.4867,"Asia/Kolkata"],["Dhaka",23.8103,90.4125,"Asia/Dhaka"],["Colombo",6.9271,79.8612,"Asia/Colombo"],
  ["Tashkent",41.2995,69.2401,"Asia/Tashkent"],["Bukhara",39.7681,64.4556,"Asia/Samarkand"],["Samarkand",39.6542,66.9597,"Asia/Samarkand"],
  ["Baku",40.4093,49.8671,"Asia/Baku"],["Kuala Lumpur",3.139,101.6869,"Asia/Kuala_Lumpur"],["Singapore",1.3521,103.8198,"Asia/Singapore"],
  ["Jakarta",-6.2088,106.8456,"Asia/Jakarta"],["Bangkok",13.7563,100.5018,"Asia/Bangkok"],["Beijing",39.9042,116.4074,"Asia/Shanghai"],
  ["Hong Kong",22.3193,114.1694,"Asia/Hong_Kong"],["Tokyo",35.6762,139.6503,"Asia/Tokyo"],["Seoul",37.5665,126.978,"Asia/Seoul"],
  ["Manila",14.5995,120.9842,"Asia/Manila"],["Sydney",-33.8688,151.2093,"Australia/Sydney"],["Melbourne",-37.8136,144.9631,"Australia/Melbourne"],
  ["Perth",-31.9505,115.8605,"Australia/Perth"],["Auckland",-36.8485,174.7633,"Pacific/Auckland"],
  ["London",51.5072,-0.1276,"Europe/London"],["Birmingham",52.4862,-1.8904,"Europe/London"],["Dublin",53.3498,-6.2603,"Europe/Dublin"],
  ["Paris",48.8566,2.3522,"Europe/Paris"],["Brussels",50.8503,4.3517,"Europe/Brussels"],["Amsterdam",52.3676,4.9041,"Europe/Amsterdam"],
  ["Berlin",52.52,13.405,"Europe/Berlin"],["Madrid",40.4168,-3.7038,"Europe/Madrid"],["Granada",37.1773,-3.5986,"Europe/Madrid"],
  ["Córdoba",37.8882,-4.7794,"Europe/Madrid"],["Lisbon",38.7223,-9.1393,"Europe/Lisbon"],["Rome",41.9028,12.4964,"Europe/Rome"],
  ["Vienna",48.2082,16.3738,"Europe/Vienna"],["Sarajevo",43.8563,18.4131,"Europe/Sarajevo"],["Athens",37.9838,23.7275,"Europe/Athens"],
  ["Stockholm",59.3293,18.0686,"Europe/Stockholm"],["Oslo",59.9139,10.7522,"Europe/Oslo"],["Moscow",55.7558,37.6173,"Europe/Moscow"],
  ["Kazan",55.7963,49.1088,"Europe/Moscow"],
];
/** The city whose time zone the device reports — an approximate place from the clock alone, no permission needed. */
function cityFromZone() {
  let z = ""; try { z = Intl.DateTimeFormat().resolvedOptions().timeZone || ""; } catch {}
  if (!z) return null;
  const c = CITIES.find(c => c[3] === z && z.endsWith(c[0].split(",")[0].replace(/ /g, "_")))
    || CITIES.find(c => c[3] === z);
  return c ? { lat: c[1], lon: c[2], label: `${c[0]} (from your time zone, ${z})`, fixedOffset: false, approxZone: true } : null;
}

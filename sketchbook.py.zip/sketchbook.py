"""The Ṭalāsim sketchbook: every open talisman, seal and circle of the book on its own page — the tracing with a
lettered copying grid, its title and page, what it is, and the book's words with it."""
import json, html, re
T = json.load(open('talismans.json')); P = {}
for k in range(6):
    try: P.update(json.load(open(f'pub/book/sketch_{k}.json')))
    except FileNotFoundError: pass
E = html.escape
css = """@page { size: 8.5in 11in; margin: 0.6in 0.7in; } body { font-family: FreeSerif, serif; color: #111; font-size: 10.5pt; }
.pg { page-break-after: always; } h1 { font-weight: normal; font-size: 16pt; margin: 0 0 2pt; } .meta { font: 8.5pt 'DejaVu Sans Mono'; color: #666; }
.wrap { margin: 6pt auto; text-align: center; } .box { position: relative; display: inline-block; } .wrap img { max-width: 6.6in; max-height: 6.0in; display: block; }
.grid { position: absolute; inset: 0; background-image: linear-gradient(rgba(200,60,40,.45) 1px, transparent 1px), linear-gradient(90deg, rgba(200,60,40,.45) 1px, transparent 1px); background-size: 12.5% 12.5%; border: 1px solid rgba(200,60,40,.6); }
.lab { font: 7pt 'DejaVu Sans Mono'; color: #c33; display: flex; } .lab span { flex: 1; text-align: center; } .pg { overflow: hidden; height: 9.75in; } p { font-size: 9.5pt; }
p { margin: 4pt 0; text-align: justify; } .note { color: #333; font-size: 9.5pt; }"""
pages = ['<div class="pg" style="text-align:center;padding-top:2.5in"><h1 style="font-size:26pt">Ṭalāsim</h1><p style="text-align:center">The talismans, seals, circles and tables of <i>Iḥyāʾ Uṣūl al-Ḥikmah</i>, traced for sketching</p>'
         '<p style="text-align:center;margin-top:24pt;font-size:9.5pt;color:#555">Each figure is the printed one reduced to clean line, with a lettered 8 × 8 copying grid. Draw the same grid lightly on your paper and copy one square at a time (A1, B1 …): the proportions stay true at any size. The page number is the original\'s. Workings aimed at harming or compelling another person are not included.</p></div>']
for n, t in enumerate(T, 1):
    src = P.get(str(t['id']))
    if not src: continue
    words = "".join(f"<p>{E(x if len(x) < 900 else x[:900] + ' …')}</p>" for x in t['text'][-2:])
    pages.append(f'<div class="pg"><div class="meta">Ṭalāsim {n} · figure #{t["id"]} · original p.{t["page"]}</div><h1>{E(t["title"])}</h1>'
                 f'<div class="wrap"><div class="box"><div class="lab">{"".join(f"<span>{c}</span>" for c in "ABCDEFGH")}</div><div style="position:relative"><img src="{src}"><div class="grid"></div></div></div></div>'
                 f'<p class="note">{E(t["note"])}</p>{words}</div>')
open('edition/talasim.html', 'w', encoding='utf-8').write(f'<!doctype html><html><head><meta charset="utf-8"><style>{css}</style></head><body>{"".join(pages)}</body></html>')
print(len(pages))

import { chromium } from 'playwright';
const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' });
const p = await b.newPage({ viewport: { width: 1300, height: 1300 } }); p.setDefaultTimeout(10000);
const errs=[]; p.on('pageerror', e => errs.push(e.message)); p.on('console', m => m.type()==='error' && errs.push(m.text()));
await p.goto('http://localhost:8766/index.html'); await p.waitForTimeout(1500);
await p.click('header button:has-text("Ālāt")');
const tabs = await p.$$eval('[role=tab]', a => a.map(x => x.innerText)); console.log('ALAT TABS', tabs.join(' | '));
await p.click('[role=tab]:has-text("Qalam")'); await p.waitForTimeout(500);
await p.fill('input[placeholder^="find a figure"]', '1645'); await p.waitForTimeout(300);
await p.click('main div[style*="cursor: pointer"] >> nth=0'); await p.waitForTimeout(3000);
console.log((await p.evaluate(() => [...document.querySelectorAll('main div')].map(d=>d.innerText).find(t => /strokes · pen down/.test(t) && t.length<300))));
await p.click('main button:has-text("frame off")'); await p.fill('main input[dir=rtl] >> nth=0', 'يا لطيف'); await p.fill('main input[dir=rtl] >> nth=1', '١٢٩'); await p.waitForTimeout(1500);
await p.screenshot({ path: '/home/claude/live/dist/q_fig.png' });
// SVG content check
const svg = await p.evaluate(() => decodeURIComponent(document.querySelector('img[alt="plotter preview"]').src.split(',')[1]));
console.log('svg len', svg.length, 'layers', (svg.match(/inkscape:label="[^"]+"/g)||[]).join(','));
// Forge → plotter
await p.click('header button:has-text("Kitāb")');
const kt = await p.$$eval('[role=tab]', a => a.map(x => x.innerText)); console.log('KITAB TABS', kt.join(' | '));
await b.close(); console.log('ERRS', errs);

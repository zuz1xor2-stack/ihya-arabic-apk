import React from "react"; import { createRoot } from "react-dom/client"; import App from "../src/engine.jsx";
if (!window.storage) window.storage = {
  get: async (k) => { try { const v = localStorage.getItem(k); return v === null ? null : { value: v }; } catch { return null; } },
  set: async (k, v) => { try { localStorage.setItem(k, v); return true; } catch { return false; } },
};
createRoot(document.getElementById("root")).render(<App />);

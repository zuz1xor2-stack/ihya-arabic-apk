import * as C from '../src/ch19.mjs';
let fail=0; const ok=(c,m)=>{ if(!c){fail++;console.log('FAIL',m);} else console.log('ok  ',m); };
for (const n of [3,4,5,6,7,8,9]) { const v=C.BOOK_FORMS[n].vis, s=C.sums(v);
  const flat=v.flat().sort((a,b)=>a-b); ok(flat.every((x,i)=>x===i+1),`order ${n} uses 1..${n*n} once`);
  ok(s.balanced && s.constant===n*(n*n+1)/2, `order ${n} magic ${s.constant}${s.diagonals?' +diag':' (diagonals differ)'}`);
  const rs=[]; for(let r=1;r<n;r++){const A=n*(n*n-1)/2+n*5+r; const w=C.ruleFirst(A,n); const t=C.sums(w.grid); if(t.balanced&&t.constant===A) rs.push(r);}
  ok(rs.length===n-1, `order ${n} absorbs every remainder [${rs}]`);
}
const vis=(g)=>JSON.stringify(g);
ok(vis(C.ruleFirst(129,4).grid)===vis([[32,35,38,24],[37,25,31,36],[26,40,33,30],[34,29,27,39]]),'Laṭīf 129 reproduces p.1895 cell for cell');
ok(vis(C.ruleFirst(1001,5).grid[0])===vis([205,197,210,201,188]),'Dār 1001 reproduces p.1946 first row');
ok(vis(C.ruleFirst(1001,5).grid[1])===vis([199,191,203,195,213]),'Dār 1001 second row');
for (const [A,n] of [[409,6],[573,7],[731,8],[801,9]]){const w=C.ruleFirst(A,n);const s=C.sums(w.grid);ok(s.balanced&&s.constant===A,`${A} on ${n}×${n} balances`);}
ok(C.sums(C.three_second(68).grid).constant===204,'Ḥakam 68 second rule → 204 (p.1708)');
const t2d=C.three_secondDigits(68); ok(t2d.grid.flat().includes(12)&&C.sums(t2d.grid).constant===204,'Ḥakam digit-sum variant');
ok(C.sums(C.three_third(37).grid).constant===555,'Awwal 37 third rule → 555 (p.1710)');
const h1=C.hollow3_first(1177); ok(vis(h1.grid)===vis([[294,785,98],[687,null,490],[196,392,589]]),'1177 hollow first rule reproduces p.1750');
ok(C.hollowEdges(h1.grid).every(e=>e===1177),'its four edges are 1177');
ok(C.hollowEdges(C.hollow3_first(57).grid).every(e=>e===57),'Majīd 57 hollow edges 57');
ok(vis(C.hollow3_second(370).grid)===vis([[3,366,1],[365,null,5],[2,4,364]]),'Serīʿ 370 reproduces p.1749');
const k2=C.sums(C.four_second({1:20,8:40,11:10,14:200}).grid); ok(k2.diagonals&&k2.constant===270,'Karīm 270 rule 2 balances with diagonals');
const k3=C.sums(C.four_third({1:121,7:66,10:97,16:166}).grid); ok(k3.diagonals&&k3.constant===450,'Ḥasbunallāh 450 rule 3 balances with diagonals');
const f5=C.sums(C.four_fifth(73).grid); ok(f5.balanced&&f5.constant===73,'Jalīl 73 fifth rule balances at 73');
ok(vis(C.four_sixth(66).grid)===vis([[8,11,46,1],[45,2,7,12],[3,48,9,6],[10,5,4,47]]),'Allah 66 sixth rule reproduces p.1903–1904');
ok(C.sums(C.five_third({1:40,14:5,22:10,10:40,18:50}).grid).constant===145,'Muhaymin 145 five-third balances');
ok(C.sums(C.five_second({1:130,7:140,15:370,18:62,24:125}).grid).balanced,'five-second example balances');
const U3=C.ulwiSpirits(3); ok(U3.stations.asil===1080,'3×3 asil 1080');
ok(U3.spirits[0].letters.join('')==='لغ','1030 → ل غ (Leghayil, p.1711)'); ok(U3.spirits[6].letters.join('')==='طمقغ','1149 → ط م ق غ (Tamkaghayil)');
const U4=C.ulwiSpirits(4); ok(U4.stations.asil===5440,'4×4 asil 5440'); ok(U4.spirits[0].letters.join('')==='صشغه','5390 → ص ش غ ه (p.1906)');
ok(U4.spirits[6].letters.join('')==='طكذغه','5729 → ط ك ذ غ ه (p.1909)');
const w=C.ruleFirst(3292,4); const byIdx=k=>w.q+k-1+(w.r&&k>=w.liftFrom?1:0);
ok(C.awanAngels4(byIdx).map(a=>a.value).join()==='815,822,825,830','aʿwān cells 815, 822, 825, 830 (p.1912–1913)');
ok(C.awanAngels4(byIdx)[0].letters.join('')==='جعذ','773 → ج ع ذ');
ok(C.governingAngel(3292).letters.join('')==='امرغج','3241 → ا م ر غ ج');
console.log(fail?`\n${fail} FAILED`:'\nall checks pass');
if (fail) process.exit(1);

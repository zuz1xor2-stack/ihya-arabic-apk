import json, sys, glob
from multiprocessing import Pool
sys.path.insert(0, '/home/claude/plot')
import warnings; warnings.filterwarnings('ignore')
import cl2
sealed = set(json.load(open('/home/claude/ihya/reader/sealed_figs.json')))
ids = sorted(i for i in range(len(cl2.FI)) if i not in sealed)
def one(i):
    try:
        r = cl2.run(i); return i, {"w": r["w"], "h": r["h"], "c": r["p"], "o": cl2.outline(i)}
    except Exception as e: return i, None
if __name__ == '__main__':
    with Pool(8) as p: res = dict(p.map(one, ids))
    bad = [i for i, v in res.items() if v is None]; print('ids', len(ids), 'bad', bad)
    for k in range(6):
        pack = {str(i): v for i, v in res.items() if v and i // 100 == k}
        s = json.dumps(pack, separators=(',', ':')); open(f'/home/claude/plot/plot_{k}.json', 'w').write(s); print(k, len(pack), len(s) // 1000000, 'MB')

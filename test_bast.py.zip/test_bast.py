"""The basṭ rules reproduce the book's own printed chains (pp.124–128, 176–178)."""
import sys, os; sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "tools"))
from bastlib import chain, number_bast, first_word, FIRST
ok = lambda c, m: print(("✓ " if c else "✗ ") + m) or c
r = [ok(chain(1) == [16, 1047, 594, 1641, 991], "alif, basṭ of letters 16·1047·594·1641·991 (pp.124–127)"),
     ok([number_bast()[k]["ا"] for k in range(5)] == [16, 911, 6137, 31296, 156119], "alif, basṭ of numbers to 156119 (p.178)"),
     ok(first_word("اهطمفشذ") == 3550 and first_word("بوينصتض") == 4015 and first_word("جزكسقثظ") == 3757 and first_word("دحلعرخغ") == 3342, "the four elements 3550 · 4015 · 3757 · 3342 (p.131)"),
     ok((FIRST["ح"], FIRST["س"], FIRST["ن"]) == (612, 524, 765), "Ḥasan's letters 612 · 524 · 765 (p.131)"),
     ok(first_word("الجمعة") == 3399 and first_word("النهار") == 3120, "Friday 3399, day 3120 (pp.132–134)")]
print("all basṭ checks pass" if all(r) else "BAST FAILURES"); sys.exit(0 if all(r) else 1)

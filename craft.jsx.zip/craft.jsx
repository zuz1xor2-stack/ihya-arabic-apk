/* ═══ craft — every open working of the book carried to what makes it: its square, its figures, and a craft card ═══ */
let WORK_FIG_MAP = null;
function workFigs(w) {
  if (!WORK_FIG_MAP) {
    const sealed = new Set(BOOK.sealedFigs || []); WORK_FIG_MAP = new Map();
    for (const f of BOOK.figs) if (!sealed.has(f.id)) { const a = WORK_FIG_MAP.get(f.page) || []; a.push(f); WORK_FIG_MAP.set(f.page, a); }
  }
  const out = [];
  for (let p = w.p; p <= w.p + 2; p++) for (const f of WORK_FIG_MAP.get(p) || []) if (f.ch === w.ch) out.push(f);
  return out.slice(0, 4);
}
const xesc = (s) => String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
function wrapText(s, n) { const words = String(s).split(/\s+/); const lines = []; let cur = "";
  for (const w of words) { if ((cur + " " + w).trim().length > n) { if (cur) lines.push(cur); cur = w; } else cur = (cur + " " + w).trim(); }
  if (cur) lines.push(cur); return lines; }
/** A printable card of one working — when, in what form, with what, what is recited — in millimetres (A5). */
function craftCardSVG(w, figs) {
  const W = 148, H = 210; let y = 18; let body = "";
  const line = (t, size = 3.6, fam = "Georgia, serif", col = "#111", wt = "normal") => { body += `<text x="12" y="${y}" font-family="${fam}" font-size="${size}" fill="${col}" font-weight="${wt}">${xesc(t)}</text>`; y += size * 1.45; };
  line(`IḤYĀʾ UṢŪL AL-ḤIKMAH · p.${w.p} · working no.${w.n} · ${w.cat}`, 2.6, "monospace", "#666");
  y += 1; for (const t of wrapText(w.title, 52)) line(t, 5, "Georgia, serif", "#111", "bold"); y += 2;
  const sec = (label, items) => { if (!items || !items.length) return; line(label.toUpperCase(), 2.6, "monospace", "#8a6d1e"); for (const t of wrapText(items.join(" · "), 70)) line(t, 3.5); y += 1.5; };
  sec("when", [...(w.days || []), ...(w.hour || []).map(h => PLANETS[h] ? `hour of ${h}` : h), ...(w.moon || []).map(m => "moon: " + m)]);
  sec("form", [...(w.element || []).map(e => e + " form"), ...(w.form || []), ...(w.square || []).map(n => `${n}×${n} square`), ...(w.values || []).map(v => `value ${v}`)]);
  sec("materials", [...(w.material || []), ...(w.incense || []).map(i => "incense: " + i)]);
  sec("recite", [...(w.recite || []), ...(w.counts || []).map(c => `${c} times`)]);
  if (figs.length) sec("figures", figs.map(f => `#${f.id} on p.${f.page}`));
  line("THE BOOK'S FULL WORDS: READ p." + w.p + " IN THE ENGINE BEFORE WORKING", 2.6, "monospace", "#8a6d1e"); y += 3;
  line("NOTES", 2.6, "monospace", "#8a6d1e");
  for (let ly = y + 4; ly < H - 14; ly += 8) body += `<line x1="12" y1="${ly}" x2="${W - 12}" y2="${ly}" stroke="#ccc" stroke-width="0.25"/>`;
  body += `<text x="12" y="${H - 8}" font-family="monospace" font-size="2.3" fill="#999">${xesc("craft card from the Iḥyāʾ Engine · conditions as the engine indexed them from the page; the page itself governs")}</text>`;
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${W}mm" height="${H}mm" viewBox="0 0 ${W} ${H}"><rect width="${W}" height="${H}" fill="#fdfcf8"/>`
    + `<rect x="6" y="6" width="${W - 12}" height="${H - 12}" fill="none" stroke="#8a6d1e" stroke-width="0.4"/>${body}</svg>`;
}
function CraftRow({ w, go }) {
  const figs = workFigs(w);
  const b = { background: "none", border: "1px solid #e8c96a55", color: "#e8c96acc", fontFamily: F.mono, fontSize: 10, padding: "2px 7px", borderRadius: 2, cursor: "pointer" };
  return <div style={{ display: "flex", flexWrap: "wrap", gap: 4, marginTop: 6 }}>
    {figs.map(f => <span key={f.id} style={{ display: "inline-flex", gap: 3 }}>
      <button style={b} onClick={() => go("shakl", { id: f.id })} title="forge this figure for your own name or need">forge figure · p.{f.page}</button>
      <button style={b} onClick={() => go("qalam", { job: { kind: "figure", id: f.id } })} title="draw it with a pen plotter">✒</button></span>)}
    <button style={b} onClick={() => download(`craft-p${w.p}-no${w.n}.svg`, craftCardSVG(w, figs), "image/svg+xml")} title="a printable A5 card of this working">craft card</button>
  </div>;
}

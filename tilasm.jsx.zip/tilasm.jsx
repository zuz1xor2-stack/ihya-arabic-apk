
/* ═══ Ṭilasm — the composer: every talisman as geometry (strokes + filled glyph outlines), so the screen, the PNG,
 *  the SVG and the pen plotter all draw exactly the same thing. Specs live in book/tilasm.json (one per book figure,
 *  plus the Durūs constructions); each spec is a list of elements in a 1000-unit box. ═══ */
const TL_DEG = Math.PI / 180;
const tlGcd = (a, b) => b ? tlGcd(b, a % b) : a;
let TL_SPECS_P = null;
function loadTilasm() {
  if (!TL_SPECS_P) TL_SPECS_P = fetch("book/tilasm.json").then(r => { if (!r.ok) throw new Error(r.status); return r.json(); })
    .catch(e => { TL_SPECS_P = null; throw e; });
  return TL_SPECS_P;
}

/* the seven seals (al-khawātim al-sabʿa), drawn for the pen in a unit box centred on 0,0 (−0.5…0.5) */
const TL_SEALS = (() => {
  const E = (cx, cy, rx, ry, a0 = 0, a1 = 360, n = 28) => Array.from({ length: n + 1 }, (_, i) => { const a = (a0 + (a1 - a0) * i / n) * TL_DEG; return [cx + rx * Math.sin(a), cy - ry * Math.cos(a)]; });
  const star = (r = 0.46) => { const p = []; for (let i = 0; i <= 5; i++) { const a = (i * 144) * TL_DEG; p.push([r * Math.sin(a), -r * Math.cos(a) + 0.04]); } return [p]; };
  return {
    star: star(),                                                                                   // the pentagram
    comb: [[[-0.38, -0.36], [0.38, -0.36]], [[-0.26, -0.36], [-0.26, 0.4]], [[0, -0.36], [0, 0.4]], [[0.26, -0.36], [0.26, 0.4]],
      [[-0.42, -0.42], [-0.3, -0.5], [-0.15, -0.42], [0, -0.5], [0.15, -0.42], [0.3, -0.5], [0.42, -0.42]]],   // three strokes, a bar and a wave over them
    mim: [E(0, -0.18, 0.17, 0.17), [[0, 0.0], [0, 0.46]]],                                         // the mīm with its tail
    lattice: [[[-0.18, -0.45], [-0.18, 0.45]], [[0.18, -0.45], [0.18, 0.45]], [[-0.45, -0.17], [0.45, -0.17]], [[-0.45, 0.17], [0.45, 0.17]]],   // the “hashtag”
    ladder: [[[-0.3, -0.42], [-0.3, 0.42]], [[-0.1, -0.42], [-0.1, 0.42]], [[0.1, -0.42], [0.1, 0.42]], [[0.3, -0.42], [0.3, 0.42]]],          // four strokes
    ha: [E(0, -0.2, 0.2, 0.22), E(0, 0.24, 0.17, 0.2)],                                             // the hāʾ, two loops
    waw: [E(0.06, -0.2, 0.2, 0.2, 30, 390), [[0.24, -0.1], [0.2, 0.15], [0.02, 0.38], [-0.28, 0.46]]],  // the wāw-like loop with its sweep
    hourglass: [[[-0.32, -0.42], [0.32, -0.42], [-0.32, 0.42], [0.32, 0.42], [-0.32, -0.42]]],
    ring: [E(0, 0, 0.32, 0.32)],
    cross: [[[0, -0.45], [0, 0.45]], [[-0.45, 0], [0.45, 0]]],
  };
})();
const TL_SEAL_ORDER = ["star", "comb", "mim", "lattice", "ladder", "ha", "waw"];

function tlSubst(t, P) {
  return String(t == null ? "" : t).replace(/\{(\w+)\}/g, (m, k) => {
    if (k === "valueIndic") return P.value ? toIndic(P.value) : "";
    if (k === "valueJummal") return P.value ? (jummal(P.value) || []).join("") : "";
    return P[k] != null ? String(P[k]) : "";
  });
}

/** Shape a line of text into local geometry: baseline at y=0, x from 0 to width. */
function tlShape(font, text, size) {
  const glyphs = shapeArabic(text), items = [];
  const sc = font ? size / font.unitsPerEm : 0;
  let x = 0;
  for (const g of glyphs) {
    if (DIGIT_STROKES[g]) { items.push({ lines: DIGIT_STROKES[g].map(s => s.map(([u, v]) => [x + u * size, v * size])) }); x += DIGIT_W * size; continue; }
    if (g === " ") { x += size * 0.28; items.push({ space: true }); continue; }
    if (!font) continue;
    const gl = font.charToGlyph(g);
    if (gl && gl.index > 0) { const rings = pathRings(gl.getPath(x, 0, size)); if (rings.length) items.push({ fill: rings }); x += gl.advanceWidth * sc; }
    else x += size * 0.5;
  }
  return { w: x, items };
}
function tlEmit(G, shaped, T, layer) {
  for (const it of shaped.items) {
    if (it.space) continue;
    if (it.lines) for (const l of it.lines) G.S.digits.push(l.map(T));
    else G.fills.push(it.fill.map(r => r.map(T)));
  }
}
const tlPoly = (cx, cy, r, a0, a1, n) => Array.from({ length: n + 1 }, (_, i) => { const a = (a0 + (a1 - a0) * i / n) * TL_DEG; return [cx + r * Math.sin(a), cy - r * Math.cos(a)]; });

/** Text along a circle. 0° is the top, angles run clockwise. fit: "natural" (once, from `start`, centred if `center`),
 *  "fill" (repeated with `sep` until the ring closes, spacing adjusted so it closes exactly), "stretch" (once, spread over `sweep`). */
function tlRing(G, font, e, P) {
  const cx = e.cx ?? 500, cy = e.cy ?? 500, r = e.r, size = e.size || 34, inward = !!e.inward;
  const text = tlSubst(e.text, P); if (!text.trim()) return;
  const sweep = e.sweep ?? 360;
  let sh = tlShape(font, text, size), reps = 1;
  const circ = r * sweep * TL_DEG;
  if (e.fit === "fill") {
    const unit = tlShape(font, text + (e.sep ?? "  "), size);
    reps = Math.max(1, Math.floor(circ / unit.w)); if (e.rep) reps = e.rep;
    sh = tlShape(font, Array(reps).fill(text).join(e.sep ?? "  ") + (sweep >= 360 ? (e.sep ?? "  ") : ""), size);
  }
  const glyphs = sh.items.filter(it => !it.space), spaces = sh.items.length - glyphs.length;
  let scale = 1;
  if (sh.w > circ) scale = circ / sh.w;                              // never overrun the ring: shrink to fit
  if (e.fit === "stretch" && sh.w < circ) scale = Math.min(circ / sh.w, e.grow || 1.6);   // a single text grows to meet the ring…
  const left = Math.max(0, circ - sh.w * scale);
  // …and what is left goes between the words (or, with no spaces, between the letters)
  const perSpace = (e.fit === "stretch" || e.fit === "fill") && spaces ? left / spaces : 0;
  const perGlyph = (e.fit === "stretch" || e.fit === "fill") && !spaces && glyphs.length > 1 ? left / glyphs.length : 0;
  const total = sh.w * scale + perSpace * spaces + perGlyph * glyphs.length;
  let a0 = (e.start ?? 0) * TL_DEG;
  if (e.center != null) a0 = e.center * TL_DEG - (inward ? -1 : 1) * total / r / 2;
  let acc = 0;
  for (const it of sh.items) {
    if (it.space) { acc += perSpace; continue; }
    const pts = it.lines ? it.lines.flat() : it.fill.flat();
    let mn = Infinity, mx = -Infinity; for (const p of pts) { if (p[0] < mn) mn = p[0]; if (p[0] > mx) mx = p[0]; }
    const c0 = (mn + mx) / 2;
    const s = (c0 * scale) + acc + perGlyph / 2; acc += perGlyph;
    const phi = inward ? a0 - s / r : a0 + s / r;
    const cs = Math.cos(phi), sn = Math.sin(phi), Px = cx + r * Math.sin(phi), Py = cy - r * Math.cos(phi);
    const T = ([x, y]) => { const u = (x - c0) * scale, v = y * scale;
      return inward ? [Px - u * cs + v * sn, Py - u * sn - v * cs] : [Px + u * cs - v * sn, Py + u * sn + v * cs]; };
    if (it.lines) for (const l of it.lines) G.S.digits.push(l.map(T)); else G.fills.push(it.fill.map(rr => rr.map(T)));
  }
}

function tlText(G, font, e, P) {
  const text = tlSubst(e.text, P); if (!text.trim()) return;
  const lines = text.split("\n");
  const size = e.size || 40, lh = size * (e.lh || 1.45);
  lines.forEach((ln, li) => {
    let sh = tlShape(font, ln, size), sc = 1;
    if (e.maxw && sh.w > e.maxw) sc = e.maxw / sh.w;
    const anchor = e.anchor || "middle", w = sh.w * sc;
    const ox = anchor === "middle" ? -w / 2 : anchor === "end" ? -w : 0;
    const by = (li - (lines.length - 1) / 2) * lh + size * 0.32 * (e.vcenter === false ? 0 : 1);
    const a = (e.rot || 0) * TL_DEG, ca = Math.cos(a), sa = Math.sin(a);
    const T = ([x, y]) => { let u = ox + x * sc; const v = by + y * sc; if (e.mirror) u = -u; return [e.x + u * ca - v * sa, e.y + u * sa + v * ca]; };
    tlEmit(G, sh, T, e.layer || "letters");
  });
}


/** Text along a straight band from (x1,y1) to (x2,y2): once, or repeated (`rep`, or as many as fit with fit:"fill"). */
function tlLineText(G, font, e, P) {
  const t0 = tlSubst(e.text, P); if (!t0.trim()) return;
  const dx = e.x2 - e.x1, dy = e.y2 - e.y1, len = Math.hypot(dx, dy), deg = Math.atan2(dy, dx) / TL_DEG;
  const size = e.size || 30, sep = e.sep ?? " ";
  let t = t0;
  if (e.rep || e.fit === "fill") { const unit = tlShape(font, t0 + sep, size).w || 1; const n = e.rep || Math.max(1, Math.floor(len / unit)); t = Array(n).fill(t0).join(sep); }
  tlText(G, font, { x: (e.x1 + e.x2) / 2, y: (e.y1 + e.y2) / 2, text: t, size, rot: e.flip ? deg + 180 : deg, maxw: len, layer: e.layer }, {});
}

function tlGrid(G, font, e, P) {
  const cells = e.cells === "$forge" ? P.grid : e.cells;
  if (!cells || !cells.length) return;
  const n = cells.length, m = cells[0].length, x = e.x, y = e.y, w = e.size, h = e.h || e.size * n / m;
  const cw = w / m, ch = h / n, L = G.S.frame;
  if (e.lines !== false) {
    for (let i = 0; i <= n; i++) L.push([[x, y + i * ch], [x + w, y + i * ch]]);
    for (let j = 0; j <= m; j++) L.push([[x + j * cw, y], [x + j * cw, y + h]]);
  }
  if (e.diag) { L.push([[x, y], [x + w, y + h]]); L.push([[x + w, y], [x, y + h]]); }
  for (let i = 0; i < n; i++) for (let j = 0; j < m; j++) {
    const v = cells[i][j]; if (v == null || v === "" || v === "-") continue;
    const cx = x + (j + 0.5) * cw, cy = y + (i + 0.5) * ch;
    if (typeof v === "string" && v.startsWith("seal:")) { tlSeal(G, { g: v.slice(5), x: cx, y: cy, size: Math.min(cw, ch) * 0.62 }); continue; }
    const ct = typeof v === "number" ? cellText(v, P.script || CELL_SCRIPT) : { text: tlSubst(v, P), ar: true };
    const len = [...ct.text].length || 1;
    const size = Math.min(ch * 0.46, (cw * 0.84) / (ct.digits && !ct.ar ? len * 0.55 : len * 0.5), e.fs || 999);
    tlText(G, font, { x: cx, y: cy, text: ct.text, size, maxw: cw * 0.86, layer: ct.digits ? "digits" : "letters" }, {});
  }
}

function tlSeal(G, e) {
  const S = TL_SEALS[e.g]; if (!S) return;
  const a = (e.rot || 0) * TL_DEG, ca = Math.cos(a), sa = Math.sin(a), k = e.size;
  for (const s of S) G.S.figure.push(s.map(([u, v]) => [e.x + (u * ca - v * sa) * k, e.y + (u * sa + v * ca) * k]));
}


/** The printed figure itself, as vector: its ink outlines (for the eye) and its centre-lines (for the pen), placed by
 *  scale s and offset x,y; anything inside `cut` (trace coordinates) is left out so a rebuilt square can take its place. */
function tlTrace(G, e, P) {
  const T0 = P.traces && P.traces[e.fig]; if (!T0) { G.notes.push("tracing not loaded"); return; }
  const s = e.s ?? 1, ox = e.x ?? 0, oy = e.y ?? 0, cut = e.cut, m = cut ? Math.max(cut[2] - cut[0], cut[3] - cut[1]) * 0.01 : 0;
  const conv = (flat) => { const xs = [], ys = [], pts = []; for (let i = 0; i < flat.length; i += 2) { xs.push(flat[i]); ys.push(flat[i + 1]); pts.push([ox + flat[i] * s, oy + flat[i + 1] * s]); } return { xs, ys, pts }; };
  // inside the square's box, the printed cells' contents are left out (their place is taken by the rebuilt square);
  // the ruled lines themselves — and everything round the square — stay exactly as printed.
  const cw = cut ? (cut[2] - cut[0]) / (e.m || 3) : 0, chh = cut ? (cut[3] - cut[1]) / (e.n || 3) : 0;
  const content = (xs, ys) => { if (!cut) return false;
    const a = Math.min(...xs), b = Math.max(...xs), c = Math.min(...ys), d = Math.max(...ys);
    const within = a >= cut[0] - m && b <= cut[2] + m && c >= cut[1] - m && d <= cut[3] + m;
    return within && !((b - a) > 0.55 * cw && (d - c) > 0.55 * chh); };
  // further boxes whose writing is replaced (a placeholder name, a blank to be filled): everything wholly inside goes
  const boxGone = (xs, ys) => (e.cuts || []).some(k => Math.min(...xs) >= k[0] && Math.max(...xs) <= k[2] && Math.min(...ys) >= k[1] && Math.max(...ys) <= k[3]);
  // keep only what lies within the given rings (by the median distance of its points from the centre)
  const outside = (xs, ys) => { if (!e.annuli) return false; const ds = xs.map((x, i) => Math.hypot(x - e.annuli[0], ys[i] - e.annuli[1])).sort((a, b) => a - b), md = ds[ds.length >> 1];
    for (let k = 2; k < e.annuli.length; k += 2) if (md >= e.annuli[k] && md <= e.annuli[k + 1]) return false; return true; };
  const gone = (xs, ys) => boxGone(xs, ys) || outside(xs, ys);
  const dot = Math.max(T0.w || 0, T0.h || 0) * 0.022;   // in clean mode the dots (and other small marks) keep their printed shape
  for (const r of T0.o || []) { const c = conv(r); if (content(c.xs, c.ys) || gone(c.xs, c.ys)) continue;
    if (!(P.clean || e.annuli) || (Math.max(...c.xs) - Math.min(...c.xs) < dot && Math.max(...c.ys) - Math.min(...c.ys) < dot)) G.ink.push(c.pts); }
  for (const r of T0.c || []) { const c = conv(r); if (content(c.xs, c.ys) || gone(c.xs, c.ys)) continue;
    G.trace.push(c.pts);
    if (P.clean || e.annuli) { const sm = tlSmooth(c.pts); let len = 0; for (let i = 1; i < sm.length; i++) len += Math.hypot(sm[i][0] - sm[i - 1][0], sm[i][1] - sm[i - 1][1]);
      const xs2 = c.xs, ys2 = c.ys; const small = Math.max(...xs2) - Math.min(...xs2) < dot && Math.max(...ys2) - Math.min(...ys2) < dot;
      if (!small && len > 2.2) G.pen.push(sm); } }
  G.penW = (P.penW || 1) * Math.max(2, 4.2 * s);
}
/** Chaikin's corner-cutting, twice: the scanned wobble goes, the hand's line stays. */
function tlSmooth(pts) {
  let p = pts; if (p.length < 3) return p;
  for (let k = 0; k < 2; k++) { const q = [p[0]];
    for (let i = 0; i < p.length - 1; i++) { const a = p[i], b = p[i + 1]; q.push([a[0] * 0.75 + b[0] * 0.25, a[1] * 0.75 + b[1] * 0.25], [a[0] * 0.25 + b[0] * 0.75, a[1] * 0.25 + b[1] * 0.75]); }
    q.push(p[p.length - 1]); p = q; }
  return p;
}


/** A square of seal-signs re-set clean: each sign taken once from the printed figure's first row (its clearest form),
 *  set in every cell by the square's own rule (each row the one before, shifted), on freshly ruled lines. */
function tlSignGrid(G, e, P) {
  const T0 = P.traces && P.traces[e.fig]; if (!T0) return;
  const s = e.s ?? 1, [bx0, by0, bx1, by1] = e.box, n = e.n, cw = (bx1 - bx0) / n, ch = (by1 - by0) / n;
  const items = (flat) => { const xs = [], ys = []; for (let i = 0; i < flat.length; i += 2) { xs.push(flat[i]); ys.push(flat[i + 1]); }
    return { xs, ys, cx: (Math.min(...xs) + Math.max(...xs)) / 2, cy: (Math.min(...ys) + Math.max(...ys)) / 2, w: Math.max(...xs) - Math.min(...xs), h: Math.max(...ys) - Math.min(...ys) }; };
  const src = {};   // key → { o: [[x,y]…], c: [[x,y]…] } relative to its cell's centre
  e.seq.forEach((k, j) => { if (src[k]) return;
    const x0 = bx0 + j * cw, y0 = by0, mx = x0 + cw / 2, my = y0 + ch / 2;
    const take = (rings) => rings.map(items).filter(r => r.w + r.h > Math.min(cw, ch) * 0.12 && r.cx > x0 + cw * 0.08 && r.cx < x0 + cw * 0.92 && r.cy > y0 + ch * 0.08 && r.cy < y0 + ch * 0.92 && r.w < cw * 0.85 && r.h < ch * 0.85)
      .map(r => r.xs.map((x, i) => [x - mx, r.ys[i] - my]));
    src[k] = { o: take(T0.o || []), c: take(T0.c || []) }; });
  const X = (x) => (e.x ?? 0) + x * s, Y = (y) => (e.y ?? 0) + y * s;
  for (let i = 0; i < n; i++) for (let j = 0; j < n; j++) {
    const k = e.seq[(((j - i * (e.shift ?? 1)) % n) + n) % n], S0 = src[k]; if (!S0) continue;
    const mx = bx0 + (j + 0.5) * cw, my = by0 + (i + 0.5) * ch, sc = e.signScale || 1;
    const tr = (r) => r.map(([u, v]) => [X(mx + u * sc), Y(my + v * sc)]);
    if (P.clean) for (const r of S0.c) G.pen.push(tlSmooth(tr(r))); else for (const r of S0.o) G.ink.push(tr(r));
  }
  G.penW = (P.penW || 1) * Math.max(2, 4.2 * s);
  if (e.rules !== false) { const L = G.S.frame;
    for (let i = 0; i <= n; i++) { L.push([[X(bx0), Y(by0 + i * ch)], [X(bx1), Y(by0 + i * ch)]]); L.push([[X(bx0 + i * cw), Y(by0)], [X(bx0 + i * cw), Y(by1)]]); }
    if (e.double) { const d = Math.min(cw, ch) * 0.12; L.push([[X(bx0 - d), Y(by0 - d)], [X(bx1 + d), Y(by0 - d)], [X(bx1 + d), Y(by1 + d)], [X(bx0 - d), Y(by1 + d)], [X(bx0 - d), Y(by0 - d)]]); } }
}

/** Build the geometry of a spec for these parameters. */
function tlBuild(spec, font, P) {
  const W = spec.w || 1000, H = spec.h || 1000;
  const G = { W, H, S: { frame: [], figure: [], digits: [], letters: [] }, fills: [], ink: [], trace: [], tline: [], erase: [], pen: [], notes: [] };
  const L = (layer) => G.S[layer || "frame"];
  for (const e of spec.els || []) {
    if (e.when && !P[e.when]) continue;
    if (e.unless && P[e.unless]) continue;
    switch (e.t) {
      case "circle": L(e.layer).push(tlPoly(e.cx ?? 500, e.cy ?? 500, e.r, e.a0 ?? 0, e.a1 ?? 360, Math.max(48, Math.round(e.r / 3)))); break;
      case "rect": L(e.layer).push([[e.x, e.y], [e.x + e.w, e.y], [e.x + e.w, e.y + e.h], [e.x, e.y + e.h], [e.x, e.y]]); break;
      case "line": L(e.layer).push(e.pts); break;
      case "poly": { const n = e.n, k = e.k || 1, g = tlGcd(n, k), cx = e.cx ?? 500, cy = e.cy ?? 500, rot = e.rot || 0;
        const V = (i) => { const a = (rot + i * 360 / n) * TL_DEG; return [cx + e.r * Math.sin(a), cy - e.r * Math.cos(a)]; };
        for (let s = 0; s < g; s++) { const pts = []; for (let i = 0; i <= n / g; i++) pts.push(V(s + i * k)); L(e.layer || "figure").push(pts); } break; }
      case "spokes": { const cx = e.cx ?? 500, cy = e.cy ?? 500; for (let i = 0; i < e.n; i++) { const a = ((e.start || 0) + i * 360 / e.n) * TL_DEG;
        L(e.layer).push([[cx + e.r1 * Math.sin(a), cy - e.r1 * Math.cos(a)], [cx + e.r2 * Math.sin(a), cy - e.r2 * Math.cos(a)]]); } break; }
      case "segments": { const cx = e.cx ?? 500, cy = e.cy ?? 500, n = e.labels.length, rm = (e.r1 + e.r2) / 2;
        if (e.spokes !== false) for (let i = 0; i < n; i++) { const a = ((e.start || 0) + i * 360 / n) * TL_DEG;
          L("frame").push([[cx + e.r1 * Math.sin(a), cy - e.r1 * Math.cos(a)], [cx + e.r2 * Math.sin(a), cy - e.r2 * Math.cos(a)]]); }
        e.labels.forEach((lab, i) => { const deg = (e.start || 0) + (i + 0.5) * 360 / n, a = deg * TL_DEG;
          const nd = ((deg % 360) + 360) % 360, flip = e.radial && e.legible !== false && nd > 90 && nd < 270;
          tlText(G, font, { x: cx + rm * Math.sin(a), y: cy - rm * Math.cos(a), text: lab, size: e.size || 30, rot: e.radial ? (flip ? deg + 180 : deg) : (e.upright ? 0 : deg), maxw: e.maxw }, P); });
        break; }
      case "ring": tlRing(G, font, e, P); break;
      case "text": tlText(G, font, e, P); break;
      case "ltext": tlLineText(G, font, e, P); break;
      case "grid": tlGrid(G, font, e, P); break;
      case "seal": tlSeal(G, e); break;
      case "seals": { const order = e.order || TL_SEAL_ORDER, n = order.length, w = e.w, sz = e.size || Math.min(e.h || 80, w / n * 0.8);
        order.forEach((g, i) => tlSeal(G, { g, x: e.x + (i + 0.5) * w / n, y: e.y, size: sz })); break; }
      case "path": L(e.layer || "figure").push(e.pts); break;
      case "note": G.notes.push(e.text); break;
      case "trace": tlTrace(G, e, P); break;
      case "signgrid": tlSignGrid(G, e, P); break;
      case "erase": G.erase.push(e.r != null ? { cx: e.cx, cy: e.cy, r: e.r } : { x: e.x, y: e.y, w: e.w, h: e.h }); break;
      default: break;
    }
  }
  return G;
}

const tlD = (pts) => "M" + pts.map(p => `${Math.round(p[0] * 10) / 10},${Math.round(p[1] * 10) / 10}`).join("L");
/** Geometry → SVG markup. */
function tlSVG(G, { ink = "#111", paper = "#fdfcf8", sw = 2.2, title = "", foot = "", bg = true } = {}) {
  const pad = 40, W = G.W + pad * 2, H = G.H + pad * 2 + (foot ? 40 : 0);
  // the printed figure first, then what is erased from it, then everything composed over it
  const under = (G.ink.length ? `<path d="${G.ink.map(r => tlD(r) + "Z").join("")}" fill="${ink}" fill-rule="evenodd"/>` : "")
    + (G.tline.length ? `<path d="${G.tline.map(tlD).join("")}" fill="none" stroke="${ink}" stroke-width="${G.tlineW || 4}" stroke-linecap="round" stroke-linejoin="round"/>` : "")
    + (G.pen.length ? `<path d="${G.pen.map(tlD).join("")}" fill="none" stroke="${ink}" stroke-width="${G.penW || 4}" stroke-linecap="round" stroke-linejoin="round"/>` : "");
  const erase = G.erase.map(z => z.r != null ? `<circle cx="${z.cx}" cy="${z.cy}" r="${z.r}" fill="${paper}"/>` : `<rect x="${z.x}" y="${z.y}" width="${z.w}" height="${z.h}" fill="${paper}"/>`).join("");
  const strokes = Object.entries(G.S).map(([k, arr]) => arr.length ? `<path d="${arr.map(tlD).join("")}" fill="none" stroke="${ink}" stroke-width="${k === "frame" ? sw : k === "digits" ? sw * 1.6 : sw * 0.9}" stroke-linecap="round" stroke-linejoin="round"/>` : "").join("");
  const fills = G.fills.length ? `<path d="${G.fills.map(f => f.map(r => tlD(r) + "Z").join("")).join("")}" fill="${ink}" fill-rule="nonzero"/>` : "";
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="${-pad} ${-pad} ${W} ${H}" width="${W}" height="${H}">` +
    (title ? `<title>${xesc(title)}</title>` : "") + (bg ? `<rect x="${-pad}" y="${-pad}" width="${W}" height="${H}" fill="${paper}"/>` : "") +
    `<g>${under}${erase}${strokes}${fills}</g>` + (foot ? `<text x="${G.W / 2}" y="${G.H + pad}" text-anchor="middle" font-family="Georgia,serif" font-size="16" fill="${ink}" opacity=".55">${xesc(foot)}</text>` : "") + `</svg>`;
}
/** The pen cannot erase: centre-lines are cut where the composition erases the print. */
function tlClipErase(lines, erase) {
  if (!erase.length) return lines;
  const inside = ([x, y]) => erase.some(z => z.r != null ? Math.hypot(x - z.cx, y - z.cy) <= z.r : x >= z.x && x <= z.x + z.w && y >= z.y && y <= z.y + z.h);
  const out = [];
  for (const l of lines) { let run = []; for (const p of l) { if (inside(p)) { if (run.length > 1) out.push(run); run = []; } else run.push(p); } if (run.length > 1) out.push(run); }
  return out;
}
/** Geometry → a plotter source (the shape Qalam's plotJob expects). */
const tlPlotSrc = (G) => ({ W: G.W, H: G.H, S: { frame: G.S.frame, figure: G.S.figure.concat(tlClipErase(G.trace, G.erase)), digits: G.S.digits, letters: [] }, fills: G.fills });

"""Turn raw OCR into verified figure records.
A numeric square is accepted only when every row and column agrees. Where the two OCR readings disagree or a
cell is blank, the row and column totals are used to decide; a value no OCR reading supports is flagged for
an eye check rather than accepted. Every figure gets its printed English caption as its description."""
import json, re, collections, itertools
AI = str.maketrans("٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹", "01234567890123456789")
raw = json.load(open("ocr_raw.json"))
pages = {}
def page_text(p):
    if p not in pages: pages[p] = open(f"pages/{p:04d}.txt", encoding="utf-8").read()
    return pages[p]
def captions(p):
    paras = re.split(r"\n\s*\n", page_text(p))
    out = []
    for para in paras:
        t = re.sub(r"\s+", " ", para).strip()
        if re.search(r"\[I+ \d+\]$", t) and len(t) > 25 and not re.match(r"^\[I+ \d+\]", t):
            out.append(re.sub(r"\s*\[I+ \d+\]$", "", t))
    return out

def cands(lat, ara):
    c = []
    a = re.sub(r"[^\d]", "", (ara or "").translate(AI))
    l = re.sub(r"[^\d]", "", lat or "")
    for x in (a, l):
        if x and int(x) not in c: c.append(int(x))
    return c

def solve(C):
    n = len(C)
    grid = [[(c[0] if c else None) for c in row] for row in C]
    def sums(g): return [sum(r) for r in g] + [sum(g[r][c] for r in range(n)) for c in range(n)]
    # expected constant: most common complete row/col total
    def target(g):
        tots = [sum(r) for r in g if None not in r] + [sum(g[r][c] for r in range(n)) for c in range(n) if all(g[r][c] is not None for r in range(n))]
        return collections.Counter(tots).most_common(1)[0][0] if tots else None
    fixes = []
    for _ in range(6):
        S = target(grid)
        if S is None: return None, fixes, None
        bad_r = [r for r in range(n) if None in grid[r] or sum(grid[r]) != S]
        bad_c = [c for c in range(n) if any(grid[r][c] is None for r in range(n)) or sum(grid[r][c] for r in range(n)) != S]
        if not bad_r and not bad_c: return grid, fixes, S
        done = False
        for r in bad_r:
            for c in bad_c:
                rowrest = sum(grid[r][k] for k in range(n) if k != c and grid[r][k] is not None)
                if any(grid[r][k] is None for k in range(n) if k != c): continue
                need = S - rowrest
                colrest = [grid[k][c] for k in range(n) if k != r]
                if None in colrest or S - sum(colrest) != need or need <= 0: continue
                fixes.append({"r": r, "c": c, "read": C[r][c], "value": need, "supported": need in C[r][c]})
                grid[r][c] = need; done = True; break
            if done: break
        if not done:
            # try alternative candidates in disagreeing cells
            alts = [(r, c) for r in range(n) for c in range(n) if len(C[r][c]) > 1]
            for r, c in alts:
                for v in C[r][c][1:]:
                    g2 = [row[:] for row in grid]; g2[r][c] = v
                    if None not in itertools.chain(*g2) and len(set(sums(g2))) == 1:
                        fixes.append({"r": r, "c": c, "read": C[r][c], "value": v, "supported": True})
                        return g2, fixes, sum(g2[0])
            return None, fixes, S
    return None, fixes, None

out = []
bypage = collections.defaultdict(list)
for f in raw: bypage[f["page"]].append(f)
for p, fs in sorted(bypage.items()):
    caps = captions(p)
    for i, f in enumerate(fs):
        rec = {"page": p, "file": f["file"], "note": caps[i] if i < len(caps) else (caps[-1] if caps else None)}
        if f["kind"] != "grid":
            rec["status"] = "figure" if rec["note"] else "unread"; rec["kind"] = f["kind"]; out.append(rec); continue
        R, Cn = f["rows"], f["cols"]
        C = [[cands(f["lat"][r][c], f["ara"][r][c]) for c in range(Cn)] for r in range(R)]
        filled = sum(1 for row in C for c in row if c)
        rec["kind"] = "grid"; rec["rows"], rec["cols"] = R, Cn
        if R == Cn and R >= 3 and filled >= R * Cn - 2:
            g, fixes, S = solve(C)
            if g:
                d1 = sum(g[k][k] for k in range(R)); d2 = sum(g[k][R - 1 - k] for k in range(R))
                rec.update({"n": R, "constant": S, "grid": g, "diagonals": d1 == S and d2 == S, "fixes": fixes,
                            "status": "verified" if all(x["supported"] for x in fixes) else "eye"})
                out.append(rec); continue
        rec["status"] = "eye" if filled else ("figure" if rec["note"] else "unread")
        rec["cells"] = C
        out.append(rec)
json.dump(out, open("figs_verified.json", "w"), ensure_ascii=False)
print(collections.Counter(r["status"] for r in out))
print("verified squares by order:", collections.Counter(r["n"] for r in out if r["status"] == "verified"))
print("with fixes:", sum(1 for r in out if r.get("fixes")), " flagged unsupported fixes:", sum(1 for r in out if r["status"] == "eye" and r.get("grid")))

"""Centerline tracings v2: upscale, Otsu, close gaps, skeletonize, prune spurs, join near endpoints, order strokes for least pen travel."""
import json, sys, numpy as np, cv2
from skimage.morphology import skeletonize, remove_small_objects
from scipy.spatial import cKDTree
FI = json.load(open('/home/claude/ihya/figs_index.json'))
NB = [(-1,-1),(-1,0),(-1,1),(0,-1),(0,1),(1,-1),(1,0),(1,1)]
def trace(sk):
    ys, xs = np.nonzero(sk); pts = set(zip(ys.tolist(), xs.tolist()))
    def nbrs(p): return [(p[0]+dy, p[1]+dx) for dy, dx in NB if (p[0]+dy, p[1]+dx) in pts]
    deg = {p: len(nbrs(p)) for p in pts}; seen = set(); lines = []
    def walk(a, b):
        path = [a, b]; seen.add((a, b)); seen.add((b, a)); prev, cur = a, b
        while deg[cur] == 2:
            nx = [q for q in nbrs(cur) if q != prev and (cur, q) not in seen]
            if not nx: break
            q = nx[0]; seen.add((cur, q)); seen.add((q, cur)); path.append(q); prev, cur = cur, q
        return path
    for p in [p for p in pts if deg[p] != 2] + list(pts):
        for q in nbrs(p):
            if (p, q) not in seen: lines.append(walk(p, q))
    return [np.array([[x, y] for y, x in ln], float) for ln in lines]
def join(lines, d):
    lines = [l for l in lines if len(l) >= 2]
    changed = True
    while changed:
        changed = False
        ends = []
        for i, l in enumerate(lines): ends += [(l[0], i, 0), (l[-1], i, 1)]
        if len(ends) < 2: break
        tree = cKDTree([e[0] for e in ends]); used = set(); out = []
        pairs = sorted(tree.query_pairs(d, output_type='ndarray').tolist(), key=lambda pq: np.linalg.norm(ends[pq[0]][0] - ends[pq[1]][0]))
        merged = {}
        for a, b in pairs:
            ia, ea = ends[a][1], ends[a][2]; ib, eb = ends[b][1], ends[b][2]
            if ia == ib or ia in used or ib in used: continue
            A = lines[ia] if ea == 1 else lines[ia][::-1]
            B = lines[ib] if eb == 0 else lines[ib][::-1]
            merged[ia] = np.vstack([A, B]); used |= {ia, ib}; changed = True
        out = [merged[i] for i in merged] + [l for i, l in enumerate(lines) if i not in used]
        lines = out
    return lines
def order(lines):
    if not lines: return lines
    rest = list(range(len(lines))); res = []; cur = np.array([0., 0.])
    while rest:
        best, bd, rev = None, 1e18, False
        for i in rest:
            l = lines[i]; d0 = ((l[0] - cur) ** 2).sum(); d1 = ((l[-1] - cur) ** 2).sum()
            if d0 < bd: best, bd, rev = i, d0, False
            if d1 < bd: best, bd, rev = i, d1, True
        l = lines[best][::-1] if rev else lines[best]; res.append(l); cur = l[-1]; rest.remove(best)
    return res
def run(i, scale=2.0):
    f = FI[i]; im = cv2.imread('/home/claude/ihya/' + f['file'], cv2.IMREAD_GRAYSCALE)
    im = cv2.resize(im, None, fx=scale, fy=scale, interpolation=cv2.INTER_CUBIC)
    im = cv2.GaussianBlur(im, (5, 5), 0)
    t, _ = cv2.threshold(im, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    bw = (im < min(t + 15, 200)).astype(np.uint8)
    bw = cv2.morphologyEx(bw, cv2.MORPH_CLOSE, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5)))
    bw = remove_small_objects(bw.astype(bool), 30)
    sk = skeletonize(bw)
    lines = [l for l in trace(sk) if len(l) >= 3]
    # prune short spurs hanging off junctions
    lines = [l for l in lines if np.abs(np.diff(l, axis=0)).sum() > 11 or len(lines) < 5]
    lines = join(lines, 7 * scale / 2)
    lines = [l for l in lines if np.abs(np.diff(l, axis=0)).sum() > 6]
    lines = order(lines)
    s = 1 / scale; out = []
    for l in lines:
        ap = cv2.approxPolyDP((l).astype(np.float32).reshape(-1, 1, 2), 0.8, False).reshape(-1, 2) * s
        out.append([round(v, 1) for v in ap.flatten().tolist()])
    return {"w": round(bw.shape[1] * s), "h": round(bw.shape[0] * s), "p": out}
def svg(r, path):
    d = ''.join('M' + ' '.join(f'{p[k]},{p[k+1]}' for k in range(0, len(p), 2)) for p in r['p'])
    open(path, 'w').write(f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {r["w"]} {r["h"]}" width="{r["w"]*2}" height="{r["h"]*2}"><rect width="100%" height="100%" fill="#fff"/><path d="{d}" fill="none" stroke="#000" stroke-width="0.7" stroke-linecap="round" stroke-linejoin="round"/></svg>')
if __name__ == "__main__":
    for i in [int(x) for x in sys.argv[1:]]:
        r = run(i); print(i, len(r['p']), 'strokes', len(json.dumps(r['p'])) // 1000, 'KB')
        json.dump(r, open(f'/home/claude/plot/u{i}.json', 'w')); svg(r, f'/home/claude/plot/u{i}.svg')

def outline(i, scale=2.0):
    f = FI[i]; im = cv2.imread('/home/claude/ihya/' + f['file'], cv2.IMREAD_GRAYSCALE)
    im = cv2.resize(im, None, fx=scale, fy=scale, interpolation=cv2.INTER_CUBIC)
    im = cv2.GaussianBlur(im, (5, 5), 0)
    t, _ = cv2.threshold(im, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    bw = (im < min(t + 15, 200)).astype(np.uint8)
    bw = remove_small_objects(bw.astype(bool), 30).astype(np.uint8)
    cs, _ = cv2.findContours(bw, cv2.RETR_LIST, cv2.CHAIN_APPROX_NONE)
    out = []
    for c in cs:
        if len(c) < 8: continue
        ap = cv2.approxPolyDP(c.astype(np.float32), 0.9, True).reshape(-1, 2) / scale
        ap = np.vstack([ap, ap[:1]])
        out.append([round(v, 1) for v in ap.flatten().tolist()])
    return out

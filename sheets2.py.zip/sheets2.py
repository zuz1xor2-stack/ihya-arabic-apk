"""Contact sheets for figures with a given status in figs_book.json (default: queued), 6 per sheet."""
import json, sys
from PIL import Image, ImageDraw, ImageFont
F = json.load(open("figs_book.json")); V = json.load(open("figs_verified.json"))
st = sys.argv[1] if len(sys.argv) > 1 else "queued"; tag = sys.argv[2] if len(sys.argv) > 2 else "q"
todo = [f["id"] for f in F if f["status"] == st]
font = ImageFont.load_default(size=22); TW, TH = 760, 560
idx = []
for s in range(0, len(todo), 6):
    chunk = todo[s:s+6]; sheet = Image.new("RGB", (3*TW, 2*TH), "white"); d = ImageDraw.Draw(sheet)
    for k, i in enumerate(chunk):
        im = Image.open(V[i]["file"]).convert("RGB"); im.thumbnail((TW-20, TH-44))
        x, y = (k % 3)*TW, (k//3)*TH; sheet.paste(im, (x+10, y+36))
        d.rectangle([x, y, x+TW-1, y+TH-1], outline=(200,0,0), width=2)
        d.text((x+10, y+6), f"#{i} p.{V[i]['page']}", fill=(200,0,0), font=font)
    fn = f"sheets/{tag}_{s//6:03d}.png"; sheet.save(fn); idx.append([fn, chunk])
json.dump(idx, open(f"sheets/{tag}_index.json", "w")); print(len(todo), "figures", len(idx), "sheets")

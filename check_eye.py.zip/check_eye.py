import sys, json
V = {"ا":1,"ب":2,"ج":3,"د":4,"ه":5,"و":6,"ز":7,"ح":8,"ط":9,"ي":10,"ك":20,"ل":30,"م":40,"ن":50,"س":60,"ع":70,"ف":80,"ص":90,"ق":100,"ر":200,"ش":300,"ت":400,"ث":500,"خ":600,"ذ":700,"ض":800,"ظ":900,"غ":1000,"ة":5,"ى":10,"أ":1,"إ":1,"آ":1,"ء":1,"ئ":10,"ؤ":6}
def val(x):
    x = x.strip()
    if x in ("-", "") or x.startswith("["): return 0
    if x.isdigit(): return int(x)
    return sum(V.get(ch, 0) for ch in x)
def parse(body): return [[c.strip() for c in r.split(",")] for r in body.split(";")]
out = {}; seen = set(); bad = 0
for ln in open("eye_reads.txt", encoding="utf-8"):
    ln = ln.rstrip("\n")
    if not ln.strip(): continue
    i, k, body = ln.split("|", 2)
    if i in seen: print("DUP", i)
    seen.add(i)
    rec = {"kind": k}
    if k in ("sq", "mx", "h3", "disc"):
        cells = parse(body); g = [[val(c) for c in r] for r in cells]; n = len(g)
        if any(len(r) != n for r in g): print(i, "SHAPE", [len(r) for r in g]); bad += 1; continue
        if k == "h3":
            e = [sum(g[0]), sum(r[-1] for r in g), sum(g[-1]), sum(r[0] for r in g)]; ok = len(set(e)) == 1; S = e[0]; diag = False
        else:
            rs = [sum(r) for r in g]; cs = [sum(g[r][c] for r in range(n)) for c in range(n)]
            d = [sum(g[t][t] for t in range(n)), sum(g[t][n - 1 - t] for t in range(n))]
            ok = len(set(rs + cs)) == 1; S = rs[0]; diag = ok and d[0] == S and d[1] == S
            if not ok and k != "disc": print(i, "BAD rows", rs, "cols", cs)
        if not ok and k != "disc": bad += 1
        if k == "disc": rec["rows_cols"] = (rs, cs)
        rec.update({"cells": cells, "values": g, "ok": ok, "constant": S if ok else None, "diagonals": diag})
    elif k == "same": rec["same"] = body
    elif k in ("table","cells"): rec["table"] = parse(body)
    else: rec["text"] = body
    out[i] = rec
json.dump(out, open("eye_reads.json", "w"), ensure_ascii=False)
print(len(out), "entries,", bad, "failing")

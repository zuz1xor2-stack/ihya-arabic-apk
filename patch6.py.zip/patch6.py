"""v2.13: Muwāfaqa removed (patch5 no longer adds it); Qalam — the plotter; every open working craftable; plotter buttons everywhere a thing is forged."""
P = '/home/claude/live/src/engine.jsx'
src = open(P, encoding='utf-8').read()
def R(old, new, cnt=1):
    global src
    assert src.count(old) == cnt, (src.count(old), old[:90])
    src = src.replace(old, new)
R('import * as SHAKL from "./shakl.mjs";', 'import * as SHAKL from "./shakl.mjs";\nimport opentype from "opentype.js";')
R("/* ═══ shell ═══ */", open('/home/claude/live/plotter.jsx', encoding='utf-8').read() + "\n/* ═══ shell ═══ */")
R('["alyawm","Today",AlatToday]', '["alyawm","Today",AlatToday],["qalam","Qalam · plotter",Qalam]')
R('const GROUP_OF = { ', 'const GROUP_OF = { qalam:"alat", ')
# Forge → plotter
R('''          <Btn hue={hue} small onClick={() => svgToPng(svgFromLayout(L, title, pagesUsed, hue), `wafq-${A}-${order}.png`)}>PNG</Btn>''',
  '''          <Btn hue={hue} small onClick={() => svgToPng(svgFromLayout(L, title, pagesUsed, hue), `wafq-${A}-${order}.png`)}>PNG</Btn>
          <Btn hue="#e8c96a" small onClick={() => go("qalam", { job: { kind: "layout", L: plateAt(Math.floor(1060 / (order + 4))), title, stem: `wafq-${A}-${order}` } })}>✒ send to the plotter</Btn>''')
# Ashkāl Forge → plotter (squares and plates)
R('''          {shown && !asPlate && <><Btn hue="#e8c96a" small onClick={dlSvg}>download SVG</Btn><Btn hue="#e8c96a" small onClick={dlPng}>download PNG</Btn></>}''',
  '''          {shown && !asPlate && <><Btn hue="#e8c96a" small onClick={dlSvg}>download SVG</Btn><Btn hue="#e8c96a" small onClick={dlPng}>download PNG</Btn>
            <Btn hue="#e8c96a" small onClick={() => go("qalam", { job: { kind: "layout", L, title: cur.title, stem: fileStem } })}>✒ send to the plotter</Btn></>}
          {(!an || asPlate) && <Btn hue="#e8c96a" small onClick={() => go("qalam", { job: { kind: "figure", id: cur.id, above: aboveT, below: belowT, frame } })}>✒ send to the plotter</Btn>}''')
# Ṭalāsim → plotter
R('''          <Btn hue="#e8c96a" small onClick={() => go("shakl", { id: cur.id })}>forge it for your name</Btn>
        </div>
        <Field hue={hue} label="YOUR NOTES ON THIS TALISMAN''', '''          <Btn hue="#e8c96a" small onClick={() => go("shakl", { id: cur.id })}>forge it for your name</Btn>
          <Btn hue="#e8c96a" small onClick={() => go("qalam", { job: { kind: "figure", id: cur.id } })}>✒ send to the plotter</Btn>
        </div>
        <Field hue={hue} label="YOUR NOTES ON THIS TALISMAN''')
# Workings: every open operation craftable — its square, its figures, and a craft card
R('function WorkCard({ w, go }) {', open('/home/claude/live/craft.jsx', encoding='utf-8').read() + '\nfunction WorkCard({ w, go }) {')
R('''      open the {w.square[0]}×{w.square[0]} in the Forge</button></div>}
  </div>;''', '''      open the {w.square[0]}×{w.square[0]} in the Forge</button></div>}
    <CraftRow w={w} go={go} />
  </div>;''')
open(P, 'w', encoding='utf-8').write(src)
print("v2.13 applied")

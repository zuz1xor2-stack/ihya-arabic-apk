/* ═══ today — what the book gives to this day and this hour (v2.6) ═══ */
const DAY_TABLE = [  // p.115 table of the days, with the Fātiḥa verse of p.1787; the litany of ch.20
  { d: "Sunday",    planet: "sun",     letter: "ف", name: "فرد",  nameTr: "al-Fard",    angel: "روقيائيل", angelTr: "Rūqyāʾīl",   colour: "yellow", incense: "aloeswood", fatiha: "الحمد لله رب العالمين", wird: 2118 },
  { d: "Monday",    planet: "moon",    letter: "ج", name: "جبار", nameTr: "al-Jabbār",  angel: "جبرائيل",  angelTr: "Jabrāʾīl",   colour: "white",  incense: "musk",       fatiha: "الرحمن الرحيم", wird: 2121 },
  { d: "Tuesday",   planet: "mars",    letter: "ش", name: "شكور", nameTr: "al-Shakūr",  angel: "سمسمائيل", angelTr: "Samsamāʾīl", colour: "red",    incense: "sandalwood", fatiha: "مالك يوم الدين", wird: 2124 },
  { d: "Wednesday", planet: "mercury", letter: "ث", name: "ثابت", nameTr: "al-Thābit",  angel: "ميكائيل",  angelTr: "Mīkāʾīl",    colour: "blue",   incense: "mastic",     fatiha: "اياك نعبد واياك نستعين", wird: 2126 },
  { d: "Thursday",  planet: "jupiter", letter: "ظ", name: "ظهير", nameTr: "al-Ẓahīr",   angel: "صرفيائيل", angelTr: "Ṣarfiyāʾīl", colour: "green",  incense: "labdanum",   fatiha: "اهدنا الصراط المستقيم", wird: 2130 },
  { d: "Friday",    planet: "venus",   letter: "خ", name: "خبير", nameTr: "al-Khabīr",  angel: "عنيائيل",  angelTr: "ʿAnyāʾīl",   colour: "grey",   incense: "frankincense", fatiha: "صراط الذين انعمت عليهم", wird: 2132 },
  { d: "Saturday",  planet: "saturn",  letter: "ز", name: "زكي",  nameTr: "al-Zakī",    angel: "كسفيائيل", angelTr: "Kasfiyāʾīl", colour: "black",  incense: "harmal",     fatiha: "غير المغضوب عليهم ولا الضالين", wird: 2135 },
];
/* Chapter 20, pp.2118–2136, read from the engine's own text of the chapter: each day's portion of Yā-Sīn, its verse of the
   Fātiḥa, the names it calls, its celestial angel and terrestrial king, the abjad group named as the king's ruler, its
   tahṭīl, its sealing verse, and the adjured spirit and master. Every day closes on Q 36:82–83. Names in Arabic only where the
   book's English settles them; the rest are left in the book's English.
   Tuesday–Friday's angels are corrected (v2.6.1): ch.20 prints Mīkāʾīl, Samsamāʾīl, Isrāfīl, ʿAzrāʾīl; the book's own day tables
   (pp.115, 584, 819–821, 920–922, 1893, 1945) give Samsamāʾīl, Mīkāʾīl, Ṣarfiyāʾīl, ʿAnyāʾīl, paired with ch.20's own kings. */
const CH20 = [
  { pp: [2118, 2120], yasin: "36:1–12", fatihaRef: "1:2",
    names: [["al-Ḥayy","الحي"],["al-Qayyūm","القيوم"],["al-Kāfī","الكافي"],["al-Shāfī","الشافي"],["al-Hādī","الهادي"],["al-Laṭīf","اللطيف"],["al-Bāqī","الباقي"]],
    angel: "Rūqiyāʾīl", angelAr: "روقيائيل", king: "Mudhhib (the Gilded)", kingAr: "المذهب", group: "abjad", tahtil: "Laṭahṭīl", tahtilAr: "للطهطيل", seal: "17:81",
    adjured: "Kaṭaghā Riyāʾīl", master: "Kaḥfā Ṭafḥiyūsh" },
  { pp: [2121, 2123], yasin: "36:13–17", fatihaRef: "1:3",
    names: [["al-Raḥmān","الرحمن"],["al-Raḥīm","الرحيم"],["Allāh","الله"],["the Ever-Gentle",null],["the Affectionate",null],["al-Jalīl","الجليل"],["al-Jabbār","الجبار"],["al-Karīm","الكريم"],["the One who makes and appoints",null]],
    angel: "Jibrāʾīl", angelAr: "جبرائيل", king: "Murra", kingAr: "مرة", kingAlt: "al-Abyaḍ, Abū l-Nūr", kingAltPp: [584, 654, 820], group: "hawwazaḥ", tahtil: "Mahṭahṭīl", tahtilAr: "مهطهطيل", seal: "25:23",
    adjured: "Mahaqqaʿjāʾīl", master: null },
  { pp: [2124, 2126], yasin: "36:18–24", fatihaRef: "1:4",
    names: [["Māliku yawm al-dīn","مالك يوم الدين"],["Muqallib al-qulūb wa-l-abṣār","مقلب القلوب والابصار"]],
    angel: "Samsamāʾīl", angelAr: "سمسمائيل", printed: "Mīkāʾīl", king: "Abā Maḥwaz, the Red (al-Aḥmar)", kingAr: "الاحمر", group: "ṭaykal", tahtil: "Qahṭayṭīl", tahtilAr: "قهطهطيل", printedTahtil: "Fahṭahayṭal", seal: "18:98",
    adjured: "Basagh Faqakrāʾīl", master: "Kaṭakḥiyūsh" },
  { pp: [2126, 2129], yasin: "36:25–47", fatihaRef: "1:5–6",
    names: [["al-Sarīʿ","السريع"],["al-Qarīb","القريب"],["al-Mujīb","المجيب"],["al-Maʿbūd","المعبود"],["al-Mustaʿān","المستعان"]],
    angel: "Mīkāʾīl", angelAr: "ميكائيل", printed: "Samsamāʾīl", king: "Burqān", kingAr: "برقان", group: "mansaʿ", tahtil: "Fahṭayṭīl", tahtilAr: "فهطيطيل", printedTahtil: "Fahṭahṭīl", seal: "10:81–82",
    adjured: "Saydaʿ Tatrīl", master: "Shajaʿ Maḥyūsh" },
  { pp: [2130, 2131], yasin: "36:48–60", fatihaRef: "1:6",
    names: [["the Omnipotent",null],["the Powerful",null],["al-Laṭīf","اللطيف"],["the Best",null],["al-Khāliq","الخالق"],["al-Hādī","الهادي"]],
    angel: "Ṣarfiyāʾīl", angelAr: "صرفيائيل", printed: "Isrāfīl", king: "Shamhūrash", kingAr: "شمهورش", group: null, tahtil: "Nahṭahṭīl", tahtilAr: "نهطهطيل", printedTahtil: "Lahaṭṭīl", seal: "41:41–42",
    adjured: "Lāwlād Nahyāʾīl", master: "Lāʿarfālyūsh" },
  { pp: [2132, 2134], yasin: "36:61–69", fatihaRef: "1:7 (first half)",
    names: [["al-Ḥakīm","الحكيم"],["al-ʿAlīm","العليم"],["ʿAllām al-ghuyūb","علام الغيوب"],["al-Nūr","النور"],["al-ʿAlī","العلي"],["al-Laṭīf","اللطيف"],["al-Hādī","الهادي"]],
    angel: "ʿAnyāʾīl", angelAr: "عنيائيل", printed: "ʿAzrāʾīl", king: "al-Abyaḍ (the White)", kingAr: "الابيض", kingAlt: "Zawbaʿa", kingAltPp: [584, 654, 662, 821], group: null, tahtil: "Jahlaṭṭīl", tahtilAr: "جهطهطيل", seal: "35:10",
    adjured: "Kajaʿlaṭāʾīl", master: "Shakmahūrash" },
  { pp: [2135, 2136], yasin: "36:70–77", fatihaRef: "1:7 (second half)",
    names: [["al-Mubīn","المبين"],["al-ʿAzīz","العزيز"],["the Master",null],["al-Muʾmin","المؤمن"],["al-Muhaymin","المهيمن"],["al-Qahhār","القهار"],["al-Kabīr","الكبير"]],
    angel: "Kasfiyāʾīl", angelAr: "كسفيائيل", king: "Maymūn", kingAr: "ميمون", group: null, tahtil: "Lajahaṭṭīl, Lamqafanjal", tahtilAr: "لخهطهطيل", seal: "7:118",
    adjured: "Baraʿjakḥiyāʾīl", master: "ʿAjakṭayūsh" },
];
/* pp.116–117, "The hours for performing a working", with the element rule of p.115. Each hour's list is split by the house
   rule: what serves oneself or another's good is listed; what is aimed at harming, compelling or binding a person is named only. */
const HOUR_BOOK = {
  saturn:  { el: null,    open: [], named: ["separation","sowing hatred","setting one against another","loathing","ruin","binding sleep","binding virility"] },
  jupiter: { el: null,    open: ["engendering love","appearing beautiful and charming in people's eyes","breaking talismans"], named: ["attraction","drawing someone to oneself","binding the tongue"] },
  mars:    { el: null,    open: [], named: ["separation","setting one against another","hatred","enmity","shedding blood","driving someone from a place","destruction"] },
  sun:     { el: "fire",  open: ["love","glory","honour","fame","appearing awe-inspiring","having one's request granted before people of standing"], named: ["drawing hearts to oneself","subjugation"] },
  venus:   { el: "earth", open: ["love","intimacy","marriage","the fulfilment of needs"], named: ["attraction","kindling passion"] },
  mercury: { el: "air",   open: ["unearthing buried treasure","the fulfilment of needs"], named: ["making someone ill","binding the tongue","drawing another's heart"] },
  moon:    { el: "water", open: ["unearthing buried treasure","releasing one who has been bound","breaking sorcery"], named: ["drawing the hearts of people of rank","binding the tongue","binding through love"] },
};
/* Chapter 3's own judgement of each mansion (pp.214–228): the nature it gives the star and its verdict, as the text words them.
   The engine's "element" of a mansion is its letter's (p.76); the omen badge is the table of p.245–246. Where chapter 3 and that table
   say opposite things (mansions 12 and 25) both are shown; neither can be preferred from the book itself. */
const CH3 = {1:["fiery","inauspicious"],2:["hot and moist","wholesome"],3:["of mixed substance","mixed"],4:["earthy","works enmity"],5:["mixed","mixed"],
  6:["—","auspicious"],7:["airy, gentle","auspicious"],8:["cold mixed with heat","mixed"],9:["watery","continuously inauspicious"],10:["cold","mixed, nearer to good"],
  11:["hot and dry","fit for good works"],12:["of earth and fire","auspicious, for middling works"],13:["hot and dry","mixed"],14:["earthy and dry","works corruption"],
  15:["airy","love and profit"],16:["airy","mixed"],17:["mixed","mixed"],18:["watery and moist","fortunate"],19:["—","auspicious, turned by ill"],
  20:["fiery, luminous","fortunate"],21:["fiery","inauspicious"],22:["earthy","inauspicious"],23:["of mixed substance","mixed"],24:["of earth and air","for all operations"],
  25:["airy","inauspicious"],26:["watery","fortunate"],27:["watery","fortunate, yet its outcome not praiseworthy"],28:["watery","auspicious"]};
const OMEN_CLASH = { 12: "the table of p.245 calls it inauspicious; chapter 3 (p.220) gives it an auspicious force for middling works",
  25: "the table of p.246 calls it auspicious; chapter 3 (p.226) calls it an airy, inauspicious star" };
/* The prologue's conditions (pp.40–46) as a daily checklist; your own items are added beside them. */
const TODAY_CHECKS = [
  ["purity", "Ritual purity — body, clothes, place, and the heart", 42],
  ["lawful", "Lawful food; no backbiting, no lying; mercy toward people", 42],
  ["idhn", "Working under licence (idhn) — my teacher's oversight", 42],
  ["salawat", "Ṣalawāt before and after every working", 44],
  ["qibla", "Facing the qibla when writing; cells drawn equal", 44],
  ["time", "Day and hour checked; not one of the inauspicious days", 43],
  ["istikhara", "Istikhāra before the working", 45],
  ["secret", "Kept it to myself", 41],
];
const ymd = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
const WEEKDAYS = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
const ELNAME = { fire: "fire", earth: "earth", air: "air", water: "water" };

function TSection({ id, title, sub, hue, children, open: open0 = true }) {
  const [open, setOpen] = useState(() => LS.get("today-open-" + id, open0));
  return <section style={{ marginTop: 22 }}>
    <button onClick={() => { setOpen(o => { LS.set("today-open-" + id, !o); return !o; }); }} aria-expanded={open}
      style={{ display: "flex", alignItems: "baseline", gap: 10, background: "none", border: "none", borderBottom: `1px solid ${hue}33`,
        width: "100%", textAlign: "left", padding: "0 0 6px", cursor: "pointer", color: "inherit" }}>
      <span style={{ fontFamily: F.mono, fontSize: 11, color: hue }}>{open ? "▾" : "▸"}</span>
      <span style={{ fontFamily: F.disp, fontSize: 22, color: "#f0ead9" }}>{title}</span>
      {sub && <span style={{ fontFamily: F.mono, fontSize: 10.5, color: "#ffffff77" }}>{sub}</span>}
    </button>
    {open && <div style={{ marginTop: 12 }}>{children}</div>}
  </section>;
}
const tCard = (hue, strong) => ({ border: `1px solid ${strong ? hue : hue + "44"}`, background: strong ? hue + "12" : "#00000033", padding: 14, borderRadius: 3, minWidth: 0 });
const tLabel = (hue) => ({ fontFamily: F.mono, fontSize: 10.5, letterSpacing: "0.08em", color: hue, textTransform: "uppercase" });
const tGrid = { display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(min(100%,260px),1fr))", gap: 10 };

function TodayPane({ hue, go, cur, hours, loc, tz }) {
  const [now, setNow] = useState(new Date());
  useEffect(() => { const t = setInterval(() => setNow(new Date()), 1000); return () => clearInterval(t); }, []);
  // the planetary day runs sunrise to sunrise: before sunrise it is still yesterday's day
  const ruler = hours && hours[0] ? hours[0].planet : DAY_RULERS[now.getDay()];
  const di = DAY_RULERS.indexOf(ruler), T = DAY_TABLE[di], W = CH20[di];
  const curH = (hours || []).find(h => now >= h.start && now < h.end) || cur;
  const night = curH ? curH.night : false;
  const M = manzilNow(now), mz = (DATA.manazil || []).find(m => m.n === M.n), mb = MANZIL_BOOK.mansions.find(m => m.n === M.n);
  const mo = moon(now), ld = lunarDay(now), hj = hijri(now);
  const PT = useMemo(() => loc ? prayerTimes(now, loc.lat, loc.lon, tz, LS.get("today-method", "ISNA")) : null, [loc, tz, now.getDate()]);
  const qb = loc ? qiblaBearing(loc.lat, loc.lon) : null;
  const dateKey = ymd(now);
  const [visited] = useState(() => LS.get("visited", []));
  const [selH, setSelH] = useState(null);
  const showH = (hours || []).find(h => h.i === selH) || curH;
  const [judgeOpen, setJudgeOpen] = useState(false);
  const left = curH ? Math.max(0, curH.end - now) : 0;
  const cd = `${Math.floor(left / 3600000)}:${String(Math.floor(left / 60000) % 60).padStart(2, "0")}:${String(Math.floor(left / 1000) % 60).padStart(2, "0")}`;
  const manhus = MANHUS_DAYS.includes(ld.day);
  const workToday = BOOK.workings.filter(w => w.cat !== "sealed" && (w.days || []).includes(T.d));
  const workHour = curH ? BOOK.workings.filter(w => w.cat !== "sealed" && (w.hour || []).includes(curH.planet)) : [];
  const rulerHours = (hours || []).filter(h => h.planet === ruler);
  const nextRuler = rulerHours.find(h => h.end > now && !(curH && h.i === curH.i));

  /* ── counter: the day's name recited by its number ── */
  const counterNames = useMemo(() => [[T.nameTr, T.name], ...W.names.filter(n => n[1])], [di]);
  const [cName, setCName] = useState(0);
  useEffect(() => setCName(0), [di]);
  const cN = counterNames[Math.min(cName, counterNames.length - 1)];
  const cTarget = abjad(cN[1]);
  const cKey = `today-count:${dateKey}:${cN[1]}`;
  const [count, setCount] = useState(() => LS.get(cKey, 0));
  useEffect(() => setCount(LS.get(cKey, 0)), [cKey]);
  const bump = (d) => setCount(c => { const n = Math.max(0, c + d); LS.set(cKey, n); return n; });

  /* ── checklist and notes, kept per date on this device ── */
  const [own, setOwn] = useState(() => LS.get("today-own-checks", []));
  const [newItem, setNewItem] = useState("");
  const [checked, setChecked] = useState(() => LS.get("today-checks:" + dateKey, {}));
  useEffect(() => setChecked(LS.get("today-checks:" + dateKey, {})), [dateKey]);
  const tick = (k) => setChecked(c => { const n = { ...c, [k]: !c[k] }; LS.set("today-checks:" + dateKey, n); return n; });
  const addOwn = () => { const t = newItem.trim(); if (!t) return; const n = [...own, { k: "own-" + Date.now(), t }]; setOwn(n); LS.set("today-own-checks", n); setNewItem(""); };
  const dropOwn = (k) => { const n = own.filter(o => o.k !== k); setOwn(n); LS.set("today-own-checks", n); };
  const [note, setNote] = useState(() => LS.get("today-note:" + dateKey, ""));
  useEffect(() => setNote(LS.get("today-note:" + dateKey, "")), [dateKey]);
  const pastNotes = useMemo(() => { const out = []; for (let i = 1; i <= 14; i++) { const d = new Date(now.getTime() - i * 864e5), v = LS.get("today-note:" + ymd(d), "");
    if (v.trim()) out.push([d, v]); } return out; }, [dateKey]);
  const allChecks = [...TODAY_CHECKS.map(([k, t, p]) => ({ k, t, p })), ...own];
  const nDone = allChecks.filter(c => checked[c.k]).length;

  /* ── the week ahead ── */
  const week = useMemo(() => Array.from({ length: 7 }, (_, i) => {
    const d = new Date(now); d.setHours(12, 0, 0, 0); d.setDate(d.getDate() + i);
    const wd = d.getDay(), l = lunarDay(d), h = hijri(d), m = manzilNow(d), mzz = (DATA.manazil || []).find(x => x.n === m.n),
      omen = (MANZIL_BOOK.mansions.find(x => x.n === m.n) || {}).omen;
    const flags = [];
    if (MANHUS_DAYS.includes(l.day)) flags.push(["inauspicious lunar day (p.43)", "#e86a52"]);
    if (l.day === 1) flags.push(["new moon — p.2116 begins its Yā-Sīn supplication here", "#e8c96a"]);
    if (l.day === 1 && wd === 0) flags.push(["first of the month on a Sunday — the 40-day riyāḍa of p.2112 may begin", "#e8c96a"]);
    if (wd === 5) flags.push(["Jumuʿa", "#8fce7f"]);
    if (wd === 1 || wd === 4) flags.push(["Monday/Thursday fast (sunna)", "#ffffff88"]);
    if (h.d >= 13 && h.d <= 15) flags.push(["white day (sunna fast)", "#ffffff88"]);
    return { d, wd, l, h, m, mzz, omen, flags, works: BOOK.workings.filter(w => w.cat !== "sealed" && (w.days || []).includes(WEEKDAYS[wd])).length };
  }), [dateKey]);

  const sheet = () => {
    const L = [];
    L.push(`Iḥyāʾ Engine — Today, ${now.toDateString()} · ${hj.d} ${hj.month} ${hj.y} AH`);
    L.push(`Day of ${PLANETS[ruler].n.split(" · ")[0]} (${T.d})${loc ? " · " + (loc.label || "") : ""}`);
    L.push("");
    L.push(`p.115  Name: ${T.nameTr} ${T.name} (${abjad(T.name)}) · letter ${T.letter} · angel ${T.angelTr} ${T.angel} · colour ${T.colour} · incense ${T.incense}`);
    L.push(`p.1787 Fātiḥa: ${T.fatiha} (${abjad(T.fatiha)})`);
    L.push(`ch.20 pp.${W.pp[0]}–${W.pp[1]}  Yā-Sīn ${W.yasin}, closing 36:82–83 · Fātiḥa ${W.fatihaRef}`);
    L.push(`       Names: ${W.names.map(n => n[0] + (n[1] ? " " + n[1] : "")).join(" · ")}`);
    L.push(`       Angel ${W.angel} · king ${W.king}${W.group ? " · group " + W.group : ""} · tahṭīl ${W.tahtil} ${W.tahtilAr}${W.printedTahtil ? " (corrected; printed " + W.printedTahtil + ")" : ""} · sealing verse Q ${W.seal}`);
    L.push("");
    L.push(`Moon: ${mo.phase}, ${(mo.illum * 100).toFixed(0)}% · lunar day ${ld.day}${manhus ? " (inauspicious, p.43)" : ""} · ${ld.waxing ? "waxing" : "waning"}`);
    if (mz) L.push(`Mansion ${mz.n} ${mz.tr} ${mz.ar} · letter ${mz.letter} · ${mb && mb.omen ? mb.omen : ""} (p.${mb && mb.judge ? mb.judge.p : ""})`);
    if (PT && !PT.polar) L.push(`Prayer: Fajr ${hoursToHM(PT.fajr)} · Sunrise ${hoursToHM(PT.sunrise)} · Ẓuhr ${hoursToHM(PT.dhuhr)} · ʿAṣr ${hoursToHM(PT.asr)} · Maghrib ${hoursToHM(PT.maghrib)} · ʿIshāʾ ${hoursToHM(PT.isha)}`);
    if (qb != null) L.push(`Qibla ${qb.toFixed(0)}° ${compass(qb)}`);
    L.push("");
    L.push("Hours:");
    for (const h of hours || []) L.push(`  ${String(h.i).padStart(2)} ${fmt(h.start)}–${fmt(h.end)}  ${h.planet}${h.planet === ruler ? "  ★ the day's own" : ""}`);
    if (note.trim()) { L.push(""); L.push("Notes:"); L.push(note); }
    download(`today-${dateKey}.txt`, L.join("\n"), "text/plain");
  };

  const P = PLANETS[ruler];
  return <div style={{ marginTop: 14, maxWidth: 980 }}>
    {/* ── at a glance ── */}
    <div style={{ ...tCard(P.h, true), display: "flex", flexWrap: "wrap", gap: 18, alignItems: "center" }}>
      <div style={{ minWidth: 0, flex: "1 1 260px" }}>
        <div style={tLabel(P.h)}>{now.toLocaleDateString([], { weekday: "long", month: "long", day: "numeric", year: "numeric" })}</div>
        <div style={{ fontFamily: F.disp, fontSize: 30, color: "#f0ead9", lineHeight: 1.15, marginTop: 4 }}>
          {P.g} Day of {P.n.split(" · ")[0]} <span dir="rtl" style={{ fontFamily: F.ar, fontSize: 24, color: P.h }}>{P.n.split(" · ")[1]}</span></div>
        <div style={{ fontSize: 14, color: "#ffffffb0", marginTop: 4 }}>{hj.d} {hj.month} {hj.y} AH · moon {mo.phase}, {(mo.illum * 100).toFixed(0)}% · lunar day {ld.day}</div>
        {T.d !== WEEKDAYS[now.getDay()] && <div style={{ fontSize: 12.5, color: "#e8c96a", marginTop: 4 }}>Before sunrise the planetary day is still {T.d}'s.</div>}
        {night && <div style={{ fontSize: 12.5, color: "#ffffff88", marginTop: 4 }}>It is night — in the Islamic reckoning this night already belongs to {WEEKDAYS[(di + 1) % 7]}.</div>}
      </div>
      {curH && <div style={{ flex: "0 1 auto" }}>
        <div style={tLabel(PLANETS[curH.planet].h)}>hour {curH.i} · {curH.night ? "night" : "day"}</div>
        <div style={{ fontSize: 19, color: PLANETS[curH.planet].h }}>{PLANETS[curH.planet].g} {PLANETS[curH.planet].n}</div>
        <div style={{ fontFamily: F.mono, fontSize: 24, color: "#f0ead9" }}>{cd}</div>
        <div style={{ fontFamily: F.mono, fontSize: 10.5, color: "#ffffff77" }}>left · until {fmt(curH.end)}</div>
      </div>}
      <div style={{ display: "flex", flexDirection: "column", gap: 6, flex: "0 1 auto" }}>
        <span style={{ fontFamily: F.mono, fontSize: 11, padding: "4px 9px", borderRadius: 12, textAlign: "center",
          color: manhus ? "#12100a" : "#8fce7f", background: manhus ? "#e86a52" : "transparent", border: `1px solid ${manhus ? "#e86a52" : "#8fce7f77"}` }}>
          {manhus ? "inauspicious day · p.43" : "not an inauspicious day"}</span>
        <span style={{ fontFamily: F.mono, fontSize: 11, padding: "4px 9px", borderRadius: 12, textAlign: "center", color: ld.waxing ? "#e8c96a" : "#9aa6b8", border: "1px solid #ffffff22" }}>
          {ld.waxing ? "moon waxing · for good work" : "moon waning"}</span>
        <Btn hue={hue} small onClick={sheet}>download today's sheet</Btn>
      </div>
    </div>
    {!loc && <div style={{ fontSize: 13, color: "#e8a25c", marginTop: 8 }}>No location set — hours run on a fixed six and six, and prayer times and qibla are hidden.{" "}
      <Btn hue="#e8a25c" small onClick={() => go("majlis")}>set it in Majlis</Btn></div>}

    {/* ── the day ── */}
    <TSection id="day" title="The day" sub={`p.115 · p.1787 · ch.20 pp.${W.pp[0]}–${W.pp[1]}`} hue={hue}>
      <div style={tGrid}>
        <div style={tCard(hue, true)}>
          <div style={tLabel(hue)}>The day's name · table of the days</div>
          <div dir="rtl" style={{ fontFamily: F.ar, fontSize: 38, color: "#f0ead9", marginTop: 4 }}>{T.name} <span style={{ fontSize: 24, color: hue }}>{T.letter}</span></div>
          <div style={{ fontSize: 14, color: "#ffffffbb" }}>{T.nameTr} · <b>{abjad(T.name)}</b> · the day's letter {T.letter} ({abjad(T.letter)})</div>
          <div style={{ fontSize: 14, color: "#ffffffaa", marginTop: 6 }}>angel <span dir="rtl" style={{ fontFamily: F.ar, fontSize: 19 }}>{T.angel}</span> {T.angelTr}</div>
          <div style={{ fontSize: 14, color: "#ffffffaa" }}>colour {T.colour} · incense {T.incense}</div>
          <div style={{ marginTop: 6 }}><Cite page={115} hue={hue} /></div>
        </div>
        <div style={tCard(hue)}>
          <div style={tLabel(hue)}>The day's verse of the Fātiḥa</div>
          <div dir="rtl" style={{ fontFamily: F.ar, fontSize: 26, color: "#f0ead9", marginTop: 6, lineHeight: 1.6 }}>{T.fatiha}</div>
          <div style={{ fontSize: 13, color: "#ffffff88" }}>Q {W.fatihaRef} · {abjad(T.fatiha)} · <Cite page={1787} hue={hue} /></div>
        </div>
        <div style={tCard(hue)}>
          <div style={tLabel(hue)}>The day's portion of Yā-Sīn · ch.20</div>
          <div style={{ fontSize: 22, color: "#f0ead9", marginTop: 6 }}>Q {W.yasin}</div>
          <div style={{ fontSize: 13.5, color: "#ffffffaa" }}>then Q 36:82–83 to close, as every day</div>
          <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginTop: 8 }}>
            <Btn hue={hue} small onClick={() => go("kitab", { chapter: 20, page: W.pp[0], view: "read" })}>read the wird · pp.{W.pp[0]}–{W.pp[1]}</Btn></div>
        </div>
      </div>
      <div style={{ ...tCard(hue), marginTop: 10 }}>
        <div style={tLabel(hue)}>The names the day's wird calls</div>
        <div style={{ display: "flex", flexWrap: "wrap", gap: 8, marginTop: 8 }}>
          {W.names.map(([tr, ar], i) => <span key={i} style={{ border: `1px solid ${hue}44`, borderRadius: 3, padding: "5px 10px", fontSize: 14, color: "#f0ead9" }}>
            {ar && <span dir="rtl" style={{ fontFamily: F.ar, fontSize: 19, marginRight: 6 }}>{ar}</span>}{tr}{ar && <span style={{ fontFamily: F.mono, fontSize: 11, color: hue, marginLeft: 6 }}>{abjad(ar)}</span>}</span>)}
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(min(100%,200px),1fr))", gap: "6px 18px", marginTop: 12, fontSize: 14, color: "#ffffffb0" }}>
          <div><span style={tLabel(hue)}>angel </span> <span dir="rtl" style={{ fontFamily: F.ar, fontSize: 18 }}>{W.angelAr}</span> {W.angel}
            {W.printed && <span style={{ fontSize: 12, color: "#8fce7f" }}> · corrected (printed {W.printed})</span>}</div>
          <div><span style={tLabel(hue)}>king </span> <span dir="rtl" style={{ fontFamily: F.ar, fontSize: 18 }}>{W.kingAr}</span> {W.king}
            {W.kingAlt && <span style={{ fontSize: 12, color: "#ffffff77" }}> · also named {W.kingAlt} ({W.kingAltPp.map(x => "p." + x).join(", ")})</span>}</div>
          <div><span style={tLabel(hue)}>ruler named </span> {W.group || <i style={{ color: "#ffffff66" }}>not named in the text</i>}</div>
          <div><span style={tLabel(hue)}>tahṭīl </span> <span dir="rtl" style={{ fontFamily: F.ar, fontSize: 18 }}>{W.tahtilAr}</span> {W.tahtil}
            {W.printedTahtil && <span style={{ fontSize: 12, color: "#8fce7f" }}> · corrected (printed {W.printedTahtil})</span>}</div>
          <div><span style={tLabel(hue)}>sealing verse </span> Q {W.seal}</div>
          <div><span style={tLabel(hue)}>adjured </span> {W.adjured}{W.master ? ` · by ${W.master}` : ""}</div>
        </div>
        {W.printed && <div style={{ marginTop: 10, borderLeft: "2px solid #8fce7f88", paddingLeft: 10, fontSize: 13, color: "#ffffffa8", lineHeight: 1.6 }}>
            Correction: chapter 20 prints {W.printed}{W.printedTahtil ? ` and the tahṭīl ${W.printedTahtil}` : ""} for {T.d} (<Cite page={W.pp[0]} hue={hue} />). The book's own day tables give {W.angel}
            {W.printedTahtil ? ` and ${W.tahtil}` : ""} — <Cite page={115} hue={hue} /> <Cite page={584} hue={hue} /> <Cite page={821} hue={hue} /> <Cite page={921} hue={hue} />{" "}
            — as does the book's second copy of this litany in chapter 21, and they pair {W.angel} with this same king, {W.king.split(" (")[0].split(",")[0]}.
            The reading text of chapter 20 now carries the correction; logged in Taṣḥīḥāt.</div>}
        <div style={{ marginTop: 10, fontSize: 12.5, color: "#ffffff77" }}>The prologue's conditions (pp.40–46), and above all the licence (p.42), come before any of it.</div>
      </div>
    </TSection>

    {/* ── the hours ── */}
    <TSection id="hours" title="The hours" sub={`pp.115–117 · ★ the day's own planet (${ruler})`} hue={hue}>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(min(100%,118px),1fr))", gap: 5 }}>
        {(hours || []).map(x => { const p = PLANETS[x.planet], on = curH && x.i === curH.i, sel = showH && x.i === showH.i, past = x.end <= now;
          return <button key={x.i} onClick={() => setSelH(x.i === selH ? null : x.i)} aria-pressed={sel}
            style={{ textAlign: "left", cursor: "pointer", color: "inherit", border: `1px solid ${on ? p.h : sel ? p.h + "99" : p.h + "33"}`,
              background: on ? p.h + "2a" : sel ? p.h + "14" : "#00000044", padding: "6px 8px", borderRadius: 2, opacity: past && !sel ? 0.45 : x.night ? 0.8 : 1 }}>
            <div style={{ fontFamily: F.mono, fontSize: 10, color: p.h + "cc" }}>{x.night ? "☽" : "☀"} {x.i} · {fmt(x.start)}</div>
            <div style={{ fontSize: 13.5, color: on ? p.h : "#ece6d8" }}>{p.g} {x.planet}{x.planet === ruler ? " ★" : ""}{HOUR_BOOK[x.planet].el ? <span style={{ fontSize: 10.5, color: ELCOL[HOUR_BOOK[x.planet].el] }}> · {HOUR_BOOK[x.planet].el}</span> : null}</div>
          </button>; })}
      </div>
      {nextRuler && <div style={{ fontSize: 13, color: "#ffffff99", marginTop: 8 }}>Next hour of the day's own planet: {fmt(nextRuler.start)}–{fmt(nextRuler.end)} ({nextRuler.night ? "night" : "day"} hour {nextRuler.i}).</div>}
      {showH && (() => { const hb = HOUR_BOOK[showH.planet], p = PLANETS[showH.planet], op = Object.entries(ORDER_PLANET).find(([, a]) => a.planet === showH.planet);
        return <div style={{ ...tCard(p.h, true), marginTop: 10 }}>
          <div style={tLabel(p.h)}>{showH === curH ? "this hour" : `hour ${showH.i}`} · {fmt(showH.start)}–{fmt(showH.end)} · what the book gives it</div>
          <div style={{ fontSize: 20, color: p.h, marginTop: 4 }}>{p.g} {p.n}</div>
          {hb.el && <div style={{ fontSize: 14, color: "#ffffffbb", marginTop: 4 }}>Workings tied to <b style={{ color: ELCOL[hb.el] }}>{ELNAME[hb.el]}</b> are done in this hour (<Cite page={115} hue={p.h} />).</div>}
          <div style={{ fontSize: 14, color: "#ffffffbb", marginTop: 6, lineHeight: 1.6 }}>
            {hb.open.length ? <>Suited to: {hb.open.join(" · ")}.</> : <>The book assigns nothing to this hour beyond harm-directed work — a time to keep to dhikr.</>} <Cite page={116} hue={p.h} /></div>
          {hb.named.length > 0 && <div style={{ fontSize: 12.5, color: "#ffffff66", marginTop: 4 }}>Also assigned, harm-directed and named only: {hb.named.join(", ")}.</div>}
          {op && <div style={{ display: "flex", gap: 6, flexWrap: "wrap", alignItems: "center", marginTop: 8 }}>
            <span style={{ fontSize: 13.5, color: "#ffffffaa" }}>Its square: the {op[0]}×{op[0]}</span><Cite page={op[1].page} hue={p.h} />
            <Btn hue={p.h} small onClick={() => go("forge", { order: +op[0] })}>open in the Forge</Btn></div>}
          {showH === curH && workHour.length > 0 && <div style={{ marginTop: 10 }}>
            <div style={tLabel(p.h)}>workings the book sets in this planet's hour · {workHour.length}</div>
            <div style={{ display: "grid", gap: 6, marginTop: 6 }}>{workHour.slice(0, 6).map(w => <WorkCard key={w.id} w={w} go={go} />)}</div></div>}
        </div>; })()}
      {loc && PT && !PT.polar && <div style={{ ...tGrid, marginTop: 10 }}>
        <div style={tCard(hue)}>
          <div style={tLabel(hue)}>Prayer times · {loc.label ? loc.label.split(" (")[0] : "your location"}</div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr auto", gap: "3px 14px", marginTop: 8, fontSize: 14.5 }}>
            {[["Fajr", PT.fajr], ["Sunrise", PT.sunrise], ["Ẓuhr", PT.dhuhr], ["ʿAṣr", PT.asr], ["Maghrib", PT.maghrib], ["ʿIshāʾ", PT.isha]].map(([k, v]) => {
              const nowH = now.getHours() + now.getMinutes() / 60;
              return <React.Fragment key={k}><span style={{ color: "#ffffffbb" }}>{k}</span>
                <span style={{ fontFamily: F.mono, color: v != null && Math.abs(v - nowH) < 0.5 ? hue : "#f0ead9" }}>{hoursToHM(v) || "—"}</span></React.Fragment>; })}
          </div>
          <div style={{ fontFamily: F.mono, fontSize: 10, color: "#ffffff66", marginTop: 6 }}>{PT.method} · computed, not the book's</div>
        </div>
        <div style={tCard(hue)}>
          <div style={tLabel(hue)}>Qibla · write facing it (p.44)</div>
          <div style={{ display: "flex", alignItems: "center", gap: 14, marginTop: 8 }}>
            <svg viewBox="-50 -50 100 100" width="92" height="92" aria-label={`qibla ${qb.toFixed(0)} degrees`}>
              <circle r="44" fill="none" stroke="#ffffff33" />
              {["N", "E", "S", "W"].map((c, i) => <text key={c} x={Math.sin(i * Math.PI / 2) * 36} y={-Math.cos(i * Math.PI / 2) * 36 + 4} textAnchor="middle" fontSize="10" fill="#ffffff77" fontFamily="monospace">{c}</text>)}
              <line x1="0" y1="0" x2={Math.sin(qb * RAD) * 40} y2={-Math.cos(qb * RAD) * 40} stroke={hue} strokeWidth="3" strokeLinecap="round" />
              <circle r="3" fill={hue} />
            </svg>
            <div><div style={{ fontFamily: F.mono, fontSize: 26, color: "#f0ead9" }}>{qb.toFixed(0)}°</div>
              <div style={{ fontSize: 13.5, color: "#ffffffaa" }}>{compass(qb)}, from true north</div></div>
          </div>
        </div>
      </div>}
    </TSection>

    {/* ── the moon ── */}
    <TSection id="moon" title="The moon" sub={`mansion ${M.n} · pp.214–245`} hue={hue}>
      <div style={tGrid}>
        <div style={tCard(hue)}>
          <div style={tLabel(hue)}>Phase</div>
          <div style={{ display: "flex", alignItems: "center", gap: 14, marginTop: 6 }}>
            <svg viewBox="-20 -20 40 40" width="56" height="56" aria-hidden="true">
              <circle r="18" fill="#1d1a14" stroke="#ffffff33" />
              <path d={(() => { const k = Math.cos(2 * Math.PI * mo.age / SYNODIC), rx = Math.abs(k) * 18, sw = mo.waxing ? 1 : 0;
                return `M0,-18 A18,18 0 0 ${sw} 0,18 A${rx},18 0 0 ${k > 0 ? 1 - sw : sw} 0,-18 Z`; })()} fill="#ece6d8" />
            </svg>
            <div><div style={{ fontSize: 17, color: "#f0ead9" }}>{mo.phase}</div>
              <div style={{ fontSize: 13.5, color: "#ffffffaa" }}>{(mo.illum * 100).toFixed(0)}% lit · {ld.waxing ? "waxing" : "waning"} · lunar day {ld.day}</div></div>
          </div>
          <div style={{ fontSize: 13, color: "#ffffff99", marginTop: 8, lineHeight: 1.6 }}>
            Beneficial work while the light increases; never on the 3rd, 5th, 13th, 16th, 21st, 24th or 25th of the lunar month. <Cite page={43} hue={hue} /></div>
          <div style={{ fontSize: 11.5, color: "#ffffff66", marginTop: 4 }}>The lunar day is counted from the astronomical new moon; a locally sighted month can run a day behind.</div>
        </div>
        {mz && <div style={tCard(hue, true)}>
          <div style={tLabel(hue)}>Mansion {mz.n} of 28 {mb && mb.omen ? `· ${mb.omen}` : ""}</div>
          <div style={{ fontSize: 20, color: "#f0ead9", marginTop: 4 }}><span dir="rtl" style={{ fontFamily: F.ar, fontSize: 24 }}>{mz.ar}</span> {mz.tr}</div>
          <div style={{ fontSize: 13.5, color: "#ffffffaa" }}>letter {mz.letter} ({mz.element}, p.76) · {mz.sign}</div>
          {CH3[mz.n] && <div style={{ fontSize: 13.5, color: "#ffffffaa" }}>chapter 3: {CH3[mz.n][0] !== "—" ? `a ${CH3[mz.n][0]} star, ` : ""}{CH3[mz.n][1]}</div>}
          {OMEN_CLASH[mz.n] && <div style={{ fontSize: 12.5, color: "#e8b84f", marginTop: 4 }}>Remark: {OMEN_CLASH[mz.n]}.</div>}
          <div style={{ fontSize: 13.5, color: "#ffffffaa", marginTop: 4 }}>moves on in about {Math.round(M.hoursToNext)} h — {new Date(now.getTime() + M.hoursToNext * 36e5).toLocaleString([], { weekday: "short", hour: "2-digit", minute: "2-digit" })}</div>
          <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginTop: 8 }}><Btn hue={hue} small onClick={() => go("manazil")}>the mansions</Btn></div>
        </div>}
      </div>
      {mb && mb.judge && <div style={{ ...tCard(hue), marginTop: 10 }}>
        <div style={tLabel(hue)}>The book's judgement of this mansion · <Cite page={mb.judge.p} hue={hue} /></div>
        <div style={{ fontSize: 15, color: "#ffffffc0", lineHeight: 1.75, marginTop: 6, maxWidth: 760 }}>
          {judgeOpen || mb.judge.t.length < 420 ? mb.judge.t : mb.judge.t.slice(0, 400).replace(/\s\S*$/, "") + "…"}</div>
        {mb.judge.t.length >= 420 && <button onClick={() => setJudgeOpen(o => !o)} style={{ background: "none", border: "none", color: hue, cursor: "pointer", fontFamily: F.mono, fontSize: 11, padding: 0, marginTop: 4 }}>{judgeOpen ? "less" : "read all"}</button>}
        {mb.rising && <div style={{ fontSize: 12.5, color: "#ffffff77", marginTop: 6 }}>{mb.rising}</div>}
      </div>}
    </TSection>

    {/* ── workings set on this day ── */}
    <TSection id="works" title={`Set on ${T.d}`} sub={`${workToday.length} open workings whose page names this day`} hue={hue} open={false}>
      {workToday.length ? <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(min(100%,300px),1fr))", gap: 8 }}>
        {workToday.map(w => <WorkCard key={w.id} w={w} go={go} />)}</div>
        : <div style={{ fontSize: 13.5, color: "#ffffff88" }}>No open working in the book names {T.d}.</div>}
    </TSection>

    {/* ── practice ── */}
    <TSection id="practice" title="Practice" sub="kept on this device, by date" hue={hue}>
      <div style={tGrid}>
        <div style={tCard(hue, true)}>
          <div style={tLabel(hue)}>Count a name by its number</div>
          <select value={cName} onChange={e => setCName(+e.target.value)} aria-label="Name to count"
            style={{ ...inputBase, marginTop: 8, width: "100%", fontSize: 14 }}>
            {counterNames.map((n, i) => <option key={i} value={i}>{n[0]} · {n[1]} · {abjad(n[1])}</option>)}</select>
          <div style={{ display: "flex", alignItems: "center", gap: 16, marginTop: 12, flexWrap: "wrap" }}>
            <button onClick={() => bump(1)} aria-label="Count one" style={{ width: 128, height: 128, borderRadius: "50%", border: `2px solid ${hue}`,
              background: `radial-gradient(circle at 50% 40%, ${hue}26, transparent 70%)`, color: "#f0ead9", cursor: "pointer", touchAction: "manipulation" }}>
              <div dir="rtl" style={{ fontFamily: F.ar, fontSize: 18, color: hue }}>{cN[1]}</div>
              <div style={{ fontFamily: F.mono, fontSize: 32 }}>{count}</div></button>
            <div style={{ minWidth: 120, flex: 1 }}>
              <div style={{ height: 7, background: "#ffffff14", borderRadius: 4, overflow: "hidden" }}><div style={{ width: Math.min(100, 100 * count / cTarget) + "%", height: "100%", background: count >= cTarget ? "#8fce7f" : hue }} /></div>
              <div style={{ fontFamily: F.mono, fontSize: 12, color: count >= cTarget ? "#8fce7f" : "#ffffff99", marginTop: 6 }}>{count} of {cTarget}{count >= cTarget ? " · complete" : ` · ${cTarget - count} left`}</div>
              <div style={{ display: "flex", gap: 5, marginTop: 8, flexWrap: "wrap" }}>
                <Btn hue={hue} small onClick={() => bump(-1)}>back one</Btn>
                <Btn hue={hue} small onClick={() => { setCount(0); LS.set(cKey, 0); }}>reset</Btn></div>
            </div>
          </div>
          <div style={{ fontSize: 12, color: "#ffffff77", marginTop: 8 }}>The target is the name's abjad number, recomputed from its letters — the book recites a name "according to its complete number" (<Cite page={2111} hue={hue} />).</div>
        </div>
        <div style={tCard(hue)}>
          <div style={tLabel(hue)}>Today's checklist · {nDone}/{allChecks.length}</div>
          <div style={{ display: "grid", gap: 4, marginTop: 8 }}>
            {allChecks.map(c => <label key={c.k} style={{ display: "flex", gap: 9, alignItems: "flex-start", fontSize: 14, color: checked[c.k] ? "#ffffff77" : "#f0ead9", cursor: "pointer", lineHeight: 1.45 }}>
              <input type="checkbox" checked={!!checked[c.k]} onChange={() => tick(c.k)} style={{ marginTop: 3, accentColor: hue }} />
              <span style={{ flex: 1, textDecoration: checked[c.k] ? "line-through" : "none" }}>{c.t}</span>
              {c.p ? <Cite page={c.p} hue={hue} /> : <button onClick={e => { e.preventDefault(); dropOwn(c.k); }} title="remove this item"
                style={{ background: "none", border: "none", color: "#ffffff55", cursor: "pointer", fontSize: 13 }}>✕</button>}
            </label>)}
          </div>
          <div style={{ display: "flex", gap: 6, marginTop: 8 }}>
            <input value={newItem} onChange={e => setNewItem(e.target.value)} onKeyDown={e => e.key === "Enter" && addOwn()} placeholder="add your own (e.g. ṣadaqa)"
              aria-label="Add your own checklist item" style={{ ...inputBase, flex: 1, minWidth: 0, fontSize: 14 }} />
            <Btn hue={hue} small onClick={addOwn}>add</Btn></div>
        </div>
      </div>
      <div style={{ ...tCard(hue), marginTop: 10 }}>
        <div style={tLabel(hue)}>Notes for {now.toLocaleDateString([], { weekday: "long", day: "numeric", month: "long" })}</div>
        <textarea value={note} onChange={e => { setNote(e.target.value); LS.set("today-note:" + dateKey, e.target.value); }} rows={4}
          placeholder="what you recited, what you wrote, what you saw…" aria-label="Notes for today"
          style={{ ...inputBase, width: "100%", marginTop: 8, fontFamily: F.body, fontSize: 15, lineHeight: 1.6, resize: "vertical" }} />
        {pastNotes.length > 0 && <details style={{ marginTop: 8 }}>
          <summary style={{ cursor: "pointer", fontFamily: F.mono, fontSize: 11, color: hue }}>earlier notes · {pastNotes.length}</summary>
          {pastNotes.map(([d, v]) => <div key={ymd(d)} style={{ marginTop: 8, fontSize: 13.5, color: "#ffffffaa", whiteSpace: "pre-wrap" }}>
            <div style={{ fontFamily: F.mono, fontSize: 10.5, color: "#ffffff77" }}>{d.toLocaleDateString([], { weekday: "short", day: "numeric", month: "short" })}</div>{v}</div>)}
        </details>}
      </div>
    </TSection>

    {/* ── the week ahead ── */}
    <TSection id="week" title="The week ahead" sub="each day at noon" hue={hue}>
      <div style={{ display: "grid", gap: 6 }}>
        {week.map((w, i) => { const t = DAY_TABLE[w.wd], p = PLANETS[t.planet];
          return <div key={i} style={{ display: "grid", gridTemplateColumns: "minmax(0,150px) minmax(0,1fr)", gap: 12, border: `1px solid ${i === 0 ? p.h : p.h + "33"}`, background: i === 0 ? p.h + "10" : "#00000033", padding: "8px 11px", borderRadius: 3 }} className="week-row">
            <div>
              <div style={{ fontSize: 15, color: p.h }}>{p.g} {i === 0 ? "Today" : i === 1 ? "Tomorrow" : WEEKDAYS[w.wd]}</div>
              <div style={{ fontFamily: F.mono, fontSize: 10.5, color: "#ffffff77" }}>{w.d.toLocaleDateString([], { month: "short", day: "numeric" })} · {w.h.d} {w.h.month}</div>
            </div>
            <div style={{ minWidth: 0 }}>
              <div style={{ fontSize: 13.5, color: "#ffffffbb" }}>
                <span dir="rtl" style={{ fontFamily: F.ar, fontSize: 17 }}>{t.name}</span> {t.nameTr} ({abjad(t.name)}) · Yā-Sīn {CH20[w.wd].yasin}
                {" · "}lunar day {w.l.day} · mansion {w.m.n}{w.mzz ? ` ${w.mzz.tr}` : ""}{w.omen ? ` (${OMEN_CLASH[w.m.n] ? "table and ch.3 disagree" : w.omen})` : ""}{w.works ? ` · ${w.works} workings name this day` : ""}</div>
              {w.flags.length > 0 && <div style={{ display: "flex", flexWrap: "wrap", gap: 4, marginTop: 4 }}>
                {w.flags.map(([f, c], j) => <span key={j} style={{ fontFamily: F.mono, fontSize: 10.5, color: c, border: `1px solid ${c}66`, padding: "1px 7px", borderRadius: 10 }}>{f}</span>)}</div>}
            </div>
          </div>; })}
      </div>
      <div style={{ fontSize: 11.5, color: "#ffffff66", marginTop: 6 }}>Sunna fasts are the tradition, not this book; everything else is cited.</div>
    </TSection>

    {/* ── your reading ── */}
    <TSection id="reading" title="Your reading" sub={`${visited.length} of 2,401 pages opened`} hue={hue} open={false}>
      <div style={{ display: "grid", gap: 4 }}>
        {BOOK.chapters.map(c => { const n = visited.filter(p => p >= c.from && p <= c.to).length, tot = c.to - c.from + 1;
          return <button key={c.ch} onClick={() => go("kitab", { chapter: c.ch, view: "read", page: c.from })}
            style={{ display: "grid", gridTemplateColumns: "minmax(0,170px) 1fr 70px", gap: 10, alignItems: "center", background: "none", border: "none", color: "inherit", cursor: "pointer", textAlign: "left", padding: "2px 0" }}>
            <span style={{ fontSize: 12.5, color: "#ffffffaa" }}>{CHNAME(c.ch)}</span>
            <span style={{ height: 5, background: "#ffffff14", borderRadius: 3, overflow: "hidden" }}><span style={{ display: "block", height: "100%", width: (100 * n / tot) + "%", background: hue }} /></span>
            <span style={{ fontFamily: F.mono, fontSize: 10.5, color: "#ffffff77" }}>{n}/{tot}</span></button>; })}
      </div>
    </TSection>
  </div>;
}

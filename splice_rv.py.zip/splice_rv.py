"""Splice data/review_verify.json into src/engine.jsx as REVIEW_VERIFY."""
import json, re
s = open("src/engine.jsx", encoding="utf-8").read()
js = "/*@RV*/const REVIEW_VERIFY = " + json.dumps(json.load(open("data/review_verify.json", encoding="utf-8")), ensure_ascii=False, separators=(",", ":")) + ";/*@RVEND*/"
s = re.sub(r"/\*@RV\*/.*?/\*@RVEND\*/", lambda m: js, s, flags=re.S)
open("src/engine.jsx", "w", encoding="utf-8").write(s)

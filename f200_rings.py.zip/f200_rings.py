# Circles re-set: the book's own texts typeset in their rings; signs and letters that are not text carried from the print.
KURSI = "الله لا اله الا هو الحي القيوم لا تاخذه سنة ولا نوم له ما في السموات وما في الارض من ذا الذي يشفع عنده الا باذنه يعلم ما بين ايديهم وما خلفهم ولا يحيطون بشيء من علمه الا بما شاء وسع كرسيه السموات والارض ولا يؤوده حفظهما وهو العلي العظيم"
FATH29 = "محمد رسول الله والذين معه اشداء على الكفار رحماء بينهم تراهم ركعا سجدا يبتغون فضلا من الله ورضوانا سيماهم في وجوههم من اثر السجود ذلك مثلهم في التوراة ومثلهم في الانجيل كزرع اخرج شطاه فازره فاستغلظ فاستوى على سوقه يعجب الزراع ليغيظ بهم الكفار وعد الله الذين امنوا وعملوا الصالحات منهم مغفرة واجرا عظيما"
import math

# ── #226 · p.1466 · the circle of the Basmala ──
tw, th = trace_dims(226); sc = 1000 / max(tw, th); CX, CY = 394, 386
def S(v): return v * sc
arm = []
for deg in (0, 90, 180, 270):
    a = math.radians(deg); mid = 205
    x, y = CX + mid * math.sin(a), CY - mid * math.cos(a); nx, ny = math.cos(a) * 26, math.sin(a) * 26
    arm += [dict(t="text", x=S(x - nx), y=S(y - ny), text="بسم الله الرحمن الرحيم", size=S(30), rot=(0 if deg == 270 else deg - 90), maxw=S(230), label=f"arm {deg}°"),
            dict(t="text", x=S(x + nx), y=S(y + ny), text="بسم الله الرحمن الرحيم", size=S(30), rot=(0 if deg == 270 else deg - 90), maxw=S(230), label=f"arm {deg}°")]
    arm.append(dict(t="line", pts=[[S(CX + 70 * math.sin(a)), S(CY - 70 * math.cos(a))], [S(CX + 330 * math.sin(a)), S(CY - 330 * math.cos(a))]], layer="frame"))
add(id="f226", fig=226, page=1466, title="The circle of the Basmala, for the bearer", group="seal", w=round(tw * sc), h=round(th * sc) + 90,
    desc="The Basmala's circle (p.1466), typeset: the Basmala along both sides of each arm of the cross, the bearer's name in the roundel at the centre, al-Fatḥ 48:29 round the outer ring and the book's prayer for the bearer in the inner ring. Fumigated with Indian aloeswood and carried — for dignity, honour and the love of those who see one.",
    slots=dict(person="فلان", prayer=""),
    els=[dict(t="circle", cx=S(CX), cy=S(CY), r=S(400)), dict(t="circle", cx=S(CX), cy=S(CY), r=S(372)),
         dict(t="ring", cx=S(CX), cy=S(CY), r=S(386), text=FATH29, size=S(19), fit="stretch", label="outer ring · al-Fatḥ 48:29"),
         dict(t="circle", cx=S(CX), cy=S(CY), r=S(344)),
         dict(t="ring", cx=S(CX), cy=S(CY), r=S(358), text="{prayer}", size=S(19), fit="stretch", label="inner ring · the prayer for the bearer"),
         *arm, dict(t="circle", cx=S(CX), cy=S(CY), r=S(62)), dict(t="text", x=S(CX), y=S(CY), text="{person}", size=S(34), maxw=S(100), label="the bearer")],
    how=["Draw the circle and the cross; write the Basmala along both sides of each arm.",
         "Write al-Fatḥ 48:29 round the outer ring.",
         "In the second circle write the prayer: that God guard the bearer from all that would harm him, draw to him the hearts of all creation, and set at his service the servants of this noble Name (p.1466).",
         "Write the bearer's name in the centre; fumigate with Indian aloeswood and carry it."],
    notes=["The book gives the inner prayer in translation only, so its ring is left for you to write in Arabic (type it in the ring's line below); the print's inner ring is partly worn."])

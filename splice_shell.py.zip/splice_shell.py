"""Replace the old TABS/GROUPS/App block of src/engine.jsx with tools/shell.jsx (idempotent), and wire book search to accept a query."""
import re, sys, os
root = os.path.join(os.path.dirname(__file__), "..")
src = os.path.join(root, "src", "engine.jsx"); shell = os.path.join(root, "tools", "shell.jsx")
s = open(src, encoding="utf-8").read(); sh = open(shell, encoding="utf-8").read()
mark = "/* ═══ v3.0 shell"
i = s.find(mark)
if i < 0: i = s.find("const TABS = [")
assert i > 0, "no TABS block found"
kh = "".join(open(os.path.join(root, "tools", f), encoding="utf-8").read() for f in ("khadim.jsx", "tilasm.jsx", "tilasm_ui.jsx"))
def once(s, a, b):
    return s if b in s else s.replace(a, b)
s = s[:i] + sh + kh
s = once(s, 'function SearchPane({ hue, go }) {\n  const [q, setQ] = useState("");', 'function SearchPane({ hue, go, initial }) {\n  const [q, setQ] = useState(initial || "");')
s = once(s, '{view === "search" && <SearchPane hue={hue} go={go} />}', '{view === "search" && <SearchPane hue={hue} go={go} initial={rquery} key={"sq" + rquery} />}')
s = once(s, 'if (job.kind === "layout" && job.L) return plotFromLayout(job.L, font, {});', 'if (job.kind === "layout" && job.L) return plotFromLayout(job.L, font, {});\n    if (job.kind === "geom" && job.G) return job.G;')
s = once(s, '{job.kind === "layout" ? job.title :', '{job.kind !== "figure" ? job.title :')
s = once(s, '<div style={{ marginTop: 12, textAlign: "center" }}><PlateView L={L} onHover={() => {}} /></div>',
  '{whole && <div style={{ marginTop: 12 }}><TilasmWhole figId={cur.id} grid={shown} hue={hue} go={go} stem={fileStem} title={cur.title} P0={{ name: forText, value: A }} fallback={<div style={{ textAlign: "center" }}><PlateView L={L} onHover={() => {}} /></div>} /></div>}\n            {!whole && <div style={{ marginTop: 12, textAlign: "center" }}><PlateView L={L} onHover={() => {}} /></div>}')
s = once(s, '<Btn hue={hue} small active={frame} onClick={() => setFrame(x => !x)}>{frame ? "frame on" : "frame off"}</Btn>\n            </div>',
  '<Btn hue={hue} small active={frame} onClick={() => setFrame(x => !x)}>{frame ? "frame on" : "frame off"}</Btn>\n              <Btn hue="#e8c96a" small active={whole} onClick={() => setWhole(w => !w)}>{whole ? "the whole figure, as printed round it" : "the square in the angels\' frame"}</Btn>\n            </div>')
s = once(s, 'const [showPrinted, setShowPrinted] = useState(false);\n  const canvasRef = useRef(null);', 'const [showPrinted, setShowPrinted] = useState(false);\n  const [whole, setWhole] = useState(() => LS.get("shaklWhole", true));\n  useEffect(() => { LS.set("shaklWhole", whole); }, [whole]);\n  const canvasRef = useRef(null);')
s = once(s, '<div style={{ marginTop: 10 }}><ImagePlate id={cur.id} sketch={!!cur.tal} above={aboveT} below={belowT} frame={frame} paper={paper} onReady={cv => (canvasRef.current = cv)} /></div>',
  '<div style={{ marginTop: 10 }}><ImagePlate id={cur.id} sketch={!!cur.tal} above={aboveT} below={belowT} frame={frame} paper={paper} onReady={cv => (canvasRef.current = cv)} /></div>\n          <div style={{ marginTop: 8 }}><Btn hue="#e8c96a" small onClick={() => go("studio", { id: "f" + cur.id })}>✦ compose it as vector in the Ṭilasm Studio</Btn></div>')
s = once(s, """        {l.ex.map((e, i) => e.seal""", """        {TL_LESSONS.has(l.n) && <button onClick={() => go("studio", { id: TL_LESSONS.get(l.n) })} style={{ textAlign: "left", border: `1px solid #e8c96a77`, background: "#e8c96a12", borderRadius: 3, padding: "8px 11px", cursor: "pointer", color: "inherit" }}>
              <div style={{ fontFamily: F.mono, fontSize: 11.5, color: "#e8c96a" }}>✦ Compose it whole</div><div style={{ fontSize: 13, color: "#f0ead9", marginTop: 2 }}>in the Ṭilasm Studio</div></button>}
        {l.ex.map((e, i) => e.seal""")
open(src, "w", encoding="utf-8").write(s)
print("shell spliced")

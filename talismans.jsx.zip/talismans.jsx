/* ═══ ṭalāsim — the talismans, seals and circles of the book, one by one, to read and to sketch ═══ */
const SKETCH_CACHE = {};
function loadSketch(k) {
  if (!SKETCH_CACHE[k]) SKETCH_CACHE[k] = fetch(`book/sketch_${k}.json`).then(r => { if (!r.ok) throw new Error(r.status); return r.json(); })
    .catch(e => { delete SKETCH_CACHE[k]; throw e; });
  return SKETCH_CACHE[k];
}
/** Line art on paper, with an optional squared grid to copy by — the way a drawing is enlarged by hand. */
function SketchSheet({ id, grid, gridN, paper, onReady }) {
  const ref = useRef(null);
  const [src, setSrc] = useState(null);
  useEffect(() => { let live = true; loadSketch(Math.floor(id / 100)).then(p => live && setSrc(p[String(id)] || "")).catch(() => live && setSrc("")); return () => { live = false; }; }, [id]);
  useEffect(() => {
    if (!src || !ref.current) return;
    const img = new Image();
    img.onload = () => {
      const cv = ref.current, W = img.width, H = img.height, m = Math.round(Math.max(W, H) * 0.04);
      cv.width = W + 2 * m; cv.height = H + 2 * m;
      const g = cv.getContext("2d");
      g.fillStyle = paper ? "#ffffff" : "#0d0b08"; g.fillRect(0, 0, cv.width, cv.height);
      if (!paper) g.filter = "invert(1)";
      g.drawImage(img, m, m); g.filter = "none";
      if (grid) {
        const step = Math.max(W, H) / gridN;
        g.strokeStyle = paper ? "rgba(200,60,40,0.55)" : "rgba(232,201,106,0.5)"; g.lineWidth = Math.max(1, W / 900);
        g.font = `${Math.round(step * 0.22)}px monospace`; g.fillStyle = g.strokeStyle;
        for (let i = 0, x = m; x <= m + W + 0.5; i++, x += step) { g.beginPath(); g.moveTo(x, m); g.lineTo(x, m + H); g.stroke(); if (i < gridN) g.fillText(String.fromCharCode(65 + i), x + 3, m - 4); }
        for (let i = 0, y = m; y <= m + H + 0.5; i++, y += step) { g.beginPath(); g.moveTo(m, y); g.lineTo(m + W, y); g.stroke(); if (y < m + H) g.fillText(String(i + 1), 2, y + step * 0.5); }
      }
      onReady && onReady(cv);
    };
    img.src = src;
  }, [src, grid, gridN, paper]);
  if (src === null) return <div style={{ fontFamily: F.mono, fontSize: 11, color: "#ffffff66", padding: 10 }}>preparing the tracing…</div>;
  if (!src) return <div style={{ color: "#ffffff77", fontSize: 13 }}>No tracing for this figure.</div>;
  return <canvas ref={ref} style={{ width: "100%", height: "auto", display: "block", borderRadius: 3, border: "1px solid #ffffff22" }} />;
}

function Talismans({ hue, go }) {
  const T = BOOK.talismans || [];
  const [q, setQ] = useState("");
  const [ch, setCh] = useState("all");
  const [sel, setSel] = useState(null);
  const [mode, setMode] = useState("clear");
  const [grid, setGrid] = useState(true);
  const [gridN, setGridN] = useState(8);
  const [paper, setPaper] = useState(true);
  const [notes, setNotes] = useState(() => LS.get("talismanNotes", {}));
  const canvasRef = useRef(null);
  const list = T.filter(t => (ch === "all" || t.ch === +ch) && (!q || fold(t.title + " " + t.note + " " + t.text.join(" ")).includes(fold(q)) || String(t.page) === q.trim()));
  const cur = sel != null ? T.find(t => t.id === sel) : null;
  const idx = cur ? list.findIndex(t => t.id === cur.id) : -1;
  const saveNote = (v) => setNotes(n => { const x = { ...n, [cur.id]: v }; LS.set("talismanNotes", x); return x; });
  const downloadSheet = () => { const cv = canvasRef.current; if (!cv) return;
    cv.toBlob(b => b && saveBlob(`talisman-${cur.id}-p${cur.page}${grid ? "-grid" : ""}.png`, b), "image/png"); };
  return <div>
    <H2 hue={hue} sub="the talismans, seals, circles and tables of the book — each with its page, its words, a clear image and a tracing to sketch from">Ṭalāsim</H2>
    <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "flex-end" }}>
      <Field hue={hue} label="SEARCH"><input value={q} onChange={e => setQ(e.target.value)} placeholder="seal, circle, sorcery, a page…" style={{ ...inputBase, width: "min(320px,80vw)" }} /></Field>
      <select value={ch} onChange={e => setCh(e.target.value)} style={{ ...inputBase, padding: "6px 8px", fontSize: 12.5 }}>
        <option value="all">all chapters</option>
        {BOOK.chapters.filter(c => T.some(t => t.ch === c.ch)).map(c => <option key={c.ch} value={c.ch}>{CHNAME(c.ch)} · {T.filter(t => t.ch === c.ch).length}</option>)}</select>
      <span style={{ fontFamily: F.mono, fontSize: 11, color: "#ffffff88" }}>{list.length} of {T.length}</span>
    </div>
    <div style={{ display: "grid", gridTemplateColumns: cur ? "minmax(0,330px) minmax(0,1fr)" : "1fr", gap: 18, marginTop: 14 }} className="kitab-grid">
      <div style={{ maxHeight: cur ? "80vh" : "none", overflowY: cur ? "auto" : "visible" }}>
        <table style={{ borderCollapse: "collapse", width: "100%", fontSize: 13.5 }}>
          <thead><tr style={{ color: hue, fontFamily: F.mono, fontSize: 10.5, textAlign: "left" }}>
            {["#", "TALISMAN", "PAGE"].map(h => <th key={h} style={{ padding: "6px 10px 6px 0", borderBottom: `1px solid ${hue}44`, fontWeight: 400 }}>{h}</th>)}</tr></thead>
          <tbody>{list.map((t, i) => <tr key={t.id} onClick={() => setSel(t.id)} style={{ cursor: "pointer", borderBottom: "1px solid #ffffff11", background: sel === t.id ? hue + "1e" : "transparent" }}>
            <td style={{ padding: "6px 10px 6px 0", fontFamily: F.mono, color: "#ffffff66", verticalAlign: "top" }}>{T.indexOf(t) + 1}</td>
            <td style={{ padding: "6px 10px 6px 0", color: "#f0ead9", verticalAlign: "top" }}>{t.title}
              {!cur && <div style={{ fontSize: 11.5, color: "#ffffff77", lineHeight: 1.45 }}>{t.note.slice(0, 160)}{t.note.length > 160 ? "…" : ""}</div>}</td>
            <td style={{ padding: "6px 0", fontFamily: F.mono, fontSize: 11, color: hue, whiteSpace: "nowrap", verticalAlign: "top" }}>p.{t.page}</td></tr>)}</tbody>
        </table>
      </div>
      {cur && <div style={{ minWidth: 0 }}>
        <div style={{ display: "flex", justifyContent: "space-between", gap: 8, flexWrap: "wrap", alignItems: "center" }}>
          <div><div style={{ fontFamily: F.mono, fontSize: 10.5, color: hue }}>Ṭalāsim {T.indexOf(cur) + 1} · figure #{cur.id} · {CHNAME(cur.ch)} · <Cite page={cur.page} hue={hue} /></div>
            <div style={{ fontFamily: F.disp, fontSize: 24, color: "#f0ead9", lineHeight: 1.25 }}>{cur.title}</div></div>
          <div style={{ display: "flex", gap: 5 }}>
            <Btn hue={hue} small disabled={idx <= 0} onClick={() => setSel(list[idx - 1].id)}>‹ prev</Btn>
            <Btn hue={hue} small disabled={idx < 0 || idx >= list.length - 1} onClick={() => setSel(list[idx + 1].id)}>next ›</Btn>
            <Btn hue={hue} small onClick={() => setSel(null)}>close</Btn></div>
        </div>
        <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginTop: 12, alignItems: "center" }}>
          <Btn hue={hue} small active={mode === "clear"} onClick={() => setMode("clear")}>clear image</Btn>
          <Btn hue={hue} small active={mode === "sketch"} onClick={() => setMode("sketch")}>tracing to sketch</Btn>
          {mode === "sketch" && <>
            <Btn hue={hue} small active={grid} onClick={() => setGrid(g => !g)}>{grid ? "copy grid on" : "copy grid off"}</Btn>
            {grid && [6, 8, 12].map(n => <Btn key={n} hue={hue} small active={gridN === n} onClick={() => setGridN(n)}>{n}×{n}</Btn>)}
            <Btn hue={hue} small active={paper} onClick={() => setPaper(p => !p)}>{paper ? "on paper" : "on dark"}</Btn>
            <Btn hue="#e8c96a" small onClick={downloadSheet}>download sheet</Btn></>}
        </div>
        <div style={{ marginTop: 10, background: mode === "clear" ? "#00000055" : "transparent", borderRadius: 3, padding: mode === "clear" ? 10 : 0 }}>
          {mode === "clear" ? <FigImage id={cur.id} alt={cur.note} style={{ maxHeight: "70vh" }} />
            : <SketchSheet id={cur.id} grid={grid} gridN={gridN} paper={paper} onReady={cv => (canvasRef.current = cv)} />}
        </div>
        {mode === "sketch" && <div style={{ fontSize: 12.5, color: "#ffffff88", lineHeight: 1.6, marginTop: 6 }}>
          The tracing is the printed figure reduced to clean line. With the grid on, draw the same grid lightly on your paper and copy one
          square at a time (A1, B1 …): the proportions stay true at any size.</div>}
        <div style={{ fontFamily: F.mono, fontSize: 10.5, letterSpacing: "0.12em", color: hue + "bb", marginTop: 16 }}>WHAT IT IS</div>
        <div style={{ fontSize: 14, color: "#ffffffb8", lineHeight: 1.7, marginTop: 4 }}>{cur.note}</div>
        {cur.text.length > 0 && <>
          <div style={{ fontFamily: F.mono, fontSize: 10.5, letterSpacing: "0.12em", color: hue + "bb", marginTop: 14 }}>THE BOOK'S WORDS WITH IT</div>
          {cur.text.map((t, i) => <p key={i} style={{ fontSize: 14.5, color: "#e9e3d4", lineHeight: 1.8, margin: "6px 0" }}>{withAnchors(t, q)}</p>)}</>}
        <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginTop: 10 }}>
          <Btn hue={hue} small onClick={() => go("kitab", { chapter: cur.ch, page: cur.page, view: "read" })}>read it in the book · p.{cur.page}</Btn>
        </div>
        <Field hue={hue} label="YOUR NOTES ON THIS TALISMAN (kept on this device)">
          <textarea rows={3} value={notes[cur.id] || ""} onChange={e => saveNote(e.target.value)}
            style={{ ...inputBase, width: "100%", boxSizing: "border-box", fontSize: 14, marginTop: 4 }} /></Field>
      </div>}
    </div>
  </div>;
}


// Iḥyāʾ Engine v1.4 — Chapter 19 constructors, read from the book's own pages.
// Grids here are written VISUALLY, as printed (left to right on the page).
// The engine stores rows right-to-left (column 0 on the right), so toStore() reverses each row.

export const toStore = (vis) => vis.map(r => r.slice().reverse());
export const toVisual = toStore;

/** The natural forms exactly as the book prints them (orders 3–9). */
export const BOOK_FORMS = {
  3: { page: 1702, anchor: "I 119", element: "earth",
       vis: [[4,9,2],[3,5,7],[8,1,6]] },
  4: { page: 1889, anchor: "I 244", element: "fire",
       vis: [[8,11,14,1],[13,2,7,12],[3,16,9,6],[10,5,4,15]] },
  5: { page: 1945, anchor: "I 273", element: null,
       vis: [[18,10,22,14,1],[12,4,16,8,25],[6,23,15,2,19],[5,17,9,21,13],[24,11,3,20,7]] },
  6: { page: 1995, anchor: "I 296", element: null,
       vis: [[24,30,36,1,7,13],[25,31,15,23,5,12],[18,10,2,33,28,20],
             [32,14,29,11,19,6],[3,22,8,27,17,34],[9,4,21,16,35,26]] },
  7: { page: 2005, anchor: "I 301", element: null,
       vis: [[26,30,20,38,14,46,1],[11,43,5,23,34,17,42],[31,21,39,8,47,2,27],
             [44,6,24,35,18,36,12],[15,40,9,48,3,28,32],[7,25,29,19,37,13,45],
             [41,10,49,4,22,33,16]] },
  8: { page: 2016, anchor: "I 308", element: null,
       vis: [[39,47,22,30,60,52,9,1],[55,63,6,14,44,36,25,17],[28,20,41,33,7,15,54,62],
             [12,4,57,49,23,31,38,46],[5,13,56,64,26,18,43,35],[21,29,40,48,10,2,59,51],
             [58,50,11,3,37,45,24,32],[42,34,27,19,53,61,8,16]] },
  // p.2026 prints 54 twice; r7c3 must be 59 (the only missing value) — logged as a correction.
  9: { page: 2026, anchor: "I 316", element: null, misprint: { r: 6, c: 2, printed: 54, correct: 59 },
       vis: [[37,78,29,70,21,62,13,54,5],[6,38,79,30,71,22,63,14,46],[47,7,39,80,31,72,23,55,15],
             [16,48,8,40,81,32,64,24,56],[57,17,49,9,41,73,33,65,25],[26,58,18,50,1,42,74,34,66],
             [67,27,59,10,51,2,43,75,35],[36,68,19,60,11,52,3,44,76],[77,28,69,20,61,12,53,4,45]] },
};

/** The book's own fourfold element forms (pp.1889–1892): earth = 180°, air = mirror L-R, water = mirror T-B. */
export const rot180 = (g) => g.slice().reverse().map(r => r.slice().reverse());
export const mirrorLR = (g) => g.map(r => r.slice().reverse());
export const mirrorTB = (g) => g.slice().reverse();
export const BOOK_ELEMENT_FORMS_4 = { fire: g => g, earth: rot180, air: mirrorLR, water: mirrorTB };

export function sums(g) {
  const n = g.length;
  const rows = g.map(r => r.reduce((a, b) => a + b, 0));
  const cols = g[0].map((_, c) => g.reduce((a, r) => a + r[c], 0));
  const d1 = g.reduce((a, r, i) => a + r[i], 0), d2 = g.reduce((a, r, i) => a + r[n - 1 - i], 0);
  const all = rows.concat(cols);
  const balanced = all.every(s => s === rows[0]);
  return { rows, cols, d1, d2, balanced, diagonals: balanced && d1 === rows[0] && d2 === rows[0], constant: balanced ? rows[0] : null };
}
/** Replace each cell (a value 1..n² = its "cell number") by f(k). */
export const mapCells = (vis, f) => vis.map(r => r.map(k => f(k)));

/* ── istinṭāq: a number resolved back into abjad letters ── */
const UNITS = ["", "ا","ب","ج","د","ه","و","ز","ح","ط"];
const TENS  = ["", "ي","ك","ل","م","ن","س","ع","ف","ص"];
const HUND  = ["", "ق","ر","ش","ت","ث","خ","ذ","ض","ظ"];
/** Letters in ascending place order (units first), thousands as غ followed by its multiplier.
 *  This is the order the book reads the ʿulwī names in: 5390 → ص ش غ ه (p.1906). */
export function istintaq(n) {
  if (!Number.isInteger(n) || n <= 0) return null;
  const out = [];
  const below = n % 1000, th = Math.floor(n / 1000);
  if (below % 10) out.push(UNITS[below % 10]);
  if (Math.floor(below / 10) % 10) out.push(TENS[Math.floor(below / 10) % 10]);
  if (Math.floor(below / 100)) out.push(HUND[Math.floor(below / 100)]);
  if (th) { out.push("غ"); if (th > 1) out.push(...istintaq(th)); }
  return out;
}

/* ── the eight stations (pp.1701, 1710–1711, 1904–1905) ── */
export function stations(n) {
  const cells = n * n, miftah = 1, mughlak = cells, adil = miftah + mughlak;
  const wafq = n * (cells + 1) / 2, mesahe = n * wafq, zabit = wafq + mesahe, ghaye = 2 * zabit, asil = ghaye * mughlak;
  return { miftah, mughlak, adil, wafq, mesahe, zabit, ghaye, asil };
}
export const AYIL = { ar: "ائيل", v: 51 };   // the book's value for "Ayil"
export const TISHIN = { ar: "طيش", v: 319 }; // the book's value for "Tishin"
/** ʿUlwī spirits of the bare n×n wafq: for each station, (asil + station − 51) → istinṭāq + Ayil.
 *  The suflī derivation (−319, read left to right) serves workings of harm by the book's own
 *  statement (p.1700, 1711) and is sealed: named and cited, not computed. */
export function ulwiSpirits(n) {
  const S = stations(n), out = [];
  for (const k of ["miftah","mughlak","adil","wafq","mesahe","zabit","ghaye"]) {
    const total = S.asil + S[k], rest = total - AYIL.v;
    const letters = istintaq(rest);
    out.push({ station: k, stationValue: S[k], total, rest, letters, name: letters.join("") + AYIL.ar });
  }
  return { stations: S, spirits: out };
}
/** The governing angel of a named wafq (p.1913): one row's total − 51 → istinṭāq + Ayil.
 *  Auxiliary (aʿwān) angels of a 4×4 (p.1912–1913): cells 1, 8, 10, 15 (fill order) − 42 → istinṭāq + Āil. */
export function governingAngel(rowTotal) {
  const rest = rowTotal - AYIL.v; const letters = istintaq(rest);
  return letters ? { rest, letters, name: letters.join("") + AYIL.ar } : null;
}
export function awanAngels4(cellValueByIndex) {
  return [1, 8, 10, 15].map(k => {
    const v = cellValueByIndex(k), rest = v - 42, letters = istintaq(rest);
    return { cell: k, value: v, rest, letters, name: letters ? letters.join("") + "ائل" : null };
  });
}

/* ── the constructors ── */
const sub = (n) => n * (n * n - 1) / 2;
/** General first rule for orders 3–9 (pp.1732, 1893, 1944, 1994, 2004, 2016, 2025):
 *  subtract n(n²−1)/2, divide by n; quotient in cell 1, +1 each cell; remainder r lifts cells from (n−r)·n+1. */
export function ruleFirst(A, n, vis = BOOK_FORMS[n].vis) {
  const d = A - sub(n);
  if (d < n) return { error: `below the ${n}×${n} floor (${sub(n) + n})` };
  const q = Math.floor(d / n), r = d % n, from = (n - r) * n + 1;
  const grid = mapCells(vis, k => q + k - 1 + (r && k >= from ? 1 : 0));
  return { grid, q, r, liftFrom: r ? from : null, rule: "first", page: BOOK_FORMS[n].page };
}
/** 3×3 second rule (p.1705–1708): the value itself in the centre; −1 down to cell 1, +1 up to cell 9. Constant 3A. */
export const three_second = (A) => ({ grid: mapCells(BOOK_FORMS[3].vis, k => A + (k - 5)), constant: 3 * A, page: 1705, centreIsName: true });
/** 3×3 second rule, the digit-sum variant (p.1708): step = digit sum; cell1 = A − 4·step; centre = A. */
export function three_secondDigits(A) {
  const s = String(A).split("").reduce((a, d) => a + +d, 0);
  return { grid: mapCells(BOOK_FORMS[3].vis, k => A + (k - 5) * s), step: s, constant: 3 * A, page: 1708 };
}
/** 3×3 third rule (p.1709–1710): cell k = k·A. Constant 15A. */
export const three_third = (A) => ({ grid: mapCells(BOOK_FORMS[3].vis, k => k * A), constant: 15 * A, page: 1709 });

/** Hollow-centre 3×3 (pp.1746–1751). Outer cells as printed; centre left for the ḥāja. */
export const HOLLOW3 = [[3,8,1],[7,0,5],[2,4,6]];
/** First rule: A ÷ 12 = q r; cell k = q·k, remainder added from cell 6. Each edge = A.
 *  The translation says "adding one more each time"; the printed figure (p.1750, 1177 → 98, 196 … 785)
 *  and the arithmetic both require adding the quotient. Logged as a correction. */
export function hollow3_first(A) {
  const q = Math.floor(A / 12), r = A % 12;
  if (q < 1) return { error: "needs at least 12" };
  return { grid: HOLLOW3.map(row => row.map(k => k ? q * k + (k >= 6 ? r : 0) : null)), q, r, page: 1748 };
}
/** Second rule: cells 1–5 keep 1–5; cell 6 = A − 6, then +1 to cell 8 (p.1749–1751, Serīʿ 370). */
export function hollow3_second(A) {
  if (A < 15) return { error: "needs at least 15" };
  return { grid: HOLLOW3.map(row => row.map(k => k ? (k <= 5 ? k : A - 6 + (k - 6)) : null)), page: 1749 };
}
export function hollowEdges(g) {
  const n = g.length, top = g[0], bot = g[n - 1], left = g.map(r => r[0]), right = g.map(r => r[n - 1]);
  return [top, right, bot, left].map(e => e.reduce((a, b) => a + (b || 0), 0));
}

/** 4×4 rules 2, 3, 5, 6 (pp.1895–1904). `seed` maps cell index → value for the letter-bearing cells. */
export function four_second(seed) { // seed: {1,8,11,14}
  const v = {}; const s = seed;
  for (let k = 1; k <= 4; k++) v[k] = s[1] + k - 1;
  for (let k = 5; k <= 8; k++) v[k] = s[8] - 3 + (k - 5);
  for (let k = 9; k <= 12; k++) v[k] = s[11] - 2 + (k - 9);
  for (let k = 13; k <= 16; k++) v[k] = s[14] - 1 + (k - 13);
  return { grid: mapCells(BOOK_FORMS[4].vis, k => v[k]), page: 1895 };
}
export function four_third(seed) { // seed: {1,7,10,16}
  const v = {}; const s = seed;
  for (let k = 1; k <= 4; k++) v[k] = s[1] + k - 1;
  for (let k = 5; k <= 8; k++) v[k] = s[7] + (k - 7);
  for (let k = 9; k <= 12; k++) v[k] = s[10] + (k - 10);
  for (let k = 13; k <= 16; k++) v[k] = s[16] + (k - 16);
  return { grid: mapCells(BOOK_FORMS[4].vis, k => v[k]), page: 1897 };
}
export function four_fifth(A) {
  const h = Math.floor(A / 2), r = A % 2, start = h - 8;
  if (start < 9) return { error: "too small for the fifth rule" };
  return { grid: mapCells(BOOK_FORMS[4].vis, k => k <= 8 ? k : start + (k - 9) + (r && k >= 13 ? 1 : 0)), page: 1902 };
}
export function four_sixth(A) {
  const s = A - 21;
  if (s < 13) return { error: "too small for the sixth rule" };
  return { grid: mapCells(BOOK_FORMS[4].vis, k => k <= 12 ? k : s + (k - 13)), page: 1903 };
}
/** 5×5 second rule (p.1947): seeds at cells 1, 7, 15, 18, 24. */
export function five_second(s) {
  const v = {};
  for (let k = 1; k <= 5; k++) v[k] = s[1] + k - 1;
  for (let k = 16; k <= 20; k++) v[k] = s[18] + (k - 18);
  for (let k = 6; k <= 10; k++) v[k] = s[7] + (k - 7);
  for (let k = 11; k <= 15; k++) v[k] = s[15] + (k - 15);
  for (let k = 21; k <= 25; k++) v[k] = s[24] + (k - 24);
  return { grid: mapCells(BOOK_FORMS[5].vis, k => v[k]), page: 1947 };
}
/** 5×5 third rule (p.1949): seeds at cells 1, 10, 14, 18, 22. */
export function five_third(s) {
  const v = {};
  for (let k = 1; k <= 5; k++) v[k] = s[1] + k - 1;
  for (let k = 11; k <= 15; k++) v[k] = s[14] + (k - 14);
  for (let k = 21; k <= 25; k++) v[k] = s[22] + (k - 22);
  for (let k = 6; k <= 10; k++) v[k] = s[10] + (k - 10);
  for (let k = 16; k <= 20; k++) v[k] = s[18] + (k - 18);
  return { grid: mapCells(BOOK_FORMS[5].vis, k => v[k]), page: 1949 };
}

/* ── the letter squares of the threefold (pp.1795–1872) ── */
const ABJ9 = ["", "ا","ب","ج","د","ه","و","ز","ح","ط"];
export const kamali = () => mapCells(BOOK_FORMS[3].vis, k => ABJ9[k]);          // all nine
export const mufradat = () => mapCells(BOOK_FORMS[3].vis, k => k % 2 ? ABJ9[k] : ""); // odd: ا ج ه ز ط
export const muzdawijat = () => mapCells(BOOK_FORMS[3].vis, k => k % 2 ? "" : ABJ9[k]); // even: ب د و ح — budūḥ
/** Letter square of a three-letter name (p.1745: Nūr, Salām): cells 1–3 first letter, 4–6 second, 7–9 third. */
export const harfi3 = (L) => mapCells(BOOK_FORMS[3].vis, k => L[Math.floor((k - 1) / 3)] || "");

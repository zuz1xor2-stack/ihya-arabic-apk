/* ═══ basṭ — the two expansions of the letters, pp.124–129 and 176–178 ═══ */
const BAST_UNITS = ["","احد","اثنين","ثلاثة","اربعة","خمسة","ستة","سبعة","ثمانية","تسعة"];
const BAST_TENS = ["","عشرة","عشرين","ثلاثين","اربعين","خمسين","ستين","سبعين","ثمانين","تسعين"];
const BAST_HUND = ["","مائة","مائتين","ثلاثمائة","اربعمائة","خمسمائة","ستمائة","سبعمائة","ثمانمائة","تسعمائة"];
/** A number spoken as the book speaks it: units, tens, hundreds, then thousands (الف, with its multiplier). */
function bastWords(n) {
  const out = [], th = Math.floor(n / 1000); n %= 1000;
  if (th) { if (th > 1) out.push(...bastWords(th)); out.push("الف"); }
  const h = Math.floor(n / 100), t = Math.floor((n % 100) / 10), u = n % 10;
  if (h) out.push(BAST_HUND[h]); if (t) out.push(BAST_TENS[t]); if (u) out.push(BAST_UNITS[u]);
  return out;
}
/** One step of the basṭ of letters: speak the number, total its letters, add their count (alif: أحد 13 + 3 = 16). */
function bastStep(n) { const w = bastWords(n); return w.reduce((a, x) => a + abjad(x) + [...x].length, 0); }
const BAST_LET = "ابجدهوزحطيكلمنسعفصقرشتثخذضظغ";
const BAST_CARRY = { "ء":"ا","أ":"ا","إ":"ا","آ":"ا","ٱ":"ا","ة":"ه","ى":"ي","ئ":"ي","ؤ":"و" };
/** Five basṭs of every letter by both methods. Letters: each from the last by bastStep. Numbers: each letter's
 *  next basṭ is the sum of the previous basṭ over the letters of its own number-word (pp.177–178). */
const BAST_TABLE = (() => {
  const first = {}; for (const ch of BAST_LET) first[ch] = bastStep(abjad(ch));
  const hur = {}; for (const ch of BAST_LET) { const c = [first[ch]]; for (let k = 1; k < 5; k++) c.push(bastStep(c[k - 1])); hur[ch] = c; }
  const num = [first];
  for (let k = 1; k < 5; k++) { const prev = num[k - 1], nx = {};
    for (const ch of BAST_LET) nx[ch] = [...bastWords(abjad(ch)).join("")].reduce((a, c) => a + prev[BAST_CARRY[c] || c], 0);
    num.push(nx); }
  const adad = {}; for (const ch of BAST_LET) adad[ch] = num.map(m => m[ch]);
  return { first, hur, adad };
})();
const bastLetters = (s) => [...normalize(s)].map(c => BAST_CARRY[c] || c).filter(c => BAST_LET.includes(c));
const bastFirst = (s) => bastLetters(s).reduce((a, c) => a + BAST_TABLE.first[c], 0);
const BAST_GROUPS = { fire: "اهطمفشذ", earth: "بوينصتض", air: "جزكسقثظ", water: "دحلعرخغ" };
const BAST_DAYWORD = ["الاحد","الاثنين","الثلاثاء","الاربعاء","الخميس","الجمعة","السبت"];
const BAST_PLANETWORD = { saturn:"الزحل", jupiter:"المشتري", mars:"المريخ", sun:"الشمس", venus:"الزهرة", mercury:"العطارد", moon:"القمر" };
const BAST_NEED = { jalb:["جلب","attraction"], tard:["طرد","repulsion"], sihha:["الصحت","health"], saqam:["السقم","sickness"] };

function BastCalc({ hue, cur, ruler, now }) {
  const [talib, setTalib] = useState("حسن");
  const [matlub, setMatlub] = useState("");
  const [need, setNeed] = useState("jalb");
  const [good, setGood] = useState(true);
  const [night, setNight] = useState(cur ? cur.night : false);
  const [method, setMethod] = useState("hur");
  const [show, setShow] = useState("ا");
  const names = talib + " " + matlub;
  const cnt = { fire: 0, earth: 0, air: 0, water: 0 };
  for (const c of bastLetters(names)) for (const [k, v] of Object.entries(BAST_GROUPS)) if (v.includes(c)) cnt[k]++;
  // p.131: if no element predominates by count, take the element of the letter whose first basṭ is greatest (Ḥasan → ن 765 → earth)
  const maxN = Math.max(...Object.values(cnt));
  const tied = Object.keys(cnt).filter(k => cnt[k] === maxN && maxN > 0);
  let domK = tied[0];
  if (tied.length > 1) { const top = bastLetters(names).filter(c => tied.some(k => BAST_GROUPS[k].includes(c)))
      .sort((a, b) => BAST_TABLE.first[b] - BAST_TABLE.first[a])[0];
    domK = tied.find(k => BAST_GROUPS[k].includes(top)); }
  const dom = [domK, maxN];
  const hourWord = cur ? BAST_PLANETWORD[cur.planet] : null;
  const rows = [
    [1, "the names of the ṭālib and the maṭlūb", names.trim(), bastFirst(names)],
    [2, `the letters of the predominant element — ${dom[1] ? dom[0] + (tied.length > 1 ? " (tie broken by the greatest first basṭ, p.131)" : "") : "—"}`, dom[1] ? BAST_GROUPS[dom[0]].split("").join(" ") : "", dom[1] ? bastFirst(BAST_GROUPS[dom[0]]) : 0],
    [3, night ? "night" : "day", night ? "الليل" : "النهار", bastFirst(night ? "الليل" : "النهار")],
    [4, `the hour — ${cur ? cur.planet : "—"} (spoken as its planet)`, hourWord || "", hourWord ? bastFirst(hourWord) : 0],
    [5, "the day", BAST_DAYWORD[now.getDay()], bastFirst(BAST_DAYWORD[now.getDay()])],
    [6, `the day's planet — ${ruler || "—"}`, BAST_PLANETWORD[ruler] || "", BAST_PLANETWORD[ruler] ? bastFirst(BAST_PLANETWORD[ruler]) : 0],
    [7, `the need — ${BAST_NEED[need][1]}`, BAST_NEED[need][0], bastFirst(BAST_NEED[need][0])],
    [8, good ? "good" : "ill", good ? "الخير" : "الشر", bastFirst(good ? "الخير" : "الشر")],
  ];
  const total = rows.reduce((a, r) => a + r[3], 0);
  const spoken = istintaq(total);
  const chainOf = (ch) => (method === "hur" ? BAST_TABLE.hur : BAST_TABLE.adad)[ch];
  return <div style={{ marginTop: 22 }}>
    <div style={{ fontFamily: F.mono, fontSize: 10.5, letterSpacing: "0.12em", color: hue + "bb" }}>THE BASṬ, WORKED — pp.124–134 and 176–185</div>
    <div style={{ fontSize: 13.5, color: "#ffffff99", lineHeight: 1.7, maxWidth: 780, marginTop: 6 }}>
      Every letter's value is spoken as an Arabic number-word; the word's letters are totalled and their count added.
      That is the first basṭ (alif: أحد = 13, three letters, 16). The book gives two ways to continue — the basṭ of letters, which repeats the same step,
      and the basṭ of numbers, where each letter's next basṭ totals the last basṭ over the letters of its own number-word. Both are computed here for
      all twenty-eight letters and reproduce the book's tables (pp.127–128, 179–181, 1038), including its alif chains 16 · 1047 · 594 · 1641 · 991 and
      16 · 911 · 6137 · 31296 · 156119.</div>
    <div style={{ display: "flex", gap: 14, flexWrap: "wrap", alignItems: "flex-end", marginTop: 12 }}>
      <Field hue={hue} label="ṬĀLIB"><input dir="rtl" value={talib} onChange={e => setTalib(e.target.value)} style={{ ...inputBase, fontFamily: F.ar, fontSize: 20, width: 170 }} /></Field>
      <Field hue={hue} label="MAṬLŪB OR THING INTENDED"><input dir="rtl" value={matlub} onChange={e => setMatlub(e.target.value)} style={{ ...inputBase, fontFamily: F.ar, fontSize: 20, width: 170 }} /></Field>
      <div style={{ display: "flex", gap: 5, flexWrap: "wrap" }}>
        {Object.entries(BAST_NEED).map(([k, [, l]]) => <Btn key={k} hue={hue} small active={need === k} onClick={() => setNeed(k)}>{l}</Btn>)}
        <Btn hue={hue} small active={good} onClick={() => setGood(g => !g)}>{good ? "for good" : "for ill"}</Btn>
        <Btn hue={hue} small active={night} onClick={() => setNight(x => !x)}>{night ? "by night" : "by day"}</Btn>
      </div>
    </div>
    <div style={{ overflowX: "auto", marginTop: 12 }}>
      <table style={{ borderCollapse: "collapse", fontSize: 13.5, minWidth: 560 }}>
        <thead><tr>{["MĪZĀN", "WHAT IS UNFOLDED", "WORD", "FIRST BASṬ"].map(h => <th key={h} style={{ textAlign: "left", fontFamily: F.mono, fontSize: 10, color: hue + "bb", padding: "4px 12px 4px 0" }}>{h}</th>)}</tr></thead>
        <tbody>{rows.map(([n, l, w, v]) => <tr key={n} style={{ borderTop: "1px solid #ffffff12" }}>
          <td style={{ fontFamily: F.mono, color: hue, padding: "5px 12px 5px 0" }}>{n}</td>
          <td style={{ color: "#ffffffb0", padding: "5px 12px 5px 0" }}>{l}</td>
          <td dir="rtl" style={{ fontFamily: F.ar, fontSize: 18, color: "#ece6d8", padding: "5px 12px 5px 0" }}>{w}</td>
          <td style={{ fontFamily: F.mono, color: "#ece6d8" }}>{v}</td></tr>)}
          <tr style={{ borderTop: "1px solid #ffffff12" }}><td style={{ fontFamily: F.mono, color: hue, padding: "5px 12px 5px 0" }}>9</td>
            <td colSpan={3} style={{ color: "#ffffff88", padding: "5px 0", fontSize: 12.5 }}>the degree of the element suited to the working — chosen by the practitioner from the degrees below, and unfolded the same way; not added here.</td></tr>
        </tbody>
      </table>
    </div>
    <div style={{ marginTop: 10, fontSize: 15, color: "#ece6d8" }}>
      Mīzān 1–8 total <b style={{ color: hue, fontSize: 22 }}>{total}</b>
      {spoken && <span> · istinṭāq <span dir="rtl" style={{ fontFamily: F.ar, fontSize: 22, color: hue }}>{spoken.join(" ")}</span></span>}
    </div>
    <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginTop: 16, alignItems: "center" }}>
      <span style={{ fontFamily: F.mono, fontSize: 10.5, color: hue + "bb" }}>FIVE BASṬS OF A LETTER</span>
      <Btn hue={hue} small active={method === "hur"} onClick={() => setMethod("hur")}>basṭ of letters</Btn>
      <Btn hue={hue} small active={method === "adad"} onClick={() => setMethod("adad")}>basṭ of numbers</Btn>
    </div>
    <div dir="rtl" style={{ display: "flex", flexWrap: "wrap", gap: 3, marginTop: 8 }}>
      {[...BAST_LET].map(ch => <button key={ch} onClick={() => setShow(ch)} style={{ width: 36, padding: "4px 0", fontFamily: F.ar, fontSize: 19, cursor: "pointer",
        background: show === ch ? hue + "22" : "transparent", border: `1px solid ${show === ch ? hue : "#ffffff22"}`, color: "#ece6d8", borderRadius: 2 }}>{ch}</button>)}
    </div>
    <div style={{ marginTop: 8, fontFamily: F.mono, fontSize: 13, color: "#ece6d8" }}>
      <span dir="rtl" style={{ fontFamily: F.ar, fontSize: 22, color: hue }}>{show}</span> = {abjad(show)} ·
      <span dir="rtl" style={{ fontFamily: F.ar, fontSize: 17 }}> {bastWords(abjad(show)).join(" ")} </span> ·{" "}
      {chainOf(show).map((v, k) => <span key={k}>{k ? " → " : ""}<b style={{ color: k === 0 ? hue : "#ece6d8" }}>{v}</b></span>)}
    </div>
  </div>;
}


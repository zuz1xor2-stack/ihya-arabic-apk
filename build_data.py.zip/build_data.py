"""Assemble the BOOK data block (outline, chapters, workings, figures) and splice it into the engine."""
import json, re, sys
H = json.load(open("headings.json"))
OUT = json.load(open("outline.json"))
W = json.load(open("workings.json"))
FIGS = json.load(open("figs_book.json")) if len(sys.argv) < 3 else json.load(open(sys.argv[2]))

starts = sorted({(h["p"], int(h["t"].split()[1])): h["t"] for h in H if h["lvl"] == 1 and h["t"].startswith("Chapter ")}.items())
def chapter_of(p):
    if p >= 2155: return 21
    c = 0
    for (s, n), _ in starts:
        if p >= s: c = n
    return c if p >= 58 else 0

SHORT = {0:"Front matter and the prologue on the conditions of the science",1:"The letters, their elements and natures",
 2:"Breaking and spreading (kasr wa-basṭ); hours, planets, the nine mīzān",3:"The twenty-eight lunar mansions",4:"The twelve signs and the planets",
 5:"The secrets of the Basmala",6:"Spiritual retreat (khalwa) and seclusion",7:"The names by which ʿĪsā raised the dead",
 8:"The four seasonal quarters",9:"The openings of the suras (fawātiḥ)",10:"The secrets of the Fātiḥa",11:"The originations of the divine Mercy",
 12:"The Greatest Name and its deployments",13:"The letters absent from the Fātiḥa (sawāqiṭ)",14:"Litanies, invocations and the qasam corpus",
 15:"The conditions binding on the practitioner",16:"The Most Beautiful Names",17:"Kāf-Hā-Yā-ʿAyn-Ṣād and its seal",18:"Āyat al-Kursī",
 19:"The awfāq and talismans",20:"Sūrat Yā-Sīn and the daily awrād",21:"Applied workings, healing verses, ciphers, index"}
SUMMARY = {
 0:"The editions, sources and title, the reference charts, and the prologue: the conditions of the science — licence (idhn), purity, diet and discipline, timing, facing the qibla, and the rest — which the book places before every operation.",
 1:"The twenty-eight letters: their elements and natures, the luminous and the dark, and the friendship and enmity of the elements toward one another.",
 2:"Breaking and spreading the letters, and fitting every operation to its time: the auspicious and inauspicious hours, the angels of the letters, the properties, days, incense and letters of the planets, the terrestrial spirits, the tables of the days, the method of basṭ, the degrees of the elements, the nine mīzān, the numerical basṭ and the multiplication of letters.",
 3:"The judgements of the twenty-eight lunar mansions: their distribution among the signs, their risings, their division among the seasons, the Arabs' rhymed sayings on them, and how to know which sign the moon is in.",
 4:"The twelve signs and their indications: lands, divisions of time, winds, the heavens, the moon and stars, the planets' bodies, sojourns, exaltations and natures, the Milky Way, hostile signs, and the letters and months of the signs.",
 5:"The secrets and blessings of the Basmala, its letters and numbers, and the workings built on it.",
 6:"Spiritual retreat and the devotional seclusions that open onto the higher realms.",
 7:"The names by which ʿĪsā, peace be upon him, raised the dead, and their workings.",
 8:"The four seasonal quarters and the seasons that belong to them.",
 9:"The occult properties of the openings of the firmly established suras and of the clear verses.",
 10:"The secrets of the Fātiḥa, its renowned properties and its invocations.",
 11:"The originations of the divine Mercy and the lights within it.",
 12:"The Greatest Name of God and its hidden operative deployments.",
 13:"The seven letters absent from the Fātiḥa, and the awfāq and invocations that belong to them.",
 14:"The litanies of remembrance and the answered invocations; the long corpus of qasam and the names that serve them.",
 15:"The conditions binding upon some practitioners and not others, from the first beginnings to the final stations.",
 16:"The Most Beautiful Names of God, one faṣl to each, with their values, squares and tried benefits.",
 17:"The properties of Kāf-Hā-Yā-ʿAyn-Ṣād and of its lordly seal.",
 18:"The properties of the Throne Verse and the God-given secrets in it.",
 19:"The tried-and-tested awfāq and talismans: the stations and spirits of every square, the rules of construction for the threefold to the tenfold, the letter squares, and their workings.",
 20:"Sūrat Yā-Sīn and its answered invocations, and the daily litanies from Sunday to Saturday.",
 21:"Applied workings drawn from the sūras, the verses of healing, the treatments for epilepsy and jinn-affliction, the ciphers, the index of the divine names, and Ṣalāt al-Fātiḥ."}

bounds = [(0, 1, 57)] + [(n, s, None) for (s, n), _ in starts]
chapters = []
order = sorted(bounds, key=lambda x: x[1])
for i, (n, s, _) in enumerate(order):
    e = (order[i + 1][1] - 1) if i + 1 < len(order) else 2154
    title = dict(((n2, t) for (s2, n2), t in starts)).get(n, "Front matter and Prologue — The Conditions and Practice of This Science")
    title = re.sub(r"^Chapter \d+ \([^)]*\)(?: \[\d+\])?:\s*", "", title)
    chapters.append({"ch": n, "from": s, "to": e, "title": title, "short": SHORT[n], "summary": SUMMARY[n]})
chapters.append({"ch": 21, "from": 2155, "to": 2401, "title": "Applied workings, the verses of healing, ciphers, and the index of the divine names",
                 "short": SHORT[21], "summary": SUMMARY[21]})

outline = []
for o in OUT:
    if not o["p"] or o["lvl"] == 1: continue
    outline.append({"t": o["t"], "p": o["p"], "ch": chapter_of(o["p"])})
outline.sort(key=lambda o: o["p"])

figs = []
for f in FIGS:
    g = {k: f[k] for k in ("page", "status") if k in f}
    g["ch"] = chapter_of(f["page"])
    for k in ("id", "n", "constant", "grid", "note", "printed", "issue", "held", "corrected", "closes", "diagonals", "table", "same", "panels", "caption", "remark", "plain"):
        if f.get(k) is not None: g[k] = f[k]
    figs.append(g)

for c in chapters:
    cf = [f for f in figs if f["ch"] == c["ch"]]
    c["figs"], c["figsDone"] = len(cf), sum(1 for f in cf if f["status"] not in ("unread", "queued"))
    c["works"] = sum(1 for w in W if w["ch"] == c["ch"] and w["cat"] != "sealed")
works = [{k: v for k, v in w.items() if v not in ([], None) and k not in ("sec", "secP")} for w in W]
BOOK = {"chapters": chapters, "outline": outline, "workings": works, "figs": figs, "sealedFigs": json.load(open("reader/sealed_figs.json")), "talismans": json.load(open("talismans.json"))}
js = "/*@BOOK*/const BOOK = " + json.dumps(BOOK, ensure_ascii=False, separators=(",", ":")) + ";/*@END*/"
src = open(sys.argv[1], encoding="utf-8").read()
if "/*@BOOK*/" in src:
    src = re.sub(r"/\*@BOOK\*/.*?/\*@END\*/", lambda m: js, src, flags=re.S)
else:
    src = src.replace("const WORKS = DATA.works.rows.map(", js + "\nconst WORKS = DATA.works.rows.map(", 1)
open(sys.argv[1], "w", encoding="utf-8").write(src)
print("BOOK:", len(chapters), "chapters,", len(outline), "headings,", len(works), "workings,", len(figs), "figures,",
      sum(1 for f in figs if f["status"] not in ("unread", "queued")), "read")

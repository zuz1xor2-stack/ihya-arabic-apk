# Book figures whose square is rebuilt for your value, or whose blank (fulān, the angel's name) takes your words,
# while everything else stays exactly as printed. Coordinates are in the tracing's units (see trace_dims).

traced(297, 1721, "Every soul has a guardian — the 3×3 of Q 86:4 in the angels' frame",
    "The threefold on 1467, the value of ﴿in kullu nafsin lammā ʿalayhā ḥāfiẓ﴾ (Q 86:4) with the Basmala: 1467 − 12 = 1455, ÷ 3 = 485 in the first cell, adding one each step (p.1721). The verse is written seven times round the square; carried on the person, so it is cast in its air form.",
    cut=(192, 180, 478, 437), forge=dict(cells=[[486, 491, 490], [493, 489, 485], [488, 487, 492]], book=1467), group="square",
    how=["Take the value of the verse with the Basmala, 1467; subtract 12 and divide by 3: 485 in the first cell, then one more in each cell to the ninth (the first rule of the threefold).",
         "Write the square in its air form, since it is carried; the four archangels on its sides.",
         "Write the verse seven times round it, then recite it over the square.",
         "With your own value the same figure is rebuilt; the verse round it stays the book's."],
    notes=["The printed square reads ٤٨٦ ٤٩١ ٤٩٠ / ٤٩٣ ٤٨٩ ٤٨٥ / ٤٨٨ ٤٨٧ ٤٩٢: every line 1467 — it closes as printed.",
           "The bottom band repeats the verse in the mirrored hand."])

traced(512, 2190, "The mirror working of al-Fātiḥa — the budūḥ 3×3 in the angels' frame",
    "Written on the back of a mirror for the Fātiḥa's invocation (p.2190): the classic 3×3 of budūḥ (4 9 2 / 3 5 7 / 8 1 6) in the archangels' frame, with the names round its corners and al-Qāsim and the ṣalawāt at its sides.",
    cut=(222, 220, 483, 463), forge=dict(cells=[[4, 9, 2], [3, 5, 7], [8, 1, 6]], book=15), group="square",
    notes=["The square as printed is the natural 3×3 (constant 15), budūḥ in its numbers."])

traced(106, 822, "The talisman for the back of the mirror — the angel's name at its centre",
    "Written on the back of a mirror for the angels of the days (pp.821–822): a ruled square with a letter at each corner, two rows of hāʾ, and in the centre the name of the angel being called — the book writes “ism al-malak”, the name of the angel.",
    group="seal",
    els=[dict(t="erase", x=150, y=215, w=185, h=80), text(242, 255, "اسم الملك", 46, maxw=170, label="the angel's name (edit)")],
    notes=["The centre is a blank in the book: write there the name of the angel of the day (Sarfiyāʾīl on Thursday, ʿAnyāʾīl on Friday, Kasfiyāʾīl on Saturday …)."])

traced(203, 1353, "Junnat al-Asmāʾ — the circle of the Names",
    "The Junnat al-Asmāʾ circle (pp.1350–1353): Āyat al-Kursī round the outermost circle, the Kufic signs in the second, the Names of majesty in the third (al-Malik, al-ʿAzīz, al-Jabbār, al-Mutakabbir, al-Muhaymin, al-Qahhār, al-ʿAlī, al-Kabīr, al-Mutaʿāl, al-Qādir, al-Muqtadir, al-Ḥakam, al-ʿAdl, al-Mudhill, al-Muntaqim), letters within, and at the centre the fourfold of the āya suited to your purpose — the book's example is Q 6:122, value 784.",
    cut=(325, 300, 510, 470), n=4, m=4, forge=dict(cells=[[195, 199, 202, 188], [201, 189, 194, 200], [190, 204, 197, 193], [198, 192, 191, 203]], book=784), group="seal",
    how=["After the greater ablution, facing the qibla, write Āyat al-Kursī round the outermost circle; the Kufic letters in the second; the Names in the third.",
         "In the fifth, Fard, Ḥayy, Qayyūm, Ḥakam, ʿAdl, Quddūs; in the sixth, the āya suited to your purpose.",
         "At the centre the fourfold of that āya: its value less 30, divided by 4, the quotient in the first cell and one more in each; a remainder of 3, 2 or 1 lifts the 5th, 9th or 13th cell (p.1353).",
         "Write it twice: carry one, soak the other and drink of it for nineteen days, reciting after every obligatory prayer."],
    notes=["The centre square reads as printed, every line 784.", "The book's text for the fourth circle is missing in this edition; the rings are carried as printed — choose 'redrawn clean' for an even line."])

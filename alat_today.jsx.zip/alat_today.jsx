/* ═══ Ālāt → Today — the instruments set for this day and this hour (v2.8) ═══
   Same day as Kitāb → Today (sunrise to sunrise), but worked: the day's name built on the day's own square, its
   governing angel, its basṭ, the hour's square, the day's letter, and buttons into every instrument with today loaded. */
const DAY_ORDER = Object.fromEntries(Object.entries(ORDER_PLANET).map(([n, a]) => [a.planet, +n]));   // ch.19: sun 6, moon 9, mars 5, mercury 8, jupiter 4, venus 7, saturn 3
function svgDownload(ref, name) {
  try { const el = ref.current && ref.current.querySelector("svg"); if (!el) return;
    const x = new XMLSerializer().serializeToString(el).replace(/#ece6d8/g, "#111").replace(/#ffffff44/g, "#777");
    download(name, x, "image/svg+xml"); } catch {}
}
function AlatToday({ hue, go, cur, hours, loc, tz }) {
  const [now, setNow] = useState(new Date());
  useEffect(() => { const t = setInterval(() => setNow(new Date()), 1000); return () => clearInterval(t); }, []);
  const ruler = hours && hours[0] ? hours[0].planet : DAY_RULERS[now.getDay()];
  const di = DAY_RULERS.indexOf(ruler), T = DAY_TABLE[di], W = CH20[di], P = PLANETS[ruler];
  const curH = (hours || []).find(h => now >= h.start && now < h.end) || cur;
  const left = curH ? Math.max(0, curH.end - now) : 0;
  const cd = `${Math.floor(left / 3600000)}:${String(Math.floor(left / 60000) % 60).padStart(2, "0")}:${String(Math.floor(left / 1000) % 60).padStart(2, "0")}`;
  const ld = lunarDay(now), manhus = MANHUS_DAYS.includes(ld.day), M = manzilNow(now), mz = (DATA.manazil || []).find(m => m.n === M.n);

  /* ── which text to set: the day's name (p.115), any name of the day's wird, the day's Fātiḥa verse, or your own ── */
  const choices = useMemo(() => [
    { k: "day", label: `the day's name · ${T.nameTr}`, ar: T.name, cite: 115 },
    ...W.names.filter(n => n[1]).map(n => ({ k: "w-" + n[1], label: `from the day's wird · ${n[0]}`, ar: n[1], cite: W.pp[0] })),
    { k: "fatiha", label: "the day's verse of the Fātiḥa", ar: T.fatiha, cite: 1787 },
    { k: "own", label: "your own name or text…", ar: null },
  ], [di]);
  const [ck, setCk] = useState("day");
  useEffect(() => setCk("day"), [di]);
  const [own, setOwn] = useState(() => LS.get("alat-today-own", ""));
  const C = choices.find(c => c.k === ck) || choices[0];
  const text = C.k === "own" ? own : C.ar;
  const A = text ? abjad(text) : 0;
  const dayN = DAY_ORDER[ruler];
  const fits = useMemo(() => A ? fitAll(A, [3, 4, 5, 6, 7, 8, 9, 10]) : [], [A]);
  const [nSel, setNSel] = useState(null);
  useEffect(() => setNSel(null), [A, dayN]);
  const dayFits = fits.find(f => f.n === dayN && f.ok);
  const n = nSel || (dayFits ? dayN : (fits.filter(f => f.ok).map(f => f.n).filter(k => k <= dayN).pop() || (fits.find(f => f.ok) || {}).n));
  const W8 = n && A ? wafq(A, n) : null;
  const vis = W8 && !W8.error ? toVisual(W8.grid) : null;
  const S8 = vis ? checkSums(vis) : null;
  const gov = A > 51 ? governingAngel(A) : null;
  const stn = n ? stations(n) : null;
  const plateRef = useRef(null);

  /* ── the hour's square, as the book prints it ── */
  const hourN = curH ? DAY_ORDER[curH.planet] : null;
  const hourVis = hourN && BOOK_FORMS[hourN] ? BOOK_FORMS[hourN].vis : null;
  const nextOwn = (hours || []).find(h => h.planet === ruler && h.end > now && !(curH && h.i === curH.i));

  /* ── basṭ: the day's word and the chosen text (pp.124–134) ── */
  const dayWord = BAST_DAYWORD[di], bDay = bastFirst(dayWord), bText = text ? bastFirst(text) : 0;
  const L = letterTable().find(x => x.ch === T.letter);

  const card = (strong, h = hue) => ({ border: `1px solid ${strong ? h : h + "44"}`, background: strong ? h + "12" : "#00000033", padding: 14, borderRadius: 3, minWidth: 0 });
  const lab = (h = hue) => ({ fontFamily: F.mono, fontSize: 10.5, letterSpacing: "0.08em", color: h, textTransform: "uppercase" });
  const grid2 = { display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(min(100%,280px),1fr))", gap: 10 };
  return <div>
    <H2 hue={hue} sub="the instruments set for this day and hour — the same day as Kitāb → Today, worked">Today</H2>

    <div style={{ ...card(true, P.h), display: "flex", flexWrap: "wrap", gap: 18, alignItems: "center" }}>
      <div style={{ flex: "1 1 260px", minWidth: 0 }}>
        <div style={lab(P.h)}>{now.toLocaleDateString([], { weekday: "long", month: "long", day: "numeric" })} · {hijri(now).d} {hijri(now).month}</div>
        <div style={{ fontFamily: F.disp, fontSize: 28, color: "#f0ead9", marginTop: 2 }}>{P.g} Day of {P.n.split(" · ")[0]} · the {dayN}×{dayN}</div>
        <div style={{ fontSize: 13.5, color: "#ffffffaa" }}>its square by chapter 19 (<Cite page={ORDER_PLANET[dayN].page} hue={P.h} />) · the day's letter {T.letter} · name {T.nameTr} {T.name} ({abjad(T.name)})</div>
      </div>
      {curH && <div>
        <div style={lab(PLANETS[curH.planet].h)}>hour {curH.i} · {curH.night ? "night" : "day"} · the {DAY_ORDER[curH.planet]}×{DAY_ORDER[curH.planet]}</div>
        <div style={{ fontSize: 18, color: PLANETS[curH.planet].h }}>{PLANETS[curH.planet].g} {PLANETS[curH.planet].n}</div>
        <div style={{ fontFamily: F.mono, fontSize: 22, color: "#f0ead9" }}>{cd}</div>
      </div>}
      <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
        <span style={{ fontFamily: F.mono, fontSize: 11, padding: "4px 9px", borderRadius: 12, textAlign: "center", color: manhus ? "#12100a" : "#8fce7f",
          background: manhus ? "#e86a52" : "transparent", border: `1px solid ${manhus ? "#e86a52" : "#8fce7f77"}` }}>{manhus ? `lunar day ${ld.day} · inauspicious (p.43)` : `lunar day ${ld.day} · open`}</span>
        <span style={{ fontFamily: F.mono, fontSize: 11, padding: "4px 9px", borderRadius: 12, textAlign: "center", color: "#ffffffaa", border: "1px solid #ffffff22" }}>
          {ld.waxing ? "moon waxing" : "moon waning"}{mz ? ` · mansion ${mz.n} ${mz.tr}` : ""}</span>
        {nextOwn && <span style={{ fontFamily: F.mono, fontSize: 11, color: "#ffffff99", textAlign: "center" }}>next {ruler} hour {fmt(nextOwn.start)}</span>}
      </div>
    </div>
    {curH && curH.planet !== ruler && <div style={{ fontSize: 13, color: "#ffffff88", marginTop: 6 }}>
      The book sets a working on the day and the hour of its planet (p.1701, p.115); the day's own planet next rules the hour at {nextOwn ? fmt(nextOwn.start) : "—"}.</div>}

    {/* ── the day's square for a name ── */}
    <div style={{ ...grid2, marginTop: 16 }}>
      <div style={card(true)}>
        <div style={lab()}>Set on the day's square</div>
        <select value={ck} onChange={e => setCk(e.target.value)} aria-label="What to set" style={{ ...inputBase, width: "100%", marginTop: 8, fontSize: 14 }}>
          {choices.map(c => <option key={c.k} value={c.k}>{c.label}{c.ar ? ` · ${c.ar.length > 24 ? c.ar.slice(0, 24) + "…" : c.ar}` : ""}</option>)}</select>
        {C.k === "own" && <input dir="rtl" value={own} onChange={e => { setOwn(e.target.value); LS.set("alat-today-own", e.target.value); }} placeholder="اكتب الاسم أو الآية"
          aria-label="Your own name or text" style={{ ...inputBase, width: "100%", marginTop: 6, fontFamily: F.ar, fontSize: 20 }} />}
        {text && <div dir="rtl" style={{ fontFamily: F.ar, fontSize: text.length > 30 ? 20 : 30, color: "#f0ead9", marginTop: 8, lineHeight: 1.5 }}>{text}</div>}
        {A > 0 && <div style={{ fontSize: 14, color: "#ffffffbb" }}>value <b style={{ color: hue }}>{A}</b> (mashriqī, recomputed from the letters){C.cite ? <> · <Cite page={C.cite} hue={hue} /></> : null}</div>}
        {A > 0 && <div style={{ display: "flex", gap: 4, flexWrap: "wrap", marginTop: 10 }}>
          {fits.map(f => <button key={f.n} onClick={() => f.ok && setNSel(f.n)} disabled={!f.ok} title={f.ok ? `${f.n}×${f.n}` : f.why}
            style={{ fontFamily: F.mono, fontSize: 11, padding: "3px 8px", borderRadius: 2, cursor: f.ok ? "pointer" : "not-allowed",
              border: `1px solid ${f.n === n ? hue : f.ok ? hue + "55" : "#ffffff18"}`, background: f.n === n ? hue : "transparent",
              color: f.n === n ? "#12100a" : f.ok ? (f.n === dayN ? hue : "#ffffffaa") : "#ffffff33" }}>{f.n}×{f.n}{f.n === dayN ? " ☉" : ""}</button>)}
        </div>}
        {A > 0 && !dayFits && <div style={{ fontSize: 12.5, color: "#e8b84f", marginTop: 6 }}>
          The day's own square, the {dayN}×{dayN}, needs at least {subtrahend(dayN) + dayN}; {A} is set on the {n}×{n} instead — or choose a longer text.</div>}
        {gov && <div style={{ marginTop: 12, fontSize: 14, color: "#ffffffbb", lineHeight: 1.6 }}>
          <span style={lab()}>governing angel </span> <span dir="rtl" style={{ fontFamily: F.ar, fontSize: 20, color: "#f0ead9" }}>{gov.name}</span>
          <div style={{ fontSize: 12.5, color: "#ffffff88" }}>{A} − 51 = {gov.rest} → {gov.letters.join(" ")} + ائيل, the rule of p.1913 for the row total of a named square (ʿulwī; the suflī derivation is sealed)</div></div>}
        {stn && <div style={{ fontSize: 12.5, color: "#ffffff88", marginTop: 8 }}>the {n}×{n}'s stations (pp.1701, 1904): miftāḥ {stn.miftah} · mughlāq {stn.mughlak} · wafq {stn.wafq} · masāḥa {stn.mesahe} · ḍābiṭ {stn.zabit} · ghāya {stn.ghaye} · aṣl {stn.asil}</div>}
      </div>
      <div style={card(false)}>
        <div style={lab()}>{vis ? `${n}×${n} on ${A} · ${S8 && S8.balanced ? `every line ${S8.constant}${S8.diagonals ? ", both diagonals too" : ""}` : "does not close"}` : "the square"}</div>
        {vis ? <div ref={plateRef} style={{ display: "flex", justifyContent: "center", marginTop: 6 }}><FramedPlate grid={vis} hue={hue} size={Math.min(440, 120 + n * 34)} /></div>
          : <div style={{ fontSize: 13.5, color: "#ffffff88", marginTop: 8 }}>{W8 && W8.error ? W8.error : "Choose a name or text."}</div>}
        {vis && <div style={{ fontSize: 12, color: "#ffffff77", marginTop: 4 }}>{A} − {subtrahend(n)} = {A - subtrahend(n)}; ÷ {n} = {W8.k}{W8.rem ? ` remainder ${W8.rem}, the last ${W8.lift} lifted by one` : ""} · on {baseSource(n)} · in the plate of chapter 19 · not printed in the book</div>}
        {vis && <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginTop: 8 }}>
          <Btn hue={hue} small onClick={() => go("forge", { text, order: n })}>open in the Forge</Btn>
          <Btn hue={hue} small onClick={() => svgDownload(plateRef, `${T.d.toLowerCase()}-${n}x${n}-${A}.svg`)}>download the plate</Btn>
          <Btn hue={hue} small onClick={() => go("qawaid")}>the rules</Btn></div>}
      </div>
    </div>

    {/* ── the hour's square and the instruments ── */}
    <div style={{ ...grid2, marginTop: 10 }}>
      {hourVis && <div style={card(false, PLANETS[curH.planet].h)}>
        <div style={lab(PLANETS[curH.planet].h)}>This hour's square · the {hourN}×{hourN} of {curH.planet} · as printed</div>
        <div style={{ display: "flex", justifyContent: "center", marginTop: 6 }}><FramedPlate grid={hourVis} hue={PLANETS[curH.planet].h} size={Math.min(360, 110 + hourN * 30)} /></div>
        <div style={{ fontSize: 12.5, color: "#ffffff88" }}>the natural form, <Cite page={BOOK_FORMS[hourN].page} hue={PLANETS[curH.planet].h} /> · {HOUR_BOOK[curH.planet].el ? `workings tied to ${HOUR_BOOK[curH.planet].el} (p.115)` : "no element assigned to this hour (p.115)"}</div>
        <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginTop: 8 }}>
          {text && <Btn hue={PLANETS[curH.planet].h} small onClick={() => go("forge", { text, order: hourN })}>set {A} on it in the Forge</Btn>}
          <Btn hue={PLANETS[curH.planet].h} small onClick={() => go("hours")}>the hours</Btn></div>
      </div>}
      <div style={card(false)}>
        <div style={lab()}>Basṭ · pp.124–134</div>
        <div style={{ fontSize: 14, color: "#ffffffbb", marginTop: 6, lineHeight: 1.7 }}>
          the day's word <span dir="rtl" style={{ fontFamily: F.ar, fontSize: 19, color: "#f0ead9" }}>{dayWord}</span> — first basṭ <b style={{ color: hue }}>{bDay}</b><br />
          {text && <>the text set above — first basṭ <b style={{ color: hue }}>{bText}</b><br /></>}
          the day's letter <span dir="rtl" style={{ fontFamily: F.ar, fontSize: 19, color: "#f0ead9" }}>{T.letter}</span> — {abjad(T.letter)}, {L ? `${L.element}, ${L.nature}` : ""} (p.76) · first basṭ {bastFirst(T.letter)}
        </div>
        <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginTop: 8 }}><Btn hue={hue} small onClick={() => go("bast")}>the basṭ instrument</Btn><Btn hue={hue} small onClick={() => go("huruf")}>the letters</Btn></div>
      </div>
      <div style={card(false)}>
        <div style={lab()}>The day's set · p.115 · ch.20</div>
        <div style={{ fontSize: 14, color: "#ffffffbb", marginTop: 6, lineHeight: 1.75 }}>
          angel <span dir="rtl" style={{ fontFamily: F.ar, fontSize: 18 }}>{W.angelAr}</span> {W.angel} · king <span dir="rtl" style={{ fontFamily: F.ar, fontSize: 18 }}>{W.kingAr}</span> {W.king.split(" (")[0]}<br />
          tahṭīl <span dir="rtl" style={{ fontFamily: F.ar, fontSize: 18 }}>{W.tahtilAr}</span> {W.tahtil}<br />
          colour {T.colour} · ink {["yellow orpiment","white lead","cinnabar","sarcocolla","verdigris","camphor","vitriol"][di]} · incense {T.incense}<br />
          Yā-Sīn {W.yasin} · Fātiḥa {W.fatihaRef}
        </div>
        <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginTop: 8 }}>
          <Btn hue={hue} small onClick={() => go("kitab", { view: "today" })}>Kitāb → Today</Btn>
          <Btn hue={hue} small onClick={() => go("wird")}>the counter</Btn>
          <Btn hue={hue} small onClick={() => go("chambers")}>incense (Bakhūr)</Btn></div>
      </div>
      <div style={card(false)}>
        <div style={lab()}>Place, prayer and qibla</div>
        <div style={{ fontSize: 14, color: "#ffffffbb", marginTop: 6, lineHeight: 1.7 }}>
          {loc ? <>{loc.label ? loc.label.split(" (")[0] : "your location"} · qibla {qiblaBearing(loc.lat, loc.lon).toFixed(0)}° {compass(qiblaBearing(loc.lat, loc.lon))}<br />
            {(() => { const p = prayerTimes(now, loc.lat, loc.lon, tz, "ISNA"); return p.polar ? "—" : `Fajr ${hoursToHM(p.fajr)} · Ẓuhr ${hoursToHM(p.dhuhr)} · ʿAṣr ${hoursToHM(p.asr)} · Maghrib ${hoursToHM(p.maghrib)} · ʿIshāʾ ${hoursToHM(p.isha)}`; })()}</>
            : "No location set — the hours run on a fixed six and six."}
        </div>
        <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginTop: 8 }}><Btn hue={hue} small onClick={() => go("majlis")}>Majlis</Btn><Btn hue={hue} small onClick={() => go("manazil")}>the mansions</Btn></div>
      </div>
    </div>
    <div style={{ fontSize: 12.5, color: "#ffffff77", marginTop: 14, maxWidth: 760, lineHeight: 1.6 }}>
      Every square here is built by the book's own rule and re-summed before it is shown; none is presented as the book's own figure.
      The prologue's conditions (pp.40–46) — and above all the licence (p.42) — come before any working.</div>
  </div>;
}

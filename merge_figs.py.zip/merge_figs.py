"""Merge machine-verified figures, eye readings and notes into figs_book.json for build_data.py.
Rules: a reading that closes is 'eye' (or stays 'verified'); a printed square that does not close keeps its printed
grid and, where a closing correction exists (id + 'C'), the corrected grid becomes the displayed one with the
printed one kept beside it. Notes: id|note is the description; idD is a discrepancy; idR is held for re-reading."""
import json, re, collections
V = json.load(open("figs_verified.json"))
E = json.load(open("eye_reads.json"))
notes = collections.defaultdict(dict)
for ln in open("eye_notes.txt", encoding="utf-8"):
    if "|" not in ln: continue
    k, t = ln.rstrip("\n").split("|", 1)
    m = re.match(r"^(\d+)([A-Z]+\d*)?$", k)
    if m: notes[int(m.group(1))][m.group(2) or ""] = t

def show(cells):
    out = []
    for r in cells:
        row = []
        for c in r:
            c = c.strip()
            if c in ("-", "", "•", "[petition]"): row.append(None)
            elif c.startswith("["): row.append(c.strip("[]"))
            elif c.isdigit(): row.append(int(c))
            else: row.append(c)
        out.append(row)
    return out

def resolve(k, seen=()):
    e = E.get(k)
    if e and e["kind"] == "same" and e["same"] not in seen: return resolve(e["same"], seen + (k,))
    return k, e

REMARK_ONLY = {206, 400, 407, 506}
out = []; tally = collections.Counter()
for i, v in enumerate(V):
    rec = {"id": i, "page": v["page"], "status": v["status"]}
    if v.get("note"): rec["note"] = v["note"]
    if v["status"] == "verified":
        rec.update(n=v["n"], constant=v["constant"], grid=v["grid"])
    k, e = resolve(str(i))
    if e is not None and str(i) in E:
        if k != str(i): rec["same"] = int(re.sub(r"\D", "", k))
        if e["kind"] in ("sq", "mx", "h3", "disc"):
            rec["status"] = "eye" if rec["status"] != "verified" else "verified"
            rec["grid"] = show(e["cells"]); rec["n"] = len(e["cells"][0])
            if e["ok"]: rec["constant"] = e["constant"]; rec["closes"] = True; rec["diagonals"] = e["diagonals"]
            else: rec["closes"] = False
            ck, ce = resolve(k + "C")
            if ce is not None and (k + "C") in E:
                rec["printed"] = rec["grid"]; rec["grid"] = show(ce["cells"]) if "cells" in ce else rec["grid"]
                rec["constant"] = ce.get("constant"); rec["closes"] = True; rec["corrected"] = True; rec["diagonals"] = ce.get("diagonals")
        elif e["kind"] in ("table", "cells"):
            rec["status"] = "eye"; rec["table"] = show(e["table"])
            ck, ce = resolve(k + "C")
            if ce is not None and (k + "C") in E and "cells" in ce:
                rec["printed"] = rec.pop("table"); rec["grid"] = show(ce["cells"]); rec["n"] = len(ce["cells"][0])
                rec["constant"] = ce.get("constant"); rec["closes"] = True; rec["corrected"] = True; rec["diagonals"] = ce.get("diagonals")
        elif e["kind"] == "desc":
            rec["status"] = "figure"; rec["note"] = e["text"]
    base = int(re.sub(r"\D", "", k)) if k else i
    nt = notes.get(i) or notes.get(base) or {}
    if "" in nt:
        if rec.get("note") and rec["note"] != nt[""] and not (e is not None and e.get("kind") == "desc"): rec["caption"] = rec["note"]
        rec["note"] = nt[""]
    iss = [t for s, t in sorted(nt.items()) if s.startswith("D")]
    held = [t for s, t in sorted(nt.items()) if s.startswith("R")]
    if iss or held: rec["issue"] = " ".join(iss + held)
    if held: rec["held"] = True
    # not corrections: disagreements between the book's own tables, unresolved discrepancies, and squares held as printed
    if i in REMARK_ONLY or base in REMARK_ONLY or rec.get("held"):
        if rec.get("issue"): rec["remark"] = rec.pop("issue")
    import re as _re
    if V[i].get("note") and _re.search(r"no headings|no labels|[Pp]lain|[Uu]nlabelled|without (a )?frame|no frame|no lettering outside", V[i]["note"]) and rec.get("grid"):
        rec["plain"] = True
    pans = sorted(k2 for k2 in E if re.fullmatch(rf"{base}P\d+", k2))
    if pans:
        rec["panels"] = []
        for k2 in pans:
            e2 = E[k2]; lab = notes.get(base, {}).get(k2[len(str(base)):], "")
            rec["panels"].append({"label": lab, "grid": show(e2.get("cells") or e2.get("table")), "constant": e2.get("constant"), "closes": e2.get("ok")})
        if rec["status"] == "queued": rec["status"] = "eye"
    if rec["status"] == "eye" and "grid" not in rec and "table" not in rec and "panels" not in rec: rec["status"] = "queued"
    tally[rec["status"]] += 1
    out.append(rec)
json.dump(out, open("figs_book.json", "w"), ensure_ascii=False)
print(tally, "corrected:", sum(1 for r in out if r.get("corrected")), "held:", sum(1 for r in out if r.get("held")),
      "issues:", sum(1 for r in out if r.get("issue")))

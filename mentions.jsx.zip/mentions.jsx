/** Passages of given chapters that mention any of the terms — the book's own words on a subject, with their pages. */
function BookMentions({ chapters, terms, hue, limit = 40, title }) {
  const [rows, setRows] = useState(null);
  const [err, setErr] = useState(null);
  const [all, setAll] = useState(false);
  const key = terms.join("|");
  useEffect(() => {
    let live = true; setRows(null);
    Promise.all(chapters.map(c => loadChapter(c))).then(ds => {
      if (!live) return;
      const ft = terms.map(fold), out = [];
      for (const d of ds) { let page = null;
        for (const it of d.items) { if (it.k === "pg") page = it.p;
          if (it.k === "p" && ft.some(t => fold(it.t).includes(t))) out.push({ ch: d.ch, page, t: it.t }); } }
      setRows(out);
    }).catch(e => live && setErr(String(e)));
    return () => { live = false; };
  }, [key, chapters.join(",")]);
  const first = terms[0];
  return <div style={{ marginTop: 18, maxWidth: 780 }}>
    <div style={{ fontFamily: F.mono, fontSize: 10.5, letterSpacing: "0.12em", color: hue + "bb" }}>{title || "WHAT THE BOOK SAYS"}</div>
    {err && <div style={{ color: "#e8a25c", fontSize: 13, marginTop: 6 }}>The book's text could not be loaded here ({err}).</div>}
    {!rows && !err && <div style={{ color: "#ffffff66", fontFamily: F.mono, fontSize: 11, marginTop: 6 }}>reading the chapter…</div>}
    {rows && rows.length === 0 && <div style={{ color: "#ffffff77", fontSize: 13, marginTop: 6 }}>No passage in these chapters names it.</div>}
    {rows && (all ? rows : rows.slice(0, limit)).map((r, i) => <p key={i} style={{ fontSize: 14, lineHeight: 1.8, color: "#e9e3d4", margin: "8px 0" }}>
      {withAnchors(r.t, first)} <Cite page={r.page} hue={hue} /></p>)}
    {rows && rows.length > limit && !all && <Btn hue={hue} small onClick={() => setAll(true)}>all {rows.length} passages</Btn>}
  </div>;
}


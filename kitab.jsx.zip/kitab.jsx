/* ═══ KITĀB — the engine organised as the book is: prologue, twenty chapters, appendix ═══ */
const CHAP_INSTR = {
  0: [["shart","Sharṭ — the conditions"],["glossary","Glossary"]],
  1: [["huruf","Ḥurūf — the letters"],["bast","Basṭ — the elements' degrees"]],
  2: [["bast","Basṭ — the nine mīzān"],["hours","Planetary hours"],["qawaid","Istinṭāq"],["chambers","Bakhūr of the planets"]],
  3: [["manazil","Manāzil — the mansions"]],
  4: [["falak","Falak — the signs"]],
  5: [["shields","The Basmala, letter by letter"],["forge","Forge"]],
  6: [["shart","Sharṭ"]],
  7: [["fawatih","Fawātiḥ"]],
  8: [["hours","Hours"],["falak","Falak"]],
  9: [["fawatih","Fawātiḥ — the openings"],["shields","al-Fātiḥa"]],
  10: [["shields","al-Fātiḥa"],["forge","Forge"]],
  12: [["asma","Asmāʾ"],["forge","Forge"]],
  13: [["sawaqit","Sawāqiṭ — the absent letters"]],
  14: [["wird","Wird counter"],["shurut","Shurūṭ — stated conditions"]],
  16: [["asma","Asmāʾ — the ninety-nine"],["atlas","Atlas of their squares"],["forge","Forge"]],
  17: [["khatam","Khātam — the seal"],["fawatih","Fawātiḥ"]],
  18: [["shields","Āyat al-Kursī"],["forge","Forge"]],
  19: [["qawaid","Qawāʿid — the rules"],["forge","Forge"],["atlas","Atlas"],["plate","Plate"]],
  20: [["wird","Wird"],["shields","Shields"],["majlis","Majlis"]],
};
const CATCOL = { healing:"#7fc4a8", protection:"#8fb8e8", provision:"#e8c96a", need:"#c9b58f", release:"#b58fe8", knowledge:"#9fd0e8",
  family:"#e8a2c0", standing:"#e8b84f", travel:"#8fce7f", jinn:"#b9a475", dreams:"#c9d2e0", other:"#a9a29a", sealed:"#e8a25c" };
const CHNAME = (c) => c === 0 ? "Prologue & front matter" : c === 21 ? "Applied workings & index" : `Bāb ${c}`;

/* ═══ the book itself — every page, read in the engine ═══ */
const BOOK_CACHE = {};
function loadChapter(ch) {
  if (!BOOK_CACHE[ch]) BOOK_CACHE[ch] = fetch(`book/ch${String(ch).padStart(2, "0")}.json`)
    .then(r => { if (!r.ok) throw new Error(r.status); return r.json(); })
    .catch(e => { delete BOOK_CACHE[ch]; throw e; });
  return BOOK_CACHE[ch];
}
let SEARCH_CACHE = null;
function loadSearch() {
  if (!SEARCH_CACHE) SEARCH_CACHE = fetch("book/search.json").then(r => r.json()).catch(e => { SEARCH_CACHE = null; throw e; });
  return SEARCH_CACHE;
}
const LS = {
  get(k, d) { try { const v = localStorage.getItem("ihya:" + k); return v == null ? d : JSON.parse(v); } catch { return d; } },
  set(k, v) { try { localStorage.setItem("ihya:" + k, JSON.stringify(v)); } catch {} },
};
function chapterOfPage(p) {
  const c = BOOK.chapters.find(c => p >= c.from && p <= c.to);
  return c ? c.ch : 0;
}
/** Fold a string for searching — diacritics, ʿayn/hamza marks and case ignored — keeping a map back to the original. */
function foldMap(s) {
  let out = "", map = [];
  for (let i = 0; i < s.length; i++) {
    const c = s[i];
    if (/[ʿʾ'’‘`ʻʼ]/.test(c)) continue;
    const f = c.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
    for (const x of f) { out += x; map.push(i); }
  }
  return [out, map];
}
const fold = (s) => foldMap(s)[0];
const hl = (text, q) => {
  if (!q || typeof text !== "string") return text;
  const [ft, map] = foldMap(text), fq = fold(q);
  const at = fq ? ft.indexOf(fq) : -1;
  if (at < 0) return text;
  const a = map[at], b = map[at + fq.length - 1] + 1;
  return <>{text.slice(0, a)}<mark style={{ background: "#e8c96a55", color: "inherit" }}>{text.slice(a, b)}</mark>{hl(text.slice(b), q)}</>;
};
// the book's source anchors "[I 44]" become quiet references to Manbaʿ Uṣūl al-Ḥikma
function withAnchors(t, q) {
  const parts = t.split(/(\[I+ \d+\])/);
  return parts.map((s, i) => /^\[I+ \d+\]$/.test(s)
    ? <span key={i} title="page of Manbaʿ Uṣūl al-Ḥikma" style={{ fontFamily: F.mono, fontSize: "0.68em", color: "#ffffff55", verticalAlign: "super" }}>{s.slice(1, -1)}</span>
    : <React.Fragment key={i}>{hl(s, q)}</React.Fragment>);
}

function ReadPane({ ch, hue, go, page, onPage, query }) {
  const [data, setData] = useState(null);
  const [err, setErr] = useState(null);
  const [size, setSize] = useState(() => LS.get("fontSize", 16.5));
  const [showAr, setShowAr] = useState(() => LS.get("showAr", true));
  const [marks, setMarks] = useState(() => LS.get("bookmarks", []));
  const root = useRef(null);
  useEffect(() => { setData(null); setErr(null); loadChapter(ch).then(setData).catch(e => setErr(String(e))); }, [ch]);
  useEffect(() => { LS.set("fontSize", size); }, [size]);
  useEffect(() => { LS.set("showAr", showAr); }, [showAr]);
  // scroll to the requested page once the chapter is in
  useEffect(() => {
    if (!data || !page) return;
    const el = root.current && root.current.querySelector(`[data-page="${page}"]`);
    if (el) setTimeout(() => el.scrollIntoView({ block: "start" }), 30);
  }, [data, page]);
  // remember where the reader is
  useEffect(() => {
    if (!data || !root.current) return;
    const io = new IntersectionObserver(es => {
      const vis = es.filter(e => e.isIntersecting).map(e => +e.target.dataset.page);
      if (vis.length) { const p = Math.min(...vis); LS.set("lastRead", { ch, p }); onPage && onPage(p);
        const v = LS.get("visited", []); if (!v.includes(p)) { v.push(p); LS.set("visited", v); } }
    }, { rootMargin: "0px 0px -70% 0px" });
    root.current.querySelectorAll("[data-page]").forEach(el => io.observe(el));
    return () => io.disconnect();
  }, [data]);
  const toggleMark = (p) => setMarks(m => { const n = m.some(x => x.p === p) ? m.filter(x => x.p !== p) : [...m, { p, ch, at: Date.now() }].sort((a, b) => a.p - b.p); LS.set("bookmarks", n); return n; });
  if (err) return <div style={{ marginTop: 14, color: "#e8a25c", maxWidth: 640, lineHeight: 1.7 }}>
    The text of this chapter could not be loaded ({err}). It is published beside the engine as book/ch{String(ch).padStart(2, "0")}.json; open the engine from its own link so the page can reach it.</div>;
  if (!data) return <div style={{ marginTop: 14, color: "#ffffff77", fontFamily: F.mono, fontSize: 12 }}>opening the chapter…</div>;
  const C = BOOK.chapters.find(c => c.ch === ch);
  const figById = new Map(BOOK.figs.map(f => [f.id, f]));
  return <div>
    <div style={{ position: "sticky", top: 0, zIndex: 2, background: "#0a0806ee", padding: "8px 0", display: "flex", gap: 6, flexWrap: "wrap", alignItems: "center", borderBottom: "1px solid #ffffff14" }}>
      <span style={{ fontFamily: F.mono, fontSize: 10.5, color: hue }}>pp.{C.from}–{C.to}</span>
      <Btn hue={hue} small onClick={() => setSize(s => Math.max(13, s - 1))}>A−</Btn>
      <Btn hue={hue} small onClick={() => setSize(s => Math.min(24, s + 1))}>A+</Btn>
      <Btn hue={hue} small active={showAr} onClick={() => setShowAr(a => !a)}>{showAr ? "Arabic shown" : "Arabic hidden"}</Btn>
      <label style={{ fontFamily: F.mono, fontSize: 10.5, color: "#ffffff88" }}>go to page{" "}
        <input inputMode="numeric" defaultValue="" placeholder={String(C.from)} onKeyDown={e => { if (e.key === "Enter") { const p = +e.target.value;
          if (p >= C.from && p <= C.to) { const el = root.current.querySelector(`[data-page="${p}"]`); el && el.scrollIntoView({ block: "start" }); }
          else if (p >= 1 && p <= 2401) go("kitab", { chapter: chapterOfPage(p), page: p, view: "read" }); } }}
          style={{ ...inputBase, width: 64, padding: "3px 6px", fontFamily: F.mono, fontSize: 12 }} /></label>
      {marks.length > 0 && <select value="" onChange={e => { const m = marks[+e.target.value]; if (m) go("kitab", { chapter: m.ch, page: m.p, view: "read" }); }}
        style={{ ...inputBase, padding: "3px 6px", fontSize: 12 }}>
        <option value="">bookmarks · {marks.length}</option>
        {marks.map((m, i) => <option key={i} value={i}>p.{m.p} · {CHNAME(m.ch)}</option>)}</select>}
    </div>
    <article ref={root} style={{ maxWidth: 760, fontSize: size, lineHeight: 1.85, color: "#e9e3d4", marginTop: 8 }}>
      {data.items.map((it, i) => {
        if (it.k === "pg") return <div key={i} data-page={it.p} style={{ display: "flex", alignItems: "center", gap: 8, margin: "18px 0 6px", color: "#ffffff44" }}>
          <span style={{ flex: 1, borderTop: "1px solid #ffffff12" }} />
          <button onClick={() => toggleMark(it.p)} title="bookmark this page" style={{ background: "none", border: "none", cursor: "pointer", fontFamily: F.mono, fontSize: 10.5,
            color: marks.some(m => m.p === it.p) ? "#e8c96a" : "#ffffff55" }}>{marks.some(m => m.p === it.p) ? "★" : "☆"} p.{it.p}</button></div>;
        if (it.k === "h1") return <h2 key={i} style={{ fontFamily: F.disp, fontSize: size * 1.75, color: "#f0ead9", fontWeight: 400, lineHeight: 1.25, margin: "26px 0 10px" }}>{hl(it.t, query)}</h2>;
        if (it.k === "h2") return <h3 key={i} style={{ fontFamily: F.disp, fontSize: size * 1.3, color: hue, fontWeight: 400, lineHeight: 1.3, margin: "22px 0 4px" }}>{hl(it.t, query)}</h3>;
        if (it.k === "src") return <div key={i} style={{ fontStyle: "italic", fontSize: size * 0.82, color: "#ffffff77", marginBottom: 8 }}>{it.t}</div>;
        if (it.k === "p") return <p key={i} style={{ margin: "0 0 0.9em", contentVisibility: "auto" }}>{withAnchors(it.t, query)}</p>;
        if (it.k === "ar") return showAr && data.img[it.src] ? <div key={i} style={{ margin: "6px 0 14px", textAlign: "center" }}>
          <img src={data.img[it.src]} alt="Arabic text as printed" loading="lazy"
            style={{ maxWidth: "100%", width: Math.min(it.w / 2.1, 700), filter: "invert(0.9) sepia(0.25)", opacity: 0.95 }} /></div> : null;
        if (it.k === "seal") return <div key={i} style={{ border: "1px solid #e8a25c44", background: "#3a1e1622", padding: "8px 12px", borderRadius: 3, margin: "6px 0 14px", fontSize: size * 0.85 }}>
          <span style={{ fontFamily: F.mono, fontSize: 10, color: "#e8a25c" }}>SEALED · p.{it.p} — </span>
          <span style={{ color: "#ffffffaa" }}>{it.t}</span>
          <div style={{ fontSize: 11.5, color: "#ffffff66", marginTop: 3 }}>a working aimed at harming, compelling or binding another person — named and cited, its method not carried</div></div>;
        if (it.k === "fig") { const f = figById.get(it.id); const src = !it.sealed;
          return <figure key={i} style={{ margin: "10px 0 18px", border: "1px solid #ffffff14", borderRadius: 3, padding: 10, background: "#00000033" }}>
            {src && <FigImage id={it.id} alt={f && f.note ? f.note : "figure"} />}
            {!src && <div style={{ fontFamily: F.mono, fontSize: 10.5, color: "#e8a25c" }}>figure of a sealed working — its image is not carried</div>}
            {f && <figcaption style={{ marginTop: 8 }}><FigCard f={f} hue={hue} /></figcaption>}
            {src && (BOOK.talismans || []).some(t => t.id === it.id) && <Btn hue={hue} small onClick={() => go("talasim", { id: it.id })}>open in Ṭalāsim · to read and sketch</Btn>}
          </figure>; }
        return null;
      })}
    </article>
    <div style={{ display: "flex", gap: 8, marginTop: 20 }}>
      {ch > 0 && <Btn hue={hue} onClick={() => go("kitab", { chapter: ch - 1, view: "read", page: BOOK.chapters.find(c => c.ch === ch - 1).from })}>← {CHNAME(ch - 1)}</Btn>}
      {ch < 21 && <Btn hue={hue} onClick={() => go("kitab", { chapter: ch + 1, view: "read", page: BOOK.chapters.find(c => c.ch === ch + 1).from })}>{CHNAME(ch + 1)} →</Btn>}
    </div>
  </div>;
}

/** Passages of given chapters that mention any of the terms — the book's own words on a subject, with their pages. */
function BookMentions({ chapters, terms, hue, limit = 40, title }) {
  const [rows, setRows] = useState(null);
  const [err, setErr] = useState(null);
  const [all, setAll] = useState(false);
  const key = terms.join("|");
  useEffect(() => {
    let live = true; setRows(null);
    Promise.all(chapters.map(c => loadChapter(c))).then(ds => {
      if (!live) return;
      const ft = terms.map(fold), out = [];
      for (const d of ds) { let page = null;
        for (const it of d.items) { if (it.k === "pg") page = it.p;
          if (it.k === "p" && ft.some(t => fold(it.t).includes(t))) out.push({ ch: d.ch, page, t: it.t }); } }
      setRows(out);
    }).catch(e => live && setErr(String(e)));
    return () => { live = false; };
  }, [key, chapters.join(",")]);
  const first = terms[0];
  return <div style={{ marginTop: 18, maxWidth: 780 }}>
    <div style={{ fontFamily: F.mono, fontSize: 10.5, letterSpacing: "0.12em", color: hue + "bb" }}>{title || "WHAT THE BOOK SAYS"}</div>
    {err && <div style={{ color: "#e8a25c", fontSize: 13, marginTop: 6 }}>The book's text could not be loaded here ({err}).</div>}
    {!rows && !err && <div style={{ color: "#ffffff66", fontFamily: F.mono, fontSize: 11, marginTop: 6 }}>reading the chapter…</div>}
    {rows && rows.length === 0 && <div style={{ color: "#ffffff77", fontSize: 13, marginTop: 6 }}>No passage in these chapters names it.</div>}
    {rows && (all ? rows : rows.slice(0, limit)).map((r, i) => <p key={i} style={{ fontSize: 14, lineHeight: 1.8, color: "#e9e3d4", margin: "8px 0" }}>
      {withAnchors(r.t, first)} <Cite page={r.page} hue={hue} /></p>)}
    {rows && rows.length > limit && !all && <Btn hue={hue} small onClick={() => setAll(true)}>all {rows.length} passages</Btn>}
  </div>;
}

function SearchPane({ hue, go }) {
  const [q, setQ] = useState("");
  const [idx, setIdx] = useState(null);
  const [err, setErr] = useState(null);
  const [scope, setScope] = useState("all");
  useEffect(() => { loadSearch().then(setIdx).catch(e => setErr(String(e))); }, []);
  const folded = useMemo(() => idx ? idx.map(r => fold(r[3])) : [], [idx]);
  const hits = useMemo(() => {
    if (!idx || q.trim().length < 3) return [];
    const s = fold(q.trim()), out = [];
    for (let i = 0; i < idx.length; i++) { const r = idx[i]; if (scope !== "all" && r[2] !== "h1" && r[2] !== "h2") continue;
      if (folded[i].includes(s)) { out.push(r); if (out.length >= 300) break; } }
    return out;
  }, [idx, q, scope, folded]);
  return <div style={{ marginTop: 14 }}>
    <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "flex-end" }}>
      <Field hue={hue} label="SEARCH THE WHOLE BOOK"><input value={q} onChange={e => setQ(e.target.value)} placeholder="a name, a verse, a word…"
        style={{ ...inputBase, width: "min(420px,80vw)", fontSize: 15 }} /></Field>
      <Btn hue={hue} small active={scope === "all"} onClick={() => setScope("all")}>everywhere</Btn>
      <Btn hue={hue} small active={scope === "head"} onClick={() => setScope("head")}>headings only</Btn>
    </div>
    {err && <div style={{ color: "#e8a25c", marginTop: 8 }}>The search index could not be loaded ({err}).</div>}
    {!idx && !err && <div style={{ color: "#ffffff66", fontFamily: F.mono, fontSize: 11, marginTop: 8 }}>loading the index…</div>}
    {q.trim().length >= 3 && idx && <div style={{ fontFamily: F.mono, fontSize: 11, color: "#ffffff88", marginTop: 8 }}>{hits.length >= 300 ? "300+" : hits.length} passages</div>}
    <div style={{ marginTop: 8, display: "grid", gap: 6, maxWidth: 860 }}>
      {hits.map((r, i) => { const s = r[3], [fs, mp] = foldMap(s), fat = fs.indexOf(fold(q.trim())), at = fat < 0 ? 0 : mp[fat], a = Math.max(0, at - 90);
        return <button key={i} onClick={() => go("kitab", { chapter: r[0], page: r[1], view: "read", query: q.trim() })}
          style={{ textAlign: "left", background: "#00000044", border: "1px solid #ffffff14", borderRadius: 3, padding: "8px 11px", color: "inherit", cursor: "pointer" }}>
          <div style={{ fontFamily: F.mono, fontSize: 10.5, color: hue }}>{CHNAME(r[0])} · p.{r[1]}{r[2] === "seal" ? " · sealed" : ""}</div>
          <div style={{ fontSize: 13.5, color: "#ffffffbb", lineHeight: 1.6 }}>{a > 0 ? "…" : ""}{hl(s.slice(a, at + 160), q.trim())}{at + 160 < s.length ? "…" : ""}</div>
        </button>; })}
    </div>
  </div>;
}


/* ═══ today — what the book gives to this day and this hour ═══ */
const DAY_TABLE = [  // p.115 table of the days, with the Fātiḥa verse of p.1787; the litany of ch.20
  { d: "Sunday",    planet: "sun",     letter: "ف", name: "فرد",  nameTr: "al-Fard",    angel: "روقيائيل", angelTr: "Rūqyāʾīl",   colour: "yellow", incense: "aloeswood", fatiha: "الحمد لله رب العالمين", wird: 2118 },
  { d: "Monday",    planet: "moon",    letter: "ج", name: "جبار", nameTr: "al-Jabbār",  angel: "جبرائيل",  angelTr: "Jabrāʾīl",   colour: "white",  incense: "musk",       fatiha: "الرحمن الرحيم", wird: 2121 },
  { d: "Tuesday",   planet: "mars",    letter: "ش", name: "شكور", nameTr: "al-Shakūr",  angel: "سمسمائيل", angelTr: "Samsamāʾīl", colour: "red",    incense: "sandalwood", fatiha: "مالك يوم الدين", wird: 2124 },
  { d: "Wednesday", planet: "mercury", letter: "ث", name: "ثابت", nameTr: "al-Thābit",  angel: "ميكائيل",  angelTr: "Mīkāʾīl",    colour: "blue",   incense: "mastic",     fatiha: "اياك نعبد واياك نستعين", wird: 2126 },
  { d: "Thursday",  planet: "jupiter", letter: "ظ", name: "ظهير", nameTr: "al-Ẓahīr",   angel: "صرفيائيل", angelTr: "Ṣarfiyāʾīl", colour: "green",  incense: "labdanum",   fatiha: "اهدنا الصراط المستقيم", wird: 2130 },
  { d: "Friday",    planet: "venus",   letter: "خ", name: "خبير", nameTr: "al-Khabīr",  angel: "عنيائيل",  angelTr: "ʿAnyāʾīl",   colour: "grey",   incense: "frankincense", fatiha: "صراط الذين انعمت عليهم", wird: 2132 },
  { d: "Saturday",  planet: "saturn",  letter: "ز", name: "زكي",  nameTr: "al-Zakī",    angel: "كسفيائيل", angelTr: "Kasfiyāʾīl", colour: "black",  incense: "harmal",     fatiha: "غير المغضوب عليهم ولا الضالين", wird: 2135 },
];
function TodayPane({ hue, go, cur }) {
  const now = new Date(), T = DAY_TABLE[now.getDay()];
  const M = manzilNow(now), mz = (DATA.manazil || []).find(m => m.n === M.n);
  const [visited] = useState(() => LS.get("visited", []));
  return <div style={{ marginTop: 14, maxWidth: 900 }}>
    <div style={{ fontSize: 14, color: "#ffffff99", lineHeight: 1.7, maxWidth: 720 }}>
      What the book assigns to this day and this hour, gathered from its tables — the day's letter, divine name, angel and
      verse of the Fātiḥa (pp.115, 1787), the litany chapter 20 gives for the day, and where the moon and the hour stand now.
      The conditions of the work (the prologue) come before any of it.</div>
    <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(250px,1fr))", gap: 10, marginTop: 14 }}>
      <div style={{ border: `1px solid ${hue}`, background: hue + "12", padding: 14, borderRadius: 3 }}>
        <div style={{ fontFamily: F.mono, fontSize: 10, color: hue }}>TODAY · {T.d.toUpperCase()} · {PLANETS[T.planet].n}</div>
        <div dir="rtl" style={{ fontFamily: F.ar, fontSize: 34, color: "#f0ead9", marginTop: 4 }}>{T.name} <span style={{ fontSize: 22, color: hue }}>{T.letter}</span></div>
        <div style={{ fontSize: 13, color: "#ffffffaa" }}>{T.nameTr} · {abjad(T.name)} · the day's letter {T.letter} ({abjad(T.letter)})</div>
        <div style={{ fontSize: 13, color: "#ffffffaa", marginTop: 6 }}>angel <span dir="rtl" style={{ fontFamily: F.ar, fontSize: 18 }}>{T.angel}</span> {T.angelTr}</div>
        <div style={{ fontSize: 13, color: "#ffffffaa" }}>colour {T.colour} · incense {T.incense}</div>
        <div style={{ marginTop: 6 }}><Cite page={115} hue={hue} /></div>
      </div>
      <div style={{ border: `1px solid ${hue}55`, padding: 14, borderRadius: 3 }}>
        <div style={{ fontFamily: F.mono, fontSize: 10, color: hue }}>THE DAY'S VERSE OF THE FĀTIḤA</div>
        <div dir="rtl" style={{ fontFamily: F.ar, fontSize: 24, color: "#f0ead9", marginTop: 6, lineHeight: 1.6 }}>{T.fatiha}</div>
        <div style={{ fontSize: 12, color: "#ffffff88" }}>{abjad(T.fatiha)} · <Cite page={1787} hue={hue} /></div>
      </div>
      <div style={{ border: `1px solid ${hue}55`, padding: 14, borderRadius: 3 }}>
        <div style={{ fontFamily: F.mono, fontSize: 10, color: hue }}>THE LITANY OF THE DAY · CHAPTER 20</div>
        <div style={{ fontSize: 15, color: "#f0ead9", marginTop: 6 }}>The wird of the blessed day of {T.d}</div>
        <Btn hue={hue} small onClick={() => go("kitab", { chapter: 20, page: T.wird, view: "read" })}>read it · p.{T.wird}</Btn>
      </div>
      <div style={{ border: `1px solid ${hue}55`, padding: 14, borderRadius: 3 }}>
        <div style={{ fontFamily: F.mono, fontSize: 10, color: hue }}>NOW</div>
        <div style={{ fontSize: 14, color: "#f0ead9", marginTop: 6 }}>hour of {cur ? PLANETS[cur.planet].n : "—"}{cur ? ` until ${fmt(cur.end)}` : ""}</div>
        {mz && <div style={{ fontSize: 13.5, color: "#ffffffaa", marginTop: 4 }}>moon in mansion {mz.n} · <span dir="rtl" style={{ fontFamily: F.ar, fontSize: 17 }}>{mz.ar}</span> {mz.tr} · letter {mz.letter}</div>}
        <div style={{ display: "flex", gap: 5, flexWrap: "wrap", marginTop: 8 }}>
          <Btn hue={hue} small onClick={() => go("hours")}>the hours</Btn>
          <Btn hue={hue} small onClick={() => go("manazil")}>the mansions</Btn>
          <Btn hue={hue} small onClick={() => go("kitab", { chapter: 0, view: "read", page: 40 })}>the conditions (prologue)</Btn>
        </div>
      </div>
    </div>
    <div style={{ fontFamily: F.mono, fontSize: 10.5, letterSpacing: "0.12em", color: hue + "bb", marginTop: 20 }}>YOUR READING</div>
    <div style={{ display: "grid", gap: 4, marginTop: 8 }}>
      {BOOK.chapters.map(c => { const n = visited.filter(p => p >= c.from && p <= c.to).length, tot = c.to - c.from + 1;
        return <button key={c.ch} onClick={() => go("kitab", { chapter: c.ch, view: "read", page: c.from })}
          style={{ display: "grid", gridTemplateColumns: "170px 1fr 70px", gap: 10, alignItems: "center", background: "none", border: "none", color: "inherit", cursor: "pointer", textAlign: "left", padding: "2px 0" }}>
          <span style={{ fontSize: 12.5, color: "#ffffffaa" }}>{CHNAME(c.ch)}</span>
          <span style={{ height: 5, background: "#ffffff14", borderRadius: 3, overflow: "hidden" }}><span style={{ display: "block", height: "100%", width: (100 * n / tot) + "%", background: hue }} /></span>
          <span style={{ fontFamily: F.mono, fontSize: 10.5, color: "#ffffff77" }}>{n}/{tot}</span></button>; })}
    </div>
  </div>;
}

/** A square set in the book's standard plate: the ruled frame crossing at the corners and the four archangels on its
 *  sides (Jibrāʾīl above, ʿAzrāʾīl right, Mīkāʾīl left, Isrāfīl below — as on the plates of chapter 19). Grid as printed. */
function FramedPlate({ grid, hue = "#ece6d8", size = 300 }) {
  const n = grid.length, cs = Math.max(18, Math.min(56, Math.floor((size - 90) / n))), side = n * cs;
  const pad = Math.round(cs * 0.9) + 26, W = side + pad * 2, o = pad;
  const off = Math.round(cs * 0.45) + 6, over = Math.round(cs * 0.35) + 6, a = o - off, b = o + side + off;
  const fs = Math.max(11, Math.min(18, cs * 0.42));
  return <svg viewBox={`0 0 ${W} ${W}`} width={W} height={W} style={{ maxWidth: "100%", height: "auto" }}>
    {grid.map((row, r) => row.map((v, c) => {
      const x = o + c * cs, y = o + r * cs, s = v == null ? "" : String(v), ar = /[؀-ۿ]/.test(s);
      return <g key={r + "-" + c}>
        <rect x={x} y={y} width={cs} height={cs} fill="none" stroke="#ffffff44" strokeWidth="0.8" />
        <text x={x + cs / 2} y={y + cs / 2} textAnchor="middle" dominantBaseline="central" fill="#ece6d8"
          fontFamily={ar ? F.ar : F.mono}
          fontSize={ar ? Math.min(cs * 0.5, cs * 1.7 / Math.max(2, [...s].length)) : cs * (s.length > 4 ? 0.22 : s.length > 3 ? 0.27 : 0.33)}>{s}</text>
      </g>; }))}
    {[[a - over, a, b + over, a], [a - over, b, b + over, b], [a, a - over, a, b + over], [b, a - over, b, b + over]].map(([x1, y1, x2, y2], i) =>
      <line key={i} x1={x1} y1={y1} x2={x2} y2={y2} stroke={hue} strokeWidth="1.6" />)}
    <text x={W / 2} y={a - 8} textAnchor="middle" fontFamily={F.ar} fontSize={fs} fill={hue}>جبرائيل</text>
    <text x={W / 2} y={b + fs + 4} textAnchor="middle" fontFamily={F.ar} fontSize={fs} fill={hue}>اسرافيل</text>
    <text x={a - 8} y={W / 2} textAnchor="middle" fontFamily={F.ar} fontSize={fs} fill={hue} transform={`rotate(-90,${a - 8},${W / 2})`}>ميكائيل</text>
    <text x={b + 8} y={W / 2} textAnchor="middle" fontFamily={F.ar} fontSize={fs} fill={hue} transform={`rotate(90,${b + 8},${W / 2})`}>عزرائيل</text>
  </svg>;
}

/** Figure images, cleaned and enlarged from the page, published beside the engine in packs of a hundred. */
const FIGPACK_CACHE = {};
function loadFigPack(k) {
  if (!FIGPACK_CACHE[k]) FIGPACK_CACHE[k] = fetch(`book/figs_${k}.json`)
    .then(r => { if (!r.ok) throw new Error(r.status); return r.json(); })
    .catch(e => { delete FIGPACK_CACHE[k]; throw e; });
  return FIGPACK_CACHE[k];
}
function FigImage({ id, alt, style }) {
  const [src, setSrc] = useState(null);
  useEffect(() => { let live = true; loadFigPack(Math.floor(id / 100)).then(p => live && setSrc(p[String(id)] || "")).catch(() => live && setSrc("")); return () => { live = false; }; }, [id]);
  if (src === null) return <div style={{ fontFamily: F.mono, fontSize: 10.5, color: "#ffffff55", padding: 8 }}>loading the figure…</div>;
  if (!src) return null;
  return <img src={src} alt={alt || "figure"} loading="lazy" style={{ display: "block", maxWidth: "100%", margin: "0 auto", filter: "invert(0.92) sepia(0.18)", ...style }} />;
}

/** The figures of the whole book in one place: talismans, seals, circles, squares — each clear, captioned and cited. */
function Gallery({ hue, go }) {
  const [kind, setKind] = useState("talismans");
  const [ch, setCh] = useState("all");
  const [open, setOpen] = useState(null);
  const sealed = useMemo(() => new Set(BOOK.sealedFigs || []), []);
  const list = BOOK.figs.filter(f => !sealed.has(f.id)
    && (kind === "all" || (kind === "talismans" ? f.status === "figure" : kind === "squares" ? !!f.grid : kind === "corrected" ? !!f.corrected : !!f.plain))
    && (ch === "all" || f.ch === +ch));
  return <div>
    <H2 hue={hue} sub="every figure of the book, cleaned and enlarged from the page — talismans, seals, circles and squares">Ashkāl</H2>
    <div style={{ display: "flex", gap: 6, flexWrap: "wrap", alignItems: "center" }}>
      {[["talismans", "talismans, seals & circles"], ["squares", "squares"], ["plain", "squares given their frame"], ["corrected", "corrected squares"], ["all", "everything"]].map(([k, l]) =>
        <Btn key={k} hue={hue} small active={kind === k} onClick={() => setKind(k)}>{l}</Btn>)}
      <select value={ch} onChange={e => setCh(e.target.value)} style={{ ...inputBase, padding: "4px 8px", fontSize: 12 }}>
        <option value="all">all chapters</option>
        {BOOK.chapters.map(c => <option key={c.ch} value={c.ch}>{CHNAME(c.ch)}</option>)}</select>
      <span style={{ fontFamily: F.mono, fontSize: 11, color: "#ffffff88" }}>{list.length} figures</span>
    </div>
    <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(240px,1fr))", gap: 10, marginTop: 14 }}>
      {list.map(f => <button key={f.id} onClick={() => setOpen(f)} style={{ textAlign: "left", background: "#00000044", border: "1px solid #ffffff18",
        borderRadius: 3, padding: 8, cursor: "zoom-in", color: "inherit" }}>
        <div style={{ height: 190, overflow: "hidden", display: "flex", alignItems: "center", justifyContent: "center" }}>
          {f.plain && f.grid ? <FramedPlate grid={f.grid} hue={hue} size={200} /> : <FigImage id={f.id} style={{ maxHeight: 186 }} />}</div>
        <div style={{ fontFamily: F.mono, fontSize: 10, color: hue, marginTop: 6 }}>#{f.id} · p.{f.page} · {CHNAME(f.ch)}</div>
        <div style={{ fontSize: 12, color: "#ffffffaa", lineHeight: 1.45, maxHeight: 52, overflow: "hidden" }}>{f.note || ""}</div>
      </button>)}
    </div>
    {open && <div onClick={() => setOpen(null)} style={{ position: "fixed", inset: 0, background: "#000000e6", zIndex: 50, overflowY: "auto", padding: "24px 16px" }}>
      <div onClick={e => e.stopPropagation()} style={{ maxWidth: 980, margin: "0 auto", background: "#0d0b08", border: `1px solid ${hue}55`, borderRadius: 4, padding: 16 }}>
        <div style={{ display: "flex", justifyContent: "space-between", gap: 8, flexWrap: "wrap", alignItems: "center" }}>
          <span style={{ fontFamily: F.mono, fontSize: 11, color: hue }}>#{open.id} · p.{open.page} · {CHNAME(open.ch)}</span>
          <span style={{ display: "flex", gap: 6 }}>
            <Btn hue={hue} small onClick={() => { setOpen(null); go("kitab", { chapter: open.ch, page: open.page, view: "read" }); }}>read the page</Btn>
            <Btn hue={hue} small onClick={() => setOpen(null)}>close</Btn></span>
        </div>
        <div style={{ marginTop: 12 }}><FigImage id={open.id} style={{ maxHeight: "75vh" }} /></div>
        {open.grid && <div style={{ display: "flex", justifyContent: "center", marginTop: 14 }}><FramedPlate grid={open.grid} hue={hue} size={460} /></div>}
        <div style={{ marginTop: 10 }}><FigCard f={open} hue={hue} /></div>
      </div>
    </div>}
  </div>;
}

/* ═══ ṭalāsim — the talismans, seals and circles of the book, one by one, to read and to sketch ═══ */
const SKETCH_CACHE = {};
function loadSketch(k) {
  if (!SKETCH_CACHE[k]) SKETCH_CACHE[k] = fetch(`book/sketch_${k}.json`).then(r => { if (!r.ok) throw new Error(r.status); return r.json(); })
    .catch(e => { delete SKETCH_CACHE[k]; throw e; });
  return SKETCH_CACHE[k];
}
/** Line art on paper, with an optional squared grid to copy by — the way a drawing is enlarged by hand. */
function SketchSheet({ id, grid, gridN, paper, onReady }) {
  const ref = useRef(null);
  const [src, setSrc] = useState(null);
  useEffect(() => { let live = true; loadSketch(Math.floor(id / 100)).then(p => live && setSrc(p[String(id)] || "")).catch(() => live && setSrc("")); return () => { live = false; }; }, [id]);
  useEffect(() => {
    if (!src || !ref.current) return;
    const img = new Image();
    img.onload = () => {
      const cv = ref.current, W = img.width, H = img.height, m = Math.round(Math.max(W, H) * 0.04);
      cv.width = W + 2 * m; cv.height = H + 2 * m;
      const g = cv.getContext("2d");
      g.fillStyle = paper ? "#ffffff" : "#0d0b08"; g.fillRect(0, 0, cv.width, cv.height);
      if (!paper) g.filter = "invert(1)";
      g.drawImage(img, m, m); g.filter = "none";
      if (grid) {
        const step = Math.max(W, H) / gridN;
        g.strokeStyle = paper ? "rgba(200,60,40,0.55)" : "rgba(232,201,106,0.5)"; g.lineWidth = Math.max(1, W / 900);
        g.font = `${Math.round(step * 0.22)}px monospace`; g.fillStyle = g.strokeStyle;
        for (let i = 0, x = m; x <= m + W + 0.5; i++, x += step) { g.beginPath(); g.moveTo(x, m); g.lineTo(x, m + H); g.stroke(); if (i < gridN) g.fillText(String.fromCharCode(65 + i), x + 3, m - 4); }
        for (let i = 0, y = m; y <= m + H + 0.5; i++, y += step) { g.beginPath(); g.moveTo(m, y); g.lineTo(m + W, y); g.stroke(); if (y < m + H) g.fillText(String(i + 1), 2, y + step * 0.5); }
      }
      onReady && onReady(cv);
    };
    img.src = src;
  }, [src, grid, gridN, paper]);
  if (src === null) return <div style={{ fontFamily: F.mono, fontSize: 11, color: "#ffffff66", padding: 10 }}>preparing the tracing…</div>;
  if (!src) return <div style={{ color: "#ffffff77", fontSize: 13 }}>No tracing for this figure.</div>;
  return <canvas ref={ref} style={{ width: "100%", height: "auto", display: "block", borderRadius: 3, border: "1px solid #ffffff22" }} />;
}

function Talismans({ hue, go, focus }) {
  const T = BOOK.talismans || [];
  const [q, setQ] = useState("");
  const [ch, setCh] = useState("all");
  const [sel, setSel] = useState(null);
  const [mode, setMode] = useState("clear");
  const [grid, setGrid] = useState(true);
  const [gridN, setGridN] = useState(8);
  const [paper, setPaper] = useState(true);
  const [notes, setNotes] = useState(() => LS.get("talismanNotes", {}));
  const canvasRef = useRef(null);
  useEffect(() => { if (focus && focus.id != null) { setSel(focus.id); setQ(""); setCh("all"); } }, [focus]);
  const list = T.filter(t => (ch === "all" || t.ch === +ch) && (!q || fold(t.title + " " + t.note + " " + t.text.join(" ")).includes(fold(q)) || String(t.page) === q.trim()));
  const cur = sel != null ? T.find(t => t.id === sel) : null;
  const idx = cur ? list.findIndex(t => t.id === cur.id) : -1;
  const saveNote = (v) => setNotes(n => { const x = { ...n, [cur.id]: v }; LS.set("talismanNotes", x); return x; });
  const downloadSheet = () => { const cv = canvasRef.current; if (!cv) return;
    cv.toBlob(b => b && saveBlob(`talisman-${cur.id}-p${cur.page}${grid ? "-grid" : ""}.png`, b), "image/png"); };
  return <div>
    <H2 hue={hue} sub="the talismans, seals, circles and tables of the book — each with its page, its words, a clear image and a tracing to sketch from">Ṭalāsim</H2>
    <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "flex-end" }}>
      <Field hue={hue} label="SEARCH"><input value={q} onChange={e => setQ(e.target.value)} placeholder="seal, circle, sorcery, a page…" style={{ ...inputBase, width: "min(320px,80vw)" }} /></Field>
      <select value={ch} onChange={e => setCh(e.target.value)} style={{ ...inputBase, padding: "6px 8px", fontSize: 12.5 }}>
        <option value="all">all chapters</option>
        {BOOK.chapters.filter(c => T.some(t => t.ch === c.ch)).map(c => <option key={c.ch} value={c.ch}>{CHNAME(c.ch)} · {T.filter(t => t.ch === c.ch).length}</option>)}</select>
      <span style={{ fontFamily: F.mono, fontSize: 11, color: "#ffffff88" }}>{list.length} of {T.length}</span>
    </div>
    <div style={{ display: "grid", gridTemplateColumns: cur ? "minmax(0,330px) minmax(0,1fr)" : "1fr", gap: 18, marginTop: 14 }} className="kitab-grid">
      <div style={{ maxHeight: cur ? "80vh" : "none", overflowY: cur ? "auto" : "visible" }}>
        <table style={{ borderCollapse: "collapse", width: "100%", fontSize: 13.5 }}>
          <thead><tr style={{ color: hue, fontFamily: F.mono, fontSize: 10.5, textAlign: "left" }}>
            {["#", "TALISMAN", "PAGE"].map(h => <th key={h} style={{ padding: "6px 10px 6px 0", borderBottom: `1px solid ${hue}44`, fontWeight: 400 }}>{h}</th>)}</tr></thead>
          <tbody>{list.map((t, i) => <tr key={t.id} onClick={() => setSel(t.id)} style={{ cursor: "pointer", borderBottom: "1px solid #ffffff11", background: sel === t.id ? hue + "1e" : "transparent" }}>
            <td style={{ padding: "6px 10px 6px 0", fontFamily: F.mono, color: "#ffffff66", verticalAlign: "top" }}>{T.indexOf(t) + 1}</td>
            <td style={{ padding: "6px 10px 6px 0", color: "#f0ead9", verticalAlign: "top" }}>{t.title}
              {!cur && <div style={{ fontSize: 11.5, color: "#ffffff77", lineHeight: 1.45 }}>{t.note.slice(0, 160)}{t.note.length > 160 ? "…" : ""}</div>}</td>
            <td style={{ padding: "6px 0", fontFamily: F.mono, fontSize: 11, color: hue, whiteSpace: "nowrap", verticalAlign: "top" }}>p.{t.page}</td></tr>)}</tbody>
        </table>
      </div>
      {cur && <div style={{ minWidth: 0 }}>
        <div style={{ display: "flex", justifyContent: "space-between", gap: 8, flexWrap: "wrap", alignItems: "center" }}>
          <div><div style={{ fontFamily: F.mono, fontSize: 10.5, color: hue }}>Ṭalāsim {T.indexOf(cur) + 1} · figure #{cur.id} · {CHNAME(cur.ch)} · <Cite page={cur.page} hue={hue} /></div>
            <div style={{ fontFamily: F.disp, fontSize: 24, color: "#f0ead9", lineHeight: 1.25 }}>{cur.title}</div></div>
          <div style={{ display: "flex", gap: 5 }}>
            <Btn hue={hue} small disabled={idx <= 0} onClick={() => setSel(list[idx - 1].id)}>‹ prev</Btn>
            <Btn hue={hue} small disabled={idx < 0 || idx >= list.length - 1} onClick={() => setSel(list[idx + 1].id)}>next ›</Btn>
            <Btn hue={hue} small onClick={() => setSel(null)}>close</Btn></div>
        </div>
        <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginTop: 12, alignItems: "center" }}>
          <Btn hue={hue} small active={mode === "clear"} onClick={() => setMode("clear")}>clear image</Btn>
          <Btn hue={hue} small active={mode === "sketch"} onClick={() => setMode("sketch")}>tracing to sketch</Btn>
          {mode === "sketch" && <>
            <Btn hue={hue} small active={grid} onClick={() => setGrid(g => !g)}>{grid ? "copy grid on" : "copy grid off"}</Btn>
            {grid && [6, 8, 12].map(n => <Btn key={n} hue={hue} small active={gridN === n} onClick={() => setGridN(n)}>{n}×{n}</Btn>)}
            <Btn hue={hue} small active={paper} onClick={() => setPaper(p => !p)}>{paper ? "on paper" : "on dark"}</Btn>
            <Btn hue="#e8c96a" small onClick={downloadSheet}>download sheet</Btn></>}
        </div>
        <div style={{ marginTop: 10, background: mode === "clear" ? "#00000055" : "transparent", borderRadius: 3, padding: mode === "clear" ? 10 : 0 }}>
          {mode === "clear" ? <FigImage id={cur.id} alt={cur.note} style={{ maxHeight: "70vh" }} />
            : <SketchSheet id={cur.id} grid={grid} gridN={gridN} paper={paper} onReady={cv => (canvasRef.current = cv)} />}
        </div>
        {mode === "sketch" && <div style={{ fontSize: 12.5, color: "#ffffff88", lineHeight: 1.6, marginTop: 6 }}>
          The tracing is the printed figure reduced to clean line. With the grid on, draw the same grid lightly on your paper and copy one
          square at a time (A1, B1 …): the proportions stay true at any size.</div>}
        <div style={{ fontFamily: F.mono, fontSize: 10.5, letterSpacing: "0.12em", color: hue + "bb", marginTop: 16 }}>WHAT IT IS</div>
        <div style={{ fontSize: 14, color: "#ffffffb8", lineHeight: 1.7, marginTop: 4 }}>{cur.note}</div>
        {cur.text.length > 0 && <>
          <div style={{ fontFamily: F.mono, fontSize: 10.5, letterSpacing: "0.12em", color: hue + "bb", marginTop: 14 }}>THE BOOK'S WORDS WITH IT</div>
          {cur.text.map((t, i) => <p key={i} style={{ fontSize: 14.5, color: "#e9e3d4", lineHeight: 1.8, margin: "6px 0" }}>{withAnchors(t, q)}</p>)}</>}
        <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginTop: 10 }}>
          <Btn hue={hue} small onClick={() => go("kitab", { chapter: cur.ch, page: cur.page, view: "read" })}>read it in the book · p.{cur.page}</Btn>
        </div>
        <Field hue={hue} label="YOUR NOTES ON THIS TALISMAN (kept on this device)">
          <textarea rows={3} value={notes[cur.id] || ""} onChange={e => saveNote(e.target.value)}
            style={{ ...inputBase, width: "100%", boxSizing: "border-box", fontSize: 14, marginTop: 4 }} /></Field>
      </div>}
    </div>
  </div>;
}

function FigCard({ f, hue }) {
  const [shown, setShown] = useState("grid");
  const ok = f.status === "verified" || f.status === "book-rule";
  const amber = "#e8b84f", red = "#e58a7a";
  const label = f.status === "verified" ? "✓ verified" : f.status === "book-rule" ? "✓ rebuilt from rule" : f.status === "eye" ? "read by eye"
    : f.status === "figure" ? "figure · described" : f.status === "queued" ? "grid · reading queued" : "not yet read";
  const g = shown === "printed" && f.printed ? f.printed : f.grid;
  return <div style={{ border: `1px solid ${f.issue ? "#8fce7f77" : ok ? "#8fce7f55" : f.status === "eye" ? amber + "55" : "#ffffff22"}`,
    background: "#00000044", padding: 9, borderRadius: 3, display: "flex", flexDirection: "column", gap: 6, minWidth: 0 }}>
    <div style={{ display: "flex", justifyContent: "space-between", gap: 8, fontFamily: F.mono, fontSize: 10.5, flexWrap: "wrap" }}>
      <span style={{ color: hue }}>#{f.id} · p.{f.page}{f.n ? ` · ${f.n}×${f.n}` : ""}{f.constant ? ` · Σ ${f.constant}` : ""}{f.diagonals ? " · diag ✓" : ""}</span>
      <span style={{ color: ok ? "#8fce7f" : f.status === "eye" ? amber : "#ffffff66" }}>{label}</span>
    </div>
    {f.same != null && <div style={{ fontFamily: F.mono, fontSize: 10, color: "#ffffff77" }}>repeats figure #{f.same}</div>}
    {f.printed && <div style={{ display: "flex", gap: 4 }}>
      {[["grid", "corrected"], ["printed", "as printed"]].map(([k, l]) => <button key={k} onClick={() => setShown(k)}
        style={{ background: shown === k ? hue + "22" : "transparent", border: `1px solid ${shown === k ? hue : "#ffffff22"}`, color: "#ffffffcc",
          fontFamily: F.mono, fontSize: 10, padding: "2px 7px", borderRadius: 2, cursor: "pointer" }}>{l}</button>)}</div>}
    {g && <div style={{ overflowX: "auto" }}><VisGrid vis={g} hue={hue} fit={Math.max(212, g.length * 30)}
      mark={f.printed && f.printed.length !== f.grid.length ? undefined : shown === "printed" && f.printed ? (r, c) => (f.printed[r][c] !== f.grid[r][c] ? `printed ${f.printed[r][c]} · should be ${f.grid[r][c]}` : null)
        : f.printed ? (r, c) => (f.printed[r][c] !== f.grid[r][c] ? `corrected from ${f.printed[r][c]}` : null) : undefined} /></div>}
    {f.panels && f.panels.map((p, j) => <div key={j}>
      {p.label && <div style={{ fontFamily: F.mono, fontSize: 10, color: hue, margin: "2px 0" }}>{p.label}{p.constant ? ` · Σ ${p.constant}` : ""}</div>}
      <div style={{ overflowX: "auto" }}><VisGrid vis={p.grid} hue={hue} fit={Math.max(212, p.grid.length * 30)} /></div></div>)}
    {f.table && <div style={{ overflowX: "auto" }}><VisGrid vis={f.table} hue={hue} fit={Math.max(212, f.table.length * 30)} /></div>}
    {f.closes === false && !f.printed && <div style={{ fontFamily: F.mono, fontSize: 10, color: red }}>does not close as printed</div>}
    {f.note && <div style={{ fontSize: 12, color: "#ffffff99", lineHeight: 1.5 }}>{f.note}</div>}
    {f.caption && f.caption !== f.note && <div style={{ fontSize: 11.5, color: "#ffffff66", lineHeight: 1.5, fontStyle: "italic" }}>{f.caption}</div>}
    {f.issue && <div style={{ fontSize: 12, color: "#8fce7f", lineHeight: 1.5, borderLeft: "2px solid #8fce7f88", paddingLeft: 7 }}>
      Correction (approved): {f.issue}</div>}
    {f.remark && <div style={{ fontSize: 12, color: amber, lineHeight: 1.5, borderLeft: `2px solid ${amber}88`, paddingLeft: 7 }}>
      {f.held ? "Printed as the rule gives it — " : "Remark — "}{f.remark}</div>}
    {f.plain && f.grid && <div style={{ marginTop: 2 }}><div style={{ fontFamily: F.mono, fontSize: 10, color: hue }}>printed without its frame — here in the plate of chapter 19</div>
      <div style={{ display: "flex", justifyContent: "center", marginTop: 4 }}><FramedPlate grid={f.grid} hue={hue} size={300} /></div></div>}
  </div>;
}

function WorkCard({ w, go }) {
  const col = CATCOL[w.cat] || "#a9a29a";
  if (w.cat === "sealed") return <div style={{ fontSize: 12.5, color: "#ffffff88", padding: "3px 0", borderBottom: "1px solid #ffffff0d" }}>
    <span style={{ fontFamily: F.mono, fontSize: 10.5, color: col }}>p.{w.p} · {w.n}. </span>{w.title}</div>;
  const chips = [...(w.days || []), ...(w.hour || []).map(h => PLANETS[h] ? `hour of ${h}` : h), ...(w.element || []).map(e => e + " form"),
    ...(w.form || []), ...(w.square || []).map(n => `${n}×${n}`), ...(w.material || []), ...(w.incense || []).map(i => "✻ " + i),
    ...(w.recite || []), ...(w.counts || []).map(c => `${c}×`), ...(w.moon || []).map(m => "☾ " + m)];
  return <div style={{ border: `1px solid ${col}44`, background: col + "0b", padding: "9px 11px", borderRadius: 3, minWidth: 0 }}>
    <div style={{ display: "flex", justifyContent: "space-between", gap: 8 }}>
      <span style={{ fontFamily: F.mono, fontSize: 10, color: col }}>{w.cat.toUpperCase()}</span>
      <button onClick={() => go("kitab", { chapter: chapterOfPage(w.p), page: w.p, view: "read" })} title="read the passage"
        style={{ background: "none", border: "none", cursor: "pointer", fontFamily: F.mono, fontSize: 10, color: "#ffffff99", padding: 0 }}>p.{w.p} · no.{w.n} · read ›</button></div>
    <div style={{ fontSize: 14, color: "#ece6d8", lineHeight: 1.5, marginTop: 3 }}>{w.title}</div>
    {chips.length > 0 && <div style={{ display: "flex", flexWrap: "wrap", gap: 4, marginTop: 6 }}>
      {chips.map((c, i) => <span key={i} style={{ fontFamily: F.mono, fontSize: 10.5, color: "#ffffffb0", border: "1px solid #ffffff22", padding: "1px 6px", borderRadius: 10 }}>{c}</span>)}</div>}
    {(w.square || []).length > 0 && <div style={{ marginTop: 6 }}><button onClick={() => go("forge", { order: w.square[0], value: (w.values || [])[0] })}
      style={{ background: "none", border: "1px solid #ffffff33", color: "#ffffffaa", fontFamily: F.mono, fontSize: 10, padding: "2px 7px", borderRadius: 2, cursor: "pointer" }}>
      open the {w.square[0]}×{w.square[0]} in the Forge</button></div>}
  </div>;
}

function Kitab({ hue, go, focus, cur }) {
  const [ch, setCh] = useState(focus && focus.chapter != null ? focus.chapter : 19);
  const [view, setView] = useState("overview");
  const [cat, setCat] = useState("all");
  const [rpage, setRpage] = useState(null);
  const [rquery, setRquery] = useState("");
  const [here, setHere] = useState(null);
  const last = LS.get("lastRead", null);
  useEffect(() => { if (!focus) return;
    if (focus.chapter != null) setCh(focus.chapter);
    if (focus.view) setView(focus.view);
    setRpage(focus.page || null); setRquery(focus.query || ""); }, [focus]);
  const C = BOOK.chapters.find(c => c.ch === ch) || BOOK.chapters[0];
  const secs = BOOK.outline.filter(o => o.ch === ch);
  const works = BOOK.workings.filter(w => w.ch === ch);
  const open = works.filter(w => w.cat !== "sealed"), sealed = works.filter(w => w.cat === "sealed");
  const figs = BOOK.figs.filter(f => f.ch === ch);
  const figsDone = figs.filter(f => f.status !== "unread" && f.status !== "queued").length;
  const [ff, setFf] = useState("all");
  const figIss = figs.filter(f => f.issue);
  const corr = DATA.corrections.filter(c => c.p && c.p >= C.from && c.p <= C.to);
  const nCorr = corr.length + BOOK.figs.filter(f => f.ch === ch && f.issue).length;
  const cats = [...new Set(open.map(w => w.cat))];
  const tot = BOOK.chapters.reduce((a, c) => ({ f: a.f + c.figs, fd: a.fd + c.figsDone, w: a.w + c.works }), { f: 0, fd: 0, w: 0 });
  const Bar = ({ v, m, col }) => <div style={{ height: 5, background: "#ffffff14", borderRadius: 3, overflow: "hidden", marginTop: 4 }}>
    <div style={{ width: (m ? 100 * v / m : 0) + "%", height: "100%", background: col }} /></div>;
  return <div>
    <H2 hue={hue} sub={`the book in its own order · ${BOOK.outline.length} headings from its contents · ${tot.w} numbered workings · ${tot.fd} of ${tot.f} figures read`}>Kitāb</H2>
    <div style={{ display: "grid", gridTemplateColumns: "minmax(0,250px) minmax(0,1fr)", gap: 22 }} className="kitab-grid">
      <nav aria-label="Chapters" style={{ display: "flex", flexDirection: "column", gap: 2, maxHeight: "78vh", overflowY: "auto" }}>
        {BOOK.chapters.map(c => <button key={c.ch} onClick={() => { setCh(c.ch); setView(v => (v === "read" || v === "search") ? "read" : "overview"); setRpage(c.from); }}
          style={{ textAlign: "left", background: c.ch === ch ? hue + "1e" : "transparent", border: "none",
            borderLeft: `2px solid ${c.ch === ch ? hue : "transparent"}`, color: "inherit", padding: "6px 9px", cursor: "pointer" }}>
          <div style={{ fontFamily: F.mono, fontSize: 10, color: c.ch === ch ? hue : "#ffffff77" }}>{CHNAME(c.ch)} · pp.{c.from}–{c.to}</div>
          <div style={{ fontSize: 12.5, color: c.ch === ch ? "#f0ead9" : "#ffffffaa", lineHeight: 1.35 }}>{c.short}</div>
          {c.figs > 0 && <Bar v={c.figsDone} m={c.figs} col={c.figsDone === c.figs ? "#8fce7f" : hue} />}
        </button>)}
      </nav>
      <div style={{ minWidth: 0 }}>
        <div style={{ fontFamily: F.mono, fontSize: 11, color: hue }}>{CHNAME(ch)} · pp.{C.from}–{C.to} · {C.to - C.from + 1} pages</div>
        <div style={{ fontFamily: F.disp, fontSize: 24, color: "#f0ead9", lineHeight: 1.25, marginTop: 4, maxWidth: 760 }}>{C.title}</div>
        <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginTop: 14 }}>
          {[["read","Read"],["overview","Overview"],["sections",`Sections · ${secs.length}`],["figures",`Figures · ${figsDone}/${figs.length}`],
            ["workings",`Workings · ${open.length}${sealed.length ? ` + ${sealed.length} sealed` : ""}`],["corrections",`Corrections · ${nCorr}`]]
            .map(([k, l]) => <Btn key={k} hue={hue} small active={view === k} onClick={() => { setView(k); if (k === "read") setRpage(null); }}>{l}</Btn>)}
          <span style={{ flex: 1 }} />
          <Btn hue="#e8c96a" small active={view === "today"} onClick={() => setView("today")}>☉ Today</Btn>
          <Btn hue="#e8c96a" small active={view === "search"} onClick={() => setView("search")}>⌕ Search the book</Btn>
        </div>
        {view === "read" && <ReadPane ch={ch} hue={hue} go={go} page={rpage} query={rquery} onPage={setHere} />}
        {view === "search" && <SearchPane hue={hue} go={go} />}
        {view === "today" && <TodayPane hue={hue} go={go} cur={cur} />}
        {view === "overview" && <div style={{ marginTop: 16 }}>
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 12 }}>
            <Btn hue={hue} onClick={() => { setRpage(C.from); setView("read"); }}>Read this chapter · {C.to - C.from + 1} pages</Btn>
            {last && <Btn hue="#e8c96a" onClick={() => go("kitab", { chapter: last.ch, page: last.p, view: "read" })}>Continue reading · p.{last.p}</Btn>}
          </div>
          {C.summary && <p style={{ fontSize: 15, lineHeight: 1.8, color: "#ffffffb8", maxWidth: 720 }}>{C.summary}</p>}
          <div style={{ display: "flex", gap: 10, flexWrap: "wrap", marginTop: 8 }}>
            {[["sections", secs.length], ["figures read", `${figsDone} / ${figs.length}`], ["workings", open.length],
              ["sealed", sealed.length], ["corrections", nCorr]].map(([l, v]) =>
              <div key={l} style={{ border: `1px solid ${hue}33`, padding: "8px 13px", borderRadius: 3 }}>
                <div style={{ fontFamily: F.mono, fontSize: 9.5, color: hue + "bb" }}>{String(l).toUpperCase()}</div>
                <div style={{ fontFamily: F.mono, fontSize: 18, color: "#f0ead9" }}>{v}</div></div>)}
          </div>
          {(CHAP_INSTR[ch] || []).length > 0 && <>
            <div style={{ fontFamily: F.mono, fontSize: 10.5, letterSpacing: "0.12em", color: hue + "bb", marginTop: 18 }}>INSTRUMENTS FOR THIS CHAPTER</div>
            <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginTop: 8 }}>
              {CHAP_INSTR[ch].map(([k, l]) => <Btn key={k + l} hue={hue} small onClick={() => go(k)}>{l}</Btn>)}</div></>}
          {secs.length > 0 && <>
            <div style={{ fontFamily: F.mono, fontSize: 10.5, letterSpacing: "0.12em", color: hue + "bb", marginTop: 18 }}>IN THE BOOK'S ORDER</div>
            <div style={{ marginTop: 6 }}>{secs.slice(0, 12).map((s, i) => <div key={i} style={{ display: "flex", gap: 10, fontSize: 13.5, padding: "3px 0", color: "#ffffffaa" }}>
              <span style={{ fontFamily: F.mono, fontSize: 10.5, color: hue, width: 46, flexShrink: 0 }}>p.{s.p}</span>
              <button onClick={() => { setRpage(s.p); setView("read"); }} style={{ background: "none", border: "none", padding: 0, color: "inherit", cursor: "pointer", textAlign: "left", font: "inherit" }}>{s.t}</button></div>)}
              {secs.length > 12 && <button onClick={() => setView("sections")} style={{ background: "none", border: "none", color: hue, fontFamily: F.mono, fontSize: 11, cursor: "pointer", padding: 0 }}>all {secs.length} →</button>}</div></>}
        </div>}
        {view === "sections" && <div style={{ marginTop: 14 }}>
          {secs.map((s, i) => { const nxt = secs[i + 1] ? secs[i + 1].p - 1 : C.to;
            const wn = works.filter(w => w.p >= s.p && w.p <= nxt).length, fn = figs.filter(f => f.page >= s.p && f.page <= nxt).length;
            return <div key={i} style={{ display: "flex", gap: 12, alignItems: "baseline", padding: "6px 0", borderBottom: "1px solid #ffffff0e" }}>
              <span style={{ fontFamily: F.mono, fontSize: 10.5, color: hue, width: 70, flexShrink: 0 }}>pp.{s.p}–{Math.max(s.p, nxt)}</span>
              <button onClick={() => { setRpage(s.p); setView("read"); }} style={{ flex: 1, fontSize: 14, color: "#ece6d8", minWidth: 0, textAlign: "left", background: "none", border: "none", padding: 0, cursor: "pointer" }}>{s.t}</button>
              <span style={{ fontFamily: F.mono, fontSize: 10, color: "#ffffff77", whiteSpace: "nowrap" }}>{fn ? `${fn} fig · ` : ""}{wn ? `${wn} work` : ""}</span></div>; })}
          {secs.length === 0 && <div style={{ color: "#ffffff77" }}>The book's contents list no sub-sections for this chapter; it runs as one exposition.</div>}
        </div>}
        {view === "figures" && <div style={{ marginTop: 14 }}>
          <div style={{ fontSize: 13, color: "#ffffff99", lineHeight: 1.7, maxWidth: 760, marginBottom: 12 }}>
            Each figure is read from the page image. A numeric square is shown only after its own arithmetic checks out; a
            figure that is a seal, a circle or cipher script is described and cited, not redrawn. Where the printed square
            does not close, the corrected square is shown with the printed one beside it and the changed cells marked;
            a square that cannot yet be repaired is held, never silently fixed. "Queued" and "not yet read" mark the work still to do.</div>
          <div style={{ display: "flex", gap: 5, flexWrap: "wrap", marginBottom: 10 }}>
            {[["all", figs.length], ["squares", figs.filter(f => f.grid).length], ["corrected", figs.filter(f => f.corrected).length],
              ["held", figs.filter(f => f.held).length], ["described", figs.filter(f => f.status === "figure").length],
              ["to do", figs.filter(f => f.status === "unread" || f.status === "queued").length]].filter(([k, n]) => k === "all" || n > 0)
              .map(([k, n]) => <Btn key={k} hue={hue} small active={ff === k} onClick={() => setFf(k)}>{k} · {n}</Btn>)}</div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(230px,1fr))", gap: 10 }}>
            {figs.filter(f => ff === "all" || (ff === "squares" && f.grid) || (ff === "corrected" && f.corrected) || (ff === "held" && f.held)
              || (ff === "described" && f.status === "figure") || (ff === "to do" && (f.status === "unread" || f.status === "queued")))
              .map(f => <FigCard key={f.id} f={f} hue={hue} />)}</div>
          {figs.length === 0 && <div style={{ color: "#ffffff77" }}>No figures in this chapter.</div>}
        </div>}
        {view === "workings" && <div style={{ marginTop: 14 }}>
          <div style={{ display: "flex", gap: 5, flexWrap: "wrap", marginBottom: 12 }}>
            <Btn hue={hue} small active={cat === "all"} onClick={() => setCat("all")}>all · {open.length}</Btn>
            {cats.map(k => <Btn key={k} hue={CATCOL[k] || hue} small active={cat === k} onClick={() => setCat(k)}>{k} · {open.filter(w => w.cat === k).length}</Btn>)}
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(300px,1fr))", gap: 8 }}>
            {open.filter(w => cat === "all" || w.cat === cat).map(w => <WorkCard key={w.id} w={w} go={go} />)}</div>
          {open.length === 0 && <div style={{ color: "#ffffff77" }}>No numbered workings in this chapter.</div>}
          {sealed.length > 0 && <div style={{ marginTop: 18, border: "1px solid #e8a25c44", background: "#3a1e1618", padding: 12, borderRadius: 3 }}>
            <div style={{ fontFamily: F.disp, fontSize: 18, color: "#e8a25c" }}>Sealed — indexed, not built · {sealed.length}</div>
            <div style={{ fontSize: 12.5, color: "#ffffff99", lineHeight: 1.6, margin: "4px 0 8px" }}>Workings aimed at harming, compelling or
              binding another person, kept as title and page only so the record is complete.</div>
            {sealed.map(w => <WorkCard key={w.id} w={w} go={go} />)}</div>}
        </div>}
        {view === "corrections" && <div style={{ marginTop: 14, display: "grid", gap: 8, maxWidth: 860 }}>
          {corr.map((c, i) => <div key={i} style={{ border: `1px solid ${hue}33`, padding: 11, borderRadius: 3 }}>
            <div style={{ display: "flex", justifyContent: "space-between", gap: 8 }}><span style={{ color: "#f0ead9", fontFamily: F.disp, fontSize: 16 }}>{c.says}</span><Cite page={c.p} hue={hue} /></div>
            <div style={{ fontSize: 13.5, color: "#ffffffa8", marginTop: 4, lineHeight: 1.6 }}>{c.correct}</div></div>)}
          {figIss.map(f => <div key={"f" + f.id} style={{ border: `1px solid ${f.held ? "#e58a7a55" : hue + "33"}`, padding: 11, borderRadius: 3 }}>
            <div style={{ display: "flex", justifyContent: "space-between", gap: 8 }}><span style={{ color: "#f0ead9", fontFamily: F.disp, fontSize: 16 }}>
              Figure #{f.id}{f.n ? ` · ${f.n}×${f.n}` : ""} — {f.held ? "held for re-reading" : "printed square corrected"}</span><Cite page={f.page} hue={hue} /></div>
            <div style={{ fontSize: 13.5, color: "#ffffffa8", marginTop: 4, lineHeight: 1.6 }}>{f.issue}</div></div>)}
          {nCorr === 0 && <div style={{ color: "#ffffff77" }}>No corrections logged in this chapter yet.</div>}
        </div>}
      </div>
    </div>
  </div>;
}

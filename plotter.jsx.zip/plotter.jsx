/* ═══ QALAM — the plotter: every square, seal and talisman of the book as pen lines a drawing machine can follow ═══
 * Squares and plates: the grid and frame as single lines; numbers in single-stroke digits (Western or Arabic-Indic);
 * Arabic words as the outlines of the Amiri face, shaped letter by letter from its presentation forms, with an optional hatch fill.
 * Talismans and figures: centerline tracings of the printed figure (one pen line per stroke), or its outlines for dense script.
 * Output: SVG in millimetres with numbered layers (AxiDraw / NextDraw / Inkscape), HPGL, and G-code for GRBL machines. */
const PAPERS = { A5: [148, 210], A4: [210, 297], Letter: [215.9, 279.4], A3: [297, 420] };
let PLOT_FONT_P = null;
function loadPlotFont() {
  if (!PLOT_FONT_P) PLOT_FONT_P = fetch("book/amiri-arabic.woff").then(r => { if (!r.ok) throw new Error(r.status); return r.arrayBuffer(); })
    .then(b => opentype.parse(b)).catch(e => { PLOT_FONT_P = null; throw e; });
  return PLOT_FONT_P;
}
const PLOTPACK = {};
function loadPlotPack(k) {
  if (!PLOTPACK[k]) PLOTPACK[k] = fetch(`book/plot_${k}.json`).then(r => { if (!r.ok) throw new Error(r.status); return r.json(); })
    .catch(e => { delete PLOTPACK[k]; throw e; });
  return PLOTPACK[k];
}

// ── Arabic shaping by presentation forms: [isolated, final, initial, medial]; two forms = joins on the right only ──
const AR_FORMS = (() => {
  const t = { "ء": [0xFE80], "آ": [0xFE81, 0xFE82], "أ": [0xFE83, 0xFE84], "ؤ": [0xFE85, 0xFE86], "إ": [0xFE87, 0xFE88], "ئ": [0xFE89, 0xFE8A, 0xFE8B, 0xFE8C],
    "ا": [0xFE8D, 0xFE8E], "ب": [0xFE8F], "ة": [0xFE93, 0xFE94], "ت": [0xFE95], "ث": [0xFE99], "ج": [0xFE9D], "ح": [0xFEA1], "خ": [0xFEA5],
    "د": [0xFEA9, 0xFEAA], "ذ": [0xFEAB, 0xFEAC], "ر": [0xFEAD, 0xFEAE], "ز": [0xFEAF, 0xFEB0], "س": [0xFEB1], "ش": [0xFEB5], "ص": [0xFEB9], "ض": [0xFEBD],
    "ط": [0xFEC1], "ظ": [0xFEC5], "ع": [0xFEC9], "غ": [0xFECD], "ف": [0xFED1], "ق": [0xFED5], "ك": [0xFED9], "ل": [0xFEDD], "م": [0xFEE1], "ن": [0xFEE5],
    "ه": [0xFEE9], "و": [0xFEED, 0xFEEE], "ى": [0xFEEF, 0xFEF0], "ي": [0xFEF1] };
  const o = {};
  for (const [c, f] of Object.entries(t)) o[c] = f.length === 1 && c !== "ء" ? [f[0], f[0] + 1, f[0] + 2, f[0] + 3] : f;
  o["ٱ"] = o["ا"]; o["ک"] = o["ك"]; o["ی"] = o["ي"]; o["ھ"] = o["ه"];
  return o;
})();
const LAM_ALEF = { "ا": [0xFEFB, 0xFEFC], "أ": [0xFEF7, 0xFEF8], "إ": [0xFEF9, 0xFEFA], "آ": [0xFEF5, 0xFEF6], "ٱ": [0xFEFB, 0xFEFC] };
const AR_MARKS = /[ً-ٰٟۖ-ۭ]/g;
const dualJoin = (c) => c === "ـ" || (AR_FORMS[c] && AR_FORMS[c].length === 4);
const joins = (c) => c === "ـ" || (AR_FORMS[c] && AR_FORMS[c].length >= 2);
/** Logical Arabic string → glyph characters in visual (left-to-right) order; digit runs keep their own order. */
function shapeArabic(s) {
  const ch = [...String(s).replace(AR_MARKS, "")];
  const out = [];
  for (let i = 0; i < ch.length; i++) {
    const c = ch[i], p = ch[i - 1], n = ch[i + 1];
    const jp = p != null && dualJoin(p) && joins(c);
    if (c === "ل" && n && LAM_ALEF[n]) { out.push(String.fromCharCode(LAM_ALEF[n][jp ? 1 : 0])); i++; continue; }
    const F = AR_FORMS[c];
    if (!F) { out.push(c); continue; }
    if (F.length === 1) { out.push(String.fromCharCode(F[0])); continue; }
    const jn = F.length === 4 && n != null && joins(n);
    out.push(String.fromCharCode(F[jp && jn ? 3 : jp ? 1 : jn ? 2 : 0]));
  }
  // visual order: reverse the whole run, then restore each run of digits / Latin to reading order
  const v = out.reverse(); const res = []; let buf = [];
  const isLtr = (c) => /[0-9A-Za-z٠-٩.]/.test(c);
  for (const c of v) { if (isLtr(c)) buf.push(c); else { if (buf.length) { res.push(...buf.reverse()); buf = []; } res.push(c); } }
  if (buf.length) res.push(...buf.reverse());
  return res;
}

// ── single-stroke digits, designed for the pen: unit box 0.5 wide, baseline 0, top −0.7 ──
const ellipse = (cx, cy, rx, ry, n = 18) => Array.from({ length: n + 1 }, (_, i) => [cx + rx * Math.sin(2 * Math.PI * i / n), cy - ry * Math.cos(2 * Math.PI * i / n)]);
const DIGIT_STROKES = {
  "0": [ellipse(0.25, -0.35, 0.18, 0.35)],
  "1": [[[0.14, -0.56], [0.27, -0.7], [0.27, 0]]],
  "2": [[[0.06, -0.55], [0.12, -0.67], [0.25, -0.7], [0.38, -0.66], [0.43, -0.55], [0.39, -0.42], [0.05, 0], [0.45, 0]]],
  "3": [[[0.06, -0.66], [0.2, -0.7], [0.36, -0.67], [0.42, -0.57], [0.37, -0.44], [0.2, -0.38], [0.38, -0.32], [0.45, -0.19], [0.4, -0.06], [0.24, 0], [0.05, -0.04]]],
  "4": [[[0.34, 0], [0.34, -0.7], [0.03, -0.2], [0.47, -0.2]]],
  "5": [[[0.42, -0.7], [0.1, -0.7], [0.07, -0.4], [0.22, -0.44], [0.38, -0.4], [0.45, -0.25], [0.4, -0.07], [0.24, 0], [0.05, -0.05]]],
  "6": [[[0.4, -0.66], [0.26, -0.7], [0.12, -0.62], [0.06, -0.4], [0.07, -0.15], [0.18, -0.01], [0.3, 0], [0.42, -0.08], [0.45, -0.22], [0.39, -0.36], [0.26, -0.4], [0.13, -0.35], [0.07, -0.25]]],
  "7": [[[0.05, -0.7], [0.45, -0.7], [0.18, 0]]],
  "8": [[[0.25, -0.38], [0.1, -0.45], [0.08, -0.58], [0.15, -0.68], [0.25, -0.7], [0.35, -0.68], [0.42, -0.58], [0.4, -0.45], [0.25, -0.38], [0.08, -0.28], [0.05, -0.14], [0.12, -0.03], [0.25, 0], [0.38, -0.03], [0.45, -0.14], [0.42, -0.28], [0.25, -0.38]]],
  "9": [[[0.43, -0.45], [0.37, -0.33], [0.25, -0.3], [0.12, -0.34], [0.06, -0.48], [0.1, -0.62], [0.24, -0.7], [0.37, -0.66], [0.44, -0.52], [0.42, -0.25], [0.34, -0.07], [0.22, 0], [0.1, -0.04]]],
  "٠": [[[0.25, -0.4], [0.3, -0.34], [0.25, -0.28], [0.2, -0.34], [0.25, -0.4]]],
  "١": [[[0.2, -0.7], [0.25, -0.42], [0.26, 0]]],
  "٢": [[[0.22, 0], [0.21, -0.5], [0.25, -0.6], [0.34, -0.6], [0.42, -0.65], [0.45, -0.72]]],
  "٣": [[[0.2, 0], [0.2, -0.54], [0.24, -0.66], [0.28, -0.58], [0.33, -0.67], [0.37, -0.6], [0.44, -0.72]]],
  "٤": [[[0.42, -0.7], [0.24, -0.67], [0.18, -0.57], [0.3, -0.48], [0.18, -0.44], [0.12, -0.3], [0.17, -0.08], [0.31, 0], [0.44, -0.04]]],
  "٥": [[[0.25, -0.48], [0.12, -0.35], [0.1, -0.14], [0.18, -0.02], [0.25, 0], [0.32, -0.02], [0.4, -0.14], [0.38, -0.35], [0.25, -0.48]]],
  "٦": [[[0.08, -0.7], [0.18, -0.62], [0.38, -0.63], [0.36, -0.4], [0.32, 0]]],
  "٧": [[[0.08, -0.7], [0.25, 0], [0.42, -0.7]]],
  "٨": [[[0.08, 0], [0.25, -0.7], [0.42, 0]]],
  "٩": [[[0.33, 0], [0.33, -0.5], [0.29, -0.65], [0.18, -0.68], [0.1, -0.58], [0.14, -0.46], [0.25, -0.43], [0.33, -0.5]]],
};
const DIGIT_W = 0.52;

/** Flatten an opentype path into closed rings of points. */
function pathRings(path) {
  const rings = []; let cur = null, x = 0, y = 0;
  for (const c of path.commands) {
    if (c.type === "M") { if (cur && cur.length > 2) rings.push(cur); cur = [[c.x, c.y]]; x = c.x; y = c.y; }
    else if (c.type === "L") { cur.push([c.x, c.y]); x = c.x; y = c.y; }
    else if (c.type === "Q") { for (let k = 1; k <= 6; k++) { const t = k / 6, u = 1 - t; cur.push([u * u * x + 2 * u * t * c.x1 + t * t * c.x, u * u * y + 2 * u * t * c.y1 + t * t * c.y]); } x = c.x; y = c.y; }
    else if (c.type === "C") { for (let k = 1; k <= 8; k++) { const t = k / 8, u = 1 - t; cur.push([u * u * u * x + 3 * u * u * t * c.x1 + 3 * u * t * t * c.x2 + t * t * t * c.x, u * u * u * y + 3 * u * u * t * c.y1 + 3 * u * t * t * c.y2 + t * t * t * c.y]); } x = c.x; y = c.y; }
    else if (c.type === "Z") { if (cur && cur.length > 2) { cur.push(cur[0]); rings.push(cur); } cur = null; }
  }
  if (cur && cur.length > 2) rings.push(cur);
  return rings;
}
/** Text → { lines: open single strokes (digits), fills: [rings] per glyph (letters) } centred on (cx, base), in source units. */
function plotText(font, text, cx, base, fs, rot = 0, rcx = cx, rcy = base) {
  const glyphs = shapeArabic(text);
  const isDigit = (g) => DIGIT_STROKES[g] != null;
  const scale = font ? fs / font.unitsPerEm : 0;
  const adv = glyphs.map(g => isDigit(g) ? DIGIT_W * fs : g === " " ? fs * 0.28 : font ? font.charToGlyph(g).advanceWidth * scale : 0);
  const total = adv.reduce((a, b) => a + b, 0);
  let x = cx - total / 2;
  const a = rot * Math.PI / 180, ca = Math.cos(a), sa = Math.sin(a);
  const R = ([px, py]) => rot ? [rcx + (px - rcx) * ca - (py - rcy) * sa, rcy + (px - rcx) * sa + (py - rcy) * ca] : [px, py];
  const lines = [], fills = [];
  glyphs.forEach((g, i) => {
    if (isDigit(g)) { for (const s of DIGIT_STROKES[g]) lines.push(s.map(([u, v]) => R([x + u * fs, base + v * fs]))); }
    else if (g !== " " && font) {
      const gl = font.charToGlyph(g);
      if (gl && gl.index > 0) { const rings = pathRings(gl.getPath(x, base, fs)).map(r => r.map(R)); if (rings.length) fills.push(rings); }
    }
    x += adv[i];
  });
  return { lines, fills };
}

/** A layout from layoutPlate → strokes on layers (source px). */
function plotFromLayout(L, font, opt) {
  const S = { frame: [], digits: [], letters: [] };
  const lettersFill = [];
  const add = (layer, { lines, fills }) => { for (const l of lines) S[layer === "letters" ? "digits" : layer].push(l); for (const f of fills) { lettersFill.push(f); for (const r of f) S.letters.push(r); } };
  // the grid: draw shared edges once
  const seen = new Set(); const edge = (x1, y1, x2, y2) => { const k = [x1, y1, x2, y2].map(v => Math.round(v * 10)).join(","), k2 = [x2, y2, x1, y1].map(v => Math.round(v * 10)).join(",");
    if (seen.has(k) || seen.has(k2)) return; seen.add(k); S.frame.push([[x1, y1], [x2, y2]]); };
  for (const it of L.items) {
    if (it.t === "rule") { S.frame.push([[it.x1, it.y1], [it.x2, it.y2]]); continue; }
    if (it.t === "label") { if (opt.labels !== false) add("letters", plotText(font, it.text, it.x, it.y, it.fs, it.rot || 0, it.x, it.y)); continue; }
    edge(it.x, it.y, it.x + it.w, it.y); edge(it.x + it.w, it.y, it.x + it.w, it.y + it.h); edge(it.x + it.w, it.y + it.h, it.x, it.y + it.h); edge(it.x, it.y + it.h, it.x, it.y);
    if (it.text) add("letters", plotText(font, it.text, it.x + it.w / 2, it.y + it.h / 2 + it.fs * 0.35, it.fs));
  }
  // merge collinear grid edges into long rules (fewer pen lifts)
  S.frame = mergeRules(S.frame);
  return { W: L.W, H: L.H, S, fills: lettersFill };
}
function mergeRules(segs) {
  const H = {}, V = {}, rest = [];
  for (const s of segs) { if (s.length !== 2) { rest.push(s); continue; } const [[x1, y1], [x2, y2]] = s;
    if (Math.abs(y1 - y2) < 0.01) (H[Math.round(y1 * 10)] = H[Math.round(y1 * 10)] || []).push([Math.min(x1, x2), Math.max(x1, x2), y1]);
    else if (Math.abs(x1 - x2) < 0.01) (V[Math.round(x1 * 10)] = V[Math.round(x1 * 10)] || []).push([Math.min(y1, y2), Math.max(y1, y2), x1]);
    else rest.push(s); }
  const out = [...rest];
  for (const k in H) { const a = H[k].sort((p, q) => p[0] - q[0]); let [s, e, y] = a[0];
    for (const [s2, e2] of a.slice(1)) { if (s2 <= e + 0.05) e = Math.max(e, e2); else { out.push([[s, y], [e, y]]); s = s2; e = e2; } } out.push([[s, y], [e, y]]); }
  for (const k in V) { const a = V[k].sort((p, q) => p[0] - q[0]); let [s, e, x] = a[0];
    for (const [s2, e2] of a.slice(1)) { if (s2 <= e + 0.05) e = Math.max(e, e2); else { out.push([[x, s], [x, e]]); s = s2; e = e2; } } out.push([[x, s], [x, e]]); }
  return out;
}
/** A figure's tracing (+ optional frame with the four angels and the written lines) → strokes (source px). */
function plotFromFigure(T, font, { mode = "c", above = "", below = "", frame = false, angels = DATA.angels4 || [] }) {
  const src = mode === "o" ? T.o : T.c;
  const fs = Math.max(14, Math.round(Math.max(T.w, T.h) * 0.045));
  const pad = frame ? fs * 2.6 : fs * 0.6;
  const top = pad + (above ? fs * 1.8 : 0), bot = pad + (below ? fs * 1.8 : 0);
  const W = T.w + pad * 2, H = T.h + top + bot;
  const S = { frame: [], digits: [], letters: [], figure: [] }; const fills = [];
  for (const p of src) { const pts = []; for (let k = 0; k < p.length; k += 2) pts.push([p[k] + pad, p[k + 1] + top]); S.figure.push(pts); }
  const addT = (t) => { for (const l of t.lines) S.digits.push(l); for (const f of t.fills) { fills.push(f); for (const r of f) S.letters.push(r); } };
  if (frame) {
    const m = fs * 0.5, x0 = m, y0 = (above ? fs * 1.8 : 0) + m, x1 = W - m, y1 = H - (below ? fs * 1.8 : 0) - m;
    const g = fs * 1.6;
    S.frame.push([[x0, y0], [x1, y0], [x1, y1], [x0, y1], [x0, y0]]);
    S.frame.push([[x0 + g, y0 + g], [x1 - g, y0 + g], [x1 - g, y1 - g], [x0 + g, y1 - g], [x0 + g, y0 + g]]);
    const nm = (side) => { const a = (angels || []).find(a => a.side === side); return a ? (a.ar || "") : ({ top: "جبرائيل", right: "عزرائيل", left: "ميكائيل", bottom: "اسرافيل" })[side]; };
    const cxm = (x0 + x1) / 2, cym = (y0 + y1) / 2, b = fs * 0.32;
    addT(plotText(font, nm("top"), cxm, y0 + g / 2 + b, fs * 0.8));
    addT(plotText(font, nm("bottom"), cxm, y1 - g / 2 + b, fs * 0.8));
    addT(plotText(font, nm("right"), x1 - g / 2 + b, cym, fs * 0.8, 90, x1 - g / 2 + b, cym));
    addT(plotText(font, nm("left"), x0 + g / 2 - b, cym, fs * 0.8, -90, x0 + g / 2 - b, cym));
  }
  if (above) addT(plotText(font, above, W / 2, fs * 1.25, fs));
  if (below) addT(plotText(font, below, W / 2, H - fs * 0.45, fs));
  return { W, H, S, fills };
}
/** Hatch the glyph fills (even–odd) at the given spacing and angle — all in final millimetres. */
function hatch(fills, sp, ang = 45) {
  const a = ang * Math.PI / 180, ca = Math.cos(a), sa = Math.sin(a);
  const rot = ([x, y]) => [x * ca + y * sa, -x * sa + y * ca], back = ([x, y]) => [x * ca - y * sa, x * sa + y * ca];
  const out = [];
  for (const rings of fills) {
    const R = rings.map(r => r.map(rot)); let mn = Infinity, mx = -Infinity;
    for (const r of R) for (const p of r) { mn = Math.min(mn, p[1]); mx = Math.max(mx, p[1]); }
    let flip = false;
    for (let y = Math.ceil(mn / sp) * sp; y < mx; y += sp) {
      const xs = [];
      for (const r of R) for (let i = 0; i < r.length - 1; i++) { const [x1, y1] = r[i], [x2, y2] = r[i + 1];
        if ((y1 <= y && y2 > y) || (y2 <= y && y1 > y)) xs.push(x1 + (y - y1) * (x2 - x1) / (y2 - y1)); }
      xs.sort((p, q) => p - q); if (flip) xs.reverse(); flip = !flip;
      for (let i = 0; i + 1 < xs.length; i += 2) if (Math.abs(xs[i + 1] - xs[i]) > sp * 0.2) out.push([back([xs[i], y]), back([xs[i + 1], y])]);
    }
  }
  return out;
}
/** Nearest-next ordering (and reversal) to keep the pen's travel short. */
function orderStrokes(strokes) {
  const rest = strokes.filter(s => s.length > 1).slice(), out = []; let cur = [0, 0];
  while (rest.length) {
    let bi = 0, bd = Infinity, rev = false;
    for (let i = 0; i < rest.length; i++) { const s = rest[i], a = s[0], b = s[s.length - 1];
      const d0 = (a[0] - cur[0]) ** 2 + (a[1] - cur[1]) ** 2, d1 = (b[0] - cur[0]) ** 2 + (b[1] - cur[1]) ** 2;
      if (d0 < bd) { bd = d0; bi = i; rev = false; } if (d1 < bd) { bd = d1; bi = i; rev = true; } if (bd === 0) break; }
    const s = rest.splice(bi, 1)[0]; const t = rev ? s.slice().reverse() : s; out.push(t); cur = t[t.length - 1];
  }
  return out;
}
const PLOT_LAYERS = [["frame", "1 · frame and grid"], ["figure", "2 · the figure"], ["digits", "3 · numbers"], ["letters", "4 · letters"], ["hatch", "5 · letter fill"]];
/** Fit onto paper → final job in mm: { layers: {name: [strokes]}, W, H, stats } */
function plotJob(src, o) {
  const [pw0, ph0] = PAPERS[o.paper] || PAPERS.A4; const [pw, ph] = o.landscape ? [ph0, pw0] : [pw0, ph0];
  const k = Math.min((pw - 2 * o.margin) / src.W, (ph - 2 * o.margin) / src.H) * (o.scale || 1);
  const ox = (pw - src.W * k) / 2, oy = (ph - src.H * k) / 2;
  const T = ([x, y]) => [ox + x * k, oy + y * k];
  const layers = {};
  for (const [n] of PLOT_LAYERS) if (src.S[n]) layers[n] = src.S[n].map(s => s.map(T));
  if (!o.outlineLetters) layers.letters = [];
  if (o.fill && src.fills.length) layers.hatch = hatch(src.fills.map(f => f.map(r => r.map(T))), o.spacing, 45);
  for (const n in layers) layers[n] = orderStrokes(layers[n]);
  // stats
  let down = 0, up = 0, lifts = 0, cur = [0, 0];
  for (const [n] of PLOT_LAYERS) for (const s of layers[n] || []) { up += Math.hypot(s[0][0] - cur[0], s[0][1] - cur[1]); lifts++;
    for (let i = 1; i < s.length; i++) down += Math.hypot(s[i][0] - s[i - 1][0], s[i][1] - s[i - 1][1]); cur = s[s.length - 1]; }
  const secs = down / 25 + up / 80 + lifts * 0.35;
  return { layers, W: pw, H: ph, k, stats: { down, up, lifts, secs } };
}
const f2 = (v) => Math.round(v * 100) / 100;
function jobSVG(J, pen, title = "") {
  let s = `<svg xmlns="http://www.w3.org/2000/svg" xmlns:inkscape="http://www.inkscape.org/namespaces/inkscape" width="${J.W}mm" height="${J.H}mm" viewBox="0 0 ${J.W} ${J.H}">`;
  if (title) s += `<title>${String(title).replace(/[<&>]/g, "")}</title>`;
  PLOT_LAYERS.forEach(([n, label], i) => { const st = J.layers[n]; if (!st || !st.length) return;
    s += `<g inkscape:groupmode="layer" inkscape:label="${label}" id="layer${i + 1}" fill="none" stroke="#000" stroke-width="${pen}" stroke-linecap="round" stroke-linejoin="round">`;
    for (const p of st) s += `<path d="M${p.map(q => f2(q[0]) + " " + f2(q[1])).join("L")}"/>`;
    s += "</g>"; });
  return s + "</svg>";
}
function jobHPGL(J) {
  let s = "IN;SP1;"; const u = (v) => Math.round(v * 40);
  for (const [n] of PLOT_LAYERS) for (const p of J.layers[n] || []) {
    s += `PU${u(p[0][0])},${u(J.H - p[0][1])};PD${p.slice(1).map(q => u(q[0]) + "," + u(J.H - q[1])).join(",")};\n`; }
  return s + "PU;SP0;\n";
}
function jobGcode(J, g) {
  let s = `; Iḥyāʾ Engine · Qalam — ${new Date().toISOString().slice(0, 10)}\nG21\nG90\n${g.up}\n`;
  const Y = (y) => f2(g.flip ? J.H - y : y);
  for (const [n] of PLOT_LAYERS) { const st = J.layers[n] || []; if (!st.length) continue; s += `; layer ${n}\n`;
    for (const p of st) { s += `G0 X${f2(p[0][0])} Y${Y(p[0][1])}\n${g.down}\n`; for (const q of p.slice(1)) s += `G1 X${f2(q[0])} Y${Y(q[1])} F${g.feed}\n`; s += `${g.up}\n`; } }
  return s + `G0 X0 Y0\n`;
}

/* ── the tool ── */
function Qalam({ hue, go, focus }) {
  const sealed = useMemo(() => new Set(BOOK.sealedFigs || []), []);
  const talBy = useMemo(() => new Map((BOOK.talismans || []).map(t => [t.id, t])), []);
  const figs = useMemo(() => BOOK.figs.filter(f => !sealed.has(f.id)), []);
  const [job, setJob] = useState(() => (focus && focus.job) || LS.get("qalamJob", null));
  useEffect(() => { if (focus && focus.job) { setJob(focus.job); } }, [focus]);
  useEffect(() => { if (job && job.kind === "figure") LS.set("qalamJob", { kind: "figure", id: job.id, above: job.above || "", below: job.below || "" }); }, [job]);
  const [font, setFont] = useState(null), [fontErr, setFontErr] = useState(false);
  useEffect(() => { loadPlotFont().then(setFont).catch(() => setFontErr(true)); }, []);
  const [trace, setTrace] = useState(null);
  useEffect(() => { setTrace(null); if (job && job.kind === "figure" && !sealed.has(job.id)) loadPlotPack(Math.floor(job.id / 100)).then(p => setTrace(p[String(job.id)] || false)).catch(() => setTrace(false)); }, [job && job.kind, job && job.id]);
  const [paper, setPaper] = useState(() => LS.get("qalamPaper", "A4")), [land, setLand] = useState(false);
  const [margin, setMargin] = useState(15), [pen, setPen] = useState(0.4), [fill, setFill] = useState(false), [spacing, setSpacing] = useState(0.35);
  const [outlineLetters, setOutlineLetters] = useState(true), [mode, setMode] = useState("c"), [frame, setFrame] = useState(false);
  const [above, setAbove] = useState(""), [below, setBelow] = useState("");
  const [g, setG] = useState(() => LS.get("qalamG", { up: "M5", down: "M3 S1000", feed: 3000, flip: true }));
  const [q, setQ] = useState("");
  useEffect(() => { LS.set("qalamPaper", paper); }, [paper]);
  useEffect(() => { LS.set("qalamG", g); }, [g]);
  useEffect(() => { if (job && job.kind === "figure") { setAbove(job.above || ""); setBelow(job.below || ""); setFrame(!!job.frame); } }, [job && job.id, job && job._n]);
  const fig = job && job.kind === "figure" ? figs.find(f => f.id === job.id) : null;
  const src = useMemo(() => {
    if (!job || !font && !fontErr) return null;
    if (job.kind === "layout" && job.L) return plotFromLayout(job.L, font, {});
    if (job.kind === "figure" && trace) return plotFromFigure(trace, font, { mode, above, below, frame });
    return null;
  }, [job, font, fontErr, trace, mode, above, below, frame]);
  const J = useMemo(() => src ? plotJob(src, { paper, landscape: land, margin, fill, spacing, outlineLetters }) : null, [src, paper, land, margin, fill, spacing, outlineLetters]);
  const svg = useMemo(() => J ? jobSVG(J, pen, job && job.title) : "", [J, pen]);
  const stem = job ? (job.kind === "figure" ? `qalam-figure-${job.id}` : `qalam-${(job.stem || "plate")}`) + `-${paper}` : "qalam";
  const list = q.trim() ? figs.filter(f => String(f.page) === q.trim() || String(f.id) === q.trim() || fold((talBy.get(f.id)?.title || "") + " " + (f.note || "")).includes(fold(q))) : figs;
  const label = { fontFamily: F.mono, fontSize: 10.5, letterSpacing: "0.12em", color: hue + "bb", marginTop: 14 };
  const mm = (v) => v >= 1000 ? (v / 1000).toFixed(1) + " m" : Math.round(v) + " mm";
  return <div>
    <H2 hue={hue} sub="the machine draws it in pen lines first; you write it by hand after — every square of the Forge, every open talisman and figure of the book">Qalam · the plotter</H2>
    <div style={{ display: "grid", gridTemplateColumns: "minmax(0,300px) minmax(0,1fr)", gap: 18 }} className="kitab-grid">
      <div>
        <div style={label}>WHAT TO DRAW</div>
        {job && <div style={{ fontSize: 13.5, color: "#ece6d8", marginTop: 4, lineHeight: 1.5 }}>{job.kind === "layout" ? job.title : (talBy.get(job.id)?.title || `figure #${job.id}`) + (fig ? ` · p.${fig.page}` : "")}</div>}
        <div style={{ fontSize: 12, color: "#ffffff88", lineHeight: 1.55, marginTop: 4 }}>Squares come here from the Forge and the Ashkāl Forge (“send to the plotter”). Any open figure of the book can be chosen below.</div>
        <input value={q} onChange={e => setQ(e.target.value)} placeholder="find a figure: seal, circle, a page…" style={{ ...inputBase, width: "100%", boxSizing: "border-box", marginTop: 8 }} />
        <div style={{ maxHeight: 300, overflowY: "auto", marginTop: 6, border: "1px solid #ffffff14" }}>
          {list.slice(0, 200).map(f => <div key={f.id} onClick={() => setJob({ kind: "figure", id: f.id, _n: Date.now() })}
            style={{ padding: "5px 8px", fontSize: 12.5, cursor: "pointer", borderBottom: "1px solid #ffffff0d", background: job && job.id === f.id ? hue + "22" : "transparent", color: "#ece6d8" }}>
            <span style={{ fontFamily: F.mono, fontSize: 10.5, color: hue }}>p.{f.page} </span>{talBy.get(f.id)?.title || (f.note || "").slice(0, 70)}</div>)}
          {list.length > 200 && <div style={{ fontSize: 11, color: "#ffffff66", padding: 6 }}>…{list.length - 200} more — narrow the search</div>}
        </div>

        <div style={label}>PAPER AND PEN</div>
        <div style={{ display: "flex", gap: 5, flexWrap: "wrap", marginTop: 4 }}>
          {Object.keys(PAPERS).map(p => <Btn key={p} hue={hue} small active={paper === p} onClick={() => setPaper(p)}>{p}</Btn>)}
          <Btn hue={hue} small active={land} onClick={() => setLand(x => !x)}>{land ? "landscape" : "portrait"}</Btn></div>
        <div style={{ display: "flex", gap: 10, flexWrap: "wrap", marginTop: 8, fontSize: 12, color: "#ffffffaa", fontFamily: F.mono }}>
          <label>margin <input type="number" min="5" max="60" value={margin} onChange={e => setMargin(+e.target.value || 15)} style={{ ...inputBase, width: 54, padding: "3px 5px" }} /> mm</label>
          <label>pen <input type="number" step="0.05" min="0.1" max="2" value={pen} onChange={e => setPen(+e.target.value || 0.4)} style={{ ...inputBase, width: 54, padding: "3px 5px" }} /> mm</label></div>
        {job && job.kind === "figure" && <>
          <div style={label}>THE FIGURE</div>
          <div style={{ display: "flex", gap: 5, flexWrap: "wrap", marginTop: 4 }}>
            <Btn hue={hue} small active={mode === "c"} onClick={() => setMode("c")}>single line</Btn>
            <Btn hue={hue} small active={mode === "o"} onClick={() => setMode("o")}>outlines</Btn>
            <Btn hue={hue} small active={frame} onClick={() => setFrame(x => !x)}>{frame ? "angels' frame on" : "frame off"}</Btn></div>
          <div style={{ fontSize: 11.5, color: "#ffffff77", lineHeight: 1.5, marginTop: 4 }}>Single line follows the middle of every printed stroke — best for rings, rules, letters and seals. Outlines trace both edges of each stroke — truer for dense, worn script.</div>
          <Field hue={hue} label="ABOVE"><input dir="rtl" value={above} onChange={e => setAbove(e.target.value)} style={{ ...inputBase, fontFamily: F.ar, fontSize: 16, width: "100%", boxSizing: "border-box" }} /></Field>
          <Field hue={hue} label="BELOW"><input dir="rtl" value={below} onChange={e => setBelow(e.target.value)} style={{ ...inputBase, fontFamily: F.ar, fontSize: 16, width: "100%", boxSizing: "border-box" }} /></Field>
        </>}
        <div style={label}>LETTERS</div>
        <div style={{ display: "flex", gap: 5, flexWrap: "wrap", marginTop: 4 }}>
          <Btn hue={hue} small active={outlineLetters} onClick={() => setOutlineLetters(x => !x)}>{outlineLetters ? "letter outlines on" : "letters left for the hand"}</Btn>
          <Btn hue={hue} small active={fill} onClick={() => setFill(x => !x)}>{fill ? "hatch fill on" : "no fill"}</Btn></div>
        {fill && <label style={{ display: "block", fontSize: 12, color: "#ffffffaa", fontFamily: F.mono, marginTop: 6 }}>fill spacing <input type="number" step="0.05" min="0.15" max="2" value={spacing} onChange={e => setSpacing(+e.target.value || 0.35)} style={{ ...inputBase, width: 54, padding: "3px 5px" }} /> mm</label>}
        <div style={{ fontSize: 11.5, color: "#ffffff77", lineHeight: 1.5, marginTop: 4 }}>Numbers are drawn in single strokes, the way a pen writes them. Arabic words are drawn as letter outlines in the Amiri naskh; vowel marks are left off — add them by hand.{fontErr ? " (The letter face could not be loaded, so only lines and numbers are drawn.)" : ""}</div>
      </div>

      <div style={{ minWidth: 0 }}>
        {!job && <div style={{ fontSize: 14, color: "#ffffffaa", lineHeight: 1.7, marginTop: 14 }}>Choose a figure on the left, or send a square here from the Forge.</div>}
        {job && job.kind === "figure" && sealed.has(job.id) && <div style={{ color: "#e8b84f", marginTop: 14 }}>This figure is sealed by your own rule and is not drawn.</div>}
        {job && job.kind === "figure" && trace === null && <div style={{ fontFamily: F.mono, fontSize: 11, color: "#ffffff66", marginTop: 14 }}>loading the tracing…</div>}
        {job && job.kind === "figure" && trace === false && <div style={{ color: "#ffffff88", marginTop: 14 }}>No tracing for this figure could be loaded.</div>}
        {job && !font && !fontErr && <div style={{ fontFamily: F.mono, fontSize: 11, color: "#ffffff66", marginTop: 14 }}>loading the letter face…</div>}
        {J && <>
          <div style={{ background: "#fff", borderRadius: 3, padding: 8, marginTop: 10, textAlign: "center" }}>
            <img alt="plotter preview" src={"data:image/svg+xml;charset=utf-8," + encodeURIComponent(svg)} style={{ maxWidth: "100%", maxHeight: "72vh", boxShadow: "0 0 0 1px #0002" }} /></div>
          <div style={{ fontFamily: F.mono, fontSize: 11, color: "#ffffffaa", marginTop: 6 }}>
            {paper}{land ? " landscape" : ""} · {Object.values(J.layers).reduce((a, l) => a + l.length, 0)} strokes · pen down {mm(J.stats.down)} · about {Math.max(1, Math.round(J.stats.secs / 60))} min at 25 mm/s
            {" · layers: "}{PLOT_LAYERS.filter(([n]) => (J.layers[n] || []).length).map(([, l]) => l).join(", ")}</div>
          <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginTop: 10 }}>
            <Btn hue="#e8c96a" small onClick={() => download(`${stem}.svg`, svg, "image/svg+xml")}>SVG (AxiDraw · NextDraw · Inkscape)</Btn>
            <Btn hue="#e8c96a" small onClick={() => download(`${stem}.hpgl`, jobHPGL(J), "application/vnd.hp-hpgl")}>HPGL</Btn>
            <Btn hue="#e8c96a" small onClick={() => download(`${stem}.gcode`, jobGcode(J, g), "text/plain")}>G-code (GRBL)</Btn>
            {fig && <Btn hue={hue} small onClick={() => go("shakl", { id: fig.id })}>open in the Ashkāl Forge</Btn>}
            {fig && <Btn hue={hue} small onClick={() => go("kitab", { chapter: fig.ch, page: fig.page, view: "read" })}>read it · p.{fig.page}</Btn>}
          </div>
          <details style={{ marginTop: 10 }}><summary style={{ cursor: "pointer", fontFamily: F.mono, fontSize: 11, color: hue }}>G-code pen commands</summary>
            <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginTop: 6, fontFamily: F.mono, fontSize: 11.5, color: "#ffffffaa" }}>
              <label>pen up <input value={g.up} onChange={e => setG({ ...g, up: e.target.value })} style={{ ...inputBase, width: 110, padding: "3px 5px" }} /></label>
              <label>pen down <input value={g.down} onChange={e => setG({ ...g, down: e.target.value })} style={{ ...inputBase, width: 110, padding: "3px 5px" }} /></label>
              <label>feed <input type="number" value={g.feed} onChange={e => setG({ ...g, feed: +e.target.value || 3000 })} style={{ ...inputBase, width: 70, padding: "3px 5px" }} /> mm/min</label>
              <Btn hue={hue} small active={g.flip} onClick={() => setG({ ...g, flip: !g.flip })}>{g.flip ? "origin bottom-left" : "origin top-left"}</Btn></div>
            <div style={{ fontSize: 11.5, color: "#ffffff77", marginTop: 4 }}>Servo pen-lift machines usually take M3 S… / M5; Z-axis machines take G0 Z… — set what your machine's manual gives.</div></details>
        </>}
        <QalamGuide hue={hue} />
      </div>
    </div>
  </div>;
}
function QalamGuide({ hue }) {
  const h = { fontFamily: F.mono, fontSize: 10.5, letterSpacing: "0.12em", color: hue + "bb", marginTop: 16 };
  const p = { fontSize: 13.5, color: "#ffffffbb", lineHeight: 1.7, margin: "6px 0" };
  const a = (href, t) => <a href={href} target="_blank" rel="noreferrer" style={{ color: hue }}>{t}</a>;
  return <details style={{ marginTop: 18, borderTop: "1px solid #ffffff14", paddingTop: 8 }} open>
    <summary style={{ cursor: "pointer", fontFamily: F.disp, fontSize: 18, color: "#f0ead9" }}>The machine — which to get, and how to feed it</summary>
    <div style={h}>WHICH MACHINE</div>
    <p style={p}><b>Bantam Tools NextDraw 1117</b> — the best fit. A3 (430 × 297 mm), takes pens up to 16 mm wide including fountain pens,
      drives from Inkscape, a command line or Python, and can plot an SVG straight from a USB stick with no computer attached. Listed around US$2,400.
      {" "}{a("https://shop.evilmadscientist.com/productsmenu/731", "maker's shop")} · {a("https://ca.robotshop.com/products/bantam-tools-nextdraw-1117-art-plotter-w-svg-player", "with the SVG Player")}</p>
    <p style={p}><b>UUNA TEK iDraw H (A3)</b> — the budget choice at about US$800; works through Inkscape and takes this page's SVG or G-code. The “iDraw H SE” model runs the AxiDraw software itself.
      {" "}{a("https://www.robotshop.com/products/uuna-tek-uuna-tek-174-idraw-h-version-pen-plotter-a3-size-handwriting-machine-xy-plotter-laser-engraver-without-base-plate", "iDraw H")} · {a("https://ca.robotshop.com/products/uuna-tek-idraw-h-se-a3-corexy-drawing-robot-artists-combines-the-robust-idraw-h-hardware-with-flexible-axidraw-software", "iDraw H SE")}</p>
    <p style={p}><b>AxiDraw SE/A3 (used)</b> — the classic; no longer made new, but common second-hand. Same Inkscape workflow as the NextDraw, and fountain pens (even an italic nib adapter) are supported.
      {" "}{a("https://shop.evilmadscientist.com/908", "Evil Mad Scientist")} · {a("https://all3dp.com/2/pen-plotters-best-xy-plotters/", "a survey of pen plotters")} · prices change; check before buying</p>
    <div style={h}>HOW TO FEED IT</div>
    <p style={p}>1 · Forge the square (or choose the figure), set the paper and pen width here, and download the SVG. It is already in millimetres and fitted to the sheet.</p>
    <p style={p}>2 · Open it in Inkscape. The drawing is split into numbered layers — 1 frame and grid, 2 the figure, 3 numbers, 4 letters, 5 letter fill — so you can plot one layer at a time and change pens between them (say, the grid in a fine pen, the letters in a broad nib).</p>
    <p style={p}>3 · AxiDraw / NextDraw: Extensions → AxiDraw (or NextDraw) Control → Layers, and plot layer 1, then 2… · iDraw: its Inkscape extension the same way, or the G-code file with its sender · older HP-style plotters: the HPGL file.</p>
    <p style={p}>4 · Plot in pencil or a light pen first if you mean to ink it by hand afterwards; the machine lays the geometry exactly, and your hand gives it the writing.</p>
    <div style={h}>WHAT THE MACHINE CANNOT DO</div>
    <p style={p}>The tracings follow the printed figures, which are small scans of the book; worn or dense script comes out as approximate line — read the figure in the book beside it. Vowel marks on letters are left for the hand. Figures sealed by your own rule are not offered.</p>
  </details>;
}

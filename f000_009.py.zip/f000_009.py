import math
def lt(x1, y1, x2, y2, s, size=30, **k): return dict(t="ltext", x1=x1, y1=y1, x2=x2, y2=y2, text=s, size=size, **k)
def on(cx, cy, r, deg): a = math.radians(deg); return (cx + r * math.sin(a), cy - r * math.cos(a))

# ── #9 · p.88 · the wafq of al-Thurayyā (letter jīm) ──
cx, cy, R1, R2 = 500, 610, 385, 330
L1, L2 = on(cx, cy, R1, -56), on(cx, cy, R2 + 6, -44)
R1r, R2r = on(cx, cy, R1, 56), on(cx, cy, R2 + 6, 44)
add(id="f9", fig=9, page=88, ch=2, group="square", title="The wafq of al-Thurayyā — the jīm square under its hood",
    desc="For the third mansion, al-Thurayyā, whose letter is jīm: made in its exaltation and carried, for access to the great and to gain one's object from them (p.88). A 3×3 of 49–57 round jīm, ringed by jīm and by Allah, under a hooded triangle of the same bands.",
    forge=dict(rule="second", order=3, value=53, centre="ج"),
    how=["The square is jīm's own: 53 in the centre written as the letter, the cells 49–57 round it, every line 159 (the same construction as Durūs lesson 10).",
         "Round it write “bismillāh” over and over, then a band of jīm, then Allah all round outside.",
         "Above, the hood: a band of jīm between two rules, “bismillāh” along its top and Allah along its sides.",
         "The book: made during the mansion's exaltation, and carried."],
    notes=["Read cell by cell from the facsimile (the fives are written in the Maghribī way, like an 8): ٥٢ ٥٧ ٥٠ / ٥١ ج ٥٥ / ٥٦ ٤٩ ٥٤ — exactly 49–57 on the Lo Shu with jīm (53) in the centre; every line 159.",
         "The rings read: an inner ring of بسم الله (seen as “ـسم … الله” in turn), a band of the letter ج, and an outer ring of الله.",
         "Correction: the engine had attached this figure to the paragraph on al-Buṭayn (p.87); it belongs to al-Thurayyā on p.88, whose letter is jīm — which the rings confirm.",
         "The marginal note at the right of the facsimile is illegible and is not reproduced."],
    w=1000, h=1060,
    els=[grid(380, 490, 240, fs=40),
         circle(R2 - 70, cx, cy), ring(R2 - 40, "بسم الله", 24, cx=cx, cy=cy, label="inner ring · bismillāh"),
         circle(R2, cx, cy), ring((R1 + R2) / 2 - 10, "ج", 32, cx=cx, cy=cy, rep=53, label="band of jīm"), circle(R1, cx, cy),
         ring(R1 + 26, "الله", 24, cx=cx, cy=cy, rep=66, label="outer ring · Allah"),
         # the hood
         line((30, 95), (970, 95)), line((95, 150), (905, 150)),
         line((30, 95), L1), line((95, 150), L2), line((970, 95), R1r), line((905, 150), R2r),
         lt(70, 66, 930, 66, "بسم الله", 24, fit="fill", label="hood · top"),
         lt(110, 124, 890, 124, "ج", 30, fit="fill", label="hood · band of jīm"),
         lt(250, 178, 750, 178, "الله", 22, fit="fill", label="hood · beneath"),
         lt(55, 125, L1[0] + 20, L1[1] - 40, "ج", 28, fit="fill", label="hood · left band"),
         lt(R1r[0] - 20, R1r[1] - 40, 945, 125, "ج", 28, fit="fill", label="hood · right band"),
         lt(8, 120, L1[0] - 30, L1[1] + 10, "الله", 22, fit="fill", label="hood · left side"),
         lt(R1r[0] + 30, R1r[1] + 10, 992, 120, "الله", 22, fit="fill", label="hood · right side"),
         text(500, 1035, "{name}", 30, maxw=600, label="your line (not in the book)", off=True)])

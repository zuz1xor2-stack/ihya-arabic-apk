# The Iḥyāʾ Engine — plan to carry the whole book

Goal (Al, 5 Oct 2026): the entirety of Amin Patel's *Iḥyāʾ Uṣūl al-Ḥikmah* (2nd ed., 2,401 pp.) inside the engine — every construction, every table, every operation — verified against the page, with mistakes found and corrected along the way.

Live page: https://claude.ai/artifact/LzY1UDQcRpVCyVka6iXeZH (pinned in the claude.ai sidebar).
Source of truth: `src/engine.jsx` published beside the page. `ledger.json` records what is done.
Book PDF: Google Drive, "Ihya (1).pdf", file id `1WTlAKtp5GYzeZhNVeYAHlBU58M9BDwa5`, folder "Saved from Chrome".

## House rules (carried from every earlier version)

1. Mashriqī abjad by default; every value recomputed from the letters, never copied from a table.
2. Whole numbers only. Every square re-summed before it is shown.
3. Every screen cites its page. Nothing constructed is presented as the book's; provenance is labelled (book · sister edition · tradition · engine-computed).
4. A full verification suite runs before every publish.
5. Harm-directed material (taskhīr of a person, enmity, binding, inflicting illness, suflī spirits) stays indexed and cited, with the tradition's conditions shown, and is never rendered as an operable procedure.
6. Corrections are found by arithmetic or by the printed figure, logged in Taṣḥīḥāt with page, what the book says, what is right, and how it was checked.

## Method (established in v1.4)

- Text: `pdftotext -layout`, one file per page (pdf page = printed page number).
- Figures: the grids are drawn as vector text, not readable by text extraction but clean when the page is rendered (`pdftoppm -r 110…200`) and read visually. Manuscript facsimiles use Arabic-Indic numerals and are also legible.
- A transcription is accepted only if it passes its own arithmetic (uses the expected numbers once, rows/columns/diagonals agree, or reproduces the rule the text states). A single bad cell is resolved by the permutation constraint and logged as a correction, never silently fixed.

## Phases

| Phase | Scope | Size | Status |
|---|---|---|---|
| 1 | Ch.19 construction rules, natural forms 3–9, stations, ʿulwī spirits, istinṭāq | — | **done (v1.4)** |
| 2 | Read every figure page: 672 pages carry figures; 567 still unread | ~25 pages per session → ~25 sessions | next |
| 3 | Operations: every numbered working (≈534 counted, more unnumbered) as a structured record — purpose, name/verse, value, square type/order/element, day/hour, materials, counts, page — opening its square in the Forge; harm-directed ones at catalogue level only | ch.12, 14, 16, 19, 20 first | after 2 starts |
| 4 | Chapter expositions in full: ch.2 basṭ/istinṭāq (verify the 1047/594/1641/991 chain), ch.3 mansions from the book's own table, ch.4 signs, ch.5 Basmala, ch.9–10 Fātiḥa, ch.13 sawāqiṭ squares, ch.17 KHYʿṢ, ch.18 Āyat al-Kursī | per chapter | ongoing |
| 5 | Ch.19 remaining: hollow-centre 5×5 (air/water ÷66, fire/earth ÷65), fraction-free 5×5 element forms, 3×3 element forms, remainder forms for 6–9, the 10×10 rules, triangle wafq | — | queued |
| 6 | Ch.20 daily awrād by day, and the Yā-Sīn / Ikhlāṣ / Fātiḥa workings | — | queued |
| 7 | Review loop: a Review tab where Al approves or flags each transcription and correction | — | proposed |
| 8 | Print tie-in: the corrected text and figures feed the hardcover "corrected set" | — | later |

## Session protocol

1. Read `PLAN.md` and `ledger.json` from the artifact (Artifact `read`, `path`), and `src/engine.jsx`.
2. Fetch the PDF: Al sets link sharing on, then `curl -L "https://drive.usercontent.google.com/download?id=1WTlAKtp5GYzeZhNVeYAHlBU58M9BDwa5&export=download&confirm=t"`.
3. Take the next batch from the ledger; transcribe, verify, and add to `src/engine.jsx` (data and UI).
4. `bash build/build.sh` (runs `tests/`), smoke-test in Chromium, then republish the page with `src/`, `tests/`, `build/`, `PLAN.md`, `ledger.json` as its files.
5. Update the ledger and tell Al what was added, what was corrected, and what is next.

## Status at v1.5 (2026-10-05)
- The engine opens on **Kitāb**: the book's 21 chapters plus front matter, each with its sections, figures, workings and corrections.
- Figures: 539 found; 281 read (57 machine-verified, 133 read by eye and checked line by line, 91 described). 17 misprinted squares are corrected and shown beside the printed version; 4 squares (7 figures with their repeats: 467, 469, 480, 482) are held until they can be repaired from their rules; 506 is flagged (one cell repairable, one still open).
- Next: the 162 queued grids, then the 96 unread figures, then the held squares.

## Status at v1.6 (2026-10-05)
- Every one of the 539 figures is read. 57 were verified by machine, 302 read by eye and checked line by line, and 180 (seals, circles, manuscript facsimiles, cipher) are described and cited.
- 37 printed squares are corrected beside the printed version, each correction found from the square's own arithmetic or structure. Two (467, 482) are held: their numbers are printed as the rule gives them, but the lift cannot close on the form the book used.
- The Forge's bands were replaced by the book's own ḥāshiya (written lines above and below the frame).
- The letters' elements and planets now follow chapter 1 and p.111.
- New: the basṭ instrument (chapter 2).
- Next: chapter expositions in full, the hollow-centre fivefold rule as a Forge build, chapter 20 awrād, and a Review tab.

## Status at v1.7 (2026-10-05)
- The whole book can now be read inside the engine: Kitāb → Read, chapter by chapter. The text is published beside the engine in book/ch00–ch21.json, with a text-only search index in book/search.json.
- The PDF's Arabic text layer is garbled, so the Arabic is carried as images clipped from the printed page.
- New: search, bookmarks, Today, and citations that open the book at their page.
- The corrected book (the deliverable after the system is complete): the same reading text with every correction in the ledger applied and noted, exported as a document.

## Status at v2.5 (2026-10-09)
- New tab **Ashkāl Forge** (Kitāb group, beside Ashkāl): every open figure forged for a name, text or number. Squares are rebuilt by `src/shakl.mjs` (own arrangement · carried · top row · ḍarb · letters) and tested by `tests/test_shakl.mjs`; other figures are set as framed plates. UI source in `tools/shaklforge.jsx`, pasted into `src/engine.jsx` before `const TABS`.

## Status at v2.6 (2026-10-10)
- Today rebuilt as Al's daily page: the day (p.115, p.1787, ch.20 in full), the hours (pp.115–117, prayer times, qibla), the moon (p.43, mansions pp.214–245), workings set on the day, practice tools kept per date, and the week ahead. UI source in `tools/today.jsx`, pasted into `src/engine.jsx` in place of the old TodayPane; tested by `tests/test_today.mjs` (needs `book/ch20.json` beside `kit/`).

## Status at v2.7 (2026-10-10)
- Cross-table audit of the correspondences; five new corrections applied to the reading text by `tools/patch4.py` (idempotent) and logged in Taṣḥīḥāt; reader renders `corr` items. Edition rebuilt with `tools/make_book.py` (renders `corr`) and `tools/merge_volumes.py` (two volumes, pp.1–1099 and 1100–2401). `tests/test_today.mjs` checks every correction against the text.

## Status at v2.8 (2026-10-10)
- Ālāt → Today (`tools/alat_today.jsx`). Taḥqīq: `tools/verify_review.mjs` re-verifies every Review item and writes `data/review_verify.json`, spliced in as REVIEW_VERIFY by `tools/splice_rv.py`; build.sh runs both and stops if any item fails.

## Status at v3.0 shell (2026-10-29)
- The engine is now also the website shamsalmaarif.org (GitHub Pages, repo demalhagie84/shams-al-maarif, branch main; the old site is on branch old-site). Deploy = upload `ihya-engine.html` as `index.html` (book/ is already there). robots.txt and a noindex meta keep it out of search engines.
- New shell (`tools/shell.jsx`, spliced over the old TABS/App by `tools/splice_shell.py`, which build.sh runs first): grouped sidebar with plain-English labels and icons, sticky top bar with the hour and countdown, pins, recents, hash routes (#/forge), back button, Ctrl/⌘K command palette (modules, chapters, headings, workings, names, talismans, Arabic → value → Forge, number → Forge or page, full-text book search), Settings sheet, mobile drawer + bottom bar.
- New modules: Home (day, hour, next hours, moon and mansion, reckon-a-name, continue reading, journal, pinned) and Journal (entries stamped with day, hour, mansion, lunar day; export/import JSON). Book search accepts a query from the palette.
- Next: light "parchment" theme (needs the inline colours moved to tokens), per-module polish.

## Status at v3.1 (2026-10-29) — al-Muʿallim and the Ṭilasm Studio
- al-Muʿallim (tools/khadim.jsx): Claude through the artifact's `sample` capability, with the engine as tools (search_book, read_book_pages, engine_lookup, find_workings, divine_names, abjad, make_square, find_times, journal, compose_talisman, open_in_engine). Teacher persona; deep model by default. On the public site it points to the Claude copy.
- Ṭilasm Studio (tools/tilasm.jsx renderer, tools/tilasm_ui.jsx UI, specs from tools/tilasm_specs.py → book/tilasm.json): every talisman as geometry (strokes + glyph outlines from amiri-arabic.woff) so screen, SVG, PNG and the plotter agree. 445 book figures: the printed figure carried as vector (plot packs' outlines + centre-lines); for squares, the cells' contents are cut and the square rebuilt for the user's value (grid boxes in tools/tilasm_gridbox.json, detected from the rulings). Hand reconstructions in tools/tilasm_book/*.py (#9 al-Thurayyā jīm square; #203, #226, #297, #512, #106 hybrids). Durūs lessons 3,4,5,8,10,11,12 as compositions. #364, #365, #390 kept sealed (taskhīr of a person).
- The Ashkāl Forge shows a forged square inside its whole printed figure (TilasmWhole).
- tools/patch_figs.py corrects figure records (titles, notes, misattributions: #9, #75 …).
- Next: more hand reconstructions (rings with fulān slots, seal-sign squares), the al-Sirr figures in the Studio.

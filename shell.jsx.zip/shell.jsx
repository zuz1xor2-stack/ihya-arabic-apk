/* ═══ v3.0 shell — sidebar, command palette, Home, Journal. Spliced in place of the old TABS/App by tools/splice_shell.py ═══ */

/* ── line icons (24-grid, stroke) ── */
const ICON_PATHS = {
  home: "M3 11 12 4l9 7M5 10v10h5v-6h4v6h5V10",
  spark: "M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8L12 3zM19 15l.8 2.2L22 18l-2.2.8L19 21l-.8-2.2L16 18l2.2-.8L19 15z",
  sun: "M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8zM12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4",
  pen: "M4 20h4L19 9l-4-4L4 16v4zM14 6l4 4",
  gem: "M6 3h12l3 6-9 12L3 9l3-6zM3 9h18M9 3l3 18 3-18",
  book: "M4 4h6a3 3 0 0 1 2 1 3 3 0 0 1 2-1h6v15h-6a2 2 0 0 0-2 2 2 2 0 0 0-2-2H4V4zM12 5v16",
  star: "M12 3l2.6 5.6 6 .7-4.5 4.1 1.3 6L12 16.4 6.6 19.4l1.3-6L3.4 9.3l6-.7L12 3z",
  grid: "M4 4h16v16H4zM4 9.3h16M4 14.6h16M9.3 4v16M14.6 4v16",
  hex: "M12 2.5 20.5 7.3v9.4L12 21.5l-8.5-4.8V7.3L12 2.5zM12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8z",
  para: "M13 4v16M17 4v16M10 4h9M13 13H9.5a4.5 4.5 0 0 1 0-9H13",
  scale: "M12 3v18M7 21h10M5 7h14M5 7l-3 7a3 3 0 0 0 6 0L5 7zM19 7l-3 7a3 3 0 0 0 6 0l-3-7z",
  key: "M15 3a6 6 0 1 0 0 12 6 6 0 0 0 0-12zM10.8 13.2 3 21M6 18l2 2M4 20l1.5 1.5",
  list: "M9 6h11M9 12h11M9 18h11M4 6h.01M4 12h.01M4 18h.01",
  clock: "M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18zM12 7v5l3 2",
  chat: "M4 5h16v11H8l-4 4V5z",
  moon: "M20 14.5A8.5 8.5 0 1 1 9.5 4a7 7 0 0 0 10.5 10.5z",
  orbit: "M12 9a3 3 0 1 0 0 6 3 3 0 0 0 0-6zM12 3c5 0 9 4 9 9M3 12c0-5 4-9 9-9M21 12c0 5-4 9-9 9M3 12c0 5 4 9 9 9",
  letter: "M5 19 12 4l7 15M8 13h8",
  expand: "M4 14v6h6M20 10V4h-6M4 20l7-7M20 4l-7 7",
  names: "M12 3c3 4 3 14 0 18M12 3c-3 4-3 14 0 18M3.5 9h17M3.5 15h17M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18z",
  open: "M3 7l9-4 9 4-9 4-9-4zM3 12l9 4 9-4M3 17l9 4 9-4",
  shield: "M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6l8-3z",
  rules: "M4 4h16v16H4zM8 8h3v3H8zM13 13h3v3h-3zM13 8h3M8 16h3",
  seal: "M12 2l2.2 2.8 3.5-.4.6 3.5 3.1 1.7-1.6 3.2 1.6 3.2-3.1 1.7-.6 3.5-3.5-.4L12 22l-2.2-2.8-3.5.4-.6-3.5-3.1-1.7L4.2 12 2.6 8.8l3.1-1.7.6-3.5 3.5.4L12 2z",
  sheet: "M6 2h9l5 5v15H6V2zM15 2v5h5",
  library: "M4 20V4M8 20V4M12 20l4-16 4 16M2 20h20",
  plot: "M3 21l6-6M9 15l3-9 9-3-3 9-9 3zM14 10a1 1 0 1 0 0-2 1 1 0 0 0 0 2z",
  beads: "M12 3a2 2 0 1 0 0 4 2 2 0 0 0 0-4zM6 7a2 2 0 1 0 0 4 2 2 0 0 0 0-4zM18 7a2 2 0 1 0 0 4 2 2 0 0 0 0-4zM5 14a2 2 0 1 0 0 4 2 2 0 0 0 0-4zM19 14a2 2 0 1 0 0 4 2 2 0 0 0 0-4zM12 18a2 2 0 1 0 0 4 2 2 0 0 0 0-4z",
  scroll: "M7 4h11a2 2 0 0 1 2 2v1h-4M7 4a2 2 0 0 0-2 2v12a2 2 0 0 1-2 2h12a2 2 0 0 0 2-2V7M7 4a2 2 0 0 1 2 2v1M9 11h6M9 15h6",
  flame: "M12 3c1 4 6 6 6 11a6 6 0 0 1-12 0c0-3 2-4 2-7 2 1 3 3 3 5 1-1 1-5 1-9z",
  timer: "M10 2h4M12 5a8 8 0 1 0 0 16 8 8 0 0 0 0-16zM12 9v4M19 6l1.5-1.5",
  check: "M4 12l5 5L20 6",
  edit: "M4 20h16M6 16l10-10 3 3-10 10H6v-3z",
  map: "M9 4 3 6v14l6-2 6 2 6-2V4l-6 2-6-2zM9 4v14M15 6v14",
  compare: "M8 3v18M16 3v18M3 8h5M16 16h5M3 16h5M16 8h5",
  method: "M4 6h10M4 12h16M4 18h7M17 4l3 2-3 2M14 16l3 2-3 2",
  glossary: "M5 4h11a3 3 0 0 1 3 3v13H8a3 3 0 0 1-3-3V4zM5 17a3 3 0 0 1 3-3h11",
  info: "M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18zM12 11v6M12 7.5v.5",
  search: "M11 4a7 7 0 1 0 0 14 7 7 0 0 0 0-14zM20 20l-4-4",
  menu: "M4 7h16M4 12h16M4 17h16",
  close: "M6 6l12 12M18 6 6 18",
  pin: "M15 3l6 6-4 1-4 4 1 5-2 2-4-4-5 5M9 15 4 10l2-2 5 1 4-4 1-4",
  gear: "M12 9a3 3 0 1 0 0 6 3 3 0 0 0 0-6zM19 12l2-1-1-3-2 .3-1.3-1.3L17 5l-3-1-1 2h-2L10 4 7 5l.3 2L6 8.3 4 8 3 11l2 1v0l-2 1 1 3 2-.3 1.3 1.3L7 19l3 1 1-2h2l1 2 3-1-.3-2 1.3-1.3 2 .3 1-3-2-1z",
  arrow: "M5 12h14M13 6l6 6-6 6",
  plus: "M12 5v14M5 12h14",
  download: "M12 4v12M7 11l5 5 5-5M4 20h16",
  upload: "M12 20V8M7 13l5-5 5 5M4 4h16",
  trash: "M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13",
};
function Icon({ n, size = 18, stroke = 1.6, style }) {
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={stroke}
    strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" style={{ flex: "none", ...style }}><path d={ICON_PATHS[n] || ICON_PATHS.info} /></svg>;
}

/* ── navigation: every module, grouped by what a practitioner reaches for ── */
const NAV = [
  { g: "start", label: "Start", items: [
    ["home", "Home", "your day at a glance", "home"],
    ["muallim", "al-Muʿallim", "your teacher and assistant (AI)", "spark"],
    ["alyawm", "Today", "the day's square and instruments", "sun"],
    ["journal", "Journal", "your workings, dated and timed", "pen"],
    ["grimoire", "Grimoire", "what you have kept", "gem"] ] },
  { g: "book", label: "The Book", items: [
    ["kitab", "Kitāb", "read the book, chapter by chapter", "book"],
    ["talasim", "Ṭalāsim", "talismans, seals and tables", "star"],
    ["ashkal", "Ashkāl", "every figure, enlarged from the page", "grid"],
    ["shakl", "Figure Forge", "forge any figure for a name", "hex"],
    ["haqaiq", "Ḥaqāʾiq", "the book's expositions", "para"],
    ["shart", "Sharṭ", "the conditions before any work", "scale"],
    ["sirr", "al-Sirr al-Jalīl", "the verse of 450, a whole book", "key"],
    ["durus", "Durūs", "the occult-squares course", "scroll"],
    ["index", "Index", "every record with its page", "list"] ] },
  { g: "time", label: "Time & Heavens", items: [
    ["hours", "Planetary Hours", "the 24 unequal hours, today", "clock"],
    ["majlis", "Majlis", "this hour and what it is for", "chat"],
    ["manazil", "Lunar Mansions", "the twenty-eight stations", "moon"],
    ["falak", "Falak", "the twelve signs and their natures", "orbit"] ] },
  { g: "letters", label: "Letters & Numbers", items: [
    ["huruf", "Ḥurūf", "the letters, values and elements", "letter"],
    ["bast", "Basṭ", "expansion and the nine mīzān", "expand"],
    ["asma", "Asmāʾ", "the Divine Names and their values", "names"],
    ["fawatih", "Fawātiḥ", "the disjoined letters of the sūras", "open"],
    ["sawaqit", "Sawāqiṭ", "the seven letters absent from the Fātiḥa", "letter"],
    ["shields", "Shields", "letter by letter, with running sum", "shield"] ] },
  { g: "squares", label: "Squares & Seals", items: [
    ["studio", "Ṭilasm Studio", "compose any talisman whole, for your name", "star"],
    ["forge", "Wafq Forge", "build a square for any name or number", "grid"],
    ["qawaid", "Qawāʿid", "the book's construction rules", "rules"],
    ["khatam", "Khātam", "seals and ring inscriptions", "seal"],
    ["plate", "Plate", "every verified square on one sheet", "sheet"],
    ["library", "Library", "every square and seal, searchable", "library"],
    ["qalam", "Qalam", "pen-plotter output", "plot"] ] },
  { g: "practice", label: "Practice", items: [
    ["wird", "Wird", "a counter for your litany", "beads"],
    ["works", "Works", "the licit programs, cited", "scroll"],
    ["chambers", "Bakhūr · ʿAdad", "incense, counts and states", "flame"],
    ["shurut", "Shurūṭ", "conditions of time and circumstance", "timer"] ] },
  { g: "verify", label: "Verification", items: [
    ["review", "Review", "approve or query each correction", "check"],
    ["tashihat", "Taṣḥīḥāt", "corrections to the book", "edit"],
    ["atlas", "Atlas", "planetary, transcribed, reconstructed", "map"],
    ["concordance", "Concordance", "against the sister editions", "compare"],
    ["method", "Method", "what was read, and how", "method"],
    ["glossary", "Glossary", "terms and where they live", "glossary"],
    ["book", "About", "what this is and whose work", "info"] ] },
];
const NAV_ITEM = Object.fromEntries(NAV.flatMap(s => s.items.map(([k, label, desc, icon]) => [k, { k, label, desc, icon, g: s.g, group: s.label }])));
const MOBILE_BAR = [["home", "Home", "home"], ["kitab", "Book", "book"], ["muallim", "Teacher", "spark"], ["forge", "Forge", "grid"]];
const KBD = (() => { try { return /Mac|iPhone|iPad/.test(navigator.platform || navigator.userAgent) ? "⌘K" : "Ctrl K"; } catch { return "Ctrl K"; } })();
const SHELL_PINS_DEFAULT = ["muallim", "studio", "forge", "hours"];
const TL_LESSONS = new Map([[3, "d3"], [4, "d4"], [5, "d5a"], [8, "d8"], [10, "d10"], [11, "d11"], [12, "d12"]]);
const routeOf = () => { try { const h = (window.location.hash || "").replace(/^#\/?/, "").split(/[?&]/)[0]; return NAV_ITEM[h] ? h : null; } catch { return null; } };

/* ── shared surfaces ── */
const S = {
  card: { background: "linear-gradient(180deg,#16120d,#110e0a)", border: "1px solid #ffffff12", borderRadius: 14, padding: 20,
    boxShadow: "0 1px 0 #ffffff08 inset, 0 10px 30px -18px #000" },
  label: { fontFamily: F.mono, fontSize: 10.5, letterSpacing: "0.14em", textTransform: "uppercase", color: "#ffffff66" },
  input: { background: "#0b0907", border: "1px solid #ffffff1c", color: "#ece6d8", padding: "11px 14px", fontFamily: F.body,
    fontSize: 15, outline: "none", borderRadius: 10, width: "100%" },
};
function Pill({ children, hue, onClick, active, title, icon }) {
  return <button onClick={onClick} title={title} className="ih-pill" style={{ display: "inline-flex", alignItems: "center", gap: 7,
    background: active ? hue + "26" : "#ffffff07", border: `1px solid ${active ? hue + "88" : "#ffffff17"}`, color: active ? "#f3ecdc" : "#ffffffcc",
    padding: "7px 13px", borderRadius: 999, cursor: "pointer", fontFamily: F.mono, fontSize: 11.5, letterSpacing: "0.04em" }}>
    {icon && <Icon n={icon} size={14} />}{children}</button>;
}

/* ═══ Journal ═══ */
const JOURNAL_KEY = "ihya-journal-v1";
async function loadJournal() { try { const r = await window.storage.get(JOURNAL_KEY); return r ? JSON.parse(r.value) : []; } catch { return []; } }
async function saveJournal(v) { try { await window.storage.set(JOURNAL_KEY, JSON.stringify(v)); return true; } catch { return false; } }
const JOURNAL_KINDS = [["working", "Working"], ["dhikr", "Dhikr · wird"], ["dream", "Dream · ru'yā"], ["study", "Study"], ["note", "Note"]];
const hasArabic = (s) => /[؀-ۿ]/.test(s || "");
const fmtDate = (t) => new Date(t).toLocaleDateString([], { weekday: "short", day: "numeric", month: "short", year: "numeric" });

function Journal({ hue, go, cur, hours, focus }) {
  const [list, setList] = useState(null);
  const [edit, setEdit] = useState(null);
  const [q, setQ] = useState("");
  const [kind, setKind] = useState("all");
  const fileRef = useRef(null);
  useEffect(() => { loadJournal().then(setList); }, []);
  useEffect(() => { if (focus && focus.new) setEdit(blank(focus)); }, [focus]);
  function blank(seed = {}) {
    const now = new Date(), h = hours && hours.find(x => now >= x.start && now < x.end);
    const ruler = hours && hours[0] ? hours[0].planet : null;
    return { id: "j" + now.getTime(), at: now.getTime(), kind: seed.kind || "working", title: seed.title || "", name: seed.name || "",
      intent: "", count: "", body: "", outcome: "", hourPlanet: h ? h.planet : null, dayPlanet: ruler, mansion: manzilNow(now).n, lunar: lunarDay(now).day };
  }
  const persist = (next) => { setList(next); saveJournal(next); };
  const save = () => { if (!edit) return; const ex = list.some(x => x.id === edit.id);
    persist(ex ? list.map(x => x.id === edit.id ? edit : x) : [edit, ...list]); setEdit(null); };
  const del = (id) => { if (!window.confirm("Delete this entry? This can't be undone.")) return; persist(list.filter(x => x.id !== id)); setEdit(null); };
  const exportAll = () => download(`ihya-journal-${ymd(new Date())}.json`, JSON.stringify(list, null, 1), "application/json");
  const importFile = (e) => { const f = e.target.files && e.target.files[0]; if (!f) return; const r = new FileReader();
    r.onload = () => { try { const arr = JSON.parse(r.result); if (!Array.isArray(arr)) throw 0;
      const have = new Set(list.map(x => x.id)); persist([...arr.filter(x => x && x.id && !have.has(x.id)), ...list].sort((a, b) => b.at - a.at)); }
      catch { window.alert("That file isn't a journal export."); } }; r.readAsText(f); e.target.value = ""; };
  if (!list) return <div style={{ color: "#ffffff77" }}>Opening the journal…</div>;
  const fq = fold(q.trim());
  const shown = list.filter(x => (kind === "all" || x.kind === kind) && (!fq || fold([x.title, x.name, x.intent, x.body, x.outcome].join(" ")).includes(fq)));
  const val = edit && hasArabic(edit.name) ? abjad(edit.name) : null;
  const set = (k) => (e) => setEdit({ ...edit, [k]: e.target.value });
  return <div>
    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", gap: 12, flexWrap: "wrap", marginBottom: 18 }}>
      <H2 hue={hue} sub="kept on this device · every entry stamped with its day, hour, mansion and lunar day">Journal</H2>
      <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
        <Pill hue={hue} icon="plus" active onClick={() => setEdit(blank())}>New entry</Pill>
        <Pill hue={hue} icon="download" onClick={exportAll}>Export</Pill>
        <Pill hue={hue} icon="upload" onClick={() => fileRef.current && fileRef.current.click()}>Import</Pill>
        <input ref={fileRef} type="file" accept="application/json" onChange={importFile} style={{ display: "none" }} />
      </div>
    </div>
    {edit && <div style={{ ...S.card, borderColor: hue + "55", marginBottom: 22 }}>
      <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 14 }}>
        {JOURNAL_KINDS.map(([k, l]) => <Pill key={k} hue={hue} active={edit.kind === k} onClick={() => setEdit({ ...edit, kind: k })}>{l}</Pill>)}
      </div>
      <div style={{ ...S.label, marginBottom: 12, color: hue }}>
        {fmtDate(edit.at)} · {new Date(edit.at).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
        {edit.dayPlanet && ` · day of ${edit.dayPlanet}`}{edit.hourPlanet && ` · hour of ${edit.hourPlanet}`} · mansion {edit.mansion} · lunar day {edit.lunar}</div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(min(100%,260px),1fr))", gap: 12 }}>
        <input style={S.input} placeholder="Title" value={edit.title} onChange={set("title")} autoFocus />
        <div style={{ position: "relative" }}>
          <input style={{ ...S.input, fontFamily: hasArabic(edit.name) ? F.ar : F.body, fontSize: hasArabic(edit.name) ? 20 : 15, direction: hasArabic(edit.name) ? "rtl" : "ltr", paddingLeft: 70 }}
            placeholder="Name or verse (Arabic gives its value)" value={edit.name} onChange={set("name")} />
          {val != null && <span style={{ position: "absolute", left: 12, top: "50%", transform: "translateY(-50%)", fontFamily: F.mono, color: hue, fontSize: 13 }}>{val}</span>}
        </div>
        <input style={S.input} placeholder="Intention (niyya)" value={edit.intent} onChange={set("intent")} />
        <input style={S.input} placeholder="Count · e.g. 1115 × 3" value={edit.count} onChange={set("count")} />
      </div>
      <textarea style={{ ...S.input, marginTop: 12, minHeight: 130, resize: "vertical", lineHeight: 1.6 }} placeholder="What you did — materials, incense, direction, state…" value={edit.body} onChange={set("body")} />
      <textarea style={{ ...S.input, marginTop: 12, minHeight: 70, resize: "vertical", lineHeight: 1.6 }} placeholder="Outcome and signs (add later)" value={edit.outcome} onChange={set("outcome")} />
      <div style={{ display: "flex", gap: 8, marginTop: 14, flexWrap: "wrap", alignItems: "center" }}>
        <Btn hue={hue} active onClick={save}>Save entry</Btn>
        <Btn hue={hue} onClick={() => setEdit(null)}>Cancel</Btn>
        {val != null && <Btn hue={hue} onClick={() => go("forge", { text: edit.name.trim() })}>Forge its square</Btn>}
        {list.some(x => x.id === edit.id) && <button onClick={() => del(edit.id)} style={{ marginLeft: "auto", background: "none", border: "none", color: "#e86a52aa", cursor: "pointer", display: "inline-flex", gap: 6, alignItems: "center", fontFamily: F.mono, fontSize: 11 }}><Icon n="trash" size={14} />Delete</button>}
      </div>
    </div>}
    <div style={{ display: "flex", gap: 10, flexWrap: "wrap", alignItems: "center", marginBottom: 16 }}>
      <div style={{ position: "relative", flex: "1 1 240px" }}>
        <Icon n="search" size={16} style={{ position: "absolute", left: 13, top: "50%", transform: "translateY(-50%)", color: "#ffffff55" }} />
        <input style={{ ...S.input, paddingLeft: 38 }} placeholder="Search your entries" value={q} onChange={e => setQ(e.target.value)} />
      </div>
      <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
        <Pill hue={hue} active={kind === "all"} onClick={() => setKind("all")}>All · {list.length}</Pill>
        {JOURNAL_KINDS.map(([k, l]) => { const n = list.filter(x => x.kind === k).length; return n ? <Pill key={k} hue={hue} active={kind === k} onClick={() => setKind(k)}>{l} · {n}</Pill> : null; })}
      </div>
    </div>
    {!list.length && !edit && <div style={{ ...S.card, textAlign: "center", padding: "46px 20px" }}>
      <Icon n="pen" size={30} style={{ color: hue }} />
      <div style={{ fontFamily: F.disp, fontSize: 24, marginTop: 10 }}>Your journal is empty</div>
      <div style={{ color: "#ffffff88", marginTop: 6, maxWidth: 460, marginInline: "auto", lineHeight: 1.6 }}>Record each working with its name, count and intention. The engine stamps the day, the planetary hour, the mansion and the lunar day for you.</div>
      <div style={{ marginTop: 16 }}><Btn hue={hue} active onClick={() => setEdit(blank())}>Write the first entry</Btn></div>
    </div>}
    <div style={{ display: "grid", gap: 10 }}>
      {shown.map(x => { const p = x.hourPlanet && PLANETS[x.hourPlanet];
        return <button key={x.id} onClick={() => setEdit({ ...x })} className="ih-row" style={{ ...S.card, padding: "15px 18px", textAlign: "left", cursor: "pointer", color: "inherit", display: "grid", gridTemplateColumns: "auto minmax(0,1fr) auto", gap: 14, alignItems: "center" }}>
          <div style={{ width: 38, height: 38, borderRadius: 10, display: "grid", placeItems: "center", background: (p ? p.h : hue) + "1f", color: p ? p.h : hue, fontSize: 18 }}>{p ? p.g : "✎"}</div>
          <div style={{ minWidth: 0 }}>
            <div style={{ fontSize: 16, color: "#f3ecdc", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{x.title || (JOURNAL_KINDS.find(k => k[0] === x.kind) || [, "Entry"])[1]}
              {x.name && <span style={{ fontFamily: F.ar, fontSize: 18, marginLeft: 10, color: hue }} dir="rtl">{x.name}</span>}</div>
            <div style={{ fontFamily: F.mono, fontSize: 10.5, color: "#ffffff66", marginTop: 3 }}>{fmtDate(x.at)}{x.hourPlanet ? ` · hour of ${x.hourPlanet}` : ""}{x.count ? ` · ${x.count}` : ""}{x.intent ? ` · ${x.intent}` : ""}</div>
          </div>
          <span style={{ ...S.label, fontSize: 9.5 }}>{(JOURNAL_KINDS.find(k => k[0] === x.kind) || [, ""])[1]}</span>
        </button>; })}
      {list.length > 0 && !shown.length && <div style={{ color: "#ffffff77", padding: 14 }}>No entries match.</div>}
    </div>
  </div>;
}

/* ═══ Home ═══ */
function HomeClock({ cur, hue }) {
  const [t, setT] = useState(Date.now());
  useEffect(() => { const i = setInterval(() => setT(Date.now()), 1000); return () => clearInterval(i); }, []);
  if (!cur) return null;
  const left = Math.max(0, cur.end - t), h = Math.floor(left / 3600000), m = Math.floor(left / 60000) % 60, s = Math.floor(left / 1000) % 60;
  return <span style={{ fontFamily: F.mono, fontVariantNumeric: "tabular-nums", color: hue }}>{h ? h + ":" : ""}{String(m).padStart(2, "0")}:{String(s).padStart(2, "0")}</span>;
}
function Home({ hue, go, cur, hours, loc, pins, setPins, recents, setPalette }) {
  const now = new Date();
  const H = hijri(now), M = moon(now), Z = manzilNow(now), L = lunarDay(now);
  const mz = (DATA.manazil || []).find(x => x.n === Z.n);
  const ruler = hours[0] && hours[0].planet, R = ruler && PLANETS[ruler];
  const P = cur && PLANETS[cur.planet];
  const ahead = cur ? hours.filter(h => h.start >= cur.end).slice(0, 4) : [];
  const nextOwn = ruler ? hours.find(h => h.planet === ruler && cur && h.start >= cur.end) : null;
  const [txt, setTxt] = useState("");
  const ar = hasArabic(txt), num = /^\s*\d+\s*$/.test(txt) ? +txt : null;
  const v = ar ? abjad(txt) : num, vm = ar ? abjad(txt, "maghribi") : null;
  const last = LS.get("lastRead", null);
  const lastCh = last && BOOK.chapters.find(c => c.ch === last.ch);
  const [jr, setJr] = useState([]);
  useEffect(() => { loadJournal().then(a => setJr(a.slice(0, 3))); }, []);
  const hr = now.getHours(), greet = hr < 5 ? "A blessed night" : hr < 12 ? "Ṣabāḥ al-khayr" : hr < 18 ? "As-salāmu ʿalaykum" : "Masāʾ al-khayr";
  const tile = (k) => { const it = NAV_ITEM[k]; if (!it) return null;
    return <button key={k} onClick={() => go(k)} className="ih-tile" style={{ ...S.card, padding: "14px 16px", cursor: "pointer", color: "inherit", textAlign: "left", display: "flex", gap: 12, alignItems: "center" }}>
      <span style={{ width: 36, height: 36, borderRadius: 10, display: "grid", placeItems: "center", background: hue + "1c", color: hue }}><Icon n={it.icon} size={18} /></span>
      <span style={{ minWidth: 0 }}><span style={{ display: "block", fontSize: 15.5, color: "#f3ecdc" }}>{it.label}</span>
        <span style={{ display: "block", fontSize: 12.5, color: "#ffffff77", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{it.desc}</span></span></button>; };
  return <div style={{ display: "grid", gap: 18 }}>
    {/* hero */}
    <section style={{ ...S.card, padding: "28px 28px 24px", background: `radial-gradient(900px 300px at 0% 0%, ${hue}22, transparent 60%), linear-gradient(180deg,#17130e,#100d09)`, borderColor: hue + "33" }}>
      <div style={{ display: "flex", justifyContent: "space-between", gap: 20, flexWrap: "wrap" }}>
        <div>
          <div style={{ ...S.label, color: hue }}>{now.toLocaleDateString([], { weekday: "long", day: "numeric", month: "long" })} · {H.d} {H.month} {H.y}</div>
          <h1 style={{ fontFamily: F.disp, fontWeight: 500, fontSize: "clamp(32px,5vw,48px)", margin: "8px 0 4px", lineHeight: 1.05 }}>{greet}, Al</h1>
          {R && <div style={{ color: "#ffffffaa", fontSize: 16 }}>The day of <span style={{ color: R.h }}>{R.g} {ruler[0].toUpperCase() + ruler.slice(1)}</span>{!loc && <span style={{ color: "#e8a25c", fontSize: 13 }}> · hours approximate until you set a location</span>}</div>}
        </div>
        {P && <div className="ih-hour" style={{ textAlign: "right" }}>
          <div style={S.label}>Hour {cur.i} of 24 · {cur.night ? "night" : "day"}</div>
          <div style={{ fontFamily: F.disp, fontSize: 34, color: P.h, marginTop: 4 }}>{P.g} {cur.planet[0].toUpperCase() + cur.planet.slice(1)}</div>
          <div style={{ fontSize: 13, color: "#ffffff88" }}>ends in <HomeClock cur={cur} hue={P.h} /> · {fmt(cur.end)}</div>
        </div>}
      </div>
      {ahead.length > 0 && <div style={{ display: "flex", gap: 8, marginTop: 20, flexWrap: "wrap" }}>
        {ahead.map(h => <span key={h.i} style={{ display: "inline-flex", gap: 8, alignItems: "center", padding: "6px 12px", borderRadius: 999, background: PLANETS[h.planet].h + "14", border: `1px solid ${PLANETS[h.planet].h}33`, fontFamily: F.mono, fontSize: 11.5, color: "#ffffffbb" }}>
          <span style={{ color: PLANETS[h.planet].h }}>{PLANETS[h.planet].g}</span>{fmt(h.start)} {h.planet}</span>)}
        {nextOwn && <span style={{ fontFamily: F.mono, fontSize: 11.5, color: "#ffffff77", alignSelf: "center" }}>· the day's own hour returns at {fmt(nextOwn.start)}</span>}
        <span style={{ marginLeft: "auto" }}><Pill hue={hue} icon="arrow" onClick={() => go("hours")}>All hours</Pill></span>
      </div>}
    </section>

    <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(min(100%,300px),1fr))", gap: 18 }}>
      {/* moon */}
      <section style={S.card}>
        <div style={S.label}>The Moon</div>
        <div style={{ display: "flex", gap: 16, alignItems: "center", marginTop: 12 }}>
          <svg width="64" height="64" viewBox="0 0 64 64" aria-hidden="true"><circle cx="32" cy="32" r="28" fill="#1d1a16" stroke="#ffffff22" />
            <path d={(() => { const r = 28, k = Math.cos(2 * Math.PI * M.age / SYNODIC), rx = Math.abs(k) * r, right = M.waxing;
              const outer = right ? `M32 4 A28 28 0 0 1 32 60` : `M32 4 A28 28 0 0 0 32 60`;
              const inner = `A${rx} 28 0 0 ${(right ? k <= 0 : k > 0) ? 1 : 0} 32 4`; return outer + " " + inner; })()} fill="#e9e2cf" /></svg>
          <div>
            <div style={{ fontFamily: F.disp, fontSize: 22 }}>{M.phase[0].toUpperCase() + M.phase.slice(1)}</div>
            <div style={{ fontSize: 13, color: "#ffffff88" }}>{Math.round(M.illum * 100)}% lit · lunar day {L.day}{L.manhus ? <span style={{ color: "#e86a52" }}> · manḥūs</span> : <span style={{ color: "#8fce7f" }}> · open</span>}</div>
          </div>
        </div>
        {mz && <button onClick={() => go("manazil")} className="ih-row" style={{ marginTop: 16, width: "100%", textAlign: "left", background: "#ffffff06", border: "1px solid #ffffff12", borderRadius: 10, padding: "10px 12px", color: "inherit", cursor: "pointer" }}>
          <div style={{ ...S.label, fontSize: 9.5 }}>Mansion {mz.n} of 28 · {mz.sign} · {mz.element}</div>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", marginTop: 4 }}>
            <span style={{ fontSize: 16 }}>{mz.tr}</span><span style={{ fontFamily: F.ar, fontSize: 22, color: hue }}>{mz.ar}</span></div>
          <div style={{ fontSize: 12, color: "#ffffff66" }}>next mansion in about {Math.round(Z.hoursToNext)} h</div>
        </button>}
      </section>

      {/* calculator */}
      <section style={S.card}>
        <div style={S.label}>Reckon a name</div>
        <input value={txt} onChange={e => setTxt(e.target.value)} placeholder="Type Arabic, or a number" dir={ar ? "rtl" : "ltr"}
          style={{ ...S.input, marginTop: 12, fontFamily: ar ? F.ar : F.body, fontSize: ar ? 24 : 16 }} />
        {v ? <div style={{ marginTop: 14 }}>
          <div style={{ display: "flex", gap: 18, alignItems: "baseline", flexWrap: "wrap" }}>
            <span style={{ fontFamily: F.disp, fontSize: 40, color: hue, lineHeight: 1 }}>{v}</span>
            {ar && <span style={{ fontFamily: F.mono, fontSize: 11.5, color: "#ffffff77" }}>mashriqī{vm !== v ? ` · maghribī ${vm}` : ""} · {letterCount(txt)} letters</span>}
          </div>
          {NAMES_BY_VALUE && NAMES_BY_VALUE.get && NAMES_BY_VALUE.get(v) && <div style={{ fontSize: 13, color: "#ffffff99", marginTop: 6 }}>shares its value with {[].concat(NAMES_BY_VALUE.get(v)).slice(0, 3).map(x => x.tr || x.ab || x).join(", ")}</div>}
          <div style={{ display: "flex", gap: 8, marginTop: 14, flexWrap: "wrap" }}>
            <Btn hue={hue} small active onClick={() => go("forge", ar ? { text: txt.trim() } : { value: v })}>Forge the square</Btn>
            {ar && <Btn hue={hue} small onClick={() => go("journal", { new: 1, name: txt.trim() })}>Log a working</Btn>}
          </div>
        </div> : <div style={{ fontSize: 13, color: "#ffffff66", marginTop: 12, lineHeight: 1.6 }}>Value by the mashriqī abjad, recomputed letter by letter, then straight into the Forge. Press <kbd style={{ fontFamily: F.mono, border: "1px solid #ffffff33", borderRadius: 4, padding: "0 5px" }}>{KBD}</kbd> anywhere to search everything.</div>}
      </section>

      {/* continue */}
      <section style={S.card}>
        <div style={S.label}>Continue</div>
        {lastCh ? <button onClick={() => go("kitab", { chapter: last.ch, page: last.p, view: "read" })} className="ih-row" style={{ marginTop: 12, width: "100%", textAlign: "left", background: "#ffffff06", border: "1px solid #ffffff12", borderRadius: 10, padding: "12px 14px", color: "inherit", cursor: "pointer" }}>
          <div style={{ ...S.label, fontSize: 9.5, color: hue }}>{CHNAME(lastCh.ch)} · page {last.p}</div>
          <div style={{ fontSize: 15.5, marginTop: 4, lineHeight: 1.4 }}>{lastCh.short}</div>
          <div style={{ height: 4, background: "#ffffff12", borderRadius: 2, marginTop: 10, overflow: "hidden" }}><div style={{ width: `${Math.min(100, 100 * (last.p - lastCh.from) / Math.max(1, lastCh.to - lastCh.from))}%`, height: "100%", background: hue }} /></div>
        </button> : <button onClick={() => go("kitab", { chapter: 0, view: "read", page: 1 })} className="ih-row" style={{ marginTop: 12, width: "100%", textAlign: "left", background: "#ffffff06", border: "1px solid #ffffff12", borderRadius: 10, padding: "12px 14px", color: "inherit", cursor: "pointer" }}>
          <div style={{ fontSize: 15.5 }}>Begin the book at the prologue</div></button>}
        <div style={{ ...S.label, marginTop: 18 }}>Journal</div>
        {jr.length ? jr.map(x => <button key={x.id} onClick={() => go("journal")} className="ih-row" style={{ display: "flex", justifyContent: "space-between", width: "100%", background: "none", border: "none", borderBottom: "1px solid #ffffff0d", padding: "9px 2px", color: "inherit", cursor: "pointer", textAlign: "left" }}>
          <span style={{ whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{x.title || x.name || "Entry"}</span><span style={{ fontFamily: F.mono, fontSize: 10.5, color: "#ffffff55", flex: "none", marginLeft: 8 }}>{new Date(x.at).toLocaleDateString([], { month: "short", day: "numeric" })}</span></button>)
          : <div style={{ fontSize: 13, color: "#ffffff66", marginTop: 8 }}>No entries yet.</div>}
        <div style={{ marginTop: 12 }}><Pill hue={hue} icon="plus" onClick={() => go("journal", { new: 1 })}>New entry</Pill></div>
      </section>
    </div>

    <section>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
        <div style={S.label}>Pinned instruments</div>
        <span style={{ fontSize: 12, color: "#ffffff55" }}>pin any module from its page header</span>
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(min(100%,230px),1fr))", gap: 12 }}>{pins.map(tile)}</div>
    </section>
    {recents.filter(k => !pins.includes(k) && k !== "home").length > 0 && <section>
      <div style={{ ...S.label, marginBottom: 10 }}>Recently opened</div>
      <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>{recents.filter(k => !pins.includes(k) && k !== "home").slice(0, 8).map(k => NAV_ITEM[k] &&
        <Pill key={k} hue={hue} icon={NAV_ITEM[k].icon} onClick={() => go(k)}>{NAV_ITEM[k].label}</Pill>)}</div>
    </section>}
    <section>
      <div style={{ ...S.label, marginBottom: 10 }}>Everything</div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(min(100%,250px),1fr))", gap: 12 }}>
        {NAV.filter(s => s.g !== "start").map(s => <div key={s.g} style={{ ...S.card, padding: 16 }}>
          <div style={{ fontFamily: F.disp, fontSize: 19, marginBottom: 8 }}>{s.label}</div>
          {s.items.map(([k, label, desc, icon]) => <button key={k} onClick={() => go(k)} className="ih-link" style={{ display: "flex", gap: 10, alignItems: "center", width: "100%", background: "none", border: "none", color: "#ffffffbb", padding: "6px 0", cursor: "pointer", textAlign: "left", fontSize: 14 }}>
            <Icon n={icon} size={15} style={{ color: hue + "cc" }} />{label}</button>)}
        </div>)}
      </div>
    </section>
  </div>;
}

/* ═══ Command palette ═══ */
const PALETTE_INDEX = (() => {
  const out = [];
  for (const s of NAV) for (const [k, label, desc, icon] of s.items) out.push({ type: "Module", title: label, sub: `${s.label} · ${desc}`, icon, run: (go) => go(k), hay: `${label} ${desc} ${s.label} ${k}` });
  for (const c of BOOK.chapters) out.push({ type: "Chapter", title: `${CHNAME(c.ch)} — ${c.short}`, sub: `pp.${c.from}–${c.to}`, icon: "book", run: (go) => go("kitab", { chapter: c.ch, view: "overview" }), hay: `${CHNAME(c.ch)} ${c.short} ${c.title} chapter bab ${c.ch}` });
  for (const o of BOOK.outline) out.push({ type: "Heading", title: o.t, sub: `p.${o.p} · ${CHNAME(o.ch)}`, icon: "para", run: (go) => go("kitab", { chapter: o.ch, page: o.p, view: "read" }), hay: o.t });
  for (const w of BOOK.workings) if (w.cat !== "sealed") out.push({ type: "Working", title: w.title, sub: `p.${w.p} · ${CHNAME(w.ch)} · ${w.cat}`, icon: "scroll", run: (go) => go("kitab", { chapter: w.ch, page: w.p, view: "read" }), hay: `${w.title} ${w.cat}` });
  for (const n of DATA.names) out.push({ type: "Name", title: `${n.tr}${n.en ? " — " + n.en : ""}`, sub: `${n.ab || ""}${n.mb != null ? " · " + n.mb : ""}`, ar: n.ab, icon: "names", run: (go) => go("forge", n.ab ? { text: n.ab } : { value: n.mb }), hay: `${n.tr} ${n.en || ""} ${n.ab || ""} ${n.mb || ""}` });
  for (const t of (BOOK.talismans || [])) if (t && t.id != null) out.push({ type: "Talisman", title: t.title || t.t || `Talisman ${t.id}`, sub: t.page ? `p.${t.page}` : "", icon: "star", run: (go) => go("talasim", { id: t.id }), hay: `${t.title || t.t || ""} talisman` });
  for (const x of out) x.f = fold(x.hay);
  return out;
})();
function paletteSearch(q) {
  const s = fold(q.trim()); if (!s) return [];
  const words = s.split(/\s+/).filter(Boolean), res = [];
  for (const x of PALETTE_INDEX) {
    if (!words.every(w => x.f.includes(w))) continue;
    const i = x.f.indexOf(words[0]); const tf = fold(x.title);
    let score = (tf.startsWith(s) ? 0 : tf.includes(s) ? 10 : 20) + (i < 0 ? 50 : i) / 10 + { Module: 0, Chapter: 2, Name: 3, Talisman: 5, Heading: 6, Working: 7 }[x.type];
    res.push([score, x]);
  }
  return res.sort((a, b) => a[0] - b[0]).slice(0, 40).map(r => r[1]);
}
function Palette({ open, onClose, go, hue }) {
  const [q, setQ] = useState("");
  const [sel, setSel] = useState(0);
  const inRef = useRef(null), listRef = useRef(null);
  useEffect(() => { if (open) { setQ(""); setSel(0); setTimeout(() => inRef.current && inRef.current.focus(), 10); } }, [open]);
  const items = useMemo(() => {
    const t = q.trim(), out = [];
    if (hasArabic(t)) { const v = abjad(t); out.push({ type: "Reckon", title: `Forge the square of ${t}`, sub: `mashriqī value ${v}`, icon: "grid", ar: t, run: (g) => g("forge", { text: t }) }); }
    else if (/^\d+$/.test(t)) { const n = +t;
      out.push({ type: "Number", title: `Forge a square on ${n}`, sub: `istinṭāq ${(istintaq(n) || []).join(" ")}`, icon: "grid", run: (g) => g("forge", { value: n }) });
      if (n >= 1 && n <= 2401) out.push({ type: "Page", title: `Open the book at page ${n}`, sub: CHNAME(chapterOfPage(n)), icon: "book", run: (g) => g("kitab", { chapter: chapterOfPage(n), page: n, view: "read" }) }); }
    out.push(...paletteSearch(t));
    if (t.length >= 3 && !/^\d+$/.test(t)) out.push({ type: "Full text", title: `Search the whole book for “${t}”`, sub: "every page of the translation", icon: "search", run: (g) => g("kitab", { view: "search", query: t }) });
    if (!t) return NAV.flatMap(s => s.items.map(([k, label, desc, icon]) => ({ type: s.label, title: label, sub: desc, icon, run: (g) => g(k) })));
    return out;
  }, [q]);
  useEffect(() => { setSel(0); }, [q]);
  useEffect(() => { const el = listRef.current && listRef.current.querySelector(`[data-i="${sel}"]`); el && el.scrollIntoView({ block: "nearest" }); }, [sel]);
  if (!open) return null;
  const run = (x) => { onClose(); x.run(go); };
  const onKey = (e) => {
    if (e.key === "ArrowDown") { e.preventDefault(); setSel(s => Math.min(items.length - 1, s + 1)); }
    else if (e.key === "ArrowUp") { e.preventDefault(); setSel(s => Math.max(0, s - 1)); }
    else if (e.key === "Enter" && items[sel]) { e.preventDefault(); run(items[sel]); }
    else if (e.key === "Escape") onClose();
  };
  let lastType = null;
  return <div role="dialog" aria-modal="true" aria-label="Search everything" onMouseDown={e => e.target === e.currentTarget && onClose()}
    style={{ position: "fixed", inset: 0, zIndex: 100, background: "#050403b8", backdropFilter: "blur(6px)", WebkitBackdropFilter: "blur(6px)", display: "flex", justifyContent: "center", alignItems: "flex-start", padding: "10vh 14px 14px" }} className="ih-fade">
    <div style={{ width: "min(680px,100%)", maxHeight: "76vh", display: "flex", flexDirection: "column", background: "#13100c", border: "1px solid #ffffff1f", borderRadius: 16, boxShadow: "0 30px 80px -20px #000, 0 0 0 1px #00000088", overflow: "hidden" }} className="ih-pop">
      <div style={{ display: "flex", alignItems: "center", gap: 12, padding: "14px 18px", borderBottom: "1px solid #ffffff12" }}>
        <Icon n="search" size={19} style={{ color: hue }} />
        <input ref={inRef} autoFocus value={q} onChange={e => setQ(e.target.value)} onKeyDown={onKey} placeholder="Search modules, chapters, names, workings — or type Arabic or a number"
          dir={hasArabic(q) ? "rtl" : "ltr"} style={{ flex: 1, background: "none", border: "none", outline: "none", color: "#f3ecdc", fontSize: hasArabic(q) ? 22 : 17, fontFamily: hasArabic(q) ? F.ar : F.body }} />
        <kbd onClick={onClose} style={{ fontFamily: F.mono, fontSize: 10.5, color: "#ffffff66", border: "1px solid #ffffff22", borderRadius: 5, padding: "2px 6px", cursor: "pointer" }}>esc</kbd>
      </div>
      <div ref={listRef} style={{ overflowY: "auto", padding: 8 }}>
        {items.length === 0 && <div style={{ padding: 24, color: "#ffffff66", textAlign: "center" }}>Nothing found. Try fewer letters, or search the book's full text.</div>}
        {items.map((x, i) => { const head = x.type !== lastType ? (lastType = x.type) : null;
          return <React.Fragment key={i}>
            {head && <div style={{ ...S.label, fontSize: 9.5, padding: "10px 12px 4px" }}>{head}</div>}
            <button data-i={i} onMouseMove={() => setSel(i)} onClick={() => run(x)} style={{ display: "flex", gap: 12, alignItems: "center", width: "100%", textAlign: "left", padding: "10px 12px", borderRadius: 10, border: "none", cursor: "pointer",
              background: i === sel ? hue + "22" : "transparent", color: "inherit" }}>
              <span style={{ width: 30, height: 30, borderRadius: 8, display: "grid", placeItems: "center", background: i === sel ? hue + "33" : "#ffffff0a", color: i === sel ? hue : "#ffffff99", flex: "none" }}><Icon n={x.icon} size={16} /></span>
              <span style={{ minWidth: 0, flex: 1 }}>
                <span style={{ display: "block", color: "#f3ecdc", fontSize: 14.5, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{x.title}</span>
                {x.sub && <span style={{ display: "block", color: "#ffffff66", fontSize: 12, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{x.sub}</span>}</span>
              {x.ar && <span style={{ fontFamily: F.ar, fontSize: 19, color: hue, flex: "none" }} dir="rtl">{x.ar}</span>}
              {i === sel && <Icon n="arrow" size={15} style={{ color: hue }} />}
            </button></React.Fragment>; })}
      </div>
      <div style={{ display: "flex", gap: 16, padding: "9px 18px", borderTop: "1px solid #ffffff12", fontFamily: F.mono, fontSize: 10.5, color: "#ffffff55" }}>
        <span>↑↓ move</span><span>↵ open</span><span>esc close</span><span style={{ marginLeft: "auto" }}>{PALETTE_INDEX.length.toLocaleString()} entries</span></div>
    </div>
  </div>;
}

/* ═══ settings sheet ═══ */
function Settings({ open, onClose, hue, script, setScript, loc, go }) {
  if (!open) return null;
  return <div role="dialog" aria-modal="true" aria-label="Settings" onMouseDown={e => e.target === e.currentTarget && onClose()} className="ih-fade"
    style={{ position: "fixed", inset: 0, zIndex: 90, background: "#05040399", display: "flex", justifyContent: "flex-end" }}>
    <div className="ih-slide" style={{ width: "min(380px,100%)", height: "100%", background: "#13100c", borderLeft: "1px solid #ffffff1a", padding: 24, overflowY: "auto" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <div style={{ fontFamily: F.disp, fontSize: 26 }}>Settings</div>
        <button onClick={onClose} aria-label="Close" style={{ background: "none", border: "none", color: "#ffffffaa", cursor: "pointer" }}><Icon n="close" size={20} /></button></div>
      <div style={{ ...S.label, marginTop: 24, marginBottom: 10 }}>How squares are written</div>
      <ScriptPicker hue={hue} script={script} setScript={setScript} compact />
      <div style={{ fontSize: 13, color: "#ffffff77", marginTop: 8, lineHeight: 1.5 }}>Applies to every square on screen and in downloads: Western or Indic numerals, or the abjad letters.</div>
      <div style={{ ...S.label, marginTop: 26, marginBottom: 8 }}>Location</div>
      <div style={{ fontSize: 15 }}>{loc ? (loc.name || `${loc.lat.toFixed(2)}, ${loc.lon.toFixed(2)}`) : "Not set — hours use 6 am / 6 pm"}</div>
      <div style={{ fontSize: 13, color: "#ffffff77", marginTop: 6, lineHeight: 1.5 }}>Sets true sunrise and sunset for the planetary hours, prayer times and qibla.</div>
      <div style={{ marginTop: 10 }}><Btn hue={hue} small onClick={() => { onClose(); go("majlis"); }}>Set location in Majlis</Btn></div>
      <div style={{ ...S.label, marginTop: 26, marginBottom: 8 }}>Your data</div>
      <div style={{ fontSize: 13, color: "#ffffff77", lineHeight: 1.6 }}>Journal, grimoire, wird counts, bookmarks and pins are stored in this browser only. Export the journal from its page to keep a copy.</div>
      <div style={{ ...S.label, marginTop: 26, marginBottom: 8 }}>Keyboard</div>
      <div style={{ fontFamily: F.mono, fontSize: 12, color: "#ffffffaa", lineHeight: 2 }}>⌘K / Ctrl K · search everything<br />/ · search<br />g h · home · g b · book · g f · forge</div>
      <div style={{ marginTop: 30, fontFamily: F.mono, fontSize: 10.5, color: "#ffffff44", lineHeight: 1.8 }}>v{DATA.version} · shell 3.0 · {DATA.built}</div>
    </div>
  </div>;
}

/* ═══ modules ═══ */
const TABS = [["home","Home",Home],["studio","Ṭilasm Studio",TilasmStudio],["muallim","al-Muʿallim",Khadim],["journal","Journal",Journal],["kitab","Kitāb",Kitab],["talasim","Ṭalāsim",Talismans],["ashkal","Ashkāl",Gallery],["shakl","Ashkāl Forge",ShaklForge],["review","Review",Review],["alyawm","Today",AlatToday],["qalam","Qalam · plotter",Qalam],["majlis","Majlis",Majlis],["shart","Sharṭ",Shart],["huruf","Ḥurūf",Huruf],["manazil","Manāzil",Manazil],
  ["forge","Forge",Forge],["library","Library",Library],["qawaid","Qawāʿid",Qawaid],["atlas","Atlas",Atlas],["asma","Asmāʾ",Asma],["fawatih","Fawātiḥ",Fawatih],
  ["shields","Shields",Shields],["hours","Hours",Hours],["works","Works",Works],["wird","Wird",Wird],
  ["bast","Basṭ",Bast],["falak","Falak",Falak],["sawaqit","Sawāqiṭ",Sawaqit],["khatam","Khātam",Khatam],["chambers","Bakhūr",Chambers],["shurut","Shurūṭ",Shurut],["haqaiq","Ḥaqāʾiq",Haqaiq],["tashihat","Taṣḥīḥāt",Tashihat],["method","Method",Method],["concordance","Concordance",Concordance],
  ["plate","Plate",Plate],["book","Book",Book],["sirr","al-Sirr",Sirr],["durus","Durūs",Durus],["glossary","Glossary",Glossary],["grimoire","Grimoire",Grimoire],["index","Index",Spine]];

const SHELL_CSS = (hue) => `
  @import url('https://fonts.googleapis.com/css2?family=Amiri&family=Cormorant+Garamond:wght@400;500;600&family=Spectral:wght@300;400&family=IBM+Plex+Mono:wght@400;500&display=swap');
  *{box-sizing:border-box} button,input,textarea,select{font-family:inherit} .ih-main select,.ih-main input,.ih-main textarea{max-width:100%} .ih-main label{min-width:0;max-width:100%} .ih-main img,.ih-main svg{max-width:100%} html{overflow-anchor:none;-webkit-text-size-adjust:100%} body{margin:0}
  ::selection{background:${hue}44}
  :focus-visible{outline:2px solid ${hue};outline-offset:2px}
  select,option{background:#14110c;color:#ece6d8}
  ::-webkit-scrollbar{width:10px;height:10px}::-webkit-scrollbar-thumb{background:#ffffff1a;border-radius:10px;border:2px solid transparent;background-clip:padding-box}::-webkit-scrollbar-thumb:hover{background:#ffffff33;background-clip:padding-box;border:2px solid transparent}
  .rp .rpt{opacity:.3;transition:opacity .15s}.rp:hover .rpt{opacity:1}
  .ih-nav{transition:background .15s,color .15s}.ih-nav:hover{background:#ffffff0a!important;color:#f3ecdc!important}
  .ih-tile,.ih-row,.ih-pill{transition:transform .18s ease,border-color .18s,background .18s}
  .ih-tile:hover{transform:translateY(-2px);border-color:${hue}55!important}
  .ih-row:hover{border-color:${hue}55!important;background:#ffffff0a!important}
  .ih-pill:hover{border-color:${hue}88!important}
  .ih-link:hover{color:#f3ecdc!important}
  .ih-main>*{animation:ihIn .28s ease both}
  @keyframes ihIn{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:none}}
  .kh-breathe{animation:khB 1.6s ease-in-out infinite}@keyframes khB{0%,100%{opacity:.55}50%{opacity:1}}
  .ih-fade{animation:ihFade .15s ease both}@keyframes ihFade{from{opacity:0}to{opacity:1}}
  .ih-pop{animation:ihPop .18s cubic-bezier(.2,.9,.3,1.2) both}@keyframes ihPop{from{opacity:0;transform:translateY(-8px) scale(.98)}to{opacity:1;transform:none}}
  .ih-slide{animation:ihSlide .22s ease both}@keyframes ihSlide{from{transform:translateX(30px);opacity:0}to{transform:none;opacity:1}}
  .ih-side{position:sticky;top:0;height:100vh;overflow-y:auto;scrollbar-width:thin}
  .ih-burger,.ih-bottom{display:none}
  @media (max-width:1000px){
    .ih-shell{grid-template-columns:minmax(0,1fr)!important}
    .ih-side{position:fixed;left:0;top:0;bottom:0;width:min(320px,86vw);z-index:80;transform:translateX(-105%);transition:transform .25s ease;box-shadow:20px 0 60px #000a}
    .ih-side.open{transform:none}
    .ih-burger{display:inline-flex}
    .ih-bottom{display:flex}
    .ih-main{padding-bottom:96px!important}
    .ih-hide-sm{display:none!important}
  }
  @media (max-width:700px){.ih-hour{text-align:left!important}}
  @media (max-width:760px){.kitab-grid{grid-template-columns:minmax(0,1fr)!important}.kitab-grid nav{max-height:240px!important}.ih-main{padding-left:16px!important;padding-right:16px!important}}
  @media (max-width:520px){.week-row{grid-template-columns:minmax(0,1fr)!important;gap:4px!important}}
  @media (prefers-reduced-motion: reduce){*{transition:none!important;animation:none!important}}
  @media print{.ih-side,.ih-top,.ih-bottom,footer{display:none!important}.ih-shell{display:block!important}body{background:#fff}}
`;

export default function App() {
  const [tab, setTabS] = useState(() => routeOf() || "home");
  const [script, setScriptS] = useState("western");
  useEffect(() => { (async () => { try { const r = await window.storage.get(CELL_SCRIPT_KEY);
    if (r && CELL_SCRIPTS.some(x => x[0] === r.value)) setScriptS(r.value); } catch {} })(); }, []);
  const setScript = useCallback((k) => { setScriptS(k); try { window.storage.set(CELL_SCRIPT_KEY, k); } catch {} }, []);
  CELL_SCRIPT = script;   // read by every square drawn below, on screen and in the downloads
  const [focus, setFocus] = useState(null);
  const [loc, setLoc] = useState(null);
  useEffect(() => { loadLoc().then(v => { if (v) setLoc(v); else { const z = cityFromZone(); if (z) setLoc(z); } }); }, []);
  const [kept, setKept] = useState([]);
  useEffect(() => { loadKept().then(setKept); }, []);
  const onKeep = useCallback((item) => setKept(prev => {
    const next = [...prev, { ...item, at: Date.now() }]; saveKept(next); return next; }), []);
  const [now, setNow] = useState(new Date());
  useEffect(() => { const t = setInterval(() => setNow(new Date()), 30000); return () => clearInterval(t); }, []);
  const tzNow = offsetFor(now, loc);
  const { hours, ruler } = useMemo(() => loc
    ? planetaryHoursAt(now, loc.lat, loc.lon, tzNow)
    : planetaryHours(now, "06:00", "18:00"), [now, loc, tzNow]);
  const cur = hours.find(h => now >= h.start && now < h.end);
  const hue = (cur ? PLANETS[cur.planet] : PLANETS[ruler]).h;
  const nameIndex = useMemo(() => {
    const m = new Map();
    for (const x of DATA.names) for (const v of [x.mb, x.mw, x.md]) if (v != null && !m.has(v)) m.set(v, x);
    for (const a of DATA.angels4.concat(DATA.angelsMore || []))
      if (a.kabir != null && !m.has(a.kabir)) m.set(a.kabir, { ab: a.ar, tr: a.tr, mb: a.kabir, isAngel: true });
    return m;
  }, []);
  const [pins, setPinsS] = useState(() => LS.get("pins", SHELL_PINS_DEFAULT).filter(k => NAV_ITEM[k]));
  const setPins = (v) => { setPinsS(v); LS.set("pins", v); };
  const [recents, setRecents] = useState(() => LS.get("recents", []));
  const [side, setSide] = useState(false);
  const [pal, setPal] = useState(false);
  const [settings, setSettings] = useState(false);
  const [collapsed, setCollapsed] = useState(() => LS.get("navCollapsed", {}));
  const toggleGroup = (g) => { const n = { ...collapsed, [g]: !collapsed[g] }; setCollapsed(n); LS.set("navCollapsed", n); };
  const visit = (k) => setRecents(r => { const n = [k, ...r.filter(x => x !== k)].slice(0, 12); LS.set("recents", n); return n; });
  const go = useCallback((m, o) => { if (!NAV_ITEM[m]) m = "home";
    setTabS(m); setFocus(o ? { ...o, _n: Date.now() } : null); setSide(false); visit(m);
    try { if (routeOf() !== m) window.history.pushState(null, "", "#/" + m); } catch {}
    try { window.scrollTo({ top: 0, behavior: "auto" }); } catch (e) { try { window.scrollTo(0, 0); } catch (e2) {} } }, []);
  useEffect(() => { window.__ihyaGo = (m, o) => { go(m, o); window.scrollTo && window.scrollTo(0, 0); }; }, [go]);
  useEffect(() => { const on = () => { const r = routeOf(); if (r) { setTabS(r); setFocus(null); } else setTabS("home"); };
    window.addEventListener("popstate", on); window.addEventListener("hashchange", on);
    return () => { window.removeEventListener("popstate", on); window.removeEventListener("hashchange", on); }; }, []);
  useEffect(() => { let gk = 0;
    const on = (e) => { const t = e.target, typing = t && (t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.tagName === "SELECT" || t.isContentEditable);
      if ((e.metaKey || e.ctrlKey) && (e.key === "k" || e.key === "K")) { e.preventDefault(); setPal(p => !p); return; }
      if (typing) return;
      if (e.key === "/" ) { e.preventDefault(); setPal(true); return; }
      if (e.key === "g") { gk = Date.now(); return; }
      if (Date.now() - gk < 900) { const m = { h: "home", b: "kitab", f: "forge", j: "journal", t: "alyawm", o: "hours" }[e.key]; if (m) { gk = 0; go(m); } } };
    window.addEventListener("keydown", on); return () => window.removeEventListener("keydown", on); }, [go]);
  useEffect(() => { document.title = `${NAV_ITEM[tab] ? NAV_ITEM[tab].label + " · " : ""}Iḥyāʾ Engine`; }, [tab]);
  const Body = TABS.find(t => t[0] === tab)[2];
  const it = NAV_ITEM[tab], pinned = pins.includes(tab);
  const P = cur && PLANETS[cur.planet];
  const navBtn = (k, label, desc, icon) => { const on = tab === k;
    return <button key={k} onClick={() => go(k)} className="ih-nav" title={desc} aria-current={on ? "page" : undefined}
      style={{ display: "flex", alignItems: "center", gap: 11, width: "100%", textAlign: "left", padding: "8px 11px", borderRadius: 9, border: "none", cursor: "pointer",
        background: on ? hue + "1f" : "transparent", color: on ? "#f6efdf" : "#ffffffa8", boxShadow: on ? `inset 2px 0 0 ${hue}` : "none", fontFamily: F.body, fontSize: 14.5 }}>
      <Icon n={icon} size={16} style={{ color: on ? hue : "#ffffff70" }} />
      <span style={{ flex: 1, minWidth: 0, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{label}</span>
      {pins.includes(k) && <span style={{ width: 5, height: 5, borderRadius: 9, background: hue + "aa" }} />}
    </button>; };
  return <div style={{ minHeight: "100vh", color: "#ece6d8", fontFamily: F.body,
    background: `radial-gradient(1100px 600px at 70% -10%, ${hue}12, transparent 70%), #0a0806` }}>
    <style>{SHELL_CSS(hue)}</style>
    <div className="ih-shell" style={{ display: "grid", gridTemplateColumns: "264px minmax(0,1fr)", minHeight: "100vh" }}>
      {side && <div onClick={() => setSide(false)} className="ih-fade" style={{ position: "fixed", inset: 0, background: "#000a", zIndex: 70 }} />}
      <aside className={"ih-side" + (side ? " open" : "")} style={{ background: "#0d0b08", borderRight: "1px solid #ffffff10", padding: "20px 12px 30px", display: "flex", flexDirection: "column" }} aria-label="Modules">
        <button onClick={() => go("home")} style={{ background: "none", border: "none", textAlign: "left", cursor: "pointer", color: "inherit", padding: "4px 10px 14px" }}>
          <div style={{ fontFamily: F.disp, fontSize: 28, fontWeight: 500, lineHeight: 1 }}>Iḥyāʾ <span style={{ color: hue, fontStyle: "italic" }}>Engine</span></div>
          <div style={{ fontFamily: F.mono, fontSize: 9.5, letterSpacing: "0.18em", color: "#ffffff55", marginTop: 6 }}>UṢŪL AL-ḤIKMAH</div>
        </button>
        <button onClick={() => setPal(true)} className="ih-row" style={{ display: "flex", alignItems: "center", gap: 10, margin: "0 4px 16px", padding: "9px 12px", borderRadius: 10, background: "#ffffff07", border: "1px solid #ffffff14", color: "#ffffff88", cursor: "pointer", fontSize: 14 }}>
          <Icon n="search" size={15} /><span style={{ flex: 1, textAlign: "left" }}>Search</span>
          <kbd style={{ fontFamily: F.mono, fontSize: 10, border: "1px solid #ffffff22", borderRadius: 5, padding: "1px 5px", color: "#ffffff66" }}>{KBD}</kbd></button>
        <nav style={{ display: "flex", flexDirection: "column", gap: 2 }}>
          {NAV.map(s => <div key={s.g} style={{ marginBottom: 8 }}>
            {s.g !== "start" && <button onClick={() => toggleGroup(s.g)} aria-expanded={!collapsed[s.g]} style={{ ...S.label, display: "flex", width: "100%", justifyContent: "space-between", background: "none", border: "none", cursor: "pointer", padding: "10px 11px 6px", fontSize: 9.5 }}>
              {s.label}<span style={{ transform: collapsed[s.g] ? "rotate(-90deg)" : "none", transition: "transform .15s" }}>▾</span></button>}
            {!collapsed[s.g] && s.items.map(([k, label, desc, icon]) => navBtn(k, label, desc, icon))}
          </div>)}
        </nav>
        <div style={{ marginTop: "auto", padding: "16px 11px 0", fontFamily: F.mono, fontSize: 9.5, color: "#ffffff40", lineHeight: 1.8 }}>
          {BOOK.outline.length} headings · {BOOK.workings.length} workings<br />{BOOK.figs.length} figures · v{DATA.version}</div>
      </aside>

      <div style={{ minWidth: 0, display: "flex", flexDirection: "column" }}>
        <header className="ih-top" style={{ position: "sticky", top: 0, zIndex: 50, background: "#0a0806d9", backdropFilter: "blur(12px)", WebkitBackdropFilter: "blur(12px)", borderBottom: "1px solid #ffffff0f" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 12, padding: "12px 24px", maxWidth: 1280, margin: "0 auto" }}>
            <button className="ih-burger" onClick={() => setSide(true)} aria-label="Open menu" style={{ background: "none", border: "none", color: "#ffffffcc", cursor: "pointer", padding: 4 }}><Icon n="menu" size={22} /></button>
            <div style={{ minWidth: 0, flex: 1 }}>
              <div style={{ ...S.label, fontSize: 9.5 }} className="ih-hide-sm">{it ? NAV.find(s => s.g === it.g).label : ""}</div>
              <div style={{ display: "flex", alignItems: "baseline", gap: 10, minWidth: 0 }}>
                <span style={{ fontFamily: F.disp, fontSize: 21, whiteSpace: "nowrap" }}>{it ? it.label : ""}</span>
                <span className="ih-hide-sm" style={{ fontSize: 13, color: "#ffffff66", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{it ? it.desc : ""}</span></div>
            </div>
            {P && <button onClick={() => go("hours")} title={`${cur.planet} hour until ${fmt(cur.end)} · day of ${ruler}${loc ? "" : " · approximate, no location set"}`} className="ih-pill"
              style={{ display: "inline-flex", alignItems: "center", gap: 8, background: P.h + "16", border: `1px solid ${P.h}44`, color: "#f3ecdc", padding: "6px 12px", borderRadius: 999, cursor: "pointer", fontFamily: F.mono, fontSize: 11.5 }}>
              <span style={{ color: P.h, fontSize: 15 }}>{P.g}</span><span className="ih-hide-sm">{cur.planet} · until {fmt(cur.end)}</span><span style={{ color: P.h }}><HomeClock cur={cur} hue={P.h} /></span></button>}
            {tab !== "home" && <button onClick={() => setPins(pinned ? pins.filter(x => x !== tab) : [...pins, tab])} title={pinned ? "Unpin from Home" : "Pin to Home"} aria-pressed={pinned}
              style={{ background: pinned ? hue + "22" : "none", border: `1px solid ${pinned ? hue + "77" : "#ffffff1a"}`, color: pinned ? hue : "#ffffff88", borderRadius: 999, padding: 7, cursor: "pointer", display: "inline-flex" }}><Icon n="pin" size={16} /></button>}
            <button onClick={() => setPal(true)} aria-label="Search" style={{ background: "none", border: "1px solid #ffffff1a", color: "#ffffffaa", borderRadius: 999, padding: 7, cursor: "pointer", display: "inline-flex" }}><Icon n="search" size={16} /></button>
            <button onClick={() => setSettings(true)} aria-label="Settings" style={{ background: "none", border: "1px solid #ffffff1a", color: "#ffffffaa", borderRadius: 999, padding: 7, cursor: "pointer", display: "inline-flex" }}><Icon n="gear" size={16} /></button>
          </div>
        </header>
        <main className="ih-main" key={tab} style={{ padding: "30px 24px 64px", width: "100%", maxWidth: tab === "home" ? 1180 : 1140, margin: "0 auto", flex: 1 }}>
          <Body hue={hue} script={script} setScript={setScript} nameIndex={nameIndex} hours={hours} cur={cur} go={go} focus={focus} loc={loc} setLoc={setLoc} tz={tzNow}
            items={kept} setItems={setKept} onKeep={onKeep} pins={pins} setPins={setPins} recents={recents} setPalette={setPal} />
        </main>
        <footer style={{ borderTop: "1px solid #ffffff0d", padding: "18px 24px 22px", fontFamily: F.mono, fontSize: 10.5, color: "#ffffff4d", textAlign: "center", lineHeight: 1.9 }}>
          <div>v{DATA.version} · {DATA.built} · {TABS.length} modules · {DATA.corrections.filter((c, i) => !(REVIEW_VERIFY["c" + i] && ["engine", "duplicate"].includes(REVIEW_VERIFY["c" + i].kind))).length + BOOK.figs.filter(f => f.issue).length} corrections, all re-verified</div>
          <div>whole numbers only · nothing constructed is presented as the book's · sincerity, purity, righteous intent — never toward oppression</div>
        </footer>
      </div>
    </div>

    <nav className="ih-bottom" aria-label="Quick" style={{ position: "fixed", left: 10, right: 10, bottom: 10, zIndex: 60, background: "#15110ce8", backdropFilter: "blur(14px)", WebkitBackdropFilter: "blur(14px)",
      border: "1px solid #ffffff1a", borderRadius: 18, padding: "6px 6px calc(6px + env(safe-area-inset-bottom,0px))", justifyContent: "space-around", boxShadow: "0 12px 40px #000c" }}>
      {MOBILE_BAR.map(([k, l, ic]) => <button key={k} onClick={() => go(k)} style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", gap: 3, background: tab === k ? hue + "22" : "none", border: "none", borderRadius: 12, padding: "7px 0", color: tab === k ? hue : "#ffffff99", cursor: "pointer", fontFamily: F.mono, fontSize: 10 }}>
        <Icon n={ic} size={20} />{l}</button>)}
      <button onClick={() => setPal(true)} style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", gap: 3, background: "none", border: "none", borderRadius: 12, padding: "7px 0", color: "#ffffff99", cursor: "pointer", fontFamily: F.mono, fontSize: 10 }}>
        <Icon n="search" size={20} />Search</button>
    </nav>

    <Palette open={pal} onClose={() => setPal(false)} go={go} hue={hue} />
    <Settings open={settings} onClose={() => setSettings(false)} hue={hue} script={script} setScript={setScript} loc={loc} go={go} />
  </div>;
}

"""Build the reading text of the whole book for the Kitāb reader.
Per page, in reading order: headings (by type size), paragraphs (by line gaps, joined across pages),
the book's source anchors, figures (by their position), and the Arabic — whose text layer is garbled in this
PDF — as clipped images of the printed lines, so what you read is what the page prints.
Harm-directed operations are sealed by the same default-seal rule as the workings index: the passage keeps
its first clause and page, its body and its Arabic are not carried."""
import pymupdf, re, json, os, sys, collections
from PIL import Image
import io

D = pymupdf.open("Ihya.pdf")
AR = re.compile(r"[؀-ۿݐ-ݿﭐ-﷿ﹰ-﻿]")
LAT = re.compile(r"[A-Za-zÀ-ɏḀ-ỿ]")
FIGS = json.load(open("figs_index.json"))
FIGS_BY_PAGE = collections.defaultdict(list)
for i, f in enumerate(FIGS): FIGS_BY_PAGE[f["page"]].append((i, f))
H = json.load(open("headings.json"))
CH = sorted({(h["p"], int(h["t"].split()[1])) for h in H if h["lvl"] == 1 and h["t"].startswith("Chapter ")})
def chapter_of(p):
    if p >= 2155: return 21
    c = 0
    for s, n in CH:
        if p >= s: c = n
    return c if p >= 58 else 0

def is_ar_line(t):
    a, l = len(AR.findall(t)), len(LAT.findall(t))
    return a >= 3 and a >= l

def fix_bidi(t):
    """The English gloss beside an Arabic line comes out of the PDF mirrored: 'X) … (.Y' is '(X … Y.)'."""
    m = re.match(r"^(.*?)\)\s*(.*?)\(\.(.*)$", t)
    if m and "(" not in m.group(1): return f"{m.group(1)} ({m.group(2)} {m.group(3)}.)".replace("  ", " ")
    return t

def clean(t):
    t = AR.sub("", t)
    t = re.sub(r"[‎‏‪-‮ـ]", "", t)
    t = re.sub(r"\s+", " ", t).strip()
    t = re.sub(r"\(\s+", "(", t); t = re.sub(r"\s+\)", ")", t); t = re.sub(r"(\w)\((?=\w)", r"\1 (", t)
    return t

OUTDIR = "reader"; IMG = os.path.join(OUTDIR, "ar")
os.makedirs(IMG, exist_ok=True)

def page_items(pno):
    pg = D[pno - 1]
    lines = []
    for b in pg.get_text("dict")["blocks"]:
        if b["type"] != 0: continue
        for l in b["lines"]:
            t = "".join(s["text"] for s in l["spans"])
            if not t.strip(): continue
            size = max(s["size"] for s in l["spans"])
            bold = any("Bold" in s["font"] for s in l["spans"])
            ital = all("Italic" in s["font"] for s in l["spans"] if s["text"].strip())
            lines.append({"t": t, "bb": l["bbox"], "size": size, "bold": bold, "ital": ital})
    lines.sort(key=lambda x: (round(x["bb"][1] / 4), x["bb"][0]))
    # drop the folio number
    lines = [l for l in lines if not (re.fullmatch(r"\s*\d{1,4}\s*", l["t"]) and l["bb"][1] > 700)]
    items = []
    figs = sorted(FIGS_BY_PAGE.get(pno, []), key=lambda x: x[1]["bbox"][1])
    def flush_figs(y):
        while figs and figs[0][1]["bbox"][1] < y:
            i, f = figs.pop(0); items.append({"k": "fig", "id": i})
    prev = None
    for l in lines:
        flush_figs(l["bb"][1])
        if is_ar_line(l["t"]):
            bb = l["bb"]
            if items and items[-1]["k"] == "ar" and bb[1] - items[-1]["bb"][3] < 22:
                o = items[-1]["bb"]; items[-1]["bb"] = [min(o[0], bb[0]), min(o[1], bb[1]), max(o[2], bb[2]), max(o[3], bb[3])]
            else:
                items.append({"k": "ar", "bb": list(bb)})
            gl = clean(l["t"])
            if len(LAT.findall(gl)) >= 4:  # an English gloss sharing the line
                items.append({"k": "p", "t": gl, "y": bb[1], "join": False})
            prev = None; continue
        t = clean(l["t"])
        if not t: continue
        if l["size"] >= 25:
            if items and items[-1]["k"] == "h1" and prev == "h1": items[-1]["t"] += " " + t
            else: items.append({"k": "h1", "t": t})
            prev = "h1"; continue
        if l["size"] >= 19.5 and l["bold"]:
            if items and items[-1]["k"] == "h2" and prev == "h2": items[-1]["t"] += " " + t
            else: items.append({"k": "h2", "t": t})
            prev = "h2"; continue
        if l["ital"] and re.match(r"^Manbaʿ|^Shams al-Maʿārif|^Manba", t):
            items.append({"k": "src", "t": t}); prev = None; continue
        y = l["bb"][1]
        if prev == "p" and items[-1]["k"] == "p" and y - items[-1]["y"] < 33:
            items[-1]["t"] += (" " if not items[-1]["t"].endswith("-") else "") + t; items[-1]["y"] = y
        else:
            items.append({"k": "p", "t": t, "y": y})
        prev = "p"
    flush_figs(9999)
    for it in items:
        if it["k"] == "p": it["t"] = fix_bidi(it["t"]); it.pop("y", None); it.pop("join", None)
    return items

# ── sealing: the same default-seal rule as workings.py, judged on the purpose clause of an operation ──
sys.argv = [sys.argv[0]]
WP = open("workings.py", encoding="utf-8").read()
ns = {}
exec(WP[WP.index("OTHER = re.compile"):WP.index("RISK = re.compile")], {"re": re}, ns)
OTHER, BENIGN = ns["OTHER"], ns["BENIGN"]
SEALED_W = {(w["p"], w["n"]) for w in json.load(open("workings.json")) if w["cat"] == "sealed"}
OP_START = re.compile(r"^(?:\[I+ \d+\]\s*)?(?:(\d{1,3})\.\s+|Faṣl\b|If you (?:wish|want|desire)|Whoever (?:wishes|wants|desires)|For (?:the )?(?:binding|separat|bringing|subjugat|compelling|love|sleeplessness))", re.I)
def purpose(t):
    t = re.sub(r"^(?:\[I+ \d+\]\s*)?(?:\d{1,3}\.\s+)?", "", t)
    return re.split(r"[:;.]", t, maxsplit=1)[0][:260]
OTHER_R = re.compile(r"\b(human being|hatif|hātif|irsal)\b", re.I)
BENIGN_R = re.compile(r"\b(distress|sorrow|imprison\w*|prison|treasure|pigeons?)\b", re.I)
def harmful(t):
    pc = purpose(t)
    return bool(OTHER.search(pc) or OTHER_R.search(pc)) and not (BENIGN.search(pc) or BENIGN_R.search(pc))

SEALED_FIGS = set()
REVIEW = []
EXTRA_SF = set(json.load(open("figs_sealed_extra.json"))) if os.path.exists("figs_sealed_extra.json") else set()
OPENED = set(json.load(open("seal_open.json"))) if os.path.exists("seal_open.json") else set()
def build():
    chapters = collections.defaultdict(list)
    seal = False; nimg = 0; sealed_n = 0
    for pno in range(1, len(D) + 1):
        items = page_items(pno)
        ch = chapter_of(pno)
        chapters[ch].append({"k": "pg", "p": pno})
        for it in items:
            if it["k"] in ("h1", "h2", "src"):
                seal = False
            if it["k"] == "p":
                m = OP_START.match(it["t"])
                if m:
                    n = int(m.group(1)) if m.group(1) else None
                    seal = ((pno, n) in SEALED_W) if n is not None and any(w[1] == n and abs(w[0] - pno) <= 1 for w in SEALED_W) else harmful(it["t"])
                    if seal and f"{pno}|{purpose(it['t'])[:40]}" in OPENED: seal = False
                    if seal:
                        sealed_n += 1; REVIEW.append({"p": pno, "t": it["t"][:700]})
                        chapters[ch].append({"k": "seal", "t": purpose(it["t"]), "p": pno}); continue
                if seal: continue
            if it["k"] == "ar":
                if seal: continue
                x0, y0, x1, y1 = it["bb"]
                clip = pymupdf.Rect(max(0, x0 - 3), max(0, y0 - 2), min(D[pno - 1].rect.width, x1 + 3), y1 + 3)
                pix = D[pno - 1].get_pixmap(clip=clip, dpi=150, colorspace=pymupdf.csGRAY)
                im = Image.open(io.BytesIO(pix.tobytes("png")))
                name = f"{pno:04d}_{nimg % 1000:03d}.webp"; nimg += 1
                im.save(os.path.join(IMG, name), "WEBP", quality=38, method=6)
                chapters[ch].append({"k": "ar", "src": name, "w": im.width, "h": im.height}); continue
            if it["k"] == "fig" and (seal or it["id"] in EXTRA_SF):
                it = dict(it, sealed=True); SEALED_FIGS.add(it["id"])
            if it["k"] == "p":
                L = chapters[ch]
                j = len(L) - 1
                while j >= 0 and L[j]["k"] == "pg": j -= 1
                if j >= 0 and L[j]["k"] == "p":
                    a, b = L[j]["t"], it["t"]
                    open_paren = a.endswith(")") and a.count("(") < a.count(")")
                    if open_paren or (not re.search(r"[.:!?\"”’\]\)…—]$", a) and re.match(r"^[a-zāīūḥṣḍṭẓʿ(]", b)):
                        L[j]["t"] = fix_bidi(a + (" " if not a.endswith("-") else "") + b); continue
            chapters[ch].append(it)
    for ch, items in chapters.items():
        json.dump(items, open(os.path.join(OUTDIR, f"ch{ch:02d}.json"), "w"), ensure_ascii=False, separators=(",", ":"))
    json.dump(REVIEW, open("seal_review_private.json", "w"), ensure_ascii=False, indent=0)
    SEALED_FIGS.update(json.load(open("figs_sealed_extra.json")) if os.path.exists("figs_sealed_extra.json") else [])
    json.dump(sorted(SEALED_FIGS), open(os.path.join(OUTDIR, "sealed_figs.json"), "w"))
    print("images", nimg, "sealed passages", sealed_n, "sealed figures", len(SEALED_FIGS))

if __name__ == "__main__":
    if len(os.environ.get("ONLY", "")):
        for p in map(int, os.environ["ONLY"].split(",")):
            for it in page_items(p): print(it.get("k"), (it.get("t") or str(it.get("bb") or it.get("id")))[:160])
    else:
        build()

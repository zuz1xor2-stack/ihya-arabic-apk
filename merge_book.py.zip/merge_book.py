import pymupdf, json, os, io
from PIL import Image
parts = json.load(open('edition/parts.json')); C = json.load(open('chapters.json'))
out = pymupdf.open(); starts = []
for f in parts:
    d = pymupdf.open(f.replace('.html', '.pdf')); starts.append((f, out.page_count)); out.insert_pdf(d)
nfront = pymupdf.open(parts[0].replace('.html', '.pdf')).page_count
nbook = sum(pymupdf.open(f.replace('.html', '.pdf')).page_count for f in parts if '/ch' in f)
out.set_page_labels([{"startpage": 0, "prefix": "", "style": "r", "firstpagenum": 1},
                     {"startpage": nfront, "prefix": "", "style": "D", "firstpagenum": 1},
                     {"startpage": nfront + nbook, "prefix": "Corrections ", "style": "D", "firstpagenum": 1}])
toc = [[1, "Title, contents and note", 1]]
for f, s in starts[1:]:
    if f.endswith('zz_corrections.html'): toc.append([1, "Corrections", s + 1]); continue
    ch = int(f.split('ch')[-1][:2]); c = [x for x in C if x['ch'] == ch][0]
    toc.append([1, (f"Chapter {ch}: " if 0 < ch < 21 else "") + c['short'] + f"  (p.{c['from']})", s + 1])
out.set_toc(toc)
out.set_metadata({"title": "Iḥyāʾ Uṣūl al-Ḥikmah — corrected edition", "subject": "Page for page with the original; prepared with the Iḥyāʾ Engine, 2026"})
done = set()
for p in out:
    for x in p.get_images(full=True):
        xr = x[0]
        if xr in done: continue
        done.add(xr)
        try:
            pix = pymupdf.Pixmap(out, xr)
            if pix.alpha: pix = pymupdf.Pixmap(pix, 0)
            im = Image.open(io.BytesIO(pix.tobytes('png'))).convert('L')
            if im.width > 950: im = im.resize((950, int(im.height * 950 / im.width)), Image.LANCZOS)
            b = io.BytesIO(); im.save(b, 'JPEG', quality=45, optimize=True); p.replace_image(xr, stream=b.getvalue())
        except Exception as e: pass
dst = 'edition/Ihya-corrected-full.pdf'
out.save(dst, garbage=4, deflate=True)
print(out.page_count, nfront, nbook, round(os.path.getsize(dst) / 1048576, 1), 'MiB')
